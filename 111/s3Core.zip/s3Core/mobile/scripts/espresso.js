angular.module('icbc.espresso',[])
    .factory('$es',["$rootScope","$q","$http",function($rootScope,$q,$http)
    {

        //default config
        var setting = {
            custid:"UNKNOWN",
            userservice:"usermanage",
            paymentservice:"paymentservice"
        };


        function setConfig(key,value){
            if(key === 'appid'||key === 'custid')
                setting.custid = value;
            if(key === 'userservice')
                setting.userservice = value;
            if(key === 'paymentservice')
                setting.paymentservice = value;
            else{
                setting[key] = value;
            }
        }
        function getConfig(key){
            return setting[key];
        }

        /**
         * 图片转换函数
         * @param data
         */
        function dataURLToFile(data) {
            var dataArr = data.dataUrl.split(","),name = data.name;
            var data = window.atob(dataArr[1]);
            var mime = dataArr[0].match(/:(.*?);/)[1];
            var ia = new Uint8Array(data.length)
            for(var i = 0; i< data.length; i++){
                ia[i] = data.charCodeAt(i);
            }
            var upLoadFile = new Blob([ia],{type :mime})
            var fd = new FormData();
            fd.append('file',upLoadFile,name);
            return fd;
        }
        
        function uploadFileToUrl(file,data){
             var  uploadUrl = "/"+ setting.custid +'/common/handler.php';
             var fd;
             if(typeof file == 'object' &&　file.type){
                 fd = new FormData();
                 fd.append("file",file);
             }else{
                 fd = dataURLToFile(file)
             }
            
             if(typeof data === "object"){
                for(var key in data){
                    fd.append(key,data[key]);
                }
             }
             var deferred=$q.defer();
             $http.post(uploadUrl,fd,{
                transformRequest:angular.identity,
                headers:{"Content-Type":undefined}
             }).then(function(result){
            	 var retdata = result.data;
                 if(retdata === "false"){
                     location.href="error.html";
                 }
                 if(retdata.ESPRESSO_RETURN_VERSION){
                     if(retdata.status === "001"||retdata.status === "002"||retdata.status === "003"){
                         retdata.retCode = '400';
                     }else
                         retdata = retdata.data;
                 }
                 if(retdata["status"] && retdata.status === "004"){
                     location.href="login.php";
                 }
                 deferred.resolve(retdata);
             },function(result){
            	 var retdata = result.data;
                 if(retdata === "false"){
                     location.href="error.html";
                 }
                 if(retdata.ESPRESSO_RETURN_VERSION){
                     if(retdata.status === "001"||retdata.status === "002"||retdata.status === "003"){
                         retdata.retCode = '400';
                     }else
                         retdata = retdata.data;
                 }
                 if(retdata["status"] && retdata.status === "004"){
                     location.href="login.php";
                 }
                 deferred.resolve(retdata);
             });

            return deferred.promise;
         }

        /**
         * ajax执行一个服务器端Action，该方法是同步函数版本
         * 一个Action可描述为　类名+方法名+别名(可选) 或 portalConfig中配置的数据集ID + 别名(可选)
         * id: 如 com.longkey.UserBean.test as test1 或 id1 as a 或 userBean.test as b
         * params(optional): 参数，可以是一个js对象，也可以是 var1=aa&var2=bb&... 这样的字符串
         * appid(optional): 参数，要调用的后台，不送的话就使用自己的后台
         * timeout(optional)：参数，可不送
         */
        function java(id, params, appId,timeout){
            if(!id) return;
            timeout=timeout||15000;
            params = params || {};
            appId = appId || "s3Core";
            var code = params.code ? params.code : "";
            var paramStr = '__ids=' + encodeURIComponent(id) +
            '&__params=' + encodeURIComponent(JSON.stringify(params)) +
            '&__appId=' + encodeURIComponent(appId) + '&__code=' + encodeURIComponent(code);
            var retData={};
            $.ajax({
                type: "POST",
                url: "/"+ setting.custid +'/~main/ajax.php',
                headers:{
                    "Token":$rootScope.token
                },
                async: false,
                contentType:"application/x-www-form-urlencoded; charset=UTF-8",
                data:paramStr,
                dataType: "html",
                cache:false,
                timeout:timeout,
                success: function (ajaxData) {
                    retData=JSON.parse(ajaxData);
                    if(retData.ESPRESSO_RETURN_VERSION){
                        if(retData.status === "001"||retData.status === "002"||retData.status === "003")
                            retData.retCode = '400';
                        else
                            retData = retData.data;
                    }
                    if(retData.status && retData.status === "004"){
                        location.href="login.php";
                    }
                },
                error:function (XMLHttpRequest, textStatus, errorThrown) {
                    //window.location.href = "error.html";
                }
            });
            return retData;
        }

        /**
         * 与java不同的地方时这个是异步版本
         * 一个Action可描述为　类名+方法名+别名(可选) 或 portalConfig中配置的数据集ID + 别名(可选)
         * id: 如 com.longkey.UserBean.test as test1 或 id1 as a 或 userBean.test as b
         * params(optional): 参数，可以是一个js对象，也可以是 var1=aa&var2=bb&... 这样的字符串
         * appid(optional): 参数，要调用的后台，不送的话就使用自己的后台
         * timeout,超时时间
         */
        function ajax(id, params,appId){
            if(!params)
            {
                params={};
            }
            var deferred=$q.defer();
            if(!id)
                return;
            appId = appId || "s3Core";
            var code = params.code ? params.code : "";
            var paramStr = '__ids=' + encodeURIComponent(id) +
            '&__params=' + encodeURIComponent(JSON.stringify(params)) +
            '&__appId=' + encodeURIComponent(appId) + '&__code=' + encodeURIComponent(code);
            var uri = "/"+ setting.custid +'/~main/ajax.php';
            
            $http({
                method:'POST',
                url: "/"+ setting.custid +'/~main/ajax.php',
                headers:{
                	"Content-type":"application/x-www-form-urlencoded",
                    "Token":$rootScope.token
                },
                timeout:15000,
                data:paramStr
            }).then(function (response) {
                var retdata = response.data;
                if(retdata === "false"){
                   // location.href="error.html";
                }
                if(retdata.ESPRESSO_RETURN_VERSION){
                    if(retdata.status === "001"||retdata.status === "002"||retdata.status === "003"){
                        retdata.retCode = '400';
                    }else
                        retdata = retdata.data;
                }
                if(retdata["status"] && retdata.status === "004"){
                    location.href="login.php";
                }
                deferred.resolve(retdata);
            },function (response) {
               // location.href = "error.html";
            })
            return deferred.promise;
        }

        function getCookie(name){
            var c = document.cookie;
            var arr = c.split(";");
            for (i=0;i<arr.length;i++){
                if(arr[i].indexOf(name)>=0){
                    cookie = arr[i].split("=");
                    return cookie[1];
                }
            }
            return null;
        };

        function log(text)
        {
            if(setting.debug)
            {
                console.log(text);
            }
        }

        return{
            java:java,
            ajax:ajax,
            uploadFileToUrl:uploadFileToUrl,
            setConfig:setConfig,
            getConfig:getConfig
        }
    }])
