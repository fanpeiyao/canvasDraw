var myApp = angular.module("myApp",['ui.router','ngAnimate','icbc.espresso','s3.components']);

myApp.config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
	var cache = false;
	
	 $urlRouterProvider.otherwise('/account/login');
	 
	$stateProvider
	 .state('account',{
         url:'/account',
         template:'<div ng-class="transition" ui-view></div>',
         abstract:true,
         resolve:{
        	 data1:"LoginService"
         }
     })
     .state('account.register',{
         url:'/register',
         templateUrl:'views/account/register.html',
         controller:'registerCtrl'
     })
     .state('account.login',{
         url:'/login',
         templateUrl:'views/account/login.html',
         controller:'LoginCtrl'
     })
     .state('account.findPwd',{
         url:'/findPassword',
         title:'忘记密码',
         backState:"account.login",
         templateUrl:'views/account/findPassword.html',
         controller:'FindPwdCtrl'
     })
     .state('account.firstLogin',{
         url:'/firstLogin',
         title:'修改密码',
         backState:"account.login",
         templateUrl:'views/account/firstLogin.html',
         controller:'BindCtrl'
     })
}]).run(['$rootScope', '$state', '$stateParams','$es','$timeout', function($rootScope, $state, $stateParams,$es,$timeout) {
    //处理配置信息到模块
    for(var key in config){
        $es.setConfig(key,config[key]);
    }
    var skinString = "blueredgreenorange"
    var skinPath = config.basic.theme || "blue"
    if(skinString.indexOf(skinPath) == -1) skinPath = "blue";
    angular.element("#cssfile").attr("href",_resource+"CDN/theme/201801/"+skinPath+".css");
    
    var isMicroMessenger = function(){
        var ua = navigator.userAgent.toLowerCase();
        if(ua.match(/MicroMessenger/i) == "micromessenger"){
        	return true;
        }else{
        	return false;
        }
    }
    $rootScope.iswx = isMicroMessenger();
    
    $rootScope.$on("$stateChangeSuccess",  function(event, toState, toParams, fromState, fromParams) {
        // to be used for back button //won't work when page is reloaded.
        $rootScope.previousState = fromState.name;
        $rootScope.previousState = fromParams;
        $rootScope.title = toState.title;
        $rootScope.showBack = toState.backState != null;
        $rootScope.backState = toState.backState;
        $timeout(function(){
    		$rootScope.transition = "slide-right";
    	},10)
        angular.element(document).ready(function(){
            if($rootScope.iswx && toState.title)
            	document.title = toState.title;
        });
    })

}]).directive("autoHeight",['$window',function($window){
	return{
		restrict:'A',
		link:function(scope,element,attr){
			angular.element(document).ready(function(){
				 var foot = angular.element('.footer')[0];
				 var height  = $window.innerHeight;
				 element.css({"min-height":height,"max-height":height,"overflow":"scroll"});
			})
		}
	}
}])