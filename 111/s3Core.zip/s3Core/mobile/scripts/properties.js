
var properties = {
		's3Core':{
			'common':{
				'company':'分公司',
				'customerName':'经销商'
			}
		},
		'zhongdian':{
			'common':{
				'company':'事业部',
				'customerName': '经销商'
			}
		}
}