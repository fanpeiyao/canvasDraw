/**
 * Created by chent on 2017/2/10.
 *
 * PART I non-logic directives
 */
angular.module("myApp")
.directive("fnAlert",function(){
	//警告框
	return {
		restrict:'E',
		replace:true,
		transclude:true,
		templateUrl:"templates/alert.tpl.html?v="+version||""
	}
})
.directive('fnConfirm',function(){
	//确认框
	return{
		restrict:'E',
		replace:true,
		templateUrl:"templates/comfirm.tpl.html?v="+version||""
	}
})
.directive('fnAction',function () {
	//底部拉出框
    return {
        restrict:'EA',
        transclude:true,
        replace:true,
        scope:{
        	actionId:'@'
        },
        templateUrl:"templates/fnaction.tpl.html?v="+version||"",
        link:function(scope,element,attrs){
        	element.attr("id",scope.actionId);
        }
    }
})
.directive('fnPopup',["$window",function ($window) {
	//弹出页
    return {
        restrict:'EA',
        transclude:true,
        replace:true,
        templateUrl:"templates/popup.tpl.html?v="+version||"",
        link:function(scope,element,attrs){
	        scope.poptitle = attrs.popupTitle;
	        element.ready(function(){
	       		 var height  = $window.innerHeight;
	                element.css("min-height",height);
	                element.css("max-height",height);
	       	})
        }
    }
}])
.directive('fnModal',function(){
	 return {
        restrict:'E',
        transclude:true,
        replace:true,
        templateUrl:"templates/modal.tpl.html?v="+version||""
    }
})
.directive('toggleClass',function(){
	return {
		restrict:'A',
		scope:{
			toggleClass:'@'
		},
		link:function(scope,element){
			element.on('click',function(){
				element.toggleClass(scope.toggleClass);
			})
		}
	}
})
.directive('dropDown',function(){
	return {
		restrict:'EA',
		replace:true,
		transclude:true,
		scope:{
			dropTitle:'=info'
		},
		templateUrl:"templates/dropDown.tpl.html?v="+version||"",
		link:function(scope,element,attr){
			element.find(".fn-dropdown-content").on('click',function(){
				element.dropdown('toggle');
			})
			angular.element(document).ready(function(){
                $.each(FNUI.DOMWatchers, function(i, watcher) {
                    watcher(document);
                });
            });
		}
	}
})
.directive('listActive',function(){
	return {
		restrict:'A',
		scope:{
			listActive:'@'
		},
		link:function(scope,element){
			element.ready(function(){
				element.children().first().addClass('fn-active');
				element.children().first().children().addClass('skin-color skin-back-ligther');				
				element.children().on('click',function(){
					element.find('.'+scope.listActive).children().removeClass('skin-color skin-back-ligther');
					element.find('.'+scope.listActive).removeClass(scope.listActive);
					angular.element(this).addClass(scope.listActive);
					angular.element(this).children().addClass('skin-color skin-back-ligther');
				})
	       	})
			
		}
	}
})
.directive("iscrollWrapper",["$window",function($window){
    return{
        restrict:'E',
        transclude:true,
        templateUrl:'templates/iscroll.tpl.html',
        link:function(scope,element,attr){
            var myScroll;
            function createScroll(){
            	var ele = angular.element;
                var pullUp = ele('#pullUp'),
                	pullUpLabel = pullUp.find(".pullUpLabel"),
                	pullUpIcon = pullUp.find(".pullUpIcon"),
                	
                    pullDown = ele("#pullDown"),
                    pullDownLabel = pullDown.find(".pullDownLabel"),
                    pullDownIcon = pullDown.find(".pullDownIcon"),
                    scroller = ele("#scroller")
                    loadingStep = 0,
                    textFlag = 0;
                pullDown.hide();
                pullUp.hide();

                //init
                var wrapper = document.getElementById('iscroll-wrapper');
                if(wrapper)
                    myScroll = new IScroll(wrapper,{probeType: 2,click:true});

                //高度处理
                var head = ele('.header')[0];
                var foot = ele('.footer')[0];
                var headwrapper = ele('.wrapper-head')[0]
                var height  = $window.innerHeight - (head == undefined ? 0 :head.clientHeight) - (foot == undefined ? 0 : foot.clientHeight) -headwrapper.clientHeight;
                ele(wrapper).css("min-height",height);
                
                function setCenter(jqobj){
                	var parent = jqobj.parent();
                	var width = parent.width();
                	var half = width/2;
                	var selfhalf = jqobj.width()/2;
                	jqobj.css("margin-left",half-selfhalf)
                }
                function getAdv(){
                	var adv = ["深度对接，实时同步","移动下单，方便快捷","信息咨询，一目了然"]
                	var index = Math.round(Math.random()*3);
                	return adv[index];
                }
                //滚动时
                myScroll.on('scroll', function(){
                	if(textFlag == 0){
                        pullDownLabel.html(getAdv());
                        textFlag = 1;
                	}
                    if(loadingStep == 0 && !pullDown.attr('class').match('flip|loading')
                        && !pullUp.attr('class').match('flip|loading')){
                    	if(this.y < 20 && this.y>0){
                            pullDown.hide();
                        }
                        else if(this.y <40 && this.y>20){
                        	//显示字
                            pullDown.show();
                            setCenter(pullDownLabel);
                        }else if (this.y > 40) {
                            //下拉刷新效果
                            pullDown.show();
                            setCenter(pullDownLabel);
                            myScroll.refresh();
                            pullDown.addClass('flip');
                            loadingStep = 1;
                        }else if(this.y > (this.maxScrollY -35) && this.y < this.maxScrollY){
                            pullUp.hide();
                        }else if (this.y < (this.maxScrollY - 35)) {
                            //上拉刷新效果
                            pullUp.show();
                            setCenter(pullUpLabel);
                            setCenter(pullUpIcon);
                            myScroll.refresh();
                            pullUp.addClass('loading');
                            loadingStep = 1;
                        }
                    }
                });
                //滚动完毕
                myScroll.on('scrollEnd',function(){
                	textFlag = 0;
                    if(loadingStep == 1){
                        if (pullUp.attr('class').match('flip|loading')) {
                            pullUp.removeClass('flip').addClass('loading');
                            pullUpAction();
                        }else if(pullDown.attr('class').match('flip|loading')){
                            pullDown.addClass('loading');
                            pullDownAction();
                        }
                    }else{
                        pullDown.slideUp();
                        pullUp.hide();
                    }
                });
                //下拉刷新
                function pullDownAction () {
                		//pullDown.click();
                        setTimeout(function(){
                            pullDown.slideUp('slow');
                            pullDown.attr('class', '')
                            ele(scroller).css("min-height",ele(wrapper).height()+1);
                            loadingStep = 0;	
                        },500)
                }
                // 上拉加载
                function pullUpAction () {
                        pullUp.click();
                        setTimeout(function(){
                            pullUp.hide('slow');
                            pullUp.attr('class','')
                            ele(scroller).css("min-height",ele(wrapper).height()+1);
                            loadingStep = 0;
                        },500)
                }
                wrapper.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);

                return myScroll;
            }

            angular.element(document).ready(function(){
                if(!myScroll){
                    var myScroll = createScroll();
                    scope.myScroll = myScroll;
                }
            });
        }
    }
}])
.directive('addressSelector',function(){
	 return {
         restrict:'E',
         replace:true,
         templateUrl:"templates/address.tpl.html?v="+version||"",
         link:function(scope,element,attr){
        	 scope.addressInfo = {
        			 provinceCode:"000100010001",
        			 provinceName:"北京市",
        	         cityCode:"0001000100010001",
                     cityName:"北京市 ",
        	         districtCode:"00010001000100010001",
        	         districtName:"东城区",
        	         address:"北京市 北京市 东城区"
        	 }
             scope.selectAddress =  function () {
                 var oneLevelId = scope.addressInfo.provinceCode;
                 var twoLevelId = scope.addressInfo.cityCode;
                 var threeLevelId = scope.addressInfo.districtCode;
                 new IosSelect(3,
                     [iosProvinces, iosCitys, iosCountys],
                     {
                         title: '地址选择',
                         itemHeight: 35,//每一项的高度，可选，默认 35px
                         relation: [1, 1, 0, 0],
                         oneLevelId: oneLevelId,//第一级选中id 可选
                         twoLevelId: twoLevelId,//第二级选中id 可选
                         threeLevelId: threeLevelId,//第三级选中id 可选
                         callback: function (selectOneObj, selectTwoObj, selectThreeObj) {
                        	 scope.addressInfo.provinceCode = selectOneObj.id;
                        	 scope.addressInfo.provinceName = selectOneObj.value;
                        	 
                        	 scope.addressInfo.cityCode = selectTwoObj.id;
                        	 scope.addressInfo.cityName = selectTwoObj.value;
                        	 
                        	 scope.addressInfo.districtCode = selectThreeObj.id;
                        	 scope.addressInfo.districtName = selectThreeObj.value;
                        	 scope.addressInfo.address = selectOneObj.value + ' ' + selectTwoObj.value + ' ' + selectThreeObj.value;
                        	 scope.$digest();
                         }
                     });
             }
         }
     }
})
.directive('searchBar',function(){
    return {
        restrict:'E',
        replace:true,
        transclude:true,
        templateUrl:"templates/searchbar.tpl.html?v="+version||"",
        /*controller:function($scope,$istore){
        	$scope.closeSearch = function(){
        		$scope.showSearchBody = false;
        	}
        	$scope.showSearch = function(){
        		$scope.showSearchBody = true;
        	}
        }*/
    }
})
.directive('figuresMiss',function(){
        return {
            restrict:'E',
            replace:true,
            transclude:true,
            templateUrl:"templates/figuresmissed.tpl.html?v="+version||""
        }
})
    .directive("fileModel",["$parse",function($parse){
        return {
            restrict:"A",
            link:function(scope,element,attrs){
                var model = $parse(attrs.fileModel);
                var modelSetter = model.assign;

                element.bind("change",function(){
                    scope.$apply(function(){
                        //获取file对象
                        modelSetter(scope,element[0].files[0]);
                        if(!scope.fileToUpload || scope.fileToUpload.type.indexOf("image") == -1){
                        	scope.showFile();
                        }else{
                        	s3.imageCompress(scope.fileToUpload,0.5,scope.showFile)
                        }
                    })
                })
            }
        }
    }])
    
/**
 *  PART II  logic directive in app
 */
myApp.directive('headBar',['$rootScope','$state','$window',"$timeout",function($rootScope,$state,$window,$timeout){
    return {
        restrict:'E',
        replace:true,
        templateUrl:'templates/headbar.tpl.html',
        link:function(scope,element,attr){
            scope.goBack = function(currentState,fromState){
            	$rootScope.transition = "slide-left";
            	
            	if(fromState.name == ""){		
            		//刷新页面，未知来源，如果绑定了返回地址，跳绑定地址，否则跳首页
            		if(typeof currentState.backState == "string"){
            			$state.go(currentState.backState);
            		}else{
            			$state.go("app");
            		}
            	}else if(fromState.name == "module.other"){
            		//子跳父
            		$window.history.go(-2);
            	}else if(currentState.name == "module.other"){
            		// 当前状态在子页面， 可能情况 子跳子  父跳子
            		var frameObj = document.getElementsByTagName('iframe');
            		$timeout(function(){
            			try{
            				frame = frameObj[0];
                			var childWindow = frame.contentWindow;
                			if(childWindow.history.length > 1){
                				childWindow.history.back()
                			} else {
                				$window.history.back();
                			}
            			}catch(e){
            				$window.history.back();
            			}
            		},100)

            	}else{
            		if(currentState.backState){
            			if(typeof currentState.backState == "string"){
                			$state.go(currentState.backState);
                		}else{
                			$window.history.back();
                		}
            		}else{
            			$state.go("app");
            		}
            	}
            }
        }
    }
}])
.directive("bottomBar",['$rootScope','$state','$permissions',function($rootScope,$state,$permissions){
    return{
        restrict:'E',
        replace:true,
        templateUrl:'templates/bottombar.tpl.html',
        link:function(scope,element,attr){
        	var start = {
                    menuName: '首页',
                    state: 'app',
                    menuIcon: 'icon-shouye-copy-copy-copy',
                    type:1
                };
            var end = {
                	menuName:'我的信息',
                    state:'profile.info',
                    menuIcon:' icon-gerenxinxi',
                    type:1
             };
            var bottomBar = [];
            var functionList = $permissions.getFunctionList();
            var entrance = {
        	        products : 'products.productList',
        	        myorder:'myorder.orderList', //代客下单
        	        cart: 'cart.cart',
        	        payment:'payment.paymentList',
			        uppayment:'uppayment.paymentList',
        	        delivery :'delivery.deliveryList',
        	        easyPay: 'easyPay.easyPayDetail',
        	        check : 'check.checkList',
        	        mstatement:'mstatement.mstatement',
        	        syncMessage:'syncMessage.sync',
        	        noticeBoardManage:'noticeBoardManage.list',
        	        userManage:'userManage.userInfoManage',
        	        customerRelation:'customerRelation.userList'
        	};
            for(var i=0;i<functionList.length&&bottomBar.length<3;i++){
            	var item = functionList[i];
            	if(item.bottom == "1"){
                    if(entrance.hasOwnProperty(item.menuUrl)){
                    	item.state = entrance[item.menuUrl];
                    	bottomBar.push(item);
                    }else{
                    	item.url = item.menuUrl;
                    	bottomBar.push(item);
                    }
            	}
            }
            bottomBar.unshift(start);
            bottomBar.push(end);
            //主题
            if(typeof Doodle != 'undefined'){
                if(Doodle.dateString().showFestival && Doodle.dateString().dateString=='springFestival'){
                    scope.showFestival = Doodle.dateString().showFestival;
            		var iconArr = Doodle.bottomBar(),
	    				a = 'iconArr'+ bottomBar.length;
            		if(bottomBar.length > 4){
            			iconArr.iconArr4.map(function(item,i){
            				bottomBar[i].menuIcon =iconArr.iconArr4[i] ;
    	    				return item;
    		 			});
            		}else{
            			bottomBar.map(function(item,i){
    		 				item.menuIcon =iconArr[a][i] ;
    	    				return item;
    		 			});
            		}
            	}
            }
            //主题结束
            scope.bottomBar = bottomBar;
            scope.bottomModule = function (name,state,url,type,bottom) {
            	if(type == "1")
            		$state.go(state);
            	else
            		$state.go("module.other",{title:name,dataUrl:url,type:type,bottomBoo:bottom});
            };
            scope.style = "width:"+(100/bottomBar.length)+"%";           
        }
    }
}])
.directive("tabBar",function(){
    return {
        restrict:'E',
        replace:true,
        transclude:true,
        template:'<ul class="fn-nav fn-nav-tabs fn-tabbar back-white"  ng-transclude></ul>',
        link:function(scope,element,attr){
            angular.element(document).ready(function() {
                var tabs = element;
                var length = tabs.children().length;
                tabs.addClass(' fn-avg-sm-'+length);
                tabs.find('.statusTab').first().addClass('fn-tab-active skin-color skin-border ');
                tabs.find('.statusTab').on('click',function(e){
                      tabs.find('.fn-tab-active').removeClass('fn-tab-active skin-color skin-border ');
                      angular.element(this).addClass('fn-tab-active skin-color skin-border ');
                });

                tabs.find('.statementTab').first().addClass('fn-tab-active skin-back');
                tabs.find('.statementTab').on('click',function(e){
                    tabs.find('.fn-tab-active').removeClass('fn-tab-active skin-back ');
                    angular.element(this).addClass('fn-tab-active skin-back');
                });
            });
        }
    }
}).directive("fnSelect",function(){
    return{
        restrict:'A',
        link:function(scope,element,attr){
            angular.element(document).ready(function(){
                element.selected({
                    btnWidth: '100%',
                    maxHeight:"100px"
                })
            })
        }
    }
}).directive("autoHeight",['$window',function($window){
	return{
		restrict:'A',
		link:function(scope,element,attr){
			angular.element(document).ready(function(){
				 var head = angular.element('.header')[0]; 
				 var foot = angular.element('.footer')[0];
				 var height  = $window.innerHeight - (head == undefined?0:head.clientHeight) - (foot == undefined?0:foot.clientHeight);
				 element.css({"min-height":height,"max-height":height,"overflow":"scroll"});
			})
		}
	}
}]).directive('changePhone',['$interval','$state','$modal','UserInfoService',function($interval,$state,$modal,UserInfoService){
        return{
            restrict:'E',
            replace:true,
            templateUrl:'templates/changePhone.tpl.html',
            link:function(scope,element,attr){
            	 scope.getCodeText = "获取验证码";
            	scope.getValidateCode = function(mobilePhone){
            		 var promise = UserInfoService.getValidateCode(mobilePhone);
            		 promise.then(function(result){
            			 if(result.retCode !== "200"){   
                             $modal.alert("获取验证码失败!")
                             scope.showTip = false;
                         }else{
                        	 scope.showTip = true;
                         }
            		 })
                     //点击之后 倒计时
            		 scope.countingDown = true;
                     var i = 60;
                     var timer = $interval(tick,1000,60);
                     function tick(){
                         i--;
                         scope.getCodeText = "请等待("+i+")s";
                     }
                     timer.then(function(){
                    	 scope.getCodeText = "获取验证码";
                    	 scope.countingDown = false;
                     })
            	}
            	scope.changePhone = function(mobilePhone,code){
            		var promise = UserInfoService.bindPhone(mobilePhone,code)
            		promise.then(function(result){
            			if(result && result.retCode == "200"){
                			$modal.alert("修改成功!",function(){
                				$state.go('profile.myAccount');
                			})
                        }else{
                        	$modal.alert(result.retMsg || "修改手机号码失败!")
                        }
            		})
            	}
            }
        }
    }])
.directive('passwordForm',['$state','$modal','UserInfoService',function($state,$modal,UserInfoService){
        return {
            restrict:'E',
            replace:true,
            templateUrl:'templates/password.tpl.html',
            link:function (scope,element,attr) {
            	scope.changePwd = function(oldPassword,newPassword,repeatPassword){
                	var promise = UserInfoService.changePassword(oldPassword,newPassword,repeatPassword);
                	promise.then(function(result){
                		  if(result.retCode === "200"){
                              event.preventDefault();
                              $modal.alert("修改密码成功！",function(){
                              	 $state.go("profile.info");
                              })
                          }else{
                              $modal.alert(result.retmsg || result.retMsg)
                          }
                	})
            	}
            }
        }
    }])
.directive("companyAction",["$modal",function($modal){
	return {
		require:'^?fnAction',
		restrict:'EA',
		transclude:true,
		templateUrl:"templates/companyAction.tpl.html?v="+version||"",
		link:function(scope,element){
			element.find('#companyBox').on('click',function(){
				$modal.action({id:'company-action',act:'open'});
			})
		}
	}
}])
.directive("addtocartAction",["$state","$timeout",'$q',"$number","$modal","UserInfoService","ProductService",
                              function($state,$timeout,$q,$number,$modal,UserInfoService,ProductService){
	return {
		require:'^?fnAction',
		restrict:'EA',
		transclude:true,
		templateUrl:"templates/addtocartAction.tpl.html?v="+version||"",
		link:function(scope,element){
			
			// 购物车Part
		    var step =1;
		    var max = 9999.999;//$number.sub(10000,step);
		    var min = 0.001;
		    
		    scope.changeNumber = function(product){
		    	if(product.count > max){
		    		$modal.alert("不能大于"+max)
		    		product.count = max;
		    	}
		    	 if(product.count <min){
			    		$modal.alert("不能小于"+min)
			    		product.count = min;
			    }
		    	if(!product.count){
		    		$modal.alert("不符合规范的数量，请输入"+min+"-"+max+"之间的数值")
		    		product.count = step;
		    	} 
		    }
		    
		    //点击减少
		    scope.reducePronum=function (product) {
		    	if($number.sub(product.count , step) < min){
		        	$modal.alert("不能小于"+min);
		        	return false;
		        }else{
		        	product.count = $number.sub(product.count,step);
		        }
		    };
		    
		    //点击增加
		    scope.addPronum=function(product){
		    	if($number.add(product.count , step)>max){
		    		$modal.alert("不能大于"+max);
		    		return false;
		    	}else{
		    		product.count = $number.add(product.count,step);
		    	}
		    };
		    
		    //加入购物车
		    scope.addToCart = function (preAddProduct) {
		    	var deffered = $q.defer();
		        var promise = deffered.promise;
		        var count = preAddProduct.count;
		    	if(!count){
		    		$modal.alert("不符合规范的数量，请输入"+step+"-"+max+"之间的数值")
		    	}else{
		    		var company = UserInfoService.getCurrentCompany();
		    		var overCount  = false;
			    	var cartListPromise =  ProductService.getCartList(company.companyId);
			    	cartListPromise.then(function(result){
			    		if(result.retCode === "200" || result.status === "000" ){
				        	var cartList = result.dataList;
					    	cartList.forEach(function(item){
					    		if(item.productId == preAddProduct.productId &&  (item.count + count)>max){
					    			overCount = true;
					    		}
					    	})
				        }
				    	if(overCount){
				    		$modal.alert("您的购物车中该产品总数已经超过"+max+'建议您先去结算或清理');
				    	}else{
				    		var addpromise = ProductService.addProductToCart(company.companyId,preAddProduct.productId,count,"mobileFlag");
				    		addpromise.then(function(result){
					    		if(result &&　result.status === "000"){
					    			$.toast.show('info',1000).clear();
					    			$modal.action({id:'cartproduct-action',act:'close'});
					    		}else{
					    			$modal.alert(result.retmsg||"加入购物车失败");
					    		}
					    		deffered.resolve(result)
				    		})
				    	}
			    	})
		    	}
		    	 return promise;
		    }
		    
		    //立即购买
		    scope.buyToCart = function (product,count) {
		    	var result = scope.addToCart(product,count);
		    	result.then(function(result){
		    		if(result.status == '000')
		    			$modal.action({id:'cartproduct-action',act:'close'});
		    			$timeout(function(){
		    				$state.go("cart.cart");
		    			},100)
		    	})
		    }
		}
	}
}])
.directive("dealerPopup",["UserInfoService",function(UserInfoService){
	return {
		require:'^?fnPopup',
		restrict:'EA',
		transclude:true,
		templateUrl:"templates/dealerPopup.tpl.html?v="+version||"",
		link:function(scope,element,attr){
			 var dealerPage = 0,key;
			 scope.arrowLeft = function(){
				  dealerPage--;
				  element.find(".fn-pagination-next").removeClass("fn-disabled")
				  loadDealers(dealerPage,key)
				  if(dealerPage == 0){
					  dealerPage = 0;
					  element.find(".fn-pagination-prev").addClass("fn-disabled")
				  }
			}
			   
			 scope.arrowRight = function(){
				  var allPage = scope.allPage;
				  dealerPage++;
				  element.find(".fn-pagination-prev").removeClass("fn-disabled")
				  loadDealers(dealerPage,key)
				  if(dealerPage >= allPage){
					  dealerPage = allPage;
					  element.find(".fn-pagination-next").addClass("fn-disabled")
				  }
			 }
			 
			 function loadDealers(dealerPage,key) {
			       var promise = UserInfoService.getDealerList(dealerPage,key);
			       if(promise.then){
			    	   promise.then(function(arys){
				       		if(arys.status === "000"){
				       			if(attr.showAll == 'all'){
					       			var all ={'customerId':undefined,'userName':$is3n("展示全部{%=common.customerName%}",config.custid)};
					    	        scope.dealerList =[all].concat(arys.dealerList);
				 	     			scope.allPage =  Math.floor(arys.total /8);
				       			}else{
				       				scope.dealerList = arys.dealerList;
				 	     			scope.allPage =  Math.floor(arys.total /8);
				       			}
				       			
				   	    	}else{
				   	    		scope.dealerList = [];
				   	    	}
				       	})
			       }
			   }
			 loadDealers();
			   //经销商搜索
			   scope.dealerSearch = function(keyValue){
			   		key = keyValue;
			   		dealerPage = 0;
			        loadDealers(dealerPage,key)
			   }
			   //点击按钮清空搜索内容
			   scope.dealerclickClean = function($event){
				   	$event.stopPropagation();
				   	dealerPage = 0;
				   	angular.element("#dealerSearch input").val('');
				   	key = undefined;
				    loadDealers(dealerPage,key)
			  }
			   
		}
	}
}])
.directive("formatDate",['$filter',function($filter){
	return {
		require:'ngModel',
		link:function(scope,element,attr,ngModelCtrl){
			ngModelCtrl.$formatters.push(function(modelValue){
				if(modelValue){
					return new Date(modelValue);
				}
			})
			ngModelCtrl.$parsers.push(function(value){
				if(value){
					return $filter('date')(value,'yyyy-MM-dd');
				}
			})
		}
	}
}])
.directive("moneyType",function(){
	return {
		restrict:"A",
		scope:{
			pointlen:'=moneyType'
		},
		link:function(scope,element,attr){
			var cursor = 0;
			var max = 8;
			scope.pointlen !=='' ? pointLen=scope.pointlen : pointLen = 2;
			function getCursor(elem){
				if(elem.selectionStart !== undefined){
					return elem.selectionStart;
				}else{
					var range = document.selection.createRange();
					range.moveStart("character",-elem.value.length);
					var len = range.text.length;
					return len;
				}
			}
			angular.element(document).ready(function(){
				element.on("click",function(event){
					cursor = getCursor(event.target)
				})
				
				element.on("focus",function(event){
					cursor = event.target.value.length;
				})

				element.on("keydown",function(event){
					if(cursor >= max && event.keyCode != 8){
						cursor = max;
						return  false;
					}else{
						if((event.keyCode < 48 || event.keyCode >57) && event.keyCode != 190  && event.keyCode != 8){
							return false;
						}
						if((event.keyCode < 48 || event.keyCode >57) && pointLen == 0 && event.keyCode != 8){
							return false;
						}
						if(event.keyCode == 8 && cursor >0)
							cursor--;
						else{
							var elem = event.target;
							var text = elem.value;
							if(event.keyCode == 190){
								if(text.indexOf(".") == -1 && text.length-cursor<=pointLen){
									cursor++;
								}else{
									return false;
								}
							}else{
								var ary = text.split(".");
								var before = ary[0];
								var after = ary.length>1?ary[1]:"";
								if(cursor<=before.length && before.length >=max){
									return false;
								}
								else if(cursor > before.length && after.length >=pointLen)
									return false;
								else
									cursor++;
							}
						}
					}
				})
				
			})
		}
	}
})