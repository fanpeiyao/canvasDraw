angular.module("myApp").controller('SyncCtrl',['$scope','$modal','sysService',
        function($scope,$modal,sysService){ 

	var promise = sysService.getSyncList();
	promise.then(function(result){
		$scope.syncList = result.inferfaceList;
	})
		
	$scope.executeSync = function(id){
		$scope.excecuting = true;
		$.toast.show('loading');
		var promise = sysService.executeSync(id);
		promise.then(function(result){
			$scope.excecuting = false;
			$.toast.close();
			if(result.retCode != "00"){
				$modal.alert(result.retMsg || "同步失败了");
			}
		},function(error){
			$scope.excecuting = false;
			$.toast.close();
		})
	}
}]).controller('UserInfoManageCtrl',['$scope','$state','$rootScope',"$timeout",'$istore','$modal','sysService',
                                     function($scope,$state,$rootScope,$timeout,$istore,$modal,sysService){
	

	
    function loadUsers() {
        var promise = sysService.getUserList($scope.page,$scope.searchVal);
        if(promise.then){
        	promise.then(function(result){
        		var users = [];
        		if(result.retCode == "200"){
        			 users = result.userList;
        		}
        		$scope.users = users;
        		refresh();
        	})	
        }
    }

    $scope.page = 1;
    $scope.searchHistory = $istore.getLocal(config.custid+"_userSearchHistory") ||[];
    loadUsers($scope.page,$scope.searchVal);
    	
    	
	
 	$scope.refreshPage = function () {
        $scope.page = 1;
        loadUsers();
    };
    
    $scope.loadMore = function () {
        $scope.page = $scope.page+1;
        var promise = sysService.getUserList($scope.page,$scope.searchVal);
        if(promise){
        	promise.then(function(result){
        		 var users = [];
        		 if(result.retCode == "200"){
        			 users = result.userList;
        		}
        		for(var i=0; i<users.length; i++){
                    $scope.users.push(users[i]);
                }
        		refresh(true);
        	})	
        }
        
    };
    
    $scope.keySearch = function(keyValue){
    	$scope.searchVal = keyValue;
    	$scope.page = 1;
        loadUsers();
        $scope.showSearchBody = false;   
        saveSearchHistory(keyValue);
    }
    $scope.clickClean = function($event){
    	$event.stopPropagation();
    	$scope.page = 1;
    	angular.element("#searchInput input").val('');
    	$scope.searchVal = "";
    	if($scope.showSearchBody == false){
    		loadUsers();
    	}
    }

    function saveSearchHistory(keyValue){
    	if(keyValue == null || keyValue =="")return;
        var hisstring = $istore.getLocal(config.custid+"_userSearchHistory") ||[];
        var dup = false;
        hisstring.forEach(function(item){
        	if(item === keyValue)
        		dup = true;
        })
        if(!dup){
        	if(hisstring.length < 10){
        		hisstring.unshift(keyValue);
            }else{
            	hisstring.pop();
            	hisstring.unshift(keyValue)
            }
            $istore.setLocal(config.custid+"_userSearchHistory",hisstring);
        }
    	
    }
    
    function refresh(flag){
    	$timeout(function(){
            var myScroll = $scope.myScroll;
            if(!flag)
              	myScroll.scrollTo(0,0);
            myScroll.refresh();
    	},501)
    }


}])
//编辑用户
.controller('editUserCtrl',['$scope','$modal','$timer','$state','$stateParams','sysService',
function($scope,$modal,$timer,$state,$stateParams,sysService){ 
	
    
	//取得传过来的参数
    var customId = $stateParams.customId;
    var promise = sysService.getUserList(0,customId);
    if(promise.then){
    	promise.then(function(result){
    		if(result.retCode == "200"){
    			$scope.user = result.userList[0];
    			var promise2  = sysService.getUserSenser($scope.user.UserEntitycustomId);
    			promise2.then(function(data){
    				var activeUser = data.customerVerifyList[0];
    				$scope.user.activeStatus = activeUser.status;	
    			})
    		}
    	})	
    }
    
    //获取角色列表
    var promise = sysService.getRoleList();
    if(promise){
    	promise.then(function(result){
        	if(result){
        		$scope.roleList = result.roles;
        		//已选择的角色
        		for(var i=0; i< $scope.roleList.length; i++){
        			for(var j=0; j< $scope.user.UserEntityroles.length; j++){
            			if($scope.roleList[i].RoleEntityid == $scope.user.UserEntityroles[j].RoleEntityid){
            				$scope.roleList[i].checked = true;
            			}
                    }
                }
        	}
    	})
    }
    
   $scope.activateUser = function(status){
	   var promise = sysService.activateUser($scope.user.UserEntityid,status);
	   promise.then(function(data){
		   if(data.retCode == "200")
    		$scope.user.activeStatus = status;	
	   })
   }
    
    
    var debounce = $timer.debounce(function(roleList,user){
        var rolee = "";
        roleList.forEach(function(item){
        	if(item.checked)
        		rolee = rolee + item.RoleEntityid + ","
        })
        if(rolee  == ""){
        		$modal.alert("至少为用户选择一个角色");
        }else{
        	var user = {};
        	user.unionId = $scope.user.UserEntityid;
        	user.customerId = $scope.user.UserEntitycustomId;
    		user.loginName = $scope.user.UserEntityloginName ;
    		user.mobile = $scope.user.UserEntitymobilephone;
    		user.userName = $scope.user.UserEntityuserName;
        	user.rolee = rolee;
        	var promise = sysService.editUserInfo(user);
    		if(promise.then){
    			promise.then(function(result){
    				if(result.retCode != "200"){
    					$modal.alert(result.retMsg);
    				}
    			})	
    		}	
    	}
	},1000);
    
    //修改角色
    $scope.changeRole=function (role) { 
    	 debounce($scope.roleList,$scope.user);
    }
    
    //demo
    $scope.fnPrompt = function(b) {
//    	var user =  $scope.user;
//    	 $scope.b = b;
//    	angular.element('#my-prompt').modal({
//			relatedTarget : this,
//			onConfirm : function(n) {
//				$scope.user[$scope.b] = n.data
//					var user = {};
//	        		user.customerId = $scope.user.UserEntitycustomId;
//					user.loginName = $scope.user.UserEntityloginName ;
//	        		user.mobile = $scope.user.UserEntitymobilephone;
//	        		user.unionId = $scope.user.UserEntityid;
//	        		user.userName = $scope.user.UserEntityuserName;
//	        		user.rolee = $scope.user.UserEntityroles[0].RoleEntityid;
//				var promise = sysService.editUserInfo(user);
//				if(promise.then){
//					promise.then(function(result){
//						if(result.retCode == "200"){
//							$modal.alert(result.retMsg);
//							angular.element('#my-prompt-input').val('')
//						}
//					})	
//				}
//			}
//		})
	}
    
    
    //重置密码
    $scope.resetPassword = function (loginName) {
    	$modal.confirm("重置密码","确定重置该密码?",function (e){
    		var promise = sysService.resetPassword(loginName);
            if(promise){
            	promise.then(function(result){
            		if(result.retCode == "200"){
            			$modal.alert("重置密码成功,该用户的密码重置为"+result.password)
            		}else{
            			$modal.alert(result.retMsg||"系统错误")
            		}
            	})	
            }
    	})
    };
   
}])
//新增用户
.controller('addUserCtrl',['$scope','$modal','$state','$stateParams','sysService',
function($scope,$modal,$state,$stateParams,sysService){ 
	//获取角色列表
    var promise = sysService.getRoleList();
    if(promise){
    	promise.then(function(result){
        	if(result){
        		$scope.rolees = result.roles;
        	}
    	})
    }
    
    
	$scope.addUser = function(loginName,password,repeatPassword,customerId,userName,mobilephone,rolee) {
		var user = {};
		user.loginName = loginName;
		user.password = password;
		user.repeatPassword = repeatPassword;
		user.customerId = customerId;
		user.userName = userName;
		user.mobile = mobilephone;
		user.rolee = rolee;
		var promise = sysService.addUser(user);
		if(promise.then){
			promise.then(function(result){
				if(result.retCode && result.retCode == "200"){
					$modal.alert("添加用户成功！",function(){
        				$state.go('userManage.userInfoManage');
        			});
				}else{
					$modal.alert(result.retMsg);
				}
			})
		}else{
			$modal.alert("系统错误!")
		}
	}
}]).controller('RelateCtrl',['$scope','$state','$rootScope',"$timeout",'$stateParams','$istore','$modal','sysService',
                             function($scope,$state,$rootScope,$timeout,$stateParams,$istore,$modal,sysService){
	$scope.page = 1;
	$scope.searchVal = "";
	$scope.searchHistory = $istore.getLocal(config.custid+"_userRelateSearchHistory") ||[];
	
    $scope.roles = [{id:"1",name:'经销商'},{id:"2", name:'业务员'}];
    $scope.activeRole =  $scope.roles[0];
    loadUsersRelate();
	
    $scope.changeStatus = function(role){
        $scope.page = 1;
        $scope.activeRole = role;
        loadUsersRelate();
    };

 	$scope.refreshPage = function () {
 		$scope.page = 1;
        loadUsersRelate();
    };
    $scope.loadMore = function () {
    	$scope.page = $scope.page+1;
        var promise = sysService.getRelateUserList($scope.activeRole.id,$scope.page,$scope.searchVal);
        if(promise){
        	promise.then(function(result){
        		var usersRelate = [];
        		if(result.retCode == "200"){
        			 usersRelate = result.userList;
        		}
        		for(var i=0; i<usersRelate.length; i++){
                    $scope.usersRelate.push(usersRelate[i]);
                }
        		refresh(true);
        	})	
        }
        
    };
    
    //输入关键字搜索
    $scope.keySearch = function(keyValue){
    	$scope.searchVal = keyValue;
    	$scope.page = 1;
        loadUsersRelate();
        $scope.showSearchBody = false;   
        saveSearchHistory(keyValue);
    }
    //点击按钮清空搜索内容
    $scope.clickClean = function($event){
    	$event.stopPropagation();
    	$scope.page = 1;
    	$scope.searchVal = "";
    	if($scope.showSearchBody == false){
    		loadUsersRelate();
    	}
    }

    function saveSearchHistory(keyValue){
    	if(keyValue == null)return;
        var hisstring = $istore.getLocal(config.custid+"_userRelateSearchHistory") ||[];
        var dup = false;
        hisstring.forEach(function(item){
        	if(item === keyValue)
        		dup = true;
        })
        $scope.searchHistory = hisstring;
        if(!dup){
        	if(hisstring.length < 10){
        		hisstring.unshift(keyValue);
            }else{
            	hisstring.pop();
            	hisstring.unshift(keyValue)
            }
            $istore.setLocal(config.custid+"_userRelateSearchHistory",hisstring);
        }
    	
    }
    
    function refresh(flag){
    	$timeout(function(){
            var myScroll = $scope.myScroll;
            if(!flag)
              	myScroll.scrollTo(0,0);
            myScroll.refresh();
    	},501)
    }
    //获取用户关系列表
    function loadUsersRelate() {
        var promise = sysService.getRelateUserList($scope.activeRole.id,$scope.page,$scope.searchVal);
        if(promise.then){
        	promise.then(function(result){
        		var usersRelate = [];
        		if(result.retCode == "200"){
        			 usersRelate = result.userList;
        		}
        		$scope.usersRelate = usersRelate;
        		refresh();
        	})	
        }
    }

}]).controller('RelateDetailCtrl',['$scope','$state','$rootScope',"$timeout","$timer",'$stateParams','$istore','$modal','sysService',
                             function($scope,$state,$rootScope,$timeout,$timer,$stateParams,$istore,$modal,sysService){


	var userId = $stateParams.userId;
	$scope.type = $stateParams.type;
	if($scope.type == '2')
		$scope.typeName = '业务员';
	else if($scope.type == '1')
		$scope.typeName ='经销商';
	else
		$scope.typeName ='未知';
	
	
	var promise = sysService.getRelateUserList($scope.type,1,"",userId);
	promise.then(function(result){
		if(result.retCode == '200'){
			$scope.user = result.userList[0];
			//if($scope.user.roleId)
			loadCompany();
		}
	})
	
	
	$scope.statusArray = [{id:"1",name:'归属分公司'},{id:"2", name:'关联经销商'} ];
    $scope.newStatus = $scope.statusArray[0];
    
	function loadCompany(){
		 var promise = sysService.getBindCompany($scope.user.UserEntityid,$scope.user.UserEntitycustomId);
		 promise.then(function(result){
		    	var companyList = [];
		    	if(result.retCode == "200")
		    		companyList = result.companies;
		    	$scope.bindCompanyList = companyList;
	    })
	    var promise2 = sysService.getUnbindCompanyList($scope.user.UserEntityid);
		 promise2.then(function(result2){
		    var bindCompany = [];
		    if(result2.retCode == "200")
		    	bindCompany = result2.companies;
		    $scope.unBindCompanyList = bindCompany;
	    })
	}
    
	//获取该用户绑定的经销商
	function loadBindDealer(){
        var promise = sysService.getChildNodeUser($scope.type,$scope.user.UserEntityid);
        if(promise.then){
        	promise.then(function(result){
        		var usersChild = [];
        		if(result.retCode == "200"){
        			usersChild = result.relation;
        		}
        		$scope.usersChild = usersChild;
        	})	
        }
	}
	
    $scope.changeStatus = function(newStatus){
    	$scope.newStatus = newStatus;
    	loadBindList()
    };
   //获取已绑定
    function loadBindList() {
        if ($scope.newStatus.id == '1'){
        	loadCompany()
        }else if ($scope.newStatus.id == '2'){
        	loadBindDealer()
        }
    }
    var throttle = $timer.throttle(function(user,flag){
        	var bindUser ={};
        	bindUser.userId = $scope.user.UserEntityid;
        	bindUser.customerId = $scope.user.UserEntitycustomId;
            var promise = sysService.bindUser(user,bindUser,flag);
            if(promise.then){
            	promise.then(function(result){
            		if(result.retCode == "200"){
            			loadBindDealer()
            		}else{
            			$modal.alert(result.retMsg)
            		}
            	})	
            }	
    	
	},1000);
    
    //点击解绑/绑定
    $scope.unbindUser=function (user,flag) { 
    	throttle(user,flag);
    }
    var throttleCompany = $timer.throttle(function(company,flag){
        var promise = sysService.bindCompany($scope.user.UserEntityid,$scope.user.UserEntitycustomId,
        		company.SaleCompanyEntityid,company.SaleCompanyEntitysalecompanyName,flag);
        if(promise.then){
        	promise.then(function(result){
        		if(result.retCode == "200"){
        			loadCompany()
        		}else{
        			$modal.alert(result.retMsg)
        		}
        	})	
        }
	},1000);
	
	//点击解绑/绑定
	$scope.bindCompany=function (company,flag) { 
		throttleCompany(company,flag);
	}
	
	
	
	//弹出绑定经销商
	$scope.dealerPage = 1;$scope.key="";
    $scope.selectDealer = function(){
        $scope.showpopup=true;
        loadUnbindList();
    }
    function loadUnbindList (){
    	var promise = sysService.getUnbindList(userId,$scope.dealerPage,$scope.key);
        if(promise.then){
        	promise.then(function(result){
        		var unbindList = [];
        		if(result.retCode == "200"){
        			unbindList = result.userList;
        			$scope.allPage =  Math.floor(result.count /8);
        		}
        		$scope.unbindList = unbindList;
        	})	
        }
    }
    $scope.closePopup = function(){
    	$scope.showpopup=false;
    	loadBindDealer()
    }
    
    $scope.key="";
	$scope.dealerSearch = function(keyValue){
    	$scope.key = keyValue;
    	$scope.dealerPage = 1;
    	loadUnbindList();  
    }
    $scope.cleanSearch = function($event){
    	$event.stopPropagation();
    	$scope.dealerPage = 1;
    	angular.element("#dealerSearch input").val('');
    	$scope.key = "";
    	loadUnbindList();
    }
    //经销商翻页
    $scope.arrowLeft = function(){
    	$scope.dealerPage--;
		loadUnbindList()
		if($scope.dealerPage == 1){
			$scope.dealerPage = 1;
		}
	}
	$scope.arrowRight = function(){
		var allPage = $scope.allPage;
		$scope.dealerPage++;
		loadUnbindList()
		if($scope.dealerPage >= $scope.allPage){
			$scope.dealerPage = $scope.allPage;
		}
	}
	
    var debounce = $timer.throttle(function(user,flag){
    	var bindUser ={},unbind = {};
    	bindUser.userId = $scope.user.UserEntityid;
    	bindUser.customerId = $scope.user.UserEntitycustomId;
    	unbind.userId = user.UserEntityid;
    	unbind.customerId = user.UserEntitycustomId;
    	//获取该用户下级
        var promise = sysService.bindUser(unbind,bindUser,flag);
        if(promise.then){
        	promise.then(function(result){
        		if(result.retCode == "200"){
        			loadUnbindList()
        		}else{
        			$modal.alert(result.retMsg)
        		}
        	})	
        }	
	
	},1000);
	
	//点击解绑/绑定
	$scope.bindUser=function (user,flag) { 
		 debounce(user,flag);
	}
	

	
    
}])
