/**
 * Created by chent on 2017/1/18.
 */

angular.module("myApp").controller("OrderListCtrl",["$scope","$timeout","$rootScope",'$istore','$modal',"OrderService","UserInfoService",
                                                    function ($scope,$timeout,$rootScope,$istore,$modal,OrderService,UserInfoService) {

	$scope.orders = [];
	//初始化
    function initPage(){
       var orderStatusArray = OrderService.getOrderStatusArray();
       $scope.orderStatusArray = orderStatusArray;

       $scope.filter={};
       $scope.page = 0;
       $scope.filter.start_date = getTime(30);
       
       if($rootScope.role.RoleEntityid != 1)
    	   $scope.oper = {'OperatorEntitycustomId':undefined,'OperatorEntityuserName':$is3n("全部{%=common.customerName%}",config.custid)};
       $scope.currentCompany = {'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)};
       
       $scope.filterConfig = [];
       if($scope.config.filter){
       		$scope.filterConfig = angular.copy($scope.config.filter);

           $scope.filterConfig.forEach(function(item){
               item.values = [item.name].concat(item.values);
               $scope.filter[item.key] = item.name;
		   })
	   }
       
       $scope.searchVal = "";
       
       
       loadData();
       getCompany();
    }

    
    //切换经销商和分公司
	$scope.selectDealer = function(){
     	var promise = UserInfoService.getDealerList(0);
     	promise.then(function(arys){
     		if(arys.status === "000"){
     			$scope.dealerList = arys.dealerList;
     			$scope.allPage =  Math.floor(arys.total /10);
	    	}else{
	    		$scope.dealerList = [];
	    	}
     	})
     	$scope.showpopup=true;
    }
	
    $scope.closePopup = function(){
    	$scope.showpopup=false;
    }
    
	$scope.changeDealer = function(dealer){
		dealer = {'OperatorEntitycustomId':dealer.customerId,
				'OperatorEntityuserName':dealer.userName,};
		$scope.oper = dealer;
    	/*根据经销商获取分公司*/
        loadData();
    	getCompany();
		$scope.dealerFlag = true;
    	$scope.showpopup=false;
    }
	
    function getCompany(){
    	if($rootScope.role.RoleEntityid != 1){
    		var promise = UserInfoService.getDealerCompanyList($scope.oper.OperatorEntitycustomId);
            promise.then(function(result){
            	var companyList = result.dataList;
            	var all ={'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)};
                $scope.companyList =[all].concat(companyList);
                $scope.currentCompany = all;
            });
    	}else{
        	var promise = UserInfoService.getCompanyList();
            promise.then(function(companyList){
            	 var allcomp = [{'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)}];
            	 $scope.companyList = allcomp.concat(companyList);
            });
    	}
    }

  //切换分公司
    $scope.changeCompany = function(company){
        $scope.currentCompany = company;
        loadData();
        $modal.action({id:'company-action',act:'close'});
    };
    
    
    
    
    
    function getTime(number){
        var now = new Date();
        var date;
        if(number>180){
     	   date = new Date(number);
        }else{
     	   date = new Date(now.getTime()-number*24*3600*1000);
        }
        var year = date.getFullYear()
        var month = date.getMonth()+1;
        if(month > 12) month = 1;
        var day = date.getDate();
        if(month < 10)
            month = "0"+month;
        if(day < 10)
            day = "0"+day;
        return year +'-'+month+'-'+day
    }
    
    
   //筛选/过滤器
   $scope.clearnFilter = function(){
       $scope.filter = {};
       $scope.filterConfig.forEach(function(item){
           $scope.filter[item.key] = item.name;
       });
       loadData();
   };

   $scope.changeFilter=function(){
       loadData();
   };

   $scope.changeTime = function(newTime){
       $scope.showDropdown = false;
       $scope.filter.start_date = getTime(newTime);
       $scope.changeFilter();
   };

    $scope.changeTimeauto = function(start,end){
    	$modal.action({id:'changetime-action',act:'open'});
    };

    $scope.searchTimeauto = function(start,end){
    	var startDate = new Date(start);
    	var endDate = new Date(end);
    	if(startDate.valueOf() >endDate.valueOf()){
    		$modal.alert("起始日期不能大于结束日期")
    	}else{
    		startDate = getTime(startDate.valueOf()) === 'NaN-NaN-NaN' ? undefined:getTime(startDate.valueOf());
    		$scope.filter.start_date =startDate;
            $scope.filter.end_date =  getTime(endDate.valueOf());
            $scope.changeFilter();
    	}
    	$modal.action({id:'changetime-action',act:'close'});
    };
    
    
    
    
    //输入关键字搜索
    $scope.closeSearch = function(){
		$scope.showSearchBody = false;
	}
	$scope.showSearch = function(){
		$scope.searchHistory = $istore.getLocal(config.custid+"_orderSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];        	       
		$scope.showSearchBody = true;
	}
    $scope.keySearch = function(keyValue){
    	$scope.searchVal = keyValue;
    	
        loadData();
        var myScroll = $scope.myScroll;
        $scope.showSearchBody = false;   
        saveSearchHistory(keyValue);
    };
    //点击按钮清空搜索内容
    $scope.clickClean = function($event){
    	$event.stopPropagation();
    	$scope.searchVal = "";
    	if(!$scope.showSearchBody){
    		loadData();
    	}
    };
    function saveSearchHistory(keyValue){
    	if(keyValue === null ||　keyValue === "")return;
        var hisstring = $istore.getLocal(config.custid+"_orderSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];
        var dup = false;
        hisstring.forEach(function(item){
        	if(item === keyValue)
        		dup = true;
        })
        if(!dup){
        	if(hisstring.length < 10){
        		hisstring.unshift(keyValue);
            }else{
            	hisstring.pop();
            	hisstring.unshift(keyValue)
            }
            $istore.setLocal(config.custid+"_orderSearchHistory_"+$rootScope.currentUser.UserEntitycustomId,hisstring);
        }
    	
    }
    
    
    

    $scope.loadMore = function () {
        $scope.page = $scope.page+1;
        
        var filter = angular.copy($scope.filter);
        for(var key in filter){
            $scope.filterConfig.forEach(function(item){
                if(key === item.key  && filter[key] === item.name){
                    filter[key] = undefined;
                }
            })
        }
        
        var promise;
        if($rootScope.role.RoleEntityid != 1)
        	promise = OrderService.getOrderList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.oper.OperatorEntitycustomId);
        else
        	promise = OrderService.getOrderList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId);
        
        if(promise){
        	promise.then(function(result){
        		var orderList = [];
        		if(result.status == "000"){
        			orderList =  result.orderList;
        		}
        		var orders = processData(orderList);
                for(var i=0;i<orders.length; i++){
                   $scope.orders.push(orders[i]);
                }
            	refresh();
        	})
        }
    };
    
    function loadData() {
    	$scope.page = 0;
    	
    	var filter = angular.copy($scope.filter);
    	for(var key in filter){
    		$scope.filterConfig.forEach(function(item){
    			if(key === item.key  && filter[key] === item.name){
    				filter[key] = undefined;
				}
			})
		}
    	
        var promise;
        if($rootScope.role.RoleEntityid != 1)
        	promise = OrderService.getOrderList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.oper.OperatorEntitycustomId);
        else
        	promise = OrderService.getOrderList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId);
        if(promise){
        	promise.then(function(result){
        		var orderList = [];
        		if(result.status == "000"){
        			orderList =  result.orderList;
        		}
                $scope.orders =	processData(orderList);
            	refresh();
        	})
        }
    }
    
    
    function processData(orders){
        orders.forEach(function(order){
        	$scope.orderStatusArray.forEach(function(item){
        		if(order.orderStatus === item.id)
        			order.statusName = item.name;
        	})
        	for (var key in order){
				if(key == "paymentMethod"){
          		   switch(order[key]){
		          			case 0:
		          				order[key] = "汇款";
		          					break;
		          			case 1:
		          				order[key] = "票据";
		          					break;
		          			case 2:
		          				order[key] = "信用证";
		          					break;
		          			case 3:
		          				order[key] = "其他";
	          			}
          	   }
          	   if(key == "shippingMethod"){
          		   	switch(order[key]){
		          			case "0":
		          				order[key] = "自提";
		          					break;
		          			case "1":
		          				order[key] = "配送";
		          					break;
	          			}
          	   }
          	   //处理总价 type-2
          	   if(key == "orderAmount"){
          		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
          	   }
          	   //处理产品总金额(productSum) type-3
          	   if(key == "productSum"){
          		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
          	   }
          	   //处理运费(shipFee) type-3
          	   if(key == "shipFee"){
          		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
          	   }
          	   //处理最小金额(minAmount) type-3
          	   if(key == "minAmount"){
          		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
          	   }
          	   //处理实付金额(payAmount) type-3
          	   if(key == "payAmount"){
          		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
          	   }
			}
        });
		return orders;
    }
    function refresh(flag){
    	$timeout(function(){
            var myScroll = $scope.myScroll;
            if($scope.page == 0)
            	myScroll.scrollTo(0,0);
            myScroll.refresh();
    	},501)
    }
    
    initPage();
}]);


myApp.controller("OrderDetailCtrl",["$rootScope","$scope",'$state','$stateParams','$modal','OrderService','UserInfoService',
                                    function ($rootScope,$scope,$state,$stateParams,$modal,OrderService,UserInfoService) {
    //取得传过来的参数
    var orderId = $stateParams.orderId;
    var promise= OrderService.getOrderDetail(orderId);
    if(promise){
    	promise.then(function(result){
    		if(result.status === "000"){
    			var orderDetail = result;
    			var order = orderDetail.orderDetail;
    			for(var key in order){
            		if(key == "paymentMethod"){
            			switch(order[key]){
            			case 0:
            				order[key] = "汇款";
            					break;
            			case 1:
            				order[key] = "票据";
            					break;
            			case 2:
            				order[key] = "信用证";
            					break;
            			case 3:
            				order[key] = "其他";
            			}
            		}
            		if(key == "shippingMethod"){
            			switch(order[key]){
            			case "0":
            				order[key] = "自提";
            					break;
            			case "1":
            				order[key] = "配送";
            					break;
            			}
            		}
            		//处理总价 type-2
            		if(key == "orderAmount"){
            			order[key] = (Number(order[key]).moneyFormat(typeArray[2])).money();
            		}
            		//处理产品总金额(productSum) type-3
               	   if(key == "productSum"){
              		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
               	   }
               	   //处理运费(shipFee) type-3
               	   if(key == "shipFee"){
              		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
               	   }
               	   //处理最小金额(minAmount) type-3
               	   if(key == "minAmount"){
              		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
               	   }
               	   //处理实付金额(payAmount) type-3
               	   if(key == "payAmount"){
              		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
               	   }
               	   //处理手续费(handingFee) type-3
               	   if(key == "handingFee"){
              		   order[key] != null && order[key] != undefined ? order[key] = (Number(order[key]).moneyFormat(typeArray[3])).money() : order[key]='' ;
               	   }
    			}
    	        var orderStatusArray = OrderService.getOrderStatusArray();
    	        orderStatusArray.forEach(function(item){
    	        	if(order.orderStatus === item.id)
    	        		order.statusName = item.name;
    	        })
    	        $scope.order=order;
    	        //处理金额特殊格式化
    	        for (var i=0,mul_pricee;i<orderDetail.productList.length;i++){
    	        	//处理成本价(cost)运费(shipFee) type-3
    	        	orderDetail.productList[i].cost != null && orderDetail.productList[i].cost != undefined  ? orderDetail.productList[i].cost = (Number(orderDetail.productList[i].cost).moneyFormat(typeArray[3])).money() : orderDetail.productList[i].cost=''; 
    	        	orderDetail.productList[i].shipFee != null && orderDetail.productList[i].shipFee != undefined ? orderDetail.productList[i].shipFee = (Number(orderDetail.productList[i].shipFee).moneyFormat(typeArray[3])).money() : orderDetail.productList[i].shipFee =''; 
    	        	//处理单价 type-0
    	        	orderDetail.productList[i].price = (Number(orderDetail.productList[i].price).moneyFormat(typeArray[0])).money();
    	        	//处理金额
    	        	orderDetail.productList[i].price.toString().indexOf(',') != -1 ? orderDetail.productList[i].price = orderDetail.productList[i].price.replace(/,/g, '') : orderDetail.productList[i].price;
    	        	mul_pricee = Number(orderDetail.productList[i].price);
    	        	//处理小计 type-1
    	        	orderDetail.productList[i].total =((mul_pricee.mul(orderDetail.productList[i].count)).moneyFormat(typeArray[1])).money();    	        		        	
    	        }
    	        $scope.productList=orderDetail.productList;
    	        $scope.orderDelivery=orderDetail.orderDelivery;
    		}else{
	    		$modal.alert("未查到该订单的明细！")
	    	}
    	})
    }else{
    	$modal.alert("未查到该订单的明细！")
    }

    //copy orders 
    $scope.copyOrder = function(order){
    	var msg = "复制订单会清空购物车的数据，确认复制？";
    	if($rootScope.role.RoleEntityid ==2)
    		msg = "复制订单会清空购物车的数据，并且默认选中该经销商，确认复制？";
    	$modal.confirm("购物车将被清空",msg,function(){
			var orderId = this.id;
			var promise = OrderService.copyOrder(orderId);
			promise.then(function(ary){
				if (ary && ary.status == "000") {
		    		if(ary.total > 0){//表示复制的订单中有不存在的产品
		    			$modal.alert(ary.retmsg);
		    		}else{
		    			var company = {companyId:order.companyId,companyName:order.companyName};
		    			UserInfoService.setCurrentCompany(company);
		    			if($rootScope.role.RoleEntityid ==2){
		    				UserInfoService.getOper();
		    			}
		    			$modal.alert("复制成功，点击前往购物车查看，请注意通过切换分公司寻找复制的产品。",function(){
		    				$state.go("cart.cart");
		    			});
		    		}
		    	}else{
		    		$modal.alert("复制订单出错，请检查数据是否准确。");
		    	}
			})
    	}.bind(order))
    }
}]);
