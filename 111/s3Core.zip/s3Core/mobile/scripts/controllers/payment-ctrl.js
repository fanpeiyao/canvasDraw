angular.module("myApp").controller("PaymentListCtrl",["$scope","$rootScope","$state","$timeout",'$modal',"$istore","PaymentService","UserInfoService",function ($scope,$rootScope,$state,$timeout,$modal,$istore,PaymentService,UserInfoService) {
	function initPage(){
        $scope.filter={};
        $scope.page = 0;
        /*$scope.filter.startTime = getTime(30);*/
 	    $scope.oper = {'OperatorEntitycustomId':undefined,'OperatorEntityuserName':$is3n("全部{%=common.customerName%}",config.custid)};
        $scope.currentCompany = {'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)};
        $scope.searchVal = "";
        loadPayments();
        getCompany();
    }
    //初始化
    initPage();
    //处理数据
    function processData(payments){
    	var transferStatusNameList = {7:'处理成功',0:'处理中',1:'已确认',2:'待授权',3:'待授权',4:'处理中',5:'处理中',9:'处理中',10:'处理中',11:'处理中',86:'处理中',95:'处理中',98:'处理中',8:'失败',6:'失败'};
    	payments.forEach(function(payment){
    		payment.isCheck = false;
			//修改状态展示
        	payment = transferKey(transferStatusNameList,payment,'transferStatus');
    		payment.cancelTxt = "作废";
    		for (var key in payment){
				if(key == "status"){
          		   switch(payment[key]){
	          			case "0":
	          				payment.statusName = "待确认";
	          					break;
	          			case "1":
	          				payment.statusName = "已确认";
	          					break;
	          			case "2":
	          				payment.statusName = "付款成功";
	          					break;
	          			case "3":
	          				payment.statusName = "付款失败";
	          					break;
	          			case "4":
	          				payment.statusName = "已作废";
          			}
          	   }
				//处理金额
          	   if(key == "payAmt"){
          		   payment[key] != null && payment[key] != undefined ? payment[key] = (Number(payment[key]).moneyFormat(typeArray[3])).money() : payment[key]='' ;
          	   }
			}
    		
        });
		return payments;
    }
    function loadPayments() {
    	$scope.page = 0;
     	var filter = angular.copy($scope.filter);
        var promise = PaymentService.getPaymentList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.oper.OperatorEntitycustomId);
         if(promise){
         	promise.then(function(result){
         		var payments = [];
         		if(result.retCode == "200"){
         			payments =  result.paymentList;
         			$scope.payments = processData(payments);
         		}
             	refresh();
         	})
         }
    }
    $scope.loadMore = function () {
        $scope.page = $scope.page+1;
        var filter = angular.copy($scope.filter);
        var promise = PaymentService.getPaymentList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.oper.OperatorEntitycustomId);
        if(promise){
        	promise.then(function(result){
        		var payments = [],new_payments;
        		if(result.retCode == "200"){
         			payments =  result.paymentList;
        		}
     			new_payments = processData(payments);
        		for(var i=0;i<new_payments.length; i++){
                    $scope.payments.push(new_payments[i]);
                 }
            	refresh();
        	})
        }
    };
    //获取分公司
    function getCompany(){
    	var promise = UserInfoService.getCompanyList();
        promise.then(function(companyList){
        	 var allcomp = [{'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)}];
        	 $scope.companyList = allcomp.concat(companyList);
        });
    }
    //切换经销商
	$scope.selectDealer = function(){
     	var promise = UserInfoService.getDealerList(0);
     	promise.then(function(arys){
     		if(arys.status === "000"){
       			var all ={'customerId':undefined,'userName':$is3n("展示全部{%=common.customerName%}",config.custid)};
       			$scope.dealerList =[all].concat(arys.dealerList);
     			$scope.allPage =  Math.floor(arys.total /8);
	    	}else{
	    		$scope.dealerList = [];
	    	}
     	})
     	$scope.showpopup=true;
    }
	
    $scope.closePopup = function(){
    	$scope.showpopup=false;
    }
    
	$scope.changeDealer = function(dealer){
		dealer = {'OperatorEntitycustomId':dealer.customerId,
				'OperatorEntityuserName':dealer.userName,};
		$scope.oper = dealer;
    	/*根据经销商获取分公司*/
		loadPayments();
    	getCompany();
		$scope.dealerFlag = true;
    	$scope.showpopup=false;
    }
    //切换分公司
    $scope.changeCompany = function(company){
        $scope.currentCompany = company;
        loadPayments();
        $modal.action({id:'company-action',act:'close'});
    };
    
    
    function getTime(number){
        var now = new Date();
        var date;
        if(number>180){
     	   date = new Date(number);
        }else{
     	   date = new Date(now.getTime()-number*24*3600*1000);
        }
        var year = date.getFullYear()
        var month = date.getMonth()+1;
        if(month > 12) month = 1;
        var day = date.getDate();
        if(month < 10)
            month = "0"+month;
        if(day < 10)
            day = "0"+day;
        return year +'-'+month+'-'+day
    }
    
    
    $scope.changeTime = function(newTime){
        $scope.showDropdown = false;
        $scope.filter.startTime = getTime(newTime);
        $scope.changeFilter();
    };

     $scope.changeTimeauto = function(start,end){
     	$modal.action({id:'changetime-action',act:'open'});
     };

     $scope.searchTimeauto = function(start,end){
     	var startDate = new Date(start);
     	var endDate = new Date(end);
     	if(startDate.valueOf() >endDate.valueOf()){
     		$modal.alert("起始日期不能大于结束日期")
     	}else{
     		startDate = getTime(startDate.valueOf()) === 'NaN-NaN-NaN' ? undefined:getTime(startDate.valueOf());
     		$scope.filter.startTime =startDate;
             $scope.filter.endTime =  getTime(endDate.valueOf());
             $scope.changeFilter();
     	}
     	$modal.action({id:'changetime-action',act:'close'});
     };
     
     
   //筛选/过滤器
     $scope.clearnFilter = function(){
         $scope.filter = {};
         loadPayments();
     };
     $scope.changeFilter=function(){
    	 loadPayments();
     };
     
     //输入关键字搜索
     $scope.closeSearch = function(){
 		$scope.showSearchBody = false;
 	}
 	$scope.showSearch = function(){
 		$scope.searchHistory = $istore.getLocal(config.custid+"_paymentSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];        	       
 		$scope.showSearchBody = true;
 	}
     $scope.keySearch = function(keyValue){
     	$scope.searchVal = keyValue;
     	 loadPayments();
         var myScroll = $scope.myScroll;
         $scope.showSearchBody = false;   
         saveSearchHistory(keyValue);
     };
     //点击按钮清空搜索内容
     $scope.clickClean = function($event){
     	$event.stopPropagation();
     	$scope.searchVal = "";
     	if(!$scope.showSearchBody){
     		loadPayments();
     	}
     };
     function saveSearchHistory(keyValue){
     	if(keyValue === null ||　keyValue === "")return;
         var hisstring = $istore.getLocal(config.custid+"_paymentSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];
         var dup = false;
         hisstring.forEach(function(item){
         	if(item === keyValue)
         		dup = true;
         })
         if(!dup){
         	if(hisstring.length < 10){
         		hisstring.unshift(keyValue);
             }else{
             	hisstring.pop();
             	hisstring.unshift(keyValue)
             }
             $istore.setLocal(config.custid+"_paymentSearchHistory_"+$rootScope.currentUser.UserEntitycustomId,hisstring);
         }
     	
     }
     
     function refresh(flag){
     	$timeout(function(){
             var myScroll = $scope.myScroll;
             if($scope.page == 0)
             	myScroll.scrollTo(0,0);
             myScroll.refresh();
     	},501)
     }
    
    //作废
    $scope.cancelPayment = function(item,e){
    	$modal.confirm("作废付款单","确定作废该付款单?",function (e){
    		var that = this;
    		var param={};
    		param.paymentNo = this.paymentNo;
			var promise = PaymentService.doCancel(param);
			promise.then(function(result){
    	    	if(result.retCode == "200"){
    	        	$modal.alert("作废成功");
        			that.status = '4'
        			that.statusName = '已作废'
    	        }else{
    	        	$modal.alert(result.retMsg || "作废失败")
    	        }
    		})
    	}.bind(item))	
    }
    var resubmit = true;
    //点击付款按钮时
    $scope.doTransferPay = function(payment){
		//防止重复多次点击，1秒钟之内不能重复调用
		if(resubmit == true){
			resubmit = false;
			window.setTimeout(function(){
				resubmit = true;
			},1000);
		}else{
			return;
		}
		$.toast.show('loading');
  	   	var promise = PaymentService.insertRecAccNo(payment);
	   	  	promise.then(function(result){
	   	  		if(result.retCode == "200"){
		    		var promise2 = PaymentService.doTransferPay(payment);
		    		promise2.then(function(result){
		    			if(result.retCode != "200"){
		    		  		$modal.alert(result.retmsg);
		    		  		payment.status = '3'
		    		  		payment.statusName = '付款失败'
		    		  	}
		    			if(result&&result.paymentStatus){
		    		  		if(result.paymentStatus=="2"){
		    		  			$state.go("uppayment.success",{id:payment.id,paymentNo:payment.paymentNo});
		    		  		}else{
		    		  			$modal.alert(result.retmsg);
		    		  		}
		    		  	};
		    		})
		    	}else{
		    		$modal.alert(result.retmsg|| "插入账号信息失败！");

		    	}
		   		$.toast.close();
		   })
   }
    
    
  
}])
.controller("PaymentDetailCtrl",["$scope","$rootScope",'$stateParams',"$state",'$modal','PaymentService',function ($scope,$rootScope,$stateParams,$state,$modal,PaymentService) {
    //取得传过来的参数
    var paymentNo = $stateParams.paymentNo;
    var promise = PaymentService.getPaymentDetail(paymentNo);
	$scope.showCancel = false
    promise.then(function(result){
    	if(result.retCode == "200"){
        	var payment = result.paymentList,statusNameList= {0:'待确认',1:'已确认',2:'付款成功',3:'付款失败',4:'已作废'},
        	transferStatusNameList = {7:'处理成功',0:'处理中',1:'已确认',2:'待授权',3:'待授权',4:'处理中',5:'处理中',9:'处理中',10:'处理中',11:'处理中',86:'处理中',95:'处理中',98:'处理中',8:'失败',6:'失败'};
        	//修改付款单状态展示
        	payment = transferKey(statusNameList,payment,'status');
        	payment = transferKey(transferStatusNameList,payment,'transferStatus');
    		for (var key in payment){
				//转账处理方式
				if(key == "payType"){
          		   switch(payment[key]){
	          			case "1":
	          				payment.payTypeName = "加急";
	          					break;
	          			case "2":
	          				payment.payTypeName = "普通";
          			}
          	    }
				//系统内外标志
				if(key == "sysIOFlg"){
          		   switch(payment[key]){
	          			case "1":
	          				payment.sysIOFlgName = "系统内";
	          					break;
	          			case "2":
	          				payment.sysIOFlgName = "系统外";
          			}
          	    }
				//系统内外标志
				if(key == "isPub"){
          		   switch(payment[key]){
	          			case "0":
	          				payment.isPubName = "对公账户";
	          					break;
	          			case "1":
	          				payment.isPubName = "对私账户";
          			}
          	    }
				 //处理金额
          	    if(key == "payAmt"){
          		   payment[key] != null && payment[key] != undefined ? payment[key] = (Number(payment[key]).moneyFormat(typeArray[3])).money() : payment[key]='' ;
          	    } 
			}
        	if(payment.status != "4" && payment.transferStatus == null){
        		$scope.showCancel = true;
        	}	
        	$scope.payment= payment;
        }else{
        	$modal.alert("查询付款单失败")
        }
    })
    var resubmit = true;
    //点击付款按钮时
    $scope.doTransferPay = function(){
		//防止重复多次点击，1秒钟之内不能重复调用
		if(resubmit == true){
			resubmit = false;
			window.setTimeout(function(){
				resubmit = true;
			},1000);
		}else{
			return;
		}
		$.toast.show('loading');
  	   	var promise = PaymentService.insertRecAccNo($scope.payment);
	   	  	promise.then(function(result){
	   	  		if(result.retCode == "200"){
		    		var promise2 = PaymentService.doTransferPay($scope.payment);
		    		promise2.then(function(result){
		    			if(result.retCode != "200"){
		    		  		$modal.alert(result.retmsg);
		    		  		$scope.payment.status = '3'
		    		  		$scope.payment.statusName = '付款失败'
		    		  	}
		    			if(result&&result.paymentStatus){
		    		  		if(result.paymentStatus=="2"){
		    					$state.go("uppayment.success",{id:$scope.payment.id,paymentNo:$scope.payment.paymentNo});
		    		  		}else{
		    		  			$modal.alert(result.retmsg);
		    		  		}
		    		  	};
		    		})
		    		
		    	}else{
		    		$modal.alert(result.retmsg|| "插入账号信息失败！");

		    	}
		   		$.toast.close();
		   })
  	   	
  	  
   }
   //作废
    $scope.cancelPayment = function(){
    	var item =$scope.payment; 
    	if(item.status != 4 && item.transferStatus == null){
        	$modal.confirm("作废付款单","确定作废该付款单?",function (e){
        		var param={};
        		param.paymentNo = this.paymentNo;
    			var promise = PaymentService.doCancel(param);
    			promise.then(function(result){
	    	    	if(result.retCode == "200"){
	    	        	$modal.alert("作废成功");
	    	        	$scope.payment.status = '4'
		    	        $scope.payment.statusName = '已作废'
		    	        $scope.showCancel = false;
	    	        }else{
	    	        	$modal.alert(result.retMsg || "作废失败")
	    	        }
        		})
        	}.bind(item))	
    	}else
    		return
    }
    
}])
.controller("PaymentSuccessCtrl",['$scope','$stateParams',function($scope,$stateParams){
	$scope.payment = {
			paymentNo:$stateParams.paymentNo,
			paymentId:$stateParams.id
	}
}])