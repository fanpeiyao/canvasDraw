angular.module("myApp").controller('announcementCtrl',['$scope','$state','$rootScope','$timeout','$istore','$modal','announcementService','$sce',
        function($scope,$state,$rootScope,$timeout,$istore,$modal,announcementService,$sce){
			function initPage() {
				var promise = announcementService.getNoticeList();			
		        if(promise.then){
		        	promise.then(function(result){
		        		 var notices = [];
		        		 notices = result.noticeBoardList;
		        		 notices.forEach(function(item){
		        			 item.content = $sce.trustAsHtml(item.content);
		        			 item.createTime = item.createTime.split(" ")[0];
		        		 })
		        		 $scope.notices = notices;
		        	})	
		        }
		    }
			initPage()
       }])
.controller("annDetailCtrl",["$scope","$rootScope",'$state','$stateParams','$modal','announcementService','$sce',
              function ($scope,$rootScope,$state,$stateParams,$modal,announcementService,$sce) {
            var noticeId = $stateParams.noticeId;
            var promise= announcementService.getNoticeList(noticeId);
            if(promise){
            	promise.then(function(result){
            		result.noticeBoardList[0].content = $sce.trustAsHtml(result.noticeBoardList[0].content);
            		/*result.noticeBoardList[0].createTime = result.noticeBoardList[0].createTime.split(" ")[1].slice(0,5); */
            		$scope.noticeDetail=result.noticeBoardList[0];
            	})
            }else{
            	$modal.alert("查询公告明细出错！")
            }
            
            
            $scope.deleteAnnounce = function(id){
            	var obj = {id:id}
            	$modal.confirm("删除公告","删除后不可恢复，是否确定删除公告?",function (e){
            		var id = this.id;
	            	var promise = announcementService.deleteAnnounce(id);
	            	promise.then(function(result){
	            		if(result.retCode == "200"){
	            			$.toast.show('info',1000);
	            			$state.go('noticeBoardManage.list');
	            		}else{
	            			$modal.alert(result.retMsg || "删除公告出错。 ");
	            		}
	            	})
            	}.bind(obj))
            }	
            
            $scope.editAnnounce = function(){
            	$state.go('noticeBoardManage.listChange');
            }
}]).controller("listChangeCtrl",["$scope","$rootScope",'$state','$stateParams','$modal','announcementService',
                                function ($scope,$rootScope,$state,$stateParams,$modal,announcementService) {
	
	var noticeId = $stateParams.noticeId;
    var promise= announcementService.getNoticeList(noticeId);
    
    if(promise){
    	promise.then(function(result){
//    		result.noticeBoardList[0].content = $sce.trustAsHtml(result.noticeBoardList[0].content);
    		result.noticeBoardList[0].createTime = result.noticeBoardList[0].createTime.split(" ")[1].slice(0,5); 
    		$scope.noticeDetail=result.noticeBoardList[0];
    	})
    }else{
    	$modal.alert("查询公告明细出错！")
    }
    
	$scope.cancel=function(){
		$state.go("noticeBoardManage.list")
	}
	
   /*保存*/
   $scope.save=function(title,content){
	   
	   var notice={};
	   notice.noticeId=noticeId;
	   notice.content=content;
	   notice.title=title;
	   var promise = announcementService.updateAnnounce(notice,$rootScope.currentUser.UserEntitycustomId);
	   if(promise){
		   promise.then(function(result){
			   if(result.retCode == "200"){
//				   $modal.alert(result.retMsg);
				   $.toast.show('info',1000);
				       $state.go("noticeBoardManage.list")
				}else{
					$modal.alert(result.retmsg);
				}
		   })
	   }else{
			$modal.alert("系统错误!")
		}
   }
    
    

}]).controller("annEditCtrl",["$scope",'$state','$stateParams','$rootScope','$modal','announcementService','$sce',
                                       function ($scope,$state,$stateParams,$rootScope,$modal,announcementService,$sce) {
	$scope.ok=function(content,title){
		   var notice={};
		   notice.content=content;
		   notice.customerId=$rootScope.currentUser.UserEntitycustomId;
		   notice.title=title;
		   var promise = announcementService.addNotice(notice);
		   if(promise){
			   promise.then(function(result){
				   if(result.retCode == "200"){
					   $.toast.show('info',1000);
   				       $state.go("noticeBoardManage.list")
   				}else{
   					$modal.alert(result.retmsg);
   				}
			   })
		   }else{
   			$modal.alert("系统错误!")
   		}
	}
}]);
