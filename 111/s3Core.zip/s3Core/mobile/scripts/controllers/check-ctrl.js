/**
 * Created by chent on 2017/1/18.
 */

angular.module("myApp").controller("CheckCtrl",["$scope","$state","$rootScope",'$istore','$modal',"$timeout","CheckService","UserInfoService","$stateParams",function ($scope,$state,$rootScope,$istore,$modal,$timeout,CheckService,UserInfoService,$stateParams) {

    //初始化
    function initPage(){
       $scope.currentCompany = {'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)};
       var voucherStatusArray = CheckService.getVoucherStatusArray();       
       $scope.voucherStatusArray = voucherStatusArray;
       //获取任务类型
       var workflowdArray = CheckService.getFlowName();
       workflowdArray.then(function(result){
    	   $scope.workflowdArray = [ {id:undefined,flowName:'任务类型'}].concat(result) ;
       });
       
       $scope.status = voucherStatusArray[0];

       $scope.filterConfig = [];
       $scope.searchVal = "";
       $scope.filter={};
       $scope.page = 0;
       $scope.filter.start_date = getTime(30);
       
       loadChecks();
       getCompany();
    };
    initPage();
    //筛选/过滤器
    $scope.changeFilter=function(){
    	loadChecks();
    };
	//切换状态
    $scope.changeStatus = function(newStatus){
    	$scope.page=0;
    	$scope.status = newStatus;
    	loadChecks();
    };
    //日期
    function getTime(number){
        var now = new Date();
        var date;
        if(number>180){
     	   date = new Date(number);
        }else{
     	   date = new Date(now.getTime()-number*24*3600*1000);
        }
        var year = date.getFullYear()
        var month = date.getMonth()+1;
        if(month > 12) month = 1;
        var day = date.getDate();
        if(month < 10)
            month = "0"+month;
        if(day < 10)
            day = "0"+day;
        return year +'-'+month+'-'+day
    }
    $scope.changeTime = function(newTime){
        $scope.showDropdown = false;
        $scope.filter.start_date = getTime(newTime);
        $scope.changeFilter();
    };

    $scope.changeTimeauto = function(start,end){
    	$modal.action({id:'changetime-action',act:'open'});
    };
    $scope.searchTimeauto = function(start,end){
    	var startDate = new Date(start);
    	var endDate = new Date(end);
    	if(startDate.valueOf() >endDate.valueOf()){
    		$modal.alert("起始日期不能大于结束日期")
    	}else{
    		startDate = getTime(startDate.valueOf()) === 'NaN-NaN-NaN' ? undefined:getTime(startDate.valueOf());
    		$scope.filter.start_date =startDate;
            $scope.filter.end_date =  getTime(endDate.valueOf());
            $scope.changeFilter();
    	}
    	$modal.action({id:'changetime-action',act:'close'});
    };
    //切换分公司
    function getCompany(){
    	var promise = UserInfoService.getCompanyList();
        promise.then(function(companyList){
        	 var allcomp = [{'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)}];
        	 $scope.companyList = allcomp.concat(companyList);
        });
    }
    $scope.changeCompany = function(company){
        $scope.currentCompany = company;
        loadChecks();
        $modal.action({id:'company-action',act:'close'});
    };
    //输入关键字搜索
    $scope.closeSearch = function(){
		$scope.showSearchBody = false;
	}
	$scope.showSearch = function(){
		$scope.searchHistory = $istore.getLocal(config.custid+"_checkSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];        	       
		$scope.showSearchBody = true;
	}
    $scope.keySearch = function(keyValue){
    	$scope.searchVal = keyValue;
    	loadChecks();
        var myScroll = $scope.myScroll;
        $scope.showSearchBody = false;   
        saveSearchHistory(keyValue);
    };
    //点击按钮清空搜索内容
    $scope.clickClean = function($event){
    	$event.stopPropagation();
    	$scope.searchVal = "";
    	if(!$scope.showSearchBody){
    		loadChecks();
    	}
    };
    function saveSearchHistory(keyValue){
    	if(keyValue === null ||　keyValue === "")return;
        var hisstring = $istore.getLocal(config.custid+"_checkSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];
        var dup = false;
        hisstring.forEach(function(item){
        	if(item === keyValue)
        		dup = true;
        })
        if(!dup){
        	if(hisstring.length < 10){
        		hisstring.unshift(keyValue);
            }else{
            	hisstring.pop();
            	hisstring.unshift(keyValue)
            }
            $istore.setLocal(config.custid+"_checkSearchHistory_"+$rootScope.currentUser.UserEntitycustomId,hisstring);
        }
    	
    }
    
    $scope.refreshPage = function () {
    	$scope.page=0;
    	loadChecks()
    };
    $scope.loadMore = function () {
       $scope.page = $scope.page+1;
       var filter = angular.copy($scope.filter);

       var promise = CheckService.getApproveList($scope.status.id,$scope.page,filter,$scope.currentCompany.companyId,$scope.searchVal);
       if(promise){
       	promise.then(function(result){
       		var checkList = [];
       		if(result.status == "000"){
       			checkList =  result.dataList;
       		}
       		var checks = setStatus(checkList);
               for(var i=0;i<checks.length; i++){
                  $scope.checks.push(checks[i]);
               }
           	refresh(true);
       	})
       }
    };
    $scope.goToDetail = function(taskId){
    	var promise = CheckService.getDefPage(taskId);
    	promise.then(function(result){
    		if( result.retCode === "200" && result.detail){
    			state = result.detail.defPage;
        		var urlReg = /(\/)?([a-zA-Z0-9\-\,\?\,\'\/\\\+&amp;%\$#_]*)?(.[a-zA-Z0-9].php)/;
    			if(urlReg.test(state)){
    				var param = {
    					taskId:taskId
    				}
    				$state.go("module.other",{param: JSON.stringify(param),title:"审批详情",dataUrl:state});
    			}else{
    				$state.go(state,{taskId:taskId,tab:$scope.status.id})
    			}
    		}else{
    			$modal.alert(result.regMsg||'跳转失败！')
    		}
    	})
    };
    function loadChecks() {
    	$scope.page = 0;
    	var filter = angular.copy($scope.filter);
	   	 var promise = CheckService.getApproveList($scope.status.id,$scope.page,filter,$scope.currentCompany.companyId,$scope.searchVal);
	   	 if(promise){
	   		 promise.then(function(result){
	   			    var checkList = [];
			       		if(result.status == "000"){
			       			checkList =  result.dataList;
			       		}
			       	    $scope.checks=setStatus(checkList);
			       	    refresh();
	   		 })
	   	 }
   }
    function refresh(flag){
    	$timeout(function(){
            var myScroll = $scope.myScroll;
            if(!flag)
            	myScroll.scrollTo(0,0);
            myScroll.refresh();
    	},501)
    }
   
    function setStatus(vouchers){
    	vouchers.forEach(function(voucher){
    		voucher.statusName = $scope.status.name;
        });
		return vouchers;
    }
    
   
    
}]);


myApp.controller("CheckDetailCtrl",["$scope",'$state','$stateParams','$number','$timeout','$modal','CheckService','fileReader',function ($scope,$state,$stateParams,$number,$timeout,$modal,CheckService,fileReader) {
	
	
	var taskId = $stateParams.taskId;
	$scope.tabStatus = $stateParams.tab;
	var promise = CheckService.getApproveDetail(taskId);
    if(promise.then){
    	promise.then(function(result){
    		if(result.retCode === "200"){
    			approve = result.detail;
    			var ele = angular.element('.buttonBox'),flag=0;
    			for (var key in approve){
              	   if(key === "flowStatus"){
              		   	switch(approve[key]){
 		          			case "0":
 		          				approve["flowStatusName"] = "审批中";
 		          					break;
 		          			case "1":
 		          				approve["flowStatusName"] = "审批完成";
 		          					break;
 		          			case "2":
 		          				approve["flowStatusName"] = "已作废"
 	          			}
              	   }
              	   //更改button样式
	               if(key === "isAllowApprove"){
	           		   	if(approve[key] == '0'){
	           		   		flag++;
	           		   	}
	           	   }
	               if(key === "isAllowBackward"){
	           		   	if(approve[key] == '0'){
	           		   		flag++;
	           		   	}
	           	   }
	               if(key === "isAllowRefuse"){
	           		   	if(approve[key] == '0'){
	           		   		flag++;
	           		   	}
	           	   }
    			}
    	        ele.addClass(' new-avg-'+flag);
    			$scope.approve = approve;
    			var detailInfo = JSON.parse($scope.approve.flowData);
      		    switch(detailInfo.paymentMethod){
          			case "0":
          				detailInfo.paymentMethod = "汇款";
          					break;
          			case "1":
          				detailInfo.paymentMethod = "票据";
          					break;
          			case "2":
          				detailInfo.paymentMethod = "信用证";
          					break;
          			case "3":
          				detailInfo.paymentMethod = "其他";
      			}
      		   	switch(detailInfo.shippingMethod){
          			case "0":
          				detailInfo.shippingMethod = "自提";
          					break;
          			case "1":
          				detailInfo.shippingMethod = "配送";
          					break;
      			}
      		   	
      		   	detailInfo.totalAmount.toString().indexOf(',') != -1 ? detailInfo.totalAmount = detailInfo.totalAmount.replace(/,/g, '') : detailInfo.totalAmount
      		   	//处理总价 type-2
    			detailInfo.format_totalAmount = (Number(detailInfo.totalAmount).moneyFormat(typeArray[2])).money();
    			//处理可编辑页面总价 type-2
      		   	detailInfo.format_totalAmount.toString().indexOf(',') != -1 ? detailInfo.totalAmount = Number(detailInfo.format_totalAmount.replace(/,/g, '')) : detailInfo.totalAmount = detailInfo.format_totalAmount;
    			//处理产品总金额 type-3
    			detailInfo.payAmount != null && detailInfo.payAmount != undefined? detailInfo.payAmount = (Number(detailInfo.payAmount).moneyFormat(typeArray[3])).money() : detailInfo.payAmount=''; 	
    			$scope.detailInfo = detailInfo;
    			$scope.detailInfo.orderProduct.forEach(function(item){
    				item.old_price = Number(item.price);
    				//处理单价 type-0
    				item.format_price = (Number(item.price).moneyFormat(typeArray[0])).money();
    				//处理可编辑页面单价 type-0
    				item.price = Number(item.format_price.replace(/,/g, ''));
    				item.format_price.toString().indexOf(',') != -1 ? item.price = Number(item.format_price.replace(/,/g, '')) : item.price =  Number(item.format_price);
    				//处理运费 type-3
    		        item.shipFee != null && item.shipFee != undefined ? item.shipFee = (Number(item.shipFee).moneyFormat(typeArray[3])).money() : item.shipFee = ''; 
    				//处理成本价 type-3
    		        item.cost != null && item.cost != undefined  ? item.cost = (Number(item.cost).moneyFormat(typeArray[3])).money() : item.cost =''; 
    				//处理手续费 type-3
    		        item.handingFee != null && item.handingFee != undefined? item.handingFee = (Number(item.handingFee).moneyFormat(typeArray[3])).money() : item.handingFee =''; 
    				//处理产品总金额 type-3
    		        item.productSum != null && item.productSum != undefined? item.productSum = (Number(item.productSum).moneyFormat(typeArray[3])).money() : item.productSum=''; 
    				//处理手续费 type-3
    		        item.minAmount != null && item.minAmount != undefined? item.minAmount =( Number(item.minAmount).moneyFormat(typeArray[3]) ).money(): item.minAmount=''; 
    				//处理产品总金额 type-3
    		        item.payAmount != null && item.payAmount != undefined? item.payAmount = (Number(item.payAmount).moneyFormat(typeArray[3])).money() : item.payAmount=''; 	
    			});
                getFile();
    		}else{
	    		$modal.alert("未查到该单据的明细！")
	    	}
    	})
    }else{
    	$modal.alert("未查到该单据的明细！")
    }
    
    $scope.doApprove = function(action){
    	 $scope.showpopup = true;
    	 $scope.action = action;
    };
    
    $scope.submitApprove = function(){
    	  $.toast.show('loading');
    	  switch($scope.detailInfo.shippingMethod){
			case "自提":
				$scope.detailInfo.shippingMethod = "0";
					break;
			case "配送":
				$scope.detailInfo.shippingMethod = "1";
					break;
    	  }
    	  switch($scope.detailInfo.paymentMethod){
			case "汇款":
				$scope.detailInfo.paymentMethod = "0";
					break;
			case "票据":
				$scope.detailInfo.paymentMethod = "1";
					break;
			case "信用证":
				$scope.detailInfo.paymentMethod = "2";
					break;
			case "其他":
				$scope.detailInfo.paymentMethod = "3";
    	  }
	   	  $scope.approve.flowData = JSON.stringify($scope.detailInfo);
	   	  var promise = CheckService.doApprove($scope.approve.taskId,$scope.approve.flowData,$scope.approve.newApproveNote,$scope.action,$scope.approve.flowType);
	   	  promise.then(function(result){
	   		  if(result.status == "000"){
		    		  $modal.alert("审核成功！",function(){
		    			  $state.go("check.checkList");
		    		  })
		    	  }else{
		    		  switch($scope.detailInfo.shippingMethod){
			  			case "0":
			  				$scope.detailInfo.shippingMethod = "自提";
			  					break;
			  			case "1":
			  				$scope.detailInfo.shippingMethod = "配送";
			  					break;
			      	  }
		    		  switch($scope.detailInfo.paymentMethod){
	          			case "0":
	          				$scope.detailInfo.paymentMethod = "汇款";
	          					break;
	          			case "1":
	          				$scope.detailInfo.paymentMethod = "票据";
	          					break;
	          			case "2":
	          				$scope.detailInfo.paymentMethod = "信用证";
	          					break;
	          			case "3":
	          				$scope.detailInfo.paymentMethod = "其他";
	      				}
		    		  $modal.alert("流程出错，审核失败！");
		    	  }
	   		  $.toast.close();
	      	  $scope.showpopup=false;
	   	  })
    }
    $scope.closePopup = function(){
    	$scope.showpopup=false;
    }

    //控制可修改单价的保留小数位数
    $scope.price_bitLength = typeArray[0].bitLength;
    //控制可修改总价的保留小数位数
    $scope.amount_bitLength = typeArray[2].bitLength;
    $scope.changePrice = function(checkProduct,price){
    	if(price == null){
    		return false;
    	}else{
    		var products = $scope.detailInfo.orderProduct;
    		var totalAmount = 0;
    		products.forEach(function(item){
    			var total = $number.multiply(item.price,item.count);
    			totalAmount = $number.add(totalAmount,total);
    		})
    		$scope.detailInfo.totalAmount = totalAmount;
    	}
    }
    
    $scope.caculateTotal = function(product){
    	 var now = $number.multiply(product.price,product.count);
    	 //处理小计 type-1
		 return  (now.moneyFormat(typeArray[1])).money();
    }
	$scope.showFile = function(result){
    	if($scope.fileToUpload){
        	if( $scope.fileToUpload.type.indexOf("image")>-1){
				$scope.preview = true;
				$scope.imageSrc = result.dataUrl;
			}
        	if($scope.fileToUpload.name.lastIndexOf(".")>-1){
				extName = $scope.fileToUpload.name.substring($scope.fileToUpload.name.lastIndexOf(".")+1).toLowerCase();
			}
        	//支持常用的图片及文本格式
        	var listExtName = new Array("jpg","png","jpeg","bmp","txt","xls","doc","docx","xlsx","pdf","JPG","PNG","JPEG","TXT","XLS","DOC","DOCX","XLSX","PDF");
        	var flag = 0;
        	for(var i = 0;i < listExtName.length; i++){
        		if(listExtName[i]==extName){
        			flag++;
        		}
        	}
        	if(flag == 0){
        		$scope.fileLoading = "不能上传此种格式的文件";
        	}else{
        		$scope.fileLoading = "上传中...";
                if(result){
                	sendFile(result);
                }else{
                	sendFile($scope.fileToUpload);
                }
        	}
		}
	};

	function sendFile(file){
		var postData = {
			instanceId:$scope.approve.instanceId,
			taskId:$scope.approve.taskId
		};
        var promise = CheckService.uploadFile(file,postData);
        promise.then(function(result){
        	console.log(result)
        	if(result.status == "003"){
        		$modal.alert(result.retmsg);
        		$scope.fileLoading = "出错了，上传失败";
        	}else{
	        	if(result.status == "000"){
	        		$scope.fileLoading = "上传完成";
	                getFile();	
	        	}else{
	        		$scope.fileLoading = "出错了，上传失败";
	        	}
        	}
		})
	}

    function getFile(){
        CheckService.getFileList(approve.instanceId).then(function(result){
        	if(result.status == "000"){
        		$scope.fileList = result.dataList;
        	}
        })
    }
	$scope.deleteFlie = function(fileUrl){
		if(confirm("删除后不可恢复,确定删除?")){
		    CheckService.deleteFile($scope.approve.instanceId,$scope.approve.taskId,fileUrl).then(function(result){
		    	if(result.retCode === "200"){
		    		getFile();
		    	}else{
		    		alert("删除文件失败了!");
		    	}
		    })
		}
    }
	
	

}]);



myApp.controller("CheckPaymentDetailCtrl",["$scope",'$state','$stateParams','$number','$timeout','$modal','CheckService','fileReader',function ($scope,$state,$stateParams,$number,$timeout,$modal,CheckService,fileReader) {
	
	
	var taskId = $stateParams.taskId;
	$scope.tabStatus = $stateParams.tab;
	var promise = CheckService.getApproveDetail(taskId);
    if(promise.then){
    	promise.then(function(result){
    		if(result.retCode === "200"){
    			approve = result.detail;
    			var ele = angular.element('.buttonBox'),flag=0;
    			for (var key in approve){
              	   if(key === "flowStatus"){
              		   	switch(approve[key]){
 		          			case "0":
 		          				approve["flowStatusName"] = "审批中";
 		          					break;
 		          			case "1":
 		          				approve["flowStatusName"] = "审批完成";
 		          					break;
 		          			case "2":
 		          				approve["flowStatusName"] = "已作废"
 	          			}
              	   }
              	   //更改button样式
	               if(key === "isAllowApprove"){
	           		   	if(approve[key] == '0'){
	           		   		flag++;
	           		   	}
	           	   }
	               if(key === "isAllowBackward"){
	           		   	if(approve[key] == '0'){
	           		   		flag++;
	           		   	}
	           	   }
	               if(key === "isAllowRefuse"){
	           		   	if(approve[key] == '0'){
	           		   		flag++;
	           		   	}
	           	   }
    			}
    	        ele.addClass(' new-avg-'+flag);
    			$scope.approve = approve;
    			var detailInfo = JSON.parse($scope.approve.flowData);
      		   	switch(detailInfo.status){
          			case "0":
          				detailInfo.statusName = "待确认";
          					break;
          			case "1":
          				detailInfo.statusName = "已确认";
          					break;
          			case "2":
          				detailInfo.statusName = "付款成功";
          					break;
          			case "3":
          				detailInfo.statusName = "付款失败";
          					break;
          			case "4":
          				detailInfo.statusName = "已作废";
      			}
      		   	
      		   	//转账处理方式
      		   switch(detailInfo.payType){
          			case "1":
          				detailInfo.payTypeName = "加急";
          					break;
          			case "2":
          				detailInfo.payTypeName = "普通";
      			}
				//系统内外标志
      		   switch(detailInfo.sysIOFlg){
          			case "1":
          				detailInfo.sysIOFlgName = "系统内";
          					break;
          			case "2":
          				detailInfo.sysIOFlgName = "系统外";
      			}
				//系统内外标志
      		   switch(detailInfo.isPub){
          			case "0":
          				detailInfo.isPubName = "对公账户";
          					break;
          			case "1":
          				detailInfo.isPubName = "对私账户";
      			}
      		  	$scope.detailInfo = detailInfo;
      		  	//处理产品总金额 type-3
      		  	$scope.detailInfo.payAmt != null && $scope.detailInfo.payAmt != undefined? $scope.detailInfo.payAmt = (Number($scope.detailInfo.payAmt).moneyFormat(typeArray[3])).money() : $scope.detailInfo.payAmt=''; 	
      		    
    		}else{
	    		$modal.alert("未查到该单据的明细！")
	    	}
    	})
    }else{
    	$modal.alert("未查到该单据的明细！")
    }
    
    $scope.doApprove = function(action){
    	 $scope.showpopup = true;
    	 $scope.action = action;
    };
    
    $scope.submitApprove = function(){
    	  $.toast.show('loading');
	   	  $scope.approve.flowData = JSON.stringify($scope.detailInfo);
	   	  var promise = CheckService.doApprove($scope.approve.taskId,$scope.approve.flowData,$scope.approve.newApproveNote,$scope.action,$scope.approve.flowType,$scope.detailInfo);
	   	  promise.then(function(result){
	   		  if(result.status == "000"){
		    		  $modal.alert("审核成功！",function(){
		    			  $state.go("check.checkList");
		    		  })
		    	  }else{
		    		  $modal.alert("流程出错，审核失败！");
		    	  }
	   		  $.toast.close();
	      	  $scope.showpopup=false;
	   	  })
    }
    $scope.closePopup = function(){
    	$scope.showpopup=false;
    }

}]);


myApp.controller("CheckFlowCtrl",["$scope",'$state','$stateParams','$modal','CheckService',function ($scope,$state,$stateParams,$modal,CheckService,OrderService) {  

	var instanceId = $stateParams.instanceId;
	var promise = CheckService.findApproveFlow(instanceId);
	if(promise){
		promise.then(function(data){
			var flows = [];
			if(data.status == "000"){
				flows=data.dataList;
				switch(flows[flows.length-1].flowStatus){
       			case "0":
       				$scope.flowStatusName = "审批中";
       					break;
       			case "1":
       				$scope.flowStatusName = "审批完成";
       					break;
       			case "2":
       				$scope.flowStatusName = "已作废"
				}
			}
			checkDifference(flows);
			$scope.flowBegin = flows.shift();
			$scope.flows = flows;
		})
	}
	function checkDifference(flows){
		
		if(!angular.isArray(flows))
			return flows;
		if(flows.length<2)
			return flows;
		for(var i = 1;i<flows.length;i++){
			
			var before = JSON.parse(flows[i-1].flowData);
			var after = JSON.parse(flows[i].flowData);
			
			if(before["orderProduct"]){
				before.orderProduct.forEach(function(item){
					item.price = Number(item.price)
				})
				after.orderProduct.forEach(function(item){
					item.price = Number(item.price)
				})
			}
			
			var diff = compare(before,after);

			delete diff.address;
			flows[i].diff = diff;
			for (var key in flows[i].diff){
				if(key == "orderProduct"){
					for (var j in flows[i].diff.orderProduct){
						if(key == "cost"){
							flows[i].diff.orderProduct[j].cost.newValue = (Number(flows[i].diff.orderProduct[j].cost.newValue).moneyFormat(typeArray[3])).money();
							flows[i].diff.orderProduct[j].cost.oldValue = (Number(flows[i].diff.orderProduct[j].cost.oldValue).moneyFormat(typeArray[3])).money();
		          	   }
						if(key == "shipFee"){
							flows[i].diff.orderProduct[j].shipFee.newValue = (Number(flows[i].diff.orderProduct[j].shipFee.newValue).moneyFormat(typeArray[3])).money();
							flows[i].diff.orderProduct[j].shipFee.oldValue = (Number(flows[i].diff.orderProduct[j].shipFee.oldValue).moneyFormat(typeArray[3])).money();
		          	   }
						if(key == "price"){
							flows[i].diff.orderProduct[j].price.newValue = (Number(flows[i].diff.orderProduct[j].price.newValue).moneyFormat(typeArray[0])).money();
							flows[i].diff.orderProduct[j].price.oldValue = (Number(flows[i].diff.orderProduct[j].price.oldValue).moneyFormat(typeArray[0])).money();
		          	   }
					}
          	   }
			}
		}
	}
	
	function compare(before,after){
		var diff = {};
		if(angular.isObject(before) && angular.isObject(after)){
			for(var key in before){
				if(angular.isArray(before[key])){
					var diffary = [];
					for(var i =0;i<before[key].length;i++){
						diffary[i] = compare(before[key][i],after[key][i]);
					}
					diff[key] = diffary;
				}else if(angular.isObject(before[key])){
					diff[key] = compare(before[key],after[key]);
				}else if(before[key] != after[key]){
					diff[key] = {oldValue:before[key],newValue:after[key]}
					if(before["productId"]){
						diff["productId"] = before["productId"];
						diff["productName"] = before["productName"]
					}
				}
			}
		}else if(before !== after)
			diff = {oldValue:before,newValue:after};
		return diff;
	}
}]);