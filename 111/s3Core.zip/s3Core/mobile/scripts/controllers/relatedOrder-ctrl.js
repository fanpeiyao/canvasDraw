angular.module("myApp").controller("relatedOrderCtrl",["$scope","$timeout","$rootScope",'$istore','$modal',"OrderService","receiptService","UserInfoService",
                                                    function ($scope,$timeout,$rootScope,$istore,$modal,OrderService,receiptService,UserInfoService) {

	$scope.receipts = [];
	//初始化
    function initPage(){
//       var receiptStatus = receiptService.getReceiptStatus();
       $scope.receiptStatus = [{id:undefined,name:'状态'},{id:'11',name:'待审核'},{id:'22',name:'待认领'},{id:'33',name:'已审核'}];
       $scope.paymenyMethod = [{id:undefined,name:'付款方式'},{id:'11',name:'电汇'},{id:'22',name:'电票'}];

       $scope.filter={};
       $scope.page = 0;
       $scope.filter.start_date = getTime(30);
       
 
    	$scope.oper = {'OperatorEntitycustomId':undefined,'OperatorEntityuserName':$is3n("全部{%=common.customerName%}",config.custid)};
       $scope.currentCompany = {'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)};
       
       $scope.filterConfig = [];
      /* if($scope.config.filter){
       		$scope.filterConfig = angular.copy($scope.config.filter);

           $scope.filterConfig.forEach(function(item){
               item.values = [item.name].concat(item.values);
               $scope.filter[item.key] = item.name;
		   })
	   }*/
       
       $scope.searchVal = "";
       
       loadData();
       getCompany();
    }

    
    //切换经销商和分公司
	$scope.selectDealer = function(){
     	var promise = UserInfoService.getDealerList(0);
     	promise.then(function(arys){
     		if(arys.status === "000"){
     			$scope.dealerList = arys.dealerList;
     			$scope.allPage =  Math.floor(arys.total /10);
	    	}else{
	    		$scope.dealerList = [];
	    	}
     	})
     	$scope.showpopup=true;
    }
	
    $scope.closePopup = function(){
    	$scope.showpopup=false;
    }
    
	$scope.changeDealer = function(dealer){
		dealer = {'OperatorEntitycustomId':dealer.customerId,
				'OperatorEntityuserName':dealer.userName,};
		$scope.oper = dealer;
    	/*根据经销商获取分公司*/
        loadData();
    	getCompany();
		$scope.dealerFlag = true;
    	$scope.showpopup=false;
    }
	
    function getCompany(){
    	if($rootScope.role.RoleEntityid != 1){
    		var promise = UserInfoService.getDealerCompanyList($scope.oper.OperatorEntitycustomId);
            promise.then(function(result){
            	var companyList = result.dataList;
            	var all ={'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)};
                $scope.companyList =[all].concat(companyList);
                $scope.currentCompany = all;
            });
    	}else{
        	var promise = UserInfoService.getCompanyList();
            promise.then(function(companyList){
            	 var allcomp = [{'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)}];
            	 $scope.companyList = allcomp.concat(companyList);
            });
    	}
    }

  //切换分公司
    $scope.changeCompany = function(company){
        $scope.currentCompany = company;
        loadData();
        $modal.action({id:'company-action',act:'close'});
    };
    
    
    
    
    
    function getTime(number){
        var now = new Date();
        var date;
        if(number>180){
     	   date = new Date(number);
        }else{
     	   date = new Date(now.getTime()-number*24*3600*1000);
        }
        var year = date.getFullYear()
        var month = date.getMonth()+1;
        if(month > 12) month = 1;
        var day = date.getDate();
        if(month < 10)
            month = "0"+month;
        if(day < 10)
            day = "0"+day;
        return year +'-'+month+'-'+day
    }
    
    
   //筛选/过滤器
   $scope.clearnFilter = function(){
       $scope.filter = {};
       $scope.filterConfig.forEach(function(item){
           $scope.filter[item.key] = item.name;
       });
       loadData();
   };

   $scope.changeFilter=function(){
       loadData();
   };

   $scope.changeTime = function(newTime){
       $scope.showDropdown = false;
       $scope.filter.start_date = getTime(newTime);
       $scope.changeFilter();
   };

    $scope.changeTimeauto = function(start,end){
    	$modal.action({id:'changetime-action',act:'open'});
    };

    $scope.searchTimeauto = function(start,end){
    	var startDate = new Date(start);
    	var endDate = new Date(end);
    	if(startDate.valueOf() >endDate.valueOf()){
    		$modal.alert("起始日期不能大于结束日期")
    	}else{
    		startDate = getTime(startDate.valueOf()) === 'NaN-NaN-NaN' ? undefined:getTime(startDate.valueOf());
    		$scope.filter.start_date =startDate;
            $scope.filter.end_date =  getTime(endDate.valueOf());
            $scope.changeFilter();
    	}
    	$modal.action({id:'changetime-action',act:'close'});
    };
    
    
    
    
    //输入关键字搜索
    $scope.closeSearch = function(){
		$scope.showSearchBody = false;
	}
	$scope.showSearch = function(){
		$scope.searchHistory = $istore.getLocal(config.custid+"_orderSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];        	       
		$scope.showSearchBody = true;
	}
    $scope.keySearch = function(keyValue){
    	$scope.searchVal = keyValue;
    	
        loadData();
        var myScroll = $scope.myScroll;
        $scope.showSearchBody = false;   
        saveSearchHistory(keyValue);
    };
    //点击按钮清空搜索内容
    $scope.clickClean = function($event){
    	$event.stopPropagation();
    	$scope.searchVal = "";
    	if(!$scope.showSearchBody){
    		loadData();
    	}
    };
    function saveSearchHistory(keyValue){
    	if(keyValue === null ||　keyValue === "")return;
        var hisstring = $istore.getLocal(config.custid+"_receiptSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];
        var dup = false;
        hisstring.forEach(function(item){
        	if(item === keyValue)
        		dup = true;
        })
        if(!dup){
        	if(hisstring.length < 10){
        		hisstring.unshift(keyValue);
            }else{
            	hisstring.pop();
            	hisstring.unshift(keyValue)
            }
            $istore.setLocal(config.custid+"_receiptSearchHistory_"+$rootScope.currentUser.UserEntitycustomId,hisstring);
        }
    	
    }
    
    
    

    $scope.loadMore = function () {
        $scope.page = $scope.page+1;
        
        var filter = angular.copy($scope.filter);
        for(var key in filter){
            $scope.filterConfig.forEach(function(item){
                if(key === item.key  && filter[key] === item.name){
                    filter[key] = undefined;
                }
            })
        }
        
  
        promise = OrderService.getOrderList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId);
        
        if(promise){
        	promise.then(function(result){
        		var orderList = [];
        		if(result.status == "000"){
        			orderList =  result.orderList;
        		}
        		var orders = processData(orderList);
                for(var i=0;i<orders.length; i++){
                   $scope.orders.push(orders[i]);
                }
            	refresh();
        	})
        }
    };
    
    function loadData() {
    	$scope.page = 0;
    	
    	var filter = angular.copy($scope.filter);
    	for(var key in filter){
    		$scope.filterConfig.forEach(function(item){
    			if(key === item.key  && filter[key] === item.name){
    				filter[key] = undefined;
				}
			})
		}
    	
        var promise;
        if($rootScope.role.RoleEntityid != 1)
        	promise = OrderService.getOrderList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.oper.OperatorEntitycustomId);
        else
        	promise = OrderService.getOrderList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId);
        if(promise){
        	promise.then(function(result){
        		var orderList = [];
        		if(result.status == "000"){
        			orderList =  result.orderList;
        		}
                $scope.orders =	processData(orderList);
            	refresh();
        	})
        }
    }
    
    
    function processData(receipts){
    	receipts.forEach(function(receipt){
        });
		return receipts;
    }
    function refresh(flag){
    	$timeout(function(){
            var myScroll = $scope.myScroll;
            if($scope.page == 0)
            	myScroll.scrollTo(0,0);
            myScroll.refresh();
    	},501)
    }
    
  //点击选中
    $scope.changeCheck=function (cartProduct) {
    	
        /*calculatePrice()*/
    }
    
    //全选框相关操作
    $scope.allCheck=function () {
    	if($scope.isAllCheck){
            $scope.cartProducts.forEach(function(item){
            	if(item.onSale =='1')
            		item.isCheck = true;
        	})
    	}else{
    		$scope.cartProducts.forEach(function(item){
        		item.isCheck = false;
        	})
    	}
    	calculatePrice();
    };
    
    function calculatePrice() {
        var totalPrice = 0
        var totalCount = 0;
        $scope.cartProducts.forEach(function(data){
            if(data.isCheck){
            	totalPrice = $number.add(totalPrice,$number.multiply(data.price,data.count))
            	totalCount = totalCount+1;
            }
        });
        //处理总价 type-2
        $scope.totalPrice = (Number(totalPrice).moneyFormat(typeArray[2])).money();
        $scope.totalCount = totalCount;
    }
    
    initPage();

}]);


angular.module("myApp").controller("relatedOrderDetailCtrl",["$rootScope","$scope",'$state','$stateParams','$modal','receiptService','UserInfoService',
                                    function ($rootScope,$scope,$state,$stateParams,$modal,receiptService,UserInfoService) {
    //取得传过来的参数
    var receiptId = $stateParams.id;
    
 
    

}]);
