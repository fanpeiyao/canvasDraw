/**
 * Created by chent on 2017/1/18.
 */
// 产品列表
angular.module("myApp").controller("ProductCtrl",["$scope","$rootScope","$timeout","$state",'$istore','$modal','$number',"ProductService","UserInfoService",
                                                  function ($scope,$rootScope,$timeout,$state,$istore,$modal,$number,ProductService,UserInfoService) {

	
	
    //初始化
	$scope.products = [];
	
    function initPage(){
    	$scope.page = 0;
    	$scope.keyValue="";
    	$scope.categoryId=undefined;
    	
    	$scope.filter={};
        $scope.filterConfig = [];
        
        $scope.tab = false;
        if($scope.config.filter){
             $scope.tab = true;
       		 $scope.filterConfig = angular.copy($scope.config.filter);
             $scope.filterConfig.forEach(function(item){
                 item.values = [item.name].concat(item.values);
                 $scope.filter[item.key] = item.name;
    		 })
	    }
        $scope.searchVal = "";
        
        if($rootScope.role.RoleEntityid != 1 && !$rootScope.oper){
			$scope.selectDealer();
        }else{
             	var promise = UserInfoService.getCompanyList();
             	promise.then(function(companyList){
    	            if(companyList.length > 0){
	            		 $scope.companyList = companyList;
	            		 var currentCompany = UserInfoService.getCurrentCompany();
	            		 var existcurrentCompany = false;
	                     if(currentCompany){
	                    	 $scope.companyList.forEach(function(item){
	                    		 if(item.companyId == currentCompany.companyId)
	                    			 existcurrentCompany =true
	                    	 })
	                     }
	                     if(currentCompany&& existcurrentCompany){
	                     	$scope.currentCompany = currentCompany;
	                      }else{
	                    	  	$scope.currentCompany = $scope.companyList[0];
	                            UserInfoService.setCurrentCompany($scope.currentCompany);
	                      } 
	                      loadData();
	                     
			       	 }else{
			       		$modal.alert("经销商未绑定分公司，请联系公司绑定后方可查看产品!",function(){
			       			if($rootScope.role.RoleEntityid == 2){
				       			$scope.selectDealer();
				       		}else{
				       			$state.go("app"); 
				       		}
				        })
			       	 }
             	})
        }	
    }
   
    //获取分类
    $scope.showCateList = function () {
    	if(!$scope.firsts){
    	    var promise = ProductService.getCategoryInfo();
    	    promise.then(function(result){
    	    	var cateData=result.dataList;
                var firsts=[];
                var seconds=[];
                cateData.forEach(function(item){
             	   if(item.level==="1")
             		   firsts.push(item);
             	   if(item.level==="2")
             		   seconds.push(item)
                })
                firsts.forEach(function(item){
             	   var childs = findChilds(item,seconds);
             	   item.childs = childs;
                })
                
                function findChilds(first,seconds){
             	   var childs = [];
             	   seconds.forEach(function(item){
             		   if(item.pId === first.id)
             			   childs.push(item);
             	   })
             	   return childs;
                }
                
                $scope.firsts = firsts;
                if(firsts.length>0){
             	   $scope.firstChecked = firsts[0];
                   $scope.seconds = $scope.firstChecked.childs;
                }
    	    })
    	}
        $scope.showSearchTypeBody = true
    }
   
   $scope.changeSearchtype = function(first){
	  $scope.firstChecked = first;
	  $scope.seconds = first.childs;
   };
   $scope.checkSencond=function(secondChecked){
	   $scope.secondChecked = secondChecked;
   }
   
   //确定搜索
   $scope.searchType = function () {
       $scope.page = 0;
       if($scope.secondChecked){
    	   $scope.categoryId = $scope.secondChecked.id;
       }else if($scope.firstChecked){
    	   $scope.categoryId = $scope.firstChecked.id;
       }
       loadData();
	   $scope.showSearchTypeBody = false;
   }
   $scope.deleteTypethis = function () {
	   $scope.firstChecked = undefined;
	   $scope.secondChecked = undefined;
	   $scope.categoryId = undefined;
	   loadData();
	   $scope.showSearchTypeBody = false;
   };
   
   
   
    /**
     * key search 
     */
	//为Local storage key 服务

    //搜索功能
    //输入关键字搜索
    //如果要做联想，要考虑防抖
    //$scope.$watch("model-name",function(newValue,oldValue){if(newValue === oldValue){return;} $debounce(applyQuery,350);}
    //
    $scope.showSearch = function(){
        //search history
        $scope.productSearchHistory = $istore.getLocal(config.custid+"_productSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];
        //search type history
        $scope.hotProducts = [];
        var promise = ProductService.getHotProducts();
        if(promise){
        	promise.then(function(result){
            	if(result){
            		$scope.hotProducts = result.queryList;
            	}
        	})
        }
    	$scope.showSearchBody = true;
    }
    
    
    $scope.clearnFilter = function(){
        $scope.page = 0;
        $scope.filter = {};
        $scope.filterConfig.forEach(function(item){
            $scope.filter[item.key] = item.name;
        });
        loadData();
    };

    $scope.changeFilter=function(){
        $scope.page = 0;
        loadData();
    };
    
    
    $scope.keySearch = function(keyValue){
        $scope.page = 0;
        $scope.searchVal = keyValue;
        loadData();
        $scope.showSearchBody = false;   
        saveSearchHistory(keyValue);
    }

    //点击按钮进行搜索
    $scope.clickSearch = function(clickValue){
    	$scope.searchVal = clickValue;
    	$scope.page = 0;
    	loadData();
    	$scope.showSearchBody = false;
    	saveSearchHistory(clickValue)
    }
    //点击按钮清空搜索内容
    $scope.clickClean = function($event){
    	$event.stopPropagation();
    	$scope.searchVal = '';
    	$scope.page = 0;
    	if($scope.showSearchBody == false){
    		loadData();
    	}
    } 
    //点击取消恢复搜索
    $scope.closeSearch = function(){
		$scope.showSearchBody = false;
    }
    function saveSearchHistory(keyValue){
    	if(keyValue == null ||　keyValue == "")return;
    	//search history
        var hisstring = $istore.getLocal(config.custid+"_productSearchHistory_"+$rootScope.currentUser.UserEntitycustomId) ||[];
        var dup = false;
        hisstring.forEach(function(item){
        	if(item === keyValue)
        		dup = true;
        })
        $scope.productSearchHistory = hisstring;
        if(!dup){
        	if(hisstring.length < 10){
        		hisstring.unshift(keyValue);
            }else{
            	hisstring.pop();
            	hisstring.unshift(keyValue)
            }
        	$istore.setLocal(config.custid+"_productSearchHistory_"+$rootScope.currentUser.UserEntitycustomId,hisstring);
        }
    }
    
    $scope.changeCompany = function(company){
    	$scope.page = 0;
    	$scope.searchVal = "";
        $scope.currentCompany = company;
        UserInfoService.setCurrentCompany(company);
        loadData();
        $scope.firstChecked = null;
        $scope.secondChecked = null;
    };
    
    
    
    $scope.refreshPage = function () {
        $scope.page = 0;
        loadData();
    };
    $scope.loadMore = function () {
        $scope.page =  $scope.page+1;
        var filter = angular.copy($scope.filter);
        for(var key in filter){
            $scope.filterConfig.forEach(function(item){
                if(key === item.key  && filter[key] === item.name){
                    filter[key] = undefined;
                }
            })
        }
        var promise = ProductService.getProductList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.categoryId);
        if(promise){
        	promise.then(function(result){
        		 var products = [];
        		if(result.status == "000"){
        			 products = result.dataList || [];
        			 products.forEach(function(item){
        		        item.picFilePath = item.picFilePath ? item.picFilePath : "views/product/img/default.jpg";
        		        item.count = 1;
        		        //处理单价 type-0
        		        item.price = (Number(item.price).moneyFormat(typeArray[0])).money();
        		     })
        		}
        		for(var i=0; i<products.length; i++){
                    $scope.products.push(products[i]);
                }
        		refresh(true);
        	})	
        }
        
    };
    function loadData() {
    	var filter = angular.copy($scope.filter);
    	for(var key in filter){
    		$scope.filterConfig.forEach(function(item){
    			if(key === item.key  && filter[key] === item.name){
    				filter[key] = undefined;
				}
			})
		}

    	
        var promise = ProductService.getProductList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.categoryId);
        if(promise.then){
        	promise.then(function(result){
        		 var products = [];
        		if(result.status == "000"){
        			 products = result.dataList || [];
        			 products.forEach(function(item){
        		        item.picFilePath = item.picFilePath ? item.picFilePath : "views/product/img/default.jpg";
        		        item.count = 1;
        		        item.old_price = Number(item.price);
        		        //处理单价 type-0
        		        item.price = (Number(item.price).moneyFormat(typeArray[0])).money();
        		        //处理成本价(cost)运费(shipFee) type-3
        		        item.cost != null && item.cost != undefined  ? item.cost = (Number(item.cost).moneyFormat(typeArray[3])).money() : item.cost=''; 
        		        item.shipFee != null && item.shipFee != undefined ? item.shipFee = (Number(item.shipFee).moneyFormat(typeArray[3])).money() : item.shipFee =''; 
        			 })
        		}
        		$scope.products = products;
        		refresh();
        	})	
        }
    }
    function refresh(flag){
    	$timeout(function(){
            var myScroll = $scope.myScroll;
            if(!flag)
              	myScroll.scrollTo(0,0);
            myScroll.refresh();
    	},501)
    }


    //选择经销商功能
	$scope.selectDealer = function(){
     	var promise = UserInfoService.getDealerList(0);
     	promise.then(function(arys){
     		if(arys.status === "000"){
     			$scope.dealerList = arys.dealerList;
     			$scope.allPage =  Math.floor(arys.total /10);
	    	}else{
	    		$scope.dealerList = [];
	    	}
     	})
     	$scope.showpopup=true
    }
	
	
    $scope.closePopup = function(){
    	$scope.showpopup=false
    }
	$scope.changeDealer = function(dealer){
    	var promise = UserInfoService.setDealer(dealer);
    	promise.then(function(arys){
    		if(arys.status === "000"){
    			$rootScope.oper = arys.curOper;
        		$scope.showpopup=false;
            	initPage();
        	}else{
        		$modal.alert("设置经销商失败！") ;
        	}
    	})
    }
    
    $scope.showCartAction = function(product){
    	$scope.preAddProduct = product;
    	$modal.action({id:'cartproduct-action',act:'open'});
    }
	
    initPage();
}]);


//产品详情
myApp.controller("ProductDetailCtrl",["$scope","$timeout",'$stateParams','$number','$modal','ProductService','UserInfoService',
                                      function ($scope,$timeout,$stateParams,$number,$modal,ProductService,UserInfoService) {
	
	
	//取得传过来的参数
    var productId = $stateParams.productId;
    var promise = ProductService.getProductDetail(productId);
    if(promise){
    	promise.then(function(result){
    		if(result.status == "000" || result.retCode == "200"){
	            var productInfo = result.productInfo;
	            productInfo.picFilePath = productInfo.picFilePath ? productInfo.picFilePath : "views/product/img/default.jpg";
	            productInfo.count = 1;
	        	$scope.product = productInfo;
	        	$scope.product.old_price = Number($scope.product.productPrice );
	        	//处理单价 type-0
	        	$scope.product.productPrice = (Number($scope.product.productPrice).moneyFormat(typeArray[0])).money();
		        //处理成本价(cost)运费(shipFee) type-3
		        $scope.product.cost  != null && $scope.product.cost  != undefined  ? $scope.product.cost = (Number($scope.product.cost).moneyFormat(typeArray[3])).money():$scope.product.cost =''; 
		        $scope.product.shipFee  != null && $scope.product.shipFee != undefined  ? $scope.product.shipFee = (Number($scope.product.shipFee).moneyFormat(typeArray[3])).money():$scope.product.shipFee='';
	        }else{
	        	$modal.alert("未的查到该产品的明细!")
	        }
    	})
    	
	    
	    $scope.showAction = function(product){
			$scope.preAddProduct = product;
	    	$modal.action({id:'cartproduct-action',act:'open'});
	    }
    }

}]);

