/**
 * Created by chent on 2017/1/18.
 */

angular.module("myApp").controller("mstatementCtrl",["$scope",'$state','$stateParams','$modal','mstatementService',
                                    function ($scope,$state,$stateParams,$modal,mstatementService) {
   
	 var page,time,status,key;  
	//为Local storage key 服务
    
    $scope.changeStatus = function(newStatus){
        page = 0;
        status = newStatus;
        loadOrders(status,page,time,key,$scope.currentCompany.companyId);
    };
}])


//产品详情
myApp.controller("mstDetailCtrl",["$scope","$timeout",'$stateParams','$modal','mstatementService',
                                    function ($scope,$timeout,$stateParams,$modal,mstatementService) {
	

}]);

