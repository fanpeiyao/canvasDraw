/**
 * Created by chent on 2017/2/8.
*/
angular.module('myApp').controller('LoginCtrl',['$es','$scope','$rootScope','$state','$istore','$modal','LoginService',function ($es,$scope,$rootScope,$state,$istore,$modal,LoginService) {

	function initPage(){
		$scope.logoUrl = config.basic.logo || "views/account/img/logo.png";
		$scope.companyName = config.basic.companyName || "核心企业电子供应链平台";
		if($istore.getLocal(config.custid+"_loginName"))
			 $scope.loginName = $istore.getLocal(config.custid+"_loginName");
	}
	$scope.fullyear = new Date().getFullYear();
	$scope.randomCode = function(){
	     $scope.codeurl = "../~main/captcha.php?"+Math.random();
	};
	$scope.showValidate = $istore.getLocal(config.custid+"_showValidate") || false;
	if($scope.showValidate)
		$scope.randomCode();

	  $scope.login = function(){
		  $.toast.show('loading');
         //处理登陆事宜
         var promise = LoginService.userLogin($scope.loginName,$scope.password,$scope.code,zddlvxid,$scope.showValidate);
         if(promise.then){
        	 promise.then(function(result){
                 if(result.retCode === "200"){
                	if(result.isFirstLogin){
                   	 $state.go('account.firstLogin');
                   }else{
                   	$istore.removeLocal(config.custid+"_showValidate");
                    	$istore.setLocal(config.custid+"_loginName",$scope.loginName);
                    	 if(result.onlineCount && result.onlineCount >1)
                    		 $modal.alert("此账户已在其他设备上登录，请谨慎操作",function(){
                    			location.href="index.php";
                    		 });
                    	else
                    		location.href="index.php";
                   }
                 }else{
                    	 $modal.alert(result.retMsg || result.retmsg);
                    	 $scope.randomCode();
                    	 $scope.showValidate = true;
                    	 $istore.setLocal(config.custid+"_showValidate",true);
                }
                $.toast.close();
             },function(error){
            	 $modal.alert("系统错误！");
            	$.toast.close();
             })
         }else{
        	 $modal.alert("系统错误！");
        	$.toast.close();
         }
     }
	
	$scope.register = function(){
		if($es.getConfig('custid') == 'larq'){
			location.href= "http://109.6.29.155:9610/larq/app/mobile/register.php" ;
		}else{
			$modal.alert('该功能暂未开放');
		}
	}
	initPage();
    
}]).controller("FindPwdCtrl",['$rootScope','$scope','$state','$timeout','$modal','$interval','LoginService',function($rootScope,$scope,$state,$timeout,$modal,$interval,LoginService){
	 $scope.getCodeText = "获取验证码";
      $scope.getValidateCode = function(mobilePhone,loginName){
             		 var promise = LoginService.getValidateCode(mobilePhone,loginName);
             		 promise.then(function(result){
             			 if(result.retCode !== "200"){   
                              $modal.alert(result.retMsg||"您的账号暂不能使用忘记密码功能，请联系企业咨询!")
                              $scope.showTip = false;
                          }else{
                        	  $scope.showTip = true;
                          }
             		 })
                     //点击之后 倒计时
            		 $scope.countingDown = true;
                     var i = 60;
                     var timer = $interval(tick,1000,60);
                     function tick(){
                         i--;
                         $scope.getCodeText = "请等待("+i+")s";
                     }
                     timer.then(function(){
                    	 $scope.getCodeText = "获取验证码";
                    	 $scope.countingDown = false;
                     })
            	  }
      
			      $scope.goBack = function(){
			      	$rootScope.transition = "slide-left";
			      	$timeout(function(){
			              if($scope.backState )
			                  $state.go($scope.backState);
			      	})
			      };
      
      
            	  $scope.findPassword = function(loginName,mobilephone,validateCode,password,repeatPassword){
   	                   $.toast.show('loading');
            		   var promise = LoginService.findPassword(loginName,mobilephone,validateCode,password);
            		   if(promise.then){
                		   promise.then(function(data){
                			   if(data.retCode === "200"){
                					   $modal.alert("找回密码成功，请使用新密码重新登录！",function(){
                						   $state.go("account.login")
                					   })
                			   }else{
                				   $modal.alert(data.retMsg || "您的账号暂不能使用忘记密码功能，请联系企业咨询。");
                			   }
                		   },function(error){
                          	 $modal.alert("您的账号暂不能使用忘记密码功能，请联系企业咨询。");
                         })
                         $.toast.close();
            		   }else{
            			   $modal.alert("系统错误。");
            			   $.toast.close();
            		   }
            	  }       	 
}]).controller("BindCtrl",['$scope','$state','$interval','$modal','LoginService',function($scope,$state,$interval,$modal,LoginService){
				$scope.getCodeText = "获取短信验证码";
				$scope.getValidateCode = function(mobilePhone,loginName){
           		 	var promise = LoginService.getValidateCode(mobilePhone,loginName);
           		 	promise.then(function(result){
           		 		if(result.retCode !== "200"){   
                            $modal.alert(result.retMsg||"您的账号暂不能使用忘记密码功能，请联系企业咨询!")
                            $scope.showTip = false;
                        }else{
                      	  $scope.showTip = true;
                        }
           		 	})
                   //点击之后 倒计时
          		 $scope.countingDown = true;
           		 	var i = 60;
           		 	var timer = $interval(tick,1000,60);
           		 	function tick(){
           		 		i--;
                       	$scope.getCodeText = "请等待("+i+")s";
           		 	}
           		 	timer.then(function(){
           		 		$scope.getCodeText = "获取验证码";
                  	 	$scope.countingDown = false;
           		 	})
          	  	}
            	   
            	$scope.firstLogin = function(mobilePhone,code,oldPassword,newPassword,repeatPassword){
            		var promise = LoginService.firstLogin(mobilePhone,code,oldPassword,newPassword,repeatPassword);
            		if(promise.then){
            			promise.then(function(result){
            				if(result.retCode && result.retCode == "200"){
            					//$state.go("app");
            					location.href="index.php";
            				}else{
            					$modal.alert("修改密码或手机号出错！");
            				}
            			})
            		}else{
            			$modal.alert("系统错误!")
            		}
            	}
}]).controller('registerCtrl',['$scope','$rootScope','$state','$istore','$interval','$modal','LoginService',function ($scope,$rootScope,$state,$istore,$interval,$modal,LoginService) {

	$scope.getCodeText = "获取短信验证码";
	$scope.getValidateCode = function(mobilePhone){
		 var promise = LoginService.getValidateCode(mobilePhone);
		 promise.then(function(result){
			 if(result.retCode !== "200"){   
                 $modal.alert("您的账号暂不能使用绑定手机号功能，请联系企业咨询!");
                 LoginService.userLogout();
             }
		 })
         //点击之后 倒计时
		 $scope.countingDown = true;
         var i = 60;
         var timer = $interval(tick,1000,60);
         function tick(){
             i--;
             $scope.getCodeText = "请等待 ("+i+")s";
         }
         timer.then(function(){
        	 $scope.getCodeText = "获取验证码";
        	 $scope.countingDown = false;
         })
	}
	//展示图片验证码
	$scope.randomCode = function(){
	     $scope.codeurl = "../~main/captcha.php?"+Math.random();
	}();
	//点击注册
	
	
	$scope.refister = function(){
		$.toast.show('loading');
		//注册用户
	    var promise = LoginService.registerUser($scope.loginName,$scope.mobilephone,$scope.validateCode,$scope.password,$scope.repeatPassword,$scope.email,$scope.addr,$scope.phone,$scope.idType,$scope.idNo,$scope.code);
	    if(promise.then){
		   	 promise.then(function(result){
		   		 	console.log(result)
		            if(result.retCode === "200"){
		            	/*if(result.isFirstLogin){
		            		$state.go('account.firstLogin');
		            	}else{*/
			              	/*$istore.removeLocal(config.custid+"_showValidate");
			               	$istore.setLocal(config.custid+"_loginName",$scope.loginName);
			               	 if(result.onlineCount && result.onlineCount >1)
			               		 $modal.alert("此账户已在其他设备上登录，请谨慎操作",function(){
			               			location.href="index.php";
			               		 });
			               	else
			               		location.href="index.php";*/
			              //}
		            }else{
		               	 $modal.alert(result.retMsg || result.retmsg);
		               	 $scope.randomCode();
		           }
		           $.toast.close();
		        },function(error){
		       	 	$modal.alert("系统错误！");
		       	 	$.toast.close();
		        })
		    }else{
		   	 	$modal.alert("系统错误！");
		   	 	$.toast.close();
		    }
	    
	    
	     }
	
	
    
}])
/*
.controller("MobileLogin",function(){
	scope.getCodeText = "获取验证码";
            	scope.getValidateCode = function(mobilephone){
            		 $modal.alert("当前不支持手机登录，开发人员正在努力开发，请敬候佳音！");
            		 return;
            		 UserInfoService.getValidateCode(mobilephone);
            		//点击之后 倒计时
            		 scope.countingDown = true;
                     var i = 60;
                     var timer = $interval(tick,1000,60);
                     function tick(){
                         i--;
                         scope.getCodeText = "请等待 ("+i+")s";
                     }
                     timer.then(function(){
                    	 scope.getCodeText = "获取验证码";
                    	 scope.countingDown = false;
                     })
            	}
            	scope.checkCode = function(mobilephone,validateCode){
            		var result = UserInfoService.mobileLogin(mobilephone,validateCode);
                    //点击之后 倒计时
                    if(result.retCode == "200"){
                        event.preventDefault();
                        $state.go('app');
                    }else{
                        scope.errorMessage = result.retmsg || result.retMsg;
                        scope.showError = true;
                    }
            	}
})
*/