angular.module("myApp").controller("DeliveryListCtrl",["$scope","$timeout","$rootScope",'$istore','$modal',"DeliveryService","UserInfoService",function ($scope,$timeout,$rootScope,$istore,$modal,DeliveryService,UserInfoService) {
	
	
	$scope.deliverys = [];
	
    function initPage(){
        var deliveryStatusArray = DeliveryService.getDeliveryStatusArray();
        $scope.deliveryStatusArray = deliveryStatusArray;
        $scope.page =0;
        
        $scope.filter={};
        $scope.filterConfig = [];
        $scope.filter.deliveryBeginTime = getTime(30);
        if($scope.config.filter){
            $scope.filterConfig = angular.copy($scope.config.filter);

            $scope.filterConfig.forEach(function(item){
                item.values = [item.name].concat(item.values);
                $scope.filter[item.key] = item.name;
            })
        }

        
        $scope.searchVal = "";
        
        if($rootScope.role.RoleEntityid != 1)
     	   $scope.oper = {'OperatorEntitycustomId':undefined,'OperatorEntityuserName':$is3n("全部{%=common.customerName%}",config.custid)};
        $scope.currentCompany = {'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)};

        loadData();
        getCompany();
    }
    
    
    //根据经销商获取分公司
	$scope.selectDealer = function(){
     	var promise = UserInfoService.getDealerList(0);
     	promise.then(function(arys){
     		if(arys.status === "000"){
     			$scope.dealerList = arys.dealerList;
     			$scope.allPage =  Math.floor(arys.total /10);
	    	}else{
	    		$scope.dealerList = [];
	    	}
     	})
     	$scope.showpopup=true;
     }
    $scope.closePopup = function(){
    	$scope.showpopup=false;
    }
	$scope.changeDealer = function(dealer){
		dealer = {'OperatorEntitycustomId':dealer.customerId,
				'OperatorEntityuserName':dealer.userName};
		$scope.oper = dealer;
    	getCompany(dealer.OperatorEntitycustomId)
		$scope.dealerFlag = true;
    	$scope.showpopup=false;
    	loadData();
    	getCompany();
    }
    $scope.changeCompany = function(company){
    	$scope.searchVal = "";
        $scope.currentCompany = company;
        loadData();
    };
    function getCompany(){
    	if($rootScope.role.RoleEntityid != 1){
    		var promise = UserInfoService.getDealerCompanyList($scope.oper.OperatorEntitycustomId);
            promise.then(function(result){
            	var companyList = result.dataList;
            	var all ={'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)};
                $scope.companyList =[all].concat(companyList);
                $scope.currentCompany = all;
            });
    	}else{
        	var promise = UserInfoService.getCompanyList();
            promise.then(function(companyList){
            	 var allcomp = [{'companyId':undefined,'companyName':$is3n("全部{%=common.company%}",config.custid)}];
            	 $scope.companyList = allcomp.concat(companyList);
            });
    	}
    }

    function getTime(number){
    	var now = new Date();
    	var date;
    	if(number>180){
     	   date = new Date(number);
        }else{
     	   date = new Date(now.getTime()-number*24*3600*1000);
        }
    	var year = date.getFullYear()
    	var month = date.getMonth()+1
    	if(month > 12) month = 1;
    	var day = date.getDate();
    	if(month < 10)
    		month = "0"+month;
    	if(day < 10)
    		day = "0"+day;
    	return year +'-'+month+'-'+day
    }

    $scope.clearnFilter = function(){
       $scope.filter = {};
       $scope.filterConfig.forEach(function(item){
           $scope.filter[item.key] = item.name;
       });
       loadData();
   };

    $scope.changeFilter=function(){
       loadData();
    };
    $scope.changeTime = function(newTime){
    	$scope.showDropdown = false;
        $scope.changeFilter("deliveryBeginTime",getTime(newTime));

    };
    //自定义时间
    $scope.changeTimeauto = function(start,end){
    	$modal.action({id:'changetime-action',act:'open'});
    };
    $scope.searchTimeauto = function(start,end){
    	var startDate = new Date(start);
    	var endDate = new Date(end);
    	if(startDate.valueOf() >endDate.valueOf()){
    		$modal.alert("起始日期不能大于结束日期")
    	}else{
    		startDate = getTime(startDate.valueOf()) === 'NaN-NaN-NaN' ? undefined:getTime(startDate.valueOf());
    		$scope.filter.deliveryBeginTime = startDate;
            $scope.filter.deliveryEndTime = getTime(endDate.valueOf());
            $scope.changeFilter();
    	}
    	
    	$modal.action({id:'changetime-action',act:'close'});
    };

    
    
    
    //输入关键字搜索
    
    $scope.closeSearch = function(){
		$scope.showSearchBody = false;
	}
	$scope.showSearch = function(){
        $scope.searchHistory = $istore.getLocal(config.custid+"_deliverySearchHistory") ||[];
		$scope.showSearchBody = true;
	}
    
    $scope.keySearch = function(keyValue){
    	$scope.searchVal = keyValue;
        loadData();
        $scope.showSearchBody = false;   
        saveSearchHistory(keyValue);
    };
   
    //点击按钮清空搜索内容
    $scope.clickClean = function($event){
    	$event.stopPropagation();
    	$scope.searchVal = "";
    	if($scope.showSearchBody == false){
    		loadData();
    	}
    };
    function saveSearchHistory(keyValue){
    	//search history
    	if(keyValue == null ||　keyValue == "")return;
        key = keyValue;
        var hisstring = $istore.getLocal(config.custid+"_deliverySearchHistory") ||[];
        var dup = false;
        hisstring.forEach(function(item){
        	if(item === keyValue)
        		dup = true;
        })
        if(!dup){
        	if(hisstring.length < 10){
        		hisstring.unshift(keyValue);
            }else{
            	hisstring.pop();
            	hisstring.unshift(keyValue)
            }
            $istore.setLocal(config.custid+"_deliverySearchHistory",hisstring);
        }
    }

    
    
    $scope.loadMore = function () {
        $scope.page = $scope.page+1;
        
        //处理过滤器内容
        var filter = getFilter();
        
        var promise
        if($rootScope.role.RoleEntityid == 1)
        	promise= DeliveryService.getDeliveryList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId);
        else
        	promise= DeliveryService.getDeliveryList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.oper.OperatorEntitycustomId);
        
        promise.then(function(result){
        	var deliverys = [];
		    if(result)
		        deliverys = result.deliveryList;
		    processData(deliverys);
		    for(var i=0; i<deliverys.length; i++){
	            $scope.deliverys.push(deliverys[i]);
	        }
	    	refresh();
        })
    };
    
    function loadData() {
    	$scope.page = 0;
        var filter = getFilter();
        
        var promise
        if($rootScope.role.RoleEntityid == 1)
        	promise= DeliveryService.getDeliveryList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId);
        else
        	promise= DeliveryService.getDeliveryList(filter,$scope.page,$scope.searchVal,$scope.currentCompany.companyId,$scope.oper.OperatorEntitycustomId);
    	
    	if(promise){
        	promise.then(function(result){
        		var deliverys = [];
		        if(result)
		        	deliverys = result.deliveryList;
		    	processData(deliverys);
		    	$scope.deliverys = deliverys;
		    	refresh();
        	})	
        }
    }
    
    function getFilter(){
    	 var filter = angular.copy($scope.filter);
         for(var key in filter){
             $scope.filterConfig.forEach(function(item){
                 if(key === item.key  && filter[key] === item.name){
                     filter[key] = undefined;
                 }
             })
         }
         return filter;
    }
    
    function processData(deliverys){
        deliverys.forEach(function(delivery){
        	//处理总价 type-2
    		delivery.amount = (Number(delivery.amount).moneyFormat(typeArray[2])).money();
        	$scope.deliveryStatusArray.forEach(function(item){
        		if(delivery.deliveryStatus === item.id)
        			delivery.statusName = item.name;
        	})
        });
    }
    
    function refresh(flag){
    	$timeout(function(){
            var myScroll = $scope.myScroll;
            if($scope.page ==0)
               myScroll.scrollTo(0,0);
            myScroll.refresh();
    	},501)
    }

    initPage();
}]);

myApp.controller("DeliveryDetailCtrl",["$scope",'$stateParams','DeliveryService',function ($scope,$stateParams,DeliveryService) {
    //取得传过来的参数
    var deliveryId = $stateParams.deliveryId;
    
    var promise= DeliveryService.getDeliveryDetail(deliveryId);
    if(promise){
    	promise.then(function(result){
    		if(result && result.delivery){
    			var deliveryDetail = result;
    			var delivery = deliveryDetail.delivery;
 		        var deliveryStatusArray = DeliveryService.getDeliveryStatusArray();
		        deliveryStatusArray.forEach(function(item){
		        	if(delivery.deliveryStatus === item.id)
		        		delivery.statusText = item.name;
		        })
	        	//处理总价 type-2
	    		delivery.amount = (Number(delivery.amount).moneyFormat(typeArray[2])).money();
		        $scope.delivery = delivery;
		        $scope.productList = deliveryDetail.productList;
		        $scope.productList.forEach(function(item){
		        	//处理单价 type-0
					item.price != null && item.price != undefined  ? item.price = (Number(item.price).moneyFormat(typeArray[0])).money() : item.price=''; 
    		        //处理成本价(cost)运费(shipFee) type-3
    		        item.cost != null && item.cost != undefined  ? item.cost = (Number(item.cost).moneyFormat(typeArray[3])).money() : item.cost=''; 
    		        item.shipFee != null && item.shipFee != undefined ? item.shipFee = (Number(item.shipFee).moneyFormat(typeArray[3])).money() : item.shipFee =''; 
    			 
		        	var orders = deliveryDetail.orderNos;
		        	orders.forEach(function(order){
		        		if(item.orderNo === order.orderNo){
		        			item.orderId = order.id;
		        		}
		        	})
		        })
    		}else{
    			$modal.alert("未查到该提货单信息！")
    		}
    	})
    }else{
    	$modal.alert("未查到该提货单信息！")
    }
}]);
