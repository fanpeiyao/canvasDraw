/**
 * Created by chent on 2017/1/18.
 */
angular.module("myApp").controller("EasyPayCtrl",["$scope","$rootScope","$state","$modal","UserInfoService","EasyPayService",function ($scope,$rootScope,$state,$modal,UserInfoService,EasyPayService) {
	$scope.paySubmit=function(){
		$state.go('easyPay.createPay')
	}
    
}])
.controller("CreatePayCtrl",["$scope","$rootScope","$state","$modal","UserInfoService","EasyPayService",function ($scope,$rootScope,$state,$modal,UserInfoService,EasyPayService) {
	
	$scope.payBtn=function(){
		$state.go('easyPay.confirmPay')
	}
	
    $scope.changeCompany = function(company){
        $scope.currentCompany = company;
        UserInfoService.setCurrentCompany(company);
    };
    
	function init(){
   	 	 var promise = UserInfoService.getCompanyList();
   	 	 promise.then(function(companyList){
   	 		 $scope.companyList = companyList;
   	 		 $scope.currentCompany =  $scope.companyList[0]; 
   	 	 })
	}
    init();
}])
.controller("confirmPayCtrl",["$scope","$rootScope","$state",function ($scope,$rootScope,$state) {
	$scope.payConfirm=function(){
		$state.go('easyPay.paySuccess')
	}
    
}])
.controller("PaySuccessCtrl",["$scope","$rootScope","$state",function($scope,$rootScope,$state){
	$scope.paySuccess=function(){
		$state.go('easyPay.easyPayDetail')
	}
}])




