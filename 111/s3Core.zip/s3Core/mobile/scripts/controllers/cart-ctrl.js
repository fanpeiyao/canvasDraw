/**
 * Created by chent on 2017/1/18.
 */
angular.module("myApp").controller("CartCtrl",["$scope","$rootScope","$state",'$istore','$number','$modal','$timer',"CartService","UserInfoService",
                                               function ($scope,$rootScope,$state,$istore,$number,$modal,$timer,CartService,UserInfoService) {


    //删除购物车产品
    $scope.deleteProduct=function(cartId){
    	var obj = {cartId:cartId}
    	$modal.confirm("删除产品","确定删除该产品?",function (e){
			var cartId = this.cartId;
    		var promise = CartService.deleteProduct(cartId);
    		promise.then(function(result){
    			if(result.status === "000"){
                	loadCartProducts($scope.currentCompany);
                }else{
                	$modal.alert("删除产品失败")
                }
    		})
    	}.bind(obj))									
    }
    
    var step = 1;
    var max = 9999.999//$number.sub(10000,step);
    var min = 0.001;
    //点击减少
    
    var debounce = $timer.debounce(function(cartProduct){
		    	var count =  cartProduct.count; 
		    	var companyId = $scope.currentCompany.companyId;
		    	var cartId = cartProduct.cartId;
		    	var productId = cartProduct.productId;
            	var col = "count";
        		var promise = CartService.editProduct(companyId,cartId,productId,count);
        		if(promise){
        			promise.then(function(result){
        				if(result.status !== "000"){
        					$modal.alert("修改购物车数量失败!");
    					}
        			})	
        		}
        },1000);
    
    $scope.reduceCartPro=function (cartProduct) {
        if($number.sub(cartProduct.count,step) <min ){
        	$modal.alert("不能小于"+min)
            return false;
        }else{
        	cartProduct.count = $number.sub(cartProduct.count,step);
	   		if(cartProduct.isCheck){
	             calculatePrice()
	        }
	   		debounce(cartProduct);
        }
    };
    
    //点击增加
    $scope.addCartPro=function(cartProduct){
        if($number.add(cartProduct.count,step) >max){
        	$modal.alert("数量不能超过"+max)
            return false;
        }else{
        	cartProduct.count = $number.add(cartProduct.count , step);
        	if(cartProduct.isCheck){
                calculatePrice()
            }
        	debounce(cartProduct)
        }
    };
    
    //更改数据
    $scope.changeNumber = function(cartProduct,count){
    	if(count> max){
    		$modal.alert("不能超过"+max)
    		count = max;
    	}
    	if(count<min){
    		$modal.alert("不能小于"+min)
    		count = min;
    	}
    	if(count == undefined){
    		$modal.alert("不符合规范的数量，请输入"+min+"-"+max+"之间的数值，最多保留三位小数")
    		count = step;
    	}
    	var companyId = $scope.currentCompany.companyId;
    	var cartId = cartProduct.cartId;
    	var productId =cartProduct.productId;
    	var promise = CartService.editProduct(companyId,cartId,productId,count);
		if(promise){
	     	promise.then(function(result){
	     		if(result.status == "000"){
	     			cartProduct.count = count;
	     			if(cartProduct.isCheck){
	                    calculatePrice()
	                }
	     		}
	     	})	
	     }
    	
    }
    //控制可修改单价的保留小数位数
    $scope.bitLength = typeArray[0].bitLength;
    $scope.changePrice = function(cartProduct,price){
    	if(price == "" || price == undefined)
    		price = 0;
    	if(cartProduct.isCheck){
            calculatePrice()
        }
    }
    $scope.changePriceEnd = function(cartProduct,price){
    	if(price == "" || price == undefined){
    		$modal.alert("非法的输入，请输入正确的金额！")
    		cartProduct.price = cartProduct.oldPrice;
    		cartProduct.format_price = cartProduct.price;
    	}else{
    		var companyId = $scope.currentCompany.companyId;
        	var cartId = cartProduct.cartId;
        	var productId =cartProduct.productId;
        	var promise = CartService.changePrice(companyId,cartId,productId,price);
    		if(promise){
    	     	promise.then(function(result){
    	     		if(result.status == "000"){
    	     			cartProduct.price = price;
    	     			cartProduct.oldPrice = price;
    	     			cartProduct.format_price = price;
    	     			if(cartProduct.isCheck){
    	                    calculatePrice()
    	                }
    	     		}
    	     	})	
    	     }
    	}
    	
    }
    $scope.changeValueEnd = function(cartProduct,key,value){
    	var companyId = $scope.currentCompany.companyId;
    	var cartId = cartProduct.cartId;
    	var productId =cartProduct.productId;
    	var now = new Date();
    	if(key == "toDate" && (value == undefined || value =="")){
			value = new Date((now/1000+86400)*1000).format();
    	}
		if(Date.parse(new Date(value)) <  Date.parse(now)){
			$modal.alert("收货日期不能早于明天!");
			value = new Date((now/1000+86400)*1000).format();
		}
    	var promise = CartService.updateValue(companyId,cartId,productId,key,value);
    	if(promise){
	     	promise.then(function(result){
	     		if(result.status == "000"){
	     			cartProduct[key] = value;
	     		}
	     	})	
	     }
    }
    
    
    $scope.changeCompany = function(company){
        page = 0;key = undefined;
        $scope.currentCompany = company;
        UserInfoService.setCurrentCompany(company);
        products = loadCartProducts(company);    
    };
     
    
    //点击选中
    $scope.changeCheck=function (cartProduct) {
    	if(!cartProduct.isCheck){
    		$scope.isAllCheck = false;
    	}else{
    		var flag = true;
    		for(var i=0; i<$scope.cartProducts.length;i++){
    			if($scope.cartProducts[i].isCheck != true){
    				flag = false;
    			}
    		}
    		$scope.isAllCheck = flag;
    	}
        calculatePrice()
    }
    
    //全选框相关操作
    $scope.allCheck=function () {
    	if($scope.isAllCheck){
            $scope.cartProducts.forEach(function(item){
            	if(item.onSale =='1')
            		item.isCheck = true;
        	})
    	}else{
    		$scope.cartProducts.forEach(function(item){
        		item.isCheck = false;
        	})
    	}
    	calculatePrice();
    };
    
    
    $scope.cartSubmit = function(){
    	var products = [];
    	$scope.cartProducts.forEach(function(item){
    		if(item.isCheck === true)
    			products.push(item);
    	})	
    	if(products.length === 0){
    		$modal.alert("未选中任何产品！")
    	}else{
    		$istore.set(config.custid+"_order_products",products)
        	$state.go('cart.submitCart')
    	}
    }
    
    function calculatePrice() {
        var totalPrice = 0
        var totalCount = 0;
        $scope.cartProducts.forEach(function(data){
            if(data.isCheck){
            	totalPrice = $number.add(totalPrice,$number.multiply(data.price,data.count))
            	totalCount = totalCount+1;
            }
        });
        //处理总价 type-2
        $scope.totalPrice = (Number(totalPrice).moneyFormat(typeArray[2])).money();
        $scope.totalCount = totalCount;
    }
    
    function loadCartProducts(currentCompany) {
    	var promise =  CartService.getCartList(currentCompany.companyId);
	   	if(promise){
			 promise.then(function(result){
				 var cartList = [];
				 if(result.status === "000")
					 cartList =  result.dataList;
				cartList.forEach(function(item){
						item.old_price = Number(item.price);
						//处理单价 type-0
						item.format_price = (Number(item.price).moneyFormat(typeArray[0])).money();
						//处理可编辑页面单价 type-0
						item.format_price.toString().indexOf(',') != -1 ? item.price = Number(item.format_price.replace(/,/g, '')) : item.price = Number(item.format_price);
						//处理成本价(cost)运费(shipFee) type-3
        		        item.cost != null && item.cost != undefined ? item.cost = (Number(item.cost).moneyFormat(typeArray[3])).money() : item.cost=''; 
        		        item.shipFee != null && item.shipFee != undefined ? item.shipFee = (Number(item.shipFee).moneyFormat(typeArray[3])).money() : item.shipFee=''; 
						item.toDate = item.toDate.replace(/\//g,'-');
			       		item.isCheck = false;
			       		item.picFilePath = item.picFilePath ? item.picFilePath : "views/product/img/default.jpg";
				})
				$scope.cartProducts = cartList; 
				$scope.isAllCheck = false;
				calculatePrice();
			 })	
		 }
    }
    
    
    //选择经销商功能
	$scope.selectDealer = function(){
     	var promise = UserInfoService.getDealerList();
     	promise.then(function(arys){
     		if(arys.status === "000"){
     			$scope.dealerList = arys.dealerList;
     			$scope.allPage =  Math.floor(arys.total /10);
	    	}else{
	    		$scope.dealerList = [];
	    	}
     	})
     	$scope.showpopup=true
     }
    $scope.closePopup = function(){
    	$scope.showpopup=false
    }
	$scope.changeDealer = function(dealer){
    	var promise = UserInfoService.setDealer(dealer);
    	promise.then(function(arys){
    		if(arys.status === "000"){
    			$rootScope.oper = arys.curOper;
    			$scope.dealerFlag = true;
        	}
    		$scope.showpopup=false
        	initPage();
    	})
    }

    function initPage(){
    	if($rootScope.role.RoleEntityid != 1 && !$rootScope.oper){
    		$scope.selectDealer();
        }else{
        	 var promise = UserInfoService.getCompanyList();
        	 promise.then(function(companyList){
            	 if(companyList.length > 0){
            		 $scope.companyList = companyList;
            		 var currentCompany = UserInfoService.getCurrentCompany();
            		 var existcurrentCompany = false;
                     if(currentCompany){
                    	 $scope.companyList.forEach(function(item){
                    		 if(item.companyId == currentCompany.companyId)
                    			 existcurrentCompany =true
                    	 })
                     }
                     if(currentCompany&& existcurrentCompany){
                     	$scope.currentCompany = currentCompany;
                      }else{
                    	  	$scope.currentCompany = $scope.companyList[0];
                            UserInfoService.setCurrentCompany($scope.currentCompany);
                      } 
                     loadCartProducts($scope.currentCompany);
            	 }else{
     	       		$modal.alert("经销商未绑定分公司，请联系公司绑定后方可查看产品!",function(){
    	       			if($rootScope.role.RoleEntityid == 2){
    		       			$scope.selectDealer();
    		       		}else{
    		       			$.dimmer.close();
    		       			$state.go("app"); 
    		       		}
    		        })
            	 } 
        	 })
         }
    }
    //初始化
    initPage();
}])
.controller("SubmitCartCtrl",["$scope","$rootScope","$state","$istore",'$modal',"UserInfoService",function ($scope,$rootScope,$state,$istore,$modal,UserInfoService) {
	
	//获取参数
	var products = $istore.get(config.custid+"_order_products");
	if(!products){
		$modal.alert("产品信息为空,未选择任何产品，请重新选择！",function(){ $state.go("cart.cart");});
	}
	

	$scope.info = {
		deliveryType:$scope.config.deliveryType.options[0],
		paymentMethod:$scope.config.payMethod.options[0]
	};
	if($scope.info.deliveryType.type == 1){
		showAddress();
	}
	
	// chose address
    $scope.selectAdd = function(){
	   	var userId = $rootScope.oper ? $rootScope.oper.OperatorEntityoperatorId : undefined;
	    var promise = UserInfoService.getUserAddress(userId);
        if(promise)
        	promise.then(function(result){
        		var addList=result.addressList;
        	   	if(addList &&　addList.length > 0){
        	   		$scope.addList = addList;
        	   		$scope.showpopup = true;
        	   	}else{
        	   		$modal.alert("您的账户还未添加地址,不能使用配送,请与管理员联系!")
        	   	}
        	})
    }
    $scope.closePopup = function(){
    	$scope.showpopup=false
    }
    $scope.gotoAddress = function(){
    	$state.go("profile.addAddress");
    	$scope.showpopup=false
    }
   
    $scope.changeAdd = function(address){
	    $scope.info.address = address;
	    $scope.showpopup=false
    }
    
    
    $scope.changeDeliveryType = function(dtype){
    	if(dtype === $scope.info.deliveryType)
    		return;
    	$scope.info.deliveryType = dtype;
		if(dtype.type === 1){
			showAddress();
		}
    }
    
    function showAddress(){
		//获取地址
    	var userId = $rootScope.oper ? $rootScope.oper.OperatorEntityoperatorId : undefined;
		var promise =UserInfoService.getUserAddress(userId);
		if(promise)
        	promise.then(function(result){
        		 var addressList= result.addressList;
        	        if(addressList.length == 0){
        	        	$modal.alert("还未添加收货地址，请添加地址！",function(){$state.go("profile.myAddress");});
        	        }
        	        else{
        	        	var address = addressList[0];
        	        	addressList.forEach(function(item){
        	        		if(item.isCurrent == 1){
        	        			address = item;
        	        		}
        	        	})
        	        	$scope.info.address = address;
        	        }
        	})
        else
        	$scope.addressList = [];
    }
    
    if($scope.config.toDate){
    	var now = new Date();
    	$scope.info.ordertoDate = new Date(now.getTime()+24*3600*1000);
    }
    
    
	//点击提交
	$scope.cartConfirm = function(){	
		var now = new Date();
		if($scope.config.toDate &&　$scope.info.ordertoDate == undefined){
			$modal.alert("请选择要货日期!");
			return false;
		}else if(Date.parse($scope.info.ordertoDate) < Date.parse(now)){
			$modal.alert("收货日期不能早于明天!");
			return false;	
		}else{
			$istore.set(config.custid+"_order_info",$scope.info);
			$state.go("cart.confirmCart");	
		}
	}
    
}])
.controller("OrderConfirmCtrl",["$scope","$rootScope","$state","$istore","$number",'$modal',"UserInfoService","CartService",function ($scope,$rootScope,$state,$istore,$number,$modal,UserInfoService,CartService) {
	var products = $istore.get(config.custid+"_order_products");
	var orderinfo = $istore.get(config.custid+"_order_info");

	if(!products ||　!orderinfo)
		$modal.alert("订单信息不完整，请重新选择！",function(){ $state.go("cart.cart");});
	
	var totalAmount = 0;
	var totalCount = 0;
	products.forEach(function(item){
		totalCount = $number.add(totalCount, item.count);
		//处理小计 type-1
		item.total = ($number.multiply(item.count,Number(item.price)).moneyFormat(typeArray[1],1)).money();
		totalAmount = $number.add(totalAmount , $number.multiply(item.count,Number(item.price))).moneyFormat(typeArray[2],1);
	})
	orderinfo.totalCount =totalCount;
	orderinfo.totalAmount = totalAmount.money();
	 function getTime(date){
     	date = new Date(date);
     	var year = date.getFullYear()
     	var month = date.getMonth()+1
     	if(month > 12) month = 1;
     	var day = date.getDate();
     	if(month < 10)
     		month = "0"+month;
     	if(day < 10)
     		day = "0"+day;
     	return year +'-'+month+'-'+day	    
     }
	orderinfo.ordertoDate = getTime(orderinfo.ordertoDate);
	
	$scope.products = products;
	$scope.orderinfo = orderinfo;
	
	
	var company = UserInfoService.getCurrentCompany();
	$scope.company = company;
	if($rootScope.role.RoleEntityid == 1){
		$scope.userinfo = $rootScope.currentUser;
	}else{
		$scope.userinfo = $rootScope.oper;
	}
	$scope.createOrder = function(){
		$.toast.show('loading');
		var promise = CartService.submitCart(company.companyId,products,orderinfo);
		promise.then(function(result){
			if(result && result.retCode==="200"){
				$istore.remove(config.custid+"_order_products");
				$istore.remove(config.custid+"_order_info");
				$state.go("cart.success",{id:result.orderId,orderNo:result.orderNo});
			}else{
				$modal.alert(result.retmsg||"下单失败了");
			}
			$.toast.close();
		})
	}
}])
.controller("OrderSuccessCtrl",['$scope','$stateParams',function($scope,$stateParams){
	var orderNo = $stateParams.orderNo;
	var orderId =  $stateParams.id;
	$scope.order = {
			orderNo:orderNo,
			orderId:orderId
	}
}])

