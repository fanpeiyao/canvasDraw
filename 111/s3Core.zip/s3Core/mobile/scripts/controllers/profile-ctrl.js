angular.module("myApp").controller('InfoCtrl',['$scope','$state','$rootScope','$istore','$modal','UserInfoService',
        function($scope,$state,$rootScope,$istore,$modal,UserInfoService){
            //配置所见
            $scope.selectDealer = function(){
            	$scope.showpopup = true;
            	var promise = UserInfoService.getDealerList();
            	promise.then(function(arys){
             		if(arys.status === "000"){
             			$scope.dealerList = arys.dealerList;
     	     			$scope.allPage =  Math.floor(arys.total /10);
        	    	}else{
        	    		$scope.dealerList = [];
        	    	}
             	})
            }
            $scope.closePopup = function(){
            	$scope.showpopup=false
            }
            
            $scope.changeDealer = function(dealer){
            	var promise = UserInfoService.setDealer(dealer);
            	promise.then(function(arys){
            		if(arys.status === "000"){
            			$rootScope.oper = arys.curOper;
                	}
            		$scope.showpopup=false
            	})
            }
            
            /*切换主题*/
            $scope.selectSkin = function(){
            	$scope.skinList =[{name:'默认皮肤',skinName:'blue'},{name:'吉祥如意',skinName:'red'},{name:'夏绿溢然',skinName:'green'},{name:'一米阳光',skinName:'orange'}];
            	var nowSkin = angular.element("#cssfile").attr("href");
            	var begin = nowSkin.split('/')[2];
            	var end = begin.indexOf('.');
            	$scope.nowSkin= begin.substring(0,end);
            	$modal.action({id:'dealer-action',act:'open'});
            }
            $scope.changeSkin = function(skinName){
            	 var currentSkin = skinName;
                 var nowSkin = $istore.setLocal(config.custid+"_skinHistory",currentSkin);
                 $scope.skinName = currentSkin;
            	 angular.element("#cssfile").attr("href","styles/themes/"+$scope.skinName+".css");
            	 $modal.action({id:'dealer-action',act:'close'});
            }
            
            
            //退出登录
            $scope.userLogout=function(){
            	var result = UserInfoService.userLogout();
            	if(result){
                	location.href="login.php";
            	}
            }
            
        }])
        
    //账户信息
    .controller('myAccountCtrl',['$scope','$rootScope','UserInfoService',
        function($scope,$rootScope,UserInfoService){
    		$scope.user=UserInfoService.getUserInfo(true);
        }])
        
     //地址管理列表
    .controller('AddressCtrl',['$scope','$rootScope','$modal','UserInfoService',
        function($scope,$rootScope,$modal,UserInfoService){
    	var userId = $rootScope.oper ? $rootScope.oper.OperatorEntityoperatorId : undefined;
            var promise=UserInfoService.getUserAddress(userId);
            if(promise)
            	promise.then(function(result){
            		$scope.addressList=result.addressList;
            	})
            else
            	$scope.addressList = [];
               
            //删除地址
            $scope.deleteAddress = function(addrId){
            	var obj = {addrId:addrId};
            	$modal.confirm("删除地址","确定删除该地址，删除后不可恢复?",function(){
            		$scope.$apply(function(){
            			var addrId = this.addrId;
                		var promise = UserInfoService.deleteUserAddress(addrId);
                		promise.then(function(result){
                			if(result.status == "000" || result.retCode == "200"){
                         	    for(var i=0;i<$scope.addressList.length;i++){
                            			if($scope.addressList[i].addrId == addrId){
                            				$scope.addressList.splice(i,1);
                            			}
                            	}
                         		$.toast.show('info',1000).clear();
                            }else{
                               model.alert("删除失败");
                            }
                		})
            		}.bind(obj));
                    
            	})
            };  
          
            //设置默认地址     
            $scope.setDefault = function(list){
            	if(list.isCurrent != 1){
            		var userId = $rootScope.oper ? $rootScope.oper.OperatorEntityoperatorId : undefined;
            		var promise = UserInfoService.setDefaultAddress(list.addrId,userId);
            		promise.then(function(result){
            			if(result.status == "000" || result.retCode == "200"){
                        	$scope.addressList.forEach(function(item){
                        		item.isCurrent = 0;
                        	})
                        	list.isCurrent = 1;
                    		$.toast.show('info',1000).clear();
                        }else{
                           $modal.alert("设置默认地址失败");
                        }
            		})
            	}
            }
            
        }])
    .controller('EditAddressCtrl',['$scope','$state','$stateParams','UserInfoService',
        function($scope,$state,$stateParams,UserInfoService){ 
    		
			//传参服务(数据下标)
    		var addrId = $stateParams.addrId;
		 	var address=UserInfoService.getUserAddress();
		 	var addressList=address.addressList;
		 	for(var i=0;i<addressList.length;i++){
		 		if(addressList[i].addrId==addrId){
				 	$scope.editList=addressList[i];
		 		}
		 	}
		 	
		 	var editList=$scope.editList;;
		 	
		 	//提交表单
	    	$scope.submitForm=function(){
	    		//获取省市区ID
		 		var param={
		 				firstName:addressInfo.name,//收货人
    	 				mobile:addressInfo.phone,//手机号
    	 				provId:addressInfo.provinceCode,//省
    	 				cityId:addressInfo.cityCode,//市
    	 				cityAreaId:addressInfo.districtCode,//区
                		address:addressInfo.detailAddress,//详细地址
                		isBillCurrent:0,
	            		addrId:addrId
		 		}
		 		var promise = UserInfoService.updateUserAddress(param);
		 		promise.then(function(result){
			 		if(result.status == "000" || result.retCode == "200"){
			    		$.toast.show('info',1000).clear();
			    		$state.go("profile.myAddress");
			        }else{
			           $modal.alert("修改地址失败！");
			        }
			        return result;
		 		})
	    	}
        }])
     
     //新增地址
     .controller('AddAddressCtrl',['$scope','$rootScope','$state','$modal','UserInfoService',
        function($scope,$rootScope,$state,$modal,UserInfoService){
    	 	$scope.submitForm=function(){
    	 		var addressInfo=$scope.addressInfo;
    	 		var check=0;
    	 		if(addressInfo.state==true){
    	 			check=1;
    	 		}
    	 		var param={
    	 				firstName:addressInfo.name,//收货人
    	 				mobile:addressInfo.phone,//手机号
    	 				provId:addressInfo.provinceCode,//省
    	 				cityId:addressInfo.cityCode,//市
    	 				cityAreaId:addressInfo.districtCode,//区
                		address:addressInfo.detailAddress,//详细地址
                		isBillCurrent:0,
                		isCurrent:check//是否默认地址
    	 		}
    	 		var userId = $rootScope.oper ? $rootScope.oper.OperatorEntityoperatorId : undefined;
    	 		param.userId = userId;
    	 		var promise = UserInfoService.addUserAddress(param);
    	 		if(promise)
    	 			promise.then(function(result){
    	    	        if(result.status == "000" || result.retCode == "200"){
    	    	    		$.toast.show('info',1000).clear();
    	    	    		$state.go("profile.myAddress");
    	    	        }else{
    	    	           $modal.alert("添加地址失败！");
    	    	        }
    	 			})
    	 	}
        }])