/**
 *
 *
 *   属性包括：

 *
 */
angular.module('myApp').service('claimlistService',['$q','$es','$rootScope','$istore','$modal',function($q,$es,$rootScope,$istore,$modal){
     
   
    this.getDealerCompanyList = function(customerId){
        var param = {
        		customerId:customerId
        };
    	var promise = $es.ajax("companyInfoBean.getCompanyInfoByCustId",param);
    	return promise;
    };
    


}]);

