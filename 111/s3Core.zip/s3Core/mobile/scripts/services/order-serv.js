/**
 * Created by chent on 2017/1/18.
 *
 *  OrderService
 *  订单服务，处理订单相关的数据接口
 *  getOrderStatusArray : 获取订单状态
 *  getOrderList : 获取订单列表(分页)
 *  getOrderDetail :  获取订单详情(送货地址也许要另取 看后台接口)
 *
 *
 */
angular.module("myApp").service("OrderService",['$es',function($es){
	    
        this.getOrderStatusArray = function(){
        	var modules = $es.getConfig("modules");
        	var myorder = modules.myorder || {};
        	if(myorder.status){
        		if(myorder.status.length>1)
        			return [ {id:undefined,name:'全  部'}].concat(myorder.status);
        		else
        			return myorder.status;
        	}else{
                return [
                        {id:undefined,name:'全  部'}
                    ];	
        	}
        };
    
        this.getOrderList = function(filter,page,searchVal,company,customId){
	       	var limit=5;
	       	var param=　{}; 
	       	param.page = page;
        	param.start = page*limit;
        	param.limit = limit;
        	param.orderNo = searchVal;
        	param.dealer = customId;
			for(var key in filter){
					param[key] = filter[key];
			}
        	param.company = company;
        	console.log(param)
	       	var promise=$es.ajax('orderBean.getOrderInfoList',param);
	       	return promise;
	    };

        this.getOrderDetail = function(orderId){
        	
            //get orderDetail
	        var param={
	        		orderId:orderId
	        		}
	    	var promise= $es.ajax('orderBean.getOrderDetailInfo',param);
	        return promise;
	    }
        
        
        this.copyOrder = function(orderId){
        	var params = {"orderId" : orderId}
        	var ary = $es.ajax('orderBean.doCopy', params);
        	return ary;
        }

    }]);