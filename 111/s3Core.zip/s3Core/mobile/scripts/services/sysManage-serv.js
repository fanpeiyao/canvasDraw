/**
 * Created by chent on 2017/1/18
 *
 *  sysService
 *  处理管理员相关的数据接口
 *  getUserList : 获取用户服务的列表
 *  addUser :  增加用户
 *  editUser : 修改用户信息(包含修改手机号)
 *  
 */
angular.module('myApp').service('sysService',['$q','$es','$istore','$modal',function($q,$es,$istore,$modal){
    var userManage = $es.getConfig('userservice');
    var app = $es.getConfig('custid');
    
    //获取有绑定关系的用户列表
	this.getRelateUserList = function(type,page,searchKey,userId){
		var params = {
				page:page ||1,
				searchKey:searchKey,
				type:type,
				userId:userId
			};
    	return $es.ajax("userRelateBean.getLocalUserList",params);
    }
    
	//查询该用户的下级
    this.getChildNodeUser = function(type,userId){
    	var param = { 
    			belongTo:userId,
    			type:type
    		};
    	return $es.ajax("userRelateBean.getUserRelation",param);
    }
    
    //获取可以绑定的用户
    this.getUnbindList = function(userId,pageNum,searchKey){
    	var params = {
    			page:pageNum || 1,
    			searchKey:searchKey,
    			belongTo:userId
    		};
    	return $es.ajax("userRelateBean.getUnbindList",params);
    }
    
    //将某个用户绑定到某个业务员
    this.bindUser = function(user,bindUser,flag){
    	//查询数据库
    	var params = {
    			userId:user.userId,
    			customerId:user.customerId,
    			type:"2",
    			flag:flag,  // 0 解绑，  2 绑定
    			belongTo:bindUser.userId,
    			belongCustomerId:bindUser.customerId
    	};
    	return $es.ajax("userRelateBean.editUserRelation",params);
    }
    
    //获取某个用户未绑定的分公司
    this.getUnbindCompanyList = function(userId){
    	var param = {
    			userId:userId,
    			appid:app
    			};
    	return $es.ajax("userRelateBean.getCompanyList",param);
    }
    //获取某个用户所归属的分公司
    this.getBindCompany = function(userId,customerId){
    	var param = {
    			userId:userId,
    			customerId:customerId,
    			appid:app
    		};
    	return $es.ajax("userRelateBean.getUserCompany",param);
    }
   
    //绑定或解绑某个公司
    this.bindCompany = function(userId,customerId,companyId,companyName,flag){
    	var params = {
    			userId:userId,
    			customerId:customerId,
    			companyId:companyId,
    			companyName:companyName,
    			flag:flag  //0 unbind  2 bind
    	};
    	return $es.ajax("userRelateBean.editUserCompany",params);
    }


    
    //用户信息管理部分
    
    /**
     * 
     * 获取用户信息/列表
     */
    this.getUserList = function(page,key){
           	var limit = 5;
    		//page
            page = page || 1;
            //param
            var param = {
                limit:limit,
                pageNum:page,
                searchKey:key,
                appid:app
            };
            //get data
            var promise = $es.ajax("userManageBean.getUserList",param);
            return promise;
    };
    /**
     * 获取角色列表
     */
    this.getRoleList = function(flag){
    	var promise = $es.ajax("userRelateBean.getRoleList", {});
    	return promise;
    }
    
    /**
     * 增加一个用户，暂时禁止此功能
     */
    this.addUser = function(user){
     	var params = user;
    	var promise = $es.ajax('userManageBean.addUser', params);
    	return promise;
    }
    /**
     *  编辑一个用户，暂时禁止此功能   角色也是可编辑的  后续考虑
     */
    this.editUserInfo = function(user){
		var params = user;
        //get data
        var promise=$es.ajax('userManageBean.editUser', params);
    	return promise;
    };
    /**
     * 重置密码
     * 
     */
    this.resetPassword = function(loginName){
    	var params = {
    			loginName:loginName,
    			appid:app
    	};
    	var promise =  $es.ajax("userManageBean.resetPassword",params);
    	return promise;
    };
    /**
     * 用户激活状态
     */
    this.getUserSenser = function(customerId){
    	var params = {
    			searchValue:customerId
    	}
    	var promise = $es.ajax('userAuthenBean.getUserSensor',params, userManage);
    	return promise;
    }
    
    this.activateUser = function(unionId,status){
    	var params = {};
    	params.unionId = unionId;
    	params.status = status;
    	var promise = $es.ajax('userAuthenBean.userSensor', params,userManage);
    	return promise;
    }
    
    //同步
    
    /**获取同步数据列表*/
    this.getSyncList = function(page,key){
         var promise = $es.ajax('interfaceBean.getInterfaceInfo',{});
         return promise;
    };
    /**
     * 执行同步接口
     */
    this.executeSync = function(interfaceId){
    	var promise = $es.ajax('syncHandBean.executeSync',{interCode:interfaceId});
    	return promise;
    }
}]);