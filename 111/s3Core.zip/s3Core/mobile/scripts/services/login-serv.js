/**
 * Created by chent on 2017/2/13.
 *
 *  UserService
 *  用来处理用户登录信息
 *  userLogin : 用户登录入口
 *  changePassword : 用户修改密码接口
 *  findPassword : 忘记密码找回
 *  getValidateCode : 获取验证码接口
 *  checkValidate : 校验验证码接口
 *   mobileLogin  : 手机登录(后台未实现)
 *
 */


//使用service来创建service对象，确保对象是单例的
angular.module('myApp').service('LoginService',['$es','$q',function($es,$q){

    var userManage = $es.getConfig('userservice');
    var app = $es.getConfig('custid');
    /**
     * 获取公钥 内部函数 UserService 对象私有
     * @param appid
     * @returns {*}
     */
    var getPublicKey = function(appid){
        var param = {};
        if(appid)
            param.appid = appid;
        else
            param.appid =app;
        return $es.ajax('userAuthenBean.getPublicKey',param,userManage,1000);
    };

    /**
     * 用来设置应用内部的用户session
     */
    var setLoginSession = function(){
        return $es.ajax("userInfoBean.setLoginSession",{});
    }
    
    /**
     *  登录
     * @param loginName  登录名
     * @param password  密码
     * @param code   验证码（暂无处理）
     * @returns {*}
     */
    this.userLogin = function(loginName,password,code,zddlvxid,codeFlag){
        var deffered = $q.defer();
        var promise = deffered.promise;
        
        // public key
        getPublicKey().then(function(data1){
        	if(data1.retCode == "200"){
        		var rsakey = new RSAKey();
                rsakey.setPublic(data1.modulus,data1.exponent);
                var pwd = rsakey.encrypt(password);
                var param = {};
                param.loginName = loginName;
                param.password = pwd.toString(16);
                param.appid = app;
                param.platform = "1";
                //验证码 暂时不用
                if(code)
                    param.code = code;
                else
                    param.code = '';
                if(zddlvxid)
                	param.openId = zddlvxid;
                var id = 'userAuthenBean.userLoginNew';
                if(!codeFlag)
                	id = 'userAuthenBean.userLoginNewFirst';
                $es.ajax(id,param,userManage).then(function(data2){
                	if(data2.retCode != "200"){
                		deffered.resolve(data2);
                	}else{ 
                		if(data2.isActive != "1"){
                			deffered.resolve(data2);
	                	}else{
	                        setLoginSession().then(function(data3){	
	                        	if(data2.onlineCount)
	                        		data3.onlineCount = data2.onlineCount;
	                    		if(data2.isFirstLogin == "true")
	                    			data3.isFirstLogin = true
	                        	deffered.resolve(data3);
	                        })
	                	}
                	}
                })
        	}else{
        		deffered.resolve(data1)
        	}
        })
        return promise;
    };

    /**
     * 用户注册
     * @param appid
     * @returns {*}
     */
    this.registerUser = function(username,mobile,validateCode,password,repeatPassword,email,addr,phone,idType,idNo,code){
    	var deffered = $q.defer();
        var promise = deffered.promise;
        // public key
        getPublicKey().then(function(data1){
        	if(data1.retCode == "200"){
        		var rsakey = new RSAKey();
                rsakey.setPublic(data1.modulus,data1.exponent);
                var param = {
    				newPassword : rsakey.encrypt(password).toString(16),
    				repeatPassword : rsakey.encrypt(repeatPassword).toString(16),
    				mobile : mobile,
    				validateCode : validateCode,
    				username : username,
    				email : email,
    				addr : addr,
    				phone : phone,
    				idtype : idType,
    				idno : idNo,
    				code : code
    			}
                param.appid = app;
                console.log(param)
                /*$es.ajax('UserInfoBean.userRegisterNew',param,userManage).then(function(data2){
                	deffered.resolve(data2);
                })*/
        	}else{
        		deffered.resolve(data1)
        	}
        })
        return promise;
    };
    
    this.firstLogin = function(mobile,validateCode,oldpwd,newpwd,confirmpwd){
    	var deffered = $q.defer();
        var promise = deffered.promise;
        getPublicKey().then(function(data1){
        	if(data1.retCode == "200"){
	    		var rsakey = new RSAKey();
	            rsakey.setPublic(data1.modulus,data1.exponent);
	            oldpwd = rsakey.encrypt(oldpwd);
	            newpwd = rsakey.encrypt(newpwd);
	            confirmpwd = rsakey.encrypt(confirmpwd);
	            var params = {
	                    oldPassword:oldpwd.toString(16),
	                    newPassword:newpwd.toString(16),
	                    confirmpassword:confirmpwd.toString(16),
	                    mobile:mobile,
	                    validateCode:validateCode
	            };
	            params.appid = app;
	            $es.ajax("userAuthenBean.editUserInfoByFirstLogin",params, userManage).then(function(data2){
	                	deffered.resolve(data2);
	                })
	        }else{
	        	deffered.resolve(data1)
	        }
    	})
    	return promise;
    }
    
    
    /**
     * 修改密码
     * @param oldPassword
     * @param newPassword
     * @param repeatPassword
     * @param loginName   非必须
     * @param appid        非必须
     * @returns {*}
     */
    this.changePassword = function(oldPassword,newPassword,repeatPassword,loginName,appid){
        

    	var deffered = $q.defer();
        var promise = deffered.promise;
        // public key
    	getPublicKey().then(function(data1){
    		if(data1.retCode == "200"){
        		var rsakey = new RSAKey();
                rsakey.setPublic(data1.modulus,data1.exponent);
                var oldPwd = rsakey.encrypt(oldPassword);
                var newPwd = rsakey.encrypt(newPassword);
                var repeatPwd = rsakey.encrypt(repeatPassword);

                var param = {
                    oldPassword:oldPwd,
                    newPassword:newPwd,
                    repeatPassword:repeatPwd
                };

                if(loginName)
                    param.loginName = loginName;
                if(appid)
                	param.appid = appid;
                else
                    param.appid = app;
                
                $es.ajax("userAuthenBean.changePassword",param,userManage).then(function(data2){
                	deffered.resolve(data2);
                })
        	}else{
        		deffered.resolve(data1)
        	}
    	})
    	return promise;
    };

    /**
     * @param mobile
     * @param code  
     * @param newPassword
     * @param loginName 
     * @param appid      
     * @returns {*}
     */
    this.findPassword = function(loginName,mobilephone,validateCode,newPassword){
    	var deffered = $q.defer();
        var promise = deffered.promise;
        // public key
    	getPublicKey().then(function(data1){
    		if(data1.retCode == "200"){
        		var rsakey = new RSAKey();
                rsakey.setPublic(data1.modulus,data1.exponent);
                newPassword = rsakey.encrypt(newPassword);
                
                var param = {
                    	loginName:loginName,
                        newPassword:newPassword,
                        mobile:mobilephone,
                        validateCode:validateCode
                    };
                       
                param.appid = app;
                
                $es.ajax("userAuthenBean.findPasswordNew",param,userManage).then(function(data2){
                	deffered.resolve(data2);
                })
        	}else{
        		deffered.resolve(data1)
        	}
    	})
    	return promise;
    };
    /**
     * 获取验证码
     * @param phoneNumber
     * @param loginName  非必须
     * @param appid  非必须
     * @returns {*}
     */
    this.getValidateCode = function(phoneNumber,loginName){
        var param = {
            mobile:phoneNumber,
            appid:app
        };
        //登录名 非必须
        if(loginName)
            param.loginName = loginName;
        var promise = $es.ajax('userAuthenBean.sendValidateCodeNew',param,userManage);
        return promise;
    };

    /**
     *
     * @param phoneNumber
     * @param code
     * @returns {*}
     */
    //TODO 手机号码登录 未做
    this.mobileLogin = function(phoneNumber,code){

        var param = {
            mobile:phoneNumber,
            validateCode:code
        };
        return $es.ajax('userAuthenBean.mobileLogin',param,userManage);
    };

}]);