/**
 * Created by chent on 2017/1/18.
 */

angular.module('myApp').service('receiptService',['$q','$es','$rootScope','$istore','$modal',function($q,$es,$rootScope,$istore,$modal){
     
	this.getReceiptStatus = function(){
    	
    	return [
                {id:undefined,name:'状态'},
                {id:'11',name:'待确认'},
                {id:'22',name:'一区二'}
            ];	
    };
   

}]);

