/**
 * Created by chent on 2017/1/18.
 */
var myApp = angular.module("myApp",['ui.router','oc.lazyLoad','ngAnimate','icbc.espresso','s3.components']);
	myApp.factory("$permissions",["$rootScope","$es",function($rootScope,$es){
		var permissionList=[],flag = 0;
		var pub = ["app","profile","403","error","module"];
		function getAccess(){
				if($rootScope.role){
					var result = $es.java("rolesFunctionBean.getMobileFunByRoleId",{roleId:$rootScope.role.RoleEntityid});
					if(result.retCode=="200"){
						permissionList = result.menuList;
						permissionList.push(
								{ menuIcon: "icon-shoukuandandengji color-finance", menuUrl: "receipt", state:"receipt.receiptList",type:'1',menuName:"收款单" },
								{ menuIcon: "icon-renling color-finance", menuUrl: "claimlist", state:"claimlist.claimlist",type:"1",menuName:"认领单" },
								{ menuIcon: "icon-zhanghuguanli color-finance", menuUrl: "relatedOrder", state:"relatedOrder.relatedOrderList",type:'1',menuName:"关联订单" })
					}
				}
				flag = 1;
		}
		return {
			getAccess:getAccess,
			hasPermission:function(state){
				if(flag == 0){
					getAccess();
				}
				var hasAccess = false;
				pub.forEach(function(item){
					if(state.indexOf(item) != -1)
						hasAccess = true;
				})
				if(!hasAccess){
					permissionList.forEach(function(item){
						if(state.indexOf(item.menuUrl) != -1)
							hasAccess = true;
					});
				}
				return hasAccess;
			},
			getFunctionList:function(){
				return permissionList;
			}
		}
	}]);
    myApp.run(['$rootScope', '$state', '$stateParams','$es','$permissions','$istore','$modal','$timeout','$http',
               function($rootScope, $state, $stateParams,$es,$permissions,$istore,$modal,$timeout,$http) {
    	//日期格式化
    	Date.prototype.format = function(fmt){    
        	var o = {        
        			"M+":this.getMonth()+1,// 月份        
        			"d+":this.getDate(), //日期 
        			"H+":this.getHours(),  //小时
        			"m+":this.getMinutes(), //分
        			"s+":this.getSeconds(), //秒, 
        			"q+":Math.floor((this.getMonth()+3)/3),//季度 
        			"S+":this.getMilliseconds() //毫秒   
        			}    
        	if(!fmt) fmt = "yyyy-MM-dd"   
        	if(/(y+)/.test(fmt))        
        		fmt = fmt.replace(RegExp.$1,(this.getFullYear()+"").substr(4-RegExp.$1.length));
        	for(var k in o)        
        		if (new RegExp("("+k+")").test(fmt)) 
        			fmt = fmt.replace(RegExp.$1,(RegExp.$1.length == 1)?(o[k]):(('00' + o[k]).substr((""+o[k]).length)))    
        	return fmt;
        }
        //处理配置信息到模块
        for(var key in config){
           $es.setConfig(key,config[key]);
        }
        $rootScope.productDisplay = config.display.products;

        var userinfo =  $es.java("userInfoBean.getUserData");
        if(userinfo){
            if(userinfo.retCode == "500"){
                alert(userinfo.retMsg);
                location.href = "login.php#!/account/login";
            }else{
                $rootScope.currentUser = userinfo.user;
               
                if($rootScope.currentUser.UserEntityroles){
                    var roles = $rootScope.currentUser.UserEntityroles;
                    if((!$rootScope.role && roles.length > 0)){
                        $rootScope.role = roles[0];
                        $permissions.getAccess()
                    }else{
                        alert("该用户尚未分配角色，无权访问");
                        location.href="login.php";
                    }
                } else{
                    event.preventDefault();
                    $state.go("403");
                }
            }
        }else{
        	location.href="login.php";
        }

        $rootScope.iswx = function(){
            var ua = navigator.userAgent.toLowerCase();
            if(ua.match(/MicroMessenger/i) == "micromessenger"){
                return true;
            }else{
                return false;
            }
        }();
        
        //skin history
        var skinString = "blueredgreenorange";
        var skinPath = config.basic.theme || "blue";
        if(skinString.indexOf(skinPath) == -1) skinPath = "blue";
        angular.element("#cssfile").attr("href",_resource+"CDN/theme/201801/"+skinPath+".css");
        
        $rootScope.$on("$stateChangeStart", function(event,toState, toParams, fromState, fromParams){
        	var hasPermission = $permissions.hasPermission(toState.name);
        	$http({
         		 method:'POST',
                url: '/'+config.custid+'/mobile/getToken.php',
                timeout:15000
       	 	}).then(function (response) {
       	 		$rootScope.token = response.data;
                });
        	if(!hasPermission){
            	event.preventDefault();
            	$modal.alert("您无权访问该地址");
        	}
        });
        
        $rootScope.$on("$stateChangeSuccess",  function(event, toState, toParams, fromState, fromParams) {
            $rootScope.fromState = fromState;
            $rootScope.fromParams = fromParams;
            $rootScope.currentState = toState;
            $timeout(function(){
        		$rootScope.transition = "slide-right";
        	},100)
        	
            angular.element(document).ready(function(){
                $.each(FNUI.DOMWatchers, function(i, watcher) {
                    watcher(document);
                });
                if($rootScope.iswx && toState.title)
                	document.title = toState.title;
                callbackHook.run(toState.name,toParams,$rootScope)
            });
        });
    }]).config(['$stateProvider','$urlRouterProvider',function($stateProvider,$urlRouterProvider){
        var release = "";
    	//路由之前判权限
        $urlRouterProvider.otherwise('/app');
        $stateProvider
            .state('app',{
                url:'/app',
                templateUrl:'views/public/app.html?v='+version,
                bottom:true,
                controller:["$scope",function($scope){
                	$scope.config = config.basic;
                	//主题
                    if(typeof Doodle != 'undefined'){
                        if(Doodle.dateString().showFestival){
                			$scope.config.slides = Doodle.slides();
                			$scope.showFestival= Doodle.dateString().showFestival;
                			$scope.festivalImg = Doodle.dateString().festivalImg;
                		}
                    }
                    //主题结束
                }]
            })
            .state('403',{
                url:'/403',
                templateUrl:'views/public/403.html?v='+version
            })
            //特色
            .state("module",{
                url:'/module',
                template:'<div ng-class="transition" ui-view></div>',
                abstract:true
            })
            .state('module.other', {
                url:'/other/:title/:dataUrl/:type/:param',
                title:'特色功能',
                backState:"app",
                goHome:true,
                templateUrl:'views/public/other.html',
                controller:["$scope","$rootScope","$stateParams","$sce",function($scope,$rootScope,$stateParams,$sce){
                	$rootScope.currentState.title = $stateParams.title;
                	
                	if($stateParams.bottomBoo == '1'){
                    	$rootScope.currentState.bottom = true;
                	}else{
                    	$rootScope.currentState.bottom = false;
                	}
                    var dataUrl = $stateParams.dataUrl;
                    var type = $stateParams['type'];
                    var param = $stateParams['param'] ? JSON.parse($stateParams.param):{}
                    
                    function getParams(param){
                    	var str = "?";
                    	for(var key in param){
                    		str = str + key +　"=" + param[key] + "&"
                    	}
                    	return str;
                    }
                    
                    if(type == "5")
                    	$scope.dataUrl = $sce.trustAsResourceUrl(dataUrl+"?sessionid="+ sid + getParams(param));
                    else
                    	$scope.dataUrl = $sce.trustAsResourceUrl("../fwdsvr/index.php?url="+ dataUrl + encodeURIComponent(getParams(param)));
                    var ifm = document.getElementById("otherFrame");
                    ifm.height = document.documentElement.clientHeight;
                }]
            })
            //个人信息
            .state('profile',{
                url:'/profile',
                template:'<div ng-class="transition" ui-view></div>',
                abstract:true,
                resolve:{
                	service2:"UserInfoService",
                    assets:['$ocLazyLoad', function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                        		files:[
	                            'views/profile/assets/areaData.js',
	                            ],
                        		cache:true
                        });
                    }],
                    ctrl:['$ocLazyLoad',function($ocLazyLoad){
                    	return $ocLazyLoad.load({
                    		files:[
   	                            'scripts/controllers/profile-ctrl'+release+'.js?v='+version,
	               			    'views/profile/css/personal_center.css?v='+version
                    		]
                    	})
                    }]
                },
                controller:["$scope",function($scope){
        			$scope.config = config.modules.profile || {};
                }]
            })
            .state('profile.info',{
                url:'/info',
                title:'我的信息',
                bottom:true,
                templateUrl:'views/profile/info.html?v='+version,
                controller:'InfoCtrl'
            })
            .state('profile.myAccount',{
                url:'/myAccount',
                title:'账户信息',
                backState:'profile.info',
                templateUrl:'views/profile/myAccount.html?v='+version,
                controller:'myAccountCtrl'
            })
            .state('profile.changePw',{
                url:'/changePw',
                title:'修改密码',
                backState:'profile.info',
                templateUrl:'views/profile/changePw.html?v='+version
            })
            .state('profile.changePhone',{
            	url:'/chagePhone',
            	title:'修改手机号',
            	backState:'profile.myAccount',
            	templateUrl:'views/profile/changePhone.html?v='+version
            })
            .state('profile.myAddress',{
                url:'/myAddress',
                title:'地址管理',
                backState:'profile.info',
                templateUrl:'views/profile/myAddress.html?v='+version,
                controller:'AddressCtrl'
            })
            .state('profile.addAddress',{
                url:'/addAddress',
                title:'新增地址',
                backState:'profile.myAddress',
                templateUrl:'views/profile/addAddress.html?v='+version,
                controller:'AddAddressCtrl'
            })
            .state('profile.editAddress',{
                url:'/editAddress/:addrId',
                title:'编辑收货地址',
                backState:'profile.myAddress',
                templateUrl:'views/profile/editAddress.html?v='+version,
                controller:'EditAddressCtrl'
            })
            
             //审批
            .state('check',{
            	url:'/check',
                template:'<div ng-class="transition" ui-view></div>',
                abstract:true,
                resolve:{
                	service1:"CheckService",
                    assets:['$ocLazyLoad', function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                        		files:[
	                            'views/check/css/check.css?v='+version,
	                            'scripts/controllers/check-ctrl'+release+'.js?v='+version
	                            ]
                        });
                    }]
                },
                controller:["$scope",function($scope){
                	$scope.config = config.modules.check ||{};
                }]
            })
            .state('check.checkList',{
                url:'/checkList',
                title:"审批",
                bottom:true,
                templateUrl:'views/check/checkList.html?v='+version,
                backState:"app",
                controller:'CheckCtrl'
            })
            .state('check.checkDetail',{
                url:'/checkDetail/:taskId/:tab',
                title:"审批详情",
                templateUrl:'views/check/checkDetail.html?v='+version,
                backState:"check.checkList",
                controller:'CheckDetailCtrl'
            })
            .state('check.checkDetailEdit',{
                url:'/checkDetailEdit/:taskId/:tab',
                title:"审批详情",
                templateUrl:'views/check/checkDetailEdit.html?v='+version,
                backState:"check.checkList",
                controller:'CheckDetailCtrl'
            })
            .state('check.checkPaymentDetail',{
                url:'/checkPaymentDetail/:taskId/:tab',
                title:"审批详情",
                templateUrl:'views/check/checkPaymentDetail.html?v='+version,
                backState:"check.checkList",
                controller:'CheckPaymentDetailCtrl'
            })
            .state('check.checkFlow',{
                url:'/checkFlow/:instanceId', 
                title:"审批流程",
                templateUrl:'views/check/checkFlow.html?v='+version,
                backState:true,
                controller:'CheckFlowCtrl'
            })
            
        //产品模块
            .state('products',{
                    url:'/products',
                    template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"ProductService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                   'views/product/css/product.css?v='+version,
                                   'scripts/controllers/product-ctrl'+release+'.js?v='+version
                                ]
                               });
                       }]
                    },
                    controller:["$scope",function($scope){
                    	$scope.config = config.modules.products || {};
                    	for(var i=0;i<$scope.config.props.length;i++){
                    		var item = $scope.config.props[i];
                    		if(item === "picFilePath"){
                    			$scope.config.pic = true;
                    			$scope.config.props.splice(i,1);
                    			i = i-1;
                    		}
                    		if(item === "price"){
                    			$scope.config.price = true;
                    			$scope.config.props.splice(i,1);
                    			i = i-1;
                    		}	
                    	}
                    	for(var j =0;j<$scope.config.productDetail.length;j++){
                    		var item = $scope.config.productDetail[j];
                    		if(item === "picFilePath"){
                    			$scope.config.productDetail.splice(j,1);
                    			j = j-1;
                    		}
                    		if(item === "price"){
                    			$scope.config.productDetail.splice(j,1);
                    			j = j-1;
                    		}
                    	}
                    }]
                })
                .state('products.productList',{
                    url:'/productList',
                    title:'产品选购',
                    bottom:true,
                    templateUrl:'views/product/productList.html?v='+version,
                    controller:'ProductCtrl'
                })
                .state('products.productDetail',{
                    url:'/productDetail/:productId',
                    backState:'products.productList',
                    title:'产品详情',
                    templateUrl:'views/product/productDetail.html?v='+version,
                    controller:'ProductDetailCtrl'
                })

            //购物车和订单部分
                .state('cart',{
                    url:'/cart',
                    template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service2:"CartService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                     'scripts/controllers/cart-ctrl'+release+'.js?v='+version,
                                     'views/cart/css/cart.css?v='+version
                                ]
                            	});
                             }]
                    },
                    controller:["$scope",function($scope){
                    	$scope.config = config.modules.cart ||{};
                    	var notes = [];
                    	var selectList=[];
                    	var inputList=[];
                    	
                    	//获取备注
                		for(var key in $scope.config){ 
                			if($scope.config[key].type == 'textarea'){
                				var note=$scope.config[key];
                				note.key=key;
                		        notes.push(note);
                			}	
                		}
                		//获取select	
                		for(var key in $scope.config){              			
                			if($scope.config[key].type == 'select'){
                			     var select=$scope.config[key];
                			     select.key=key;
                				selectList.push(select);
                			}	
                		}
                		//获取input
                		for(var key in $scope.config){              			
                			if($scope.config[key].type == 'text'){
                			     var input=$scope.config[key];
                			     input.key=key;
                				inputList.push(input);
                			}	
                		}
                		
                		$scope.config.selectList = selectList;
                		$scope.config.notes = notes;
                		$scope.config.inputList = inputList;
                		for(var i=0;i<$scope.config.props.length;i++){
                			var item = $scope.config.props[i];
                    		if(item.key === "picFilePath"){
                    			$scope.config.pic = true;
                    			$scope.config.props.splice(i,1);
                    			i = i-1;
                    		}
                    		if(item.key === "price"){
                    			$scope.config.price = item;
                    			$scope.config.props.splice(i,1);
                    			i = i-1;
                    		}	
                		}
                    	$scope.editAddressConfig = config.modules.profile["editAddress"];
                    }]
                })

                //购物车
                .state('cart.cart',{
                    url:'/cart',
                    title:'购物车',
                    bottom:true,
                    templateUrl:'views/cart/cart.html?v='+version,
                    controller:'CartCtrl'
                })

                //提交订单
                .state('cart.submitCart',{
                    url:'/submitCart',
                    templateUrl: 'views/cart/submitCart.html?v='+version,
                    title:"填写详情",
                    backState:"cart.cart",
                    controller:'SubmitCartCtrl'
                })

                //确认订单
                .state('cart.confirmCart',{
                    url:'/confirmCart',
                    templateUrl: 'views/cart/confirmCart.html?v='+version,
                    title:'确认订单',
                    backState:'cart.submitCart',
                    controller:'OrderConfirmCtrl'
                })
                //订单成功
                .state('cart.success',{
                    url:'/success/:orderNo/:id',
                    backState:'cart.cart',
                    templateUrl: 'views/cart/orderSucess.html?v='+version,
                    title:'订单提交',
                    controller:'OrderSuccessCtrl'
                })


        //订单列表
            .state('myorder',{
                    url:'/myorder',
                    template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"OrderService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
	                              'scripts/controllers/order-ctrl'+release+'.js?v='+version,
	                              'views/myorder/css/myorder.css?v='+version
                                ]
                            	});
                             }]
                    },
                    controller:["$scope","$rootScope","$state","$window",function($scope,$rootScope,$state,$window){
                    	$scope.config = config.modules.myorder || {};
                    	$scope.listConfig = $scope.config.list;
                    	$scope.detailConfig = $scope.config.detail;
                    	$scope.config.props.forEach(function(item,i){
                    		if(item === 'price'){
                    			$scope.config.price = true;
                    			$scope.config.props.splice(i,1);
                    		}
                    	})
                    	$scope.propsConfig = $scope.config.props;
                    }]
                })
                .state('myorder.orderList',{
                    url:'/orderList',
                    title:'订单',
                    bottom:true,
                    backState:'app',
                    templateUrl:'views/myorder/orderList.html?v='+version,
                    controller:'OrderListCtrl'
                })
                .state('myorder.orderDetail',{
                    url:'/orderDetail/:orderId',
                    backState:'myorder.orderList',
                    title:'订单详情',
                    templateUrl:'views/myorder/orderDetail.html?v='+version,
                    controller:'OrderDetailCtrl'
                })
                .state('uppayment',{
                    url:'/uppayment',
                    template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"PaymentService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
	                                'scripts/controllers/payment-ctrl'+release+'.js?v='+version,
	                                'views/payment/css/payment.css?v='+version
                                ]
                        		});
                             }]
                    }
                })
                .state('uppayment.paymentList',{
                    url:'/paymentList',
                    title:'付款单',
                    bottom:true,
                    backState:'app',
                    templateUrl:'views/payment/paymentList.html?v='+version,
                    controller:'PaymentListCtrl'
                })
                .state('uppayment.paymentDetail',{
                    url:'/paymentDetail/:paymentNo',
                    title:'付款详情',
                    backState:'uppayment.paymentList',
                    templateUrl:'views/payment/paymentDetail.html?v='+version,
                    controller:'PaymentDetailCtrl'
                })
                //付款成功
                .state('uppayment.success',{
                    url:'/success/:paymentNo/:id',
                    backState:'uppayment.paymentList',
                    templateUrl: 'views/payment/paymentSucess.html?v='+version,
                    title:'付款成功',
                    controller:'PaymentSuccessCtrl'
                })
                .state('delivery',{
                    url:'/delivery',
                    template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"DeliveryService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                'scripts/controllers/delivery-ctrl'+release+'.js?v='+version,
                                'views/delivery/css/delivery.css?v='+version
                                ]
                            });
                             }]
                    },
                    controller:["$scope",function($scope){
                    	$scope.config = config.modules.delivery || {};
                    	$scope.listConfig = $scope.config.list;
                    	$scope.detailConfig = $scope.config.detail;
                    	$scope.config.props.forEach(function(item,i){
                    		if(item.key === 'price'){
                    			$scope.config.price = item;
                    			$scope.config.props.splice(i,1);
                    		}	
                    	})
                    	$scope.propsConfig = $scope.config.props;
                    }]
                })
                .state('delivery.deliveryList',{
                    url:'/deliveryList',
                    title:'我的发货单',
                    bottom:true,
                    backState:'app',
                    templateUrl:'views/delivery/deliveryList.html?v='+version,
                    controller:'DeliveryListCtrl'
                })
                .state('delivery.deliveryDetail',{
                    url:'/deliveryDetail/:deliveryId',
                    title:'发货详情',
                    backState:'delivery.deliveryList',
                    templateUrl:'views/delivery/deliveryDetail.html?v='+version,
                    controller:'DeliveryDetailCtrl'
                })
                
                //易付
                .state('easyPay',{
                    url:'/easyPay',
                    template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"EasyPayService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                'scripts/controllers/easyPay-ctrl'+release+'.js?v='+version,
                                'views/easyPay/css/easyPay.css?v='+version
                                ]
                            });
                             }]
                    }
                })
                .state('easyPay.easyPayDetail',{
                    url:'/easyPayDetail',
                    title:'付款明细',
                    backState:'app',
                    templateUrl:'views/easyPay/easyPayDetail.html?v='+version,
                    controller:'EasyPayCtrl'
                })
                .state('easyPay.createPay',{
                    url:'/selectCompany',
                    title:'付款',
                    backState:'easyPay.easyPayDetail',
                    templateUrl:'views/easyPay/createPay.html?v='+version,
                    controller:'CreatePayCtrl'
                })
                .state('easyPay.confirmPay',{
                    url:'/confirmPay',
                    title:'付款',
                    backState:'easyPay.easyPayDetail',
                    templateUrl:'views/easyPay/confirmPay.html?v='+version,
                    controller:'confirmPayCtrl'
                })
                
                .state('easyPay.paySuccess',{
                    url:'/paySuccess',
                    title:'付款',
                    backState:'easyPay.easyPayDetail',
                    templateUrl:'views/easyPay/paySuccess.html?v='+version,
                    controller:'PaySuccessCtrl'
                })
                
                //对账单
                .state('mstatement',{
                    url:'/mstatement',
               	 	template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"mstatementService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                'scripts/controllers/mstatement-ctrl'+release+'.js?v='+version,
                                'views/mstatement/css/mstatement.css?v='+version
                                ]
                            });
                             }]
                    }
                })
                .state('mstatement.mstatement',{
                    url:'/mstatement',
                    title:'对账单',
                    backState:"app",
                    templateUrl:'views/mstatement/mstatement.html?v='+version,
                    controller:'mstatementCtrl'
                })
                .state('mstatement.mstatementDetail',{
                    url:'/mstatementDetail/:mstateId',
                    title:'对账单明细',
                    backState:'mstatement.mstatement',
                    templateUrl:'views/mstatement/mstatementDetail.html?v='+version,
                    controller:'mstDetailCtrl'
                })
                
                //公告栏
                .state("noticeBoardManage",{
                	 url:'/announcement',
                	 template:'<div ng-class="transition" ui-view></div>',
                     abstract:true,
                     resolve:{
                     	service1:"announcementService",
                         service:['$ocLazyLoad', function($ocLazyLoad) {
                             return $ocLazyLoad.load({
                             	files:[
                                 'scripts/controllers/announcement-ctrl'+release+'.js?v='+version,
                                 'views/announcement/css/announcement.css?v='+version
                                 ]
                             });
                              }]
                     }
                })
                .state("noticeBoardManage.list",{
                	url:'/list',
                	title:'公告列表',
                	backState:'app',
                	templateUrl:'views/announcement/list.html?v='+version,
                	controller:'announcementCtrl'
                })
                .state("noticeBoardManage.listDetail",{
                	url:'/listDetail/:noticeId',
                	title:'公告内容',
                	backState:'noticeBoardManage.list',
                	templateUrl:'views/announcement/listDetail.html?v='+version,
                 	controller:'annDetailCtrl'
                })
                .state("noticeBoardManage.listChange",{
                	url:'/listChange/:noticeId',
                	title:'公告编辑',
                	backState:'noticeBoardManage.list',
                	templateUrl:'views/announcement/listChange.html?v='+version,
                	controller:'listChangeCtrl'
                })
                .state("noticeBoardManage.announceEdit",{
                	url:'/announceEdit',
                	title:'创建公告',
                	backState:'noticeBoardManage.list',
                	templateUrl:'views/announcement/announceEdit.html?v='+version,
                	controller:'annEditCtrl'
                })
                
                //sys manage
                 .state("syncMessage",{
                	url:'/syncMessage',
               	 template:'<div class="{{transition}}" ui-view></div>',
                 abstract:true,
                 resolve:{
                 	 service1:"sysService",
                     service:['$ocLazyLoad', function($ocLazyLoad) {
	                         return $ocLazyLoad.load({
	                         	files:[
	                             'scripts/controllers/sysManage-ctrl'+release+'.js?v='+version,
	                             'views/syncManage/css/sysManage.css?v='+version
	                             ]
	                         });
                          }]
                 	}
                })
                .state("syncMessage.sync",{
                	url:'/sync',
                	title:'同步功能',
                	backState:'app',
                	templateUrl:'views/syncManage/syncList.html?v='+version,
                	controller:'SyncCtrl'
                })
                .state('userManage',{
                    url:'/userInfo',
               	 	template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"sysService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                'scripts/controllers/sysManage-ctrl'+release+'.js?v='+version,
                                'views/userInfoManage/css/userInfoManage.css?v='+version
                                ]
                            });
                             }]
                    }
                })
                .state('userManage.userInfoManage',{
                    url:'/userInfoManage',
                    title:'用户信息管理',
                    backState:'app',
                    templateUrl:'views/userInfoManage/userInfoManage.html?v='+version,
                    controller:'UserInfoManageCtrl'
                })
                .state('userManage.editUser',{
                    url:'/editUser/:customId',
                    title:'编辑信息',backState:'userManage.userInfoManage',
                    templateUrl:'views/userInfoManage/editUser.html?v='+version,
                    controller:'editUserCtrl'
                })
                .state('userManage.addUser',{
                    url:'/addUser',
                    title:'添加客户',backState:'userManage.userInfoManage',
                    templateUrl:'views/userInfoManage/addUser.html?v='+version,
                    controller:'addUserCtrl'
                })
                
                .state('customerRelation',{
                	 url:'/customerRelation',
               	 	template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"sysService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                'scripts/controllers/sysManage-ctrl'+release+'.js?v='+version,
                                'views/userInfoManage/css/userInfoManage.css?v='+version
                                ]
                            });
                             }]
                    }
                })
                .state('customerRelation.userList',{
                	url:'/userList',
                	 title:'用户关系列表',
                	 backState:'app',
                     templateUrl:'views/userInfoManage/userRelateList.html?v='+version,
                     controller:'RelateCtrl'
                })
                .state('customerRelation.detail',{
                	 url:'/detail/:userId/:type',
                	 title:'用户关系',
                	 backState:'customerRelation.userList',
                     templateUrl:'views/userInfoManage/userRelateDetail.html?v='+version,
                     controller:'RelateDetailCtrl'
                })
                
                //收款单
                .state('receipt',{
                	 url:'/receipt',
               	 	template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"receiptService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                'scripts/controllers/receipt-ctrl'+release+'.js?v='+version,
                                'views/receipt/css/receipt.css?v='+version
                                ]
                            });
                             }]
                    }
                })
                .state('receipt.receiptList',{
                	url:'/receiptList',
                	 title:'收款单列表',
                	 backState:'app',
                     templateUrl:'views/receipt/receiptList.html?v='+version,
                     controller:'receiptCtrl'
                })
                .state('receipt.receiptDetail',{
                	 url:'/receiptDetail/:receiptId',
                	 title:'收款单详情',
                	 backState:'receipt.receiptList',
                     templateUrl:'views/receipt/receiptDetail.html?v='+version,
                     controller:'receiptDetailCtrl'
                })


                //认领单
                .state('claimlist',{
                	 url:'/claimlist',
               	 	template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"claimlistService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                'scripts/controllers/claimlist-ctrl'+release+'.js?v='+version,
                                'views/claimlist/css/claimlist.css?v='+version
                                ]
                            });
                             }]
                    }
                })
                .state('claimlist.claimlist',{
                	url:'/claimlist',
                	 title:'认领单列表',
                	 backState:'app',
                     templateUrl:'views/claimlist/claimlist.html?v='+version,
                     controller:'claimlistCtrl'
                })
                .state('claimlist.detail',{
                	 url:'/detail/:id',
                	 title:'认领单详情',
                	 backState:'claimlist.claimlist',
                     templateUrl:'views/claimlist/claimlistDetail.html?v='+version,
                     controller:'claimlistDetailCtrl'
                })
                
                
               //关联订单
                .state('relatedOrder',{
                	 url:'/relatedOrder',
               	 	template:'<div ng-class="transition" ui-view></div>',
                    abstract:true,
                    resolve:{
                    	service1:"relatedOrderService",
                        service:['$ocLazyLoad', function($ocLazyLoad) {
                            return $ocLazyLoad.load({
                            	files:[
                                'scripts/controllers/relatedOrder-ctrl'+release+'.js?v='+version,
                                'views/relatedOrder/css/relatedOrder.css?v='+version
                                ]
                            });
                             }]
                    }
                })
                .state('relatedOrder.relatedOrderList',{
                	url:'/relatedOrderList',
                	 title:'关联订单列表',
                	 backState:'app',
                     templateUrl:'views/relatedOrder/relatedOrderList.html?v='+version,
                     controller:'relatedOrderCtrl'
                })
                .state('relatedOrder.detail',{
                	 url:'/detail/:id',
                	 title:'关联订单详情',
                	 backState:'relatedOrder.relatedOrderList',
                     templateUrl:'views/relatedOrder/relatedOrderDetail.html?v='+version,
                     controller:'relatedOrderDetailCtrl'
                })
    }]);