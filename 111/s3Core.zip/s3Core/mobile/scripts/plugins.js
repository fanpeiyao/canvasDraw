angular.module("s3.components",[])
.factory("$istore",function(){
	/**
     *  sessionStorage
     * */
    var getItem = function(key){
    	if(sessionStorage.getItem(key))
    		return JSON.parse(sessionStorage.getItem(key));
    	else
    		return sessionStorage.getItem(key)
    };
    var setItem = function(key,value){
        sessionStorage.setItem(key,JSON.stringify(value));
    };

    var removeItem = function(key){
        sessionStorage.removeItem(key);
    };

    /**
     * localStorage
     */
    var getItemLocal = function(key){
    	if(localStorage.getItem(key))
    		return JSON.parse(localStorage.getItem(key));
    	else
    		return localStorage.getItem(key)
    };
    var setItemLocal = function(key,value){
        localStorage.setItem(key,JSON.stringify(value));
    };
    var removeItemLocal = function(key){
        localStorage.removeItem(key);
    };
    return {
        get:getItem,
        set:setItem,
        remove:removeItem,
        getLocal:getItemLocal,
        setLocal:setItemLocal,
        removeLocal:removeItemLocal
    }
})
.factory("$modal",["$rootScope",function($rootScope){
	/**
    *
    * @param title  提醒标题
    * @param text  提醒内容
    * @param callback   暂时无效
    */
   var alert = function(text,callback){
       var modal1 = $("#my-alert");
       modal1.find('.fn-modal-bd').html(text);
       modal1.modal({ 
       	closeViaDimmer: 0
       });
       modal1.modal('open')
       modal1.find('.fn-modal-btn').off('click')
       if(typeof callback === "function")
           modal1.find('.fn-modal-btn').on('click',function(){
               callback();
           })
      return modal1;
   }

   /**
    *
    * @param title  确定框的标题
    * @param text  确定框的内容
    * @param onconfirm  点击确定的毁掉函数  不能为空
    * @param oncancel   点击取消的函数  可以为空
    */
   var confirm = function(title,text,onconfirm,oncancel){
       var modal1 =$("#my-confirm");
       modal1.find('.fn-modal-hd').html(title);
       modal1.find('.fn-modal-bd').html(text);
       modal1.modal({ 
       	closeViaDimmer: 0
       });
       var confirmbtn = modal1.find('#confirmbtn');
       confirmbtn.off('click');
       if(typeof onconfirm == "function"){
       	confirmbtn.on('click',function(){
       		onconfirm()
       	});
       }
       var cancelbtn = modal1.find('#cancelbtn');
       cancelbtn.off('click');
       if(typeof oncancel == "function"){
       	cancelbtn.on('click',function(){
       		oncancel()
       	});
       }
       return modal1;
   }
    
   var action = function(options){
	   var id= options.id || my-actions;
	   var act = options.act;
	   $("#"+id).modal(options.act);
   }

    return {
    	alert:alert,
    	confirm:confirm,
    	action:action
    }
    
}]).factory("$number",function(){
		return {
	   /**
         * 保证精确性的数值乘法
         * @param n1
         * @param n2
         * @returns {Number}
         */
        multiply : function (n1, n2) {
            var m = 0,
                s1 = Number(n1).toString(),
                s2 = Number(n2).toString(),
                t = s1.split(".");
            //判断小数点
            if (t[1]) {
                m += t[1].length;
            }
            t = s2.split(".");
            if (t[1]) {
                m += t[1].length;
            }
            return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
        },
        /**
         * 确保精度的数值加法
         * @param n1
         * @param n2
         * @returns {Number}
         */
        add : function (n1, n2) {
            var m1 = 0, m2 = 0,
                t =  Number(n1).toString().split(".");
            if (t[1]) {
                m1 = t[1].length;
            }
            t =  Number(n2).toString().split(".");
            if (t[1]) {
                m2 = t[1].length;
            }
            var m = Math.pow(10, Math.max(m1, m2));
            return Math.round(Number(n1) * m + Number(n2) * m) / m;
        },
        /**
         * 确保精度的数值减法
         * @param n1
         * @param n2
         * @returns {Number}
         */
        sub : function (n1, n2) {
            var m1 = 0, m2 = 0,
                t =  Number(n1).toString().split(".");
            if (t[1]) {
                m1 = t[1].length;
            }
            t =  Number(n2).toString().split(".");
            if (t[1]) {
                m2 = t[1].length;
            }
            var m = Math.pow(10, Math.max(m1, m2));
            return Number((Math.round(Number(n1) * m - Number(n2) * m) / m).toFixed(Math.max(m1, m2)));
        },

        /**
         * 相对精确的数值除法
         *
         * @param n1
         * @param n2
         * @returns {Number}
         */
        divide:function (n1, n2) {
            var m, m1 = 0, m2 = 0, t;
            var s1 =  Number(n1).toString();
            var s2 =  Number(n2).toString();
            t = s1.split(".");
            if (t[1]) {
                m1 += t[1].length;
            }
            t = s2.split(".");
            if (t[1]) {
                m2 += t[1].length;
            }
            m = Math.pow(10, m2 - m1);
            return Number((Number(s1.replace(".", "")) / Number(s2.replace(".", "")) * m).toFixed(2));
        },
        mod:function(n1,n2){
        	 var m, m1 = 0, m2 = 0, t;
             var s1 =  Number(n1).toString();
             var s2 =  Number(n2).toString();
             t = s1.split(".");
             if (t[1]) {
                 m1 += t[1].length;
             }
             t = s2.split(".");
             if (t[1]) {
                 m2 += t[1].length;
             }
             var m = Math.pow(10, Math.max(m1, m2));
             return  (Number(n1) * m) % (Number(n2) * m);
        }
        
		}
}).factory("$toast",function(){
	return{
		info:function(title,time){
			if(time)
				$.toast.content(title).show('info',time).clear();
			else
				$.toast.content(title).show('info');
		},
		warning:function(){
			if(time)
				$.toast.content(title).show('warning',time).clear();
			else
				$.toast.content(title).show('warning');
		},
		loading:function(){
			$.toast.show('loading');
		},
		close:function(){
			$.toast.close();
		}
	}
}).factory("$timer",function(){
	return {
		debounce : function(func, wait, immediate) {
	        var timeout, args, context, timestamp, result;

	        function now(){
	            return new Date().getTime();
	        }

	        var later = function() {
	            var last = now() - timestamp;

	            if (last < wait && last >= 0) {
	                timeout = setTimeout(later, wait - last);
	            } else {
	                timeout = null;
	                if (!immediate) {
	                    result = func.apply(context, args);
	                    if (!timeout) context = args = null;
	                }
	            }
	        };

	        return function() {
	            context = this;
	            args = arguments;
	            timestamp = now();
	            var callNow = immediate && !timeout;
	            if (!timeout) timeout = setTimeout(later, wait);
	            if (callNow) {
	                result = func.apply(context, args);
	                context = args = null;
	            }
	            return result;
	        };
	    },
	    throttle:function(func, wait, options) {
	    	var context, args, result;
	    	var timeout = null;
	    	var previous = 0;
	    	if (!options) options = {};
	    	function _now(){
	    		return new Date().getTime();
	    	}
	    	var later = function() {
	    		previous = options.leading === false ? 0 : _now();
	    		timeout = null;
	    		result = func.apply(context, args);
	    		if (!timeout) context = args = null;
	    	};
	    	return function() {
	    		var now = _now();
	    		if (!previous && options.leading === false) previous = now;
	    		var remaining = wait - (now - previous);
	    		context = this;
	    		args = arguments;
	    		if (remaining <= 0 || remaining > wait) {
	    			if (timeout) {
	    				clearTimeout(timeout);
	    				timeout = null;
	    			}
	    			previous = now;
	    			result = func.apply(context, args);
	    			if (!timeout) context = args = null;
	    		} else if (!timeout && options.trailing !== false) {
	    			timeout = setTimeout(later, remaining);
	    		}
	    		return result;
	    	};
	    }
	}
}).factory("fileReader",["$q",function($q){

    var onLoad = function(reader,deferred,scope){
        return function(){
            scope.$apply(function(){
                deferred.resolve(reader.result);
            })
        }
    };

    var onError = function(reader,deferred,scope){
        return function(){
            scope.$apply(function(){
                deferred.resolve(reader.result);
            })
        }
    };

    var getReader = function(deferred,scope){
        var reader = new FileReader();
        reader.onload = onLoad(reader,deferred,scope);
        reader.onerror = onError(reader,deferred,scope);
        return reader;
    };

    var readAsDataURL = function(file,scope){
        var deferred = $q.defer();
        var reader = getReader(deferred,scope);
        reader.readAsDataURL(file);
        return deferred.promise;
    };
    return{
        readAsDataURL:readAsDataURL
    }

}]);