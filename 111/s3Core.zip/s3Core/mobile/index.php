<?php
	require_once '../~main/sys.config.php';
	require_once '../common/core.class.php';
	
	$_resource = "http://gyj.icbc.com.cn/resource/";
	if($_ENV['enviroment'] == 'dev'){
		$_resource = "http://resource.gongyinju.com/resource/";
	}
	
	function execjava($ids, $params, $cmd='xml', $appId=null){
		return Core::execjava($ids, Core::treatParams($params), $cmd, $appId);
	}
	
	function getContextPath(){
		if($_SERVER['HTTP_APPID'])
			$contextPath = $_SERVER['HTTP_APPID'];
		else{
			$uri = $_SERVER['REQUEST_URI'];
			$st = stripos($uri, '/', 1);
			$contextPath = substr($uri, 1, $st-1);
		}
		if($contextPath == null)
			$contextPath = "NOTFOUND";
		return $contextPath;
	}
	$context = getContextPath();
	
	$wx_code = htmlspecialchars($_GET["code"]);
	
	if($wx_code != null){
		$parsMap = array("wx_code" => $wx_code,"subappid"=>$context);
		try{
			$loginRes=execjava("userAuthenBean.checkBindUser",$parsMap,"php","usermanage");
			if($loginRes["retCode"] == '200'){
				execjava("userInfoBean.setLoginSession",null,"php");
			}else{
				header("Location:login.php?code=".$wx_code);
			}
		}catch(Exception $e){
			header("Location:login.php?code=".$wx_code);
		}
	}
	
	$retMap = execjava('userInfoBean.getHeadData', null, "php");
	$user = $retMap["user"];
	if($user == null || $user==""){
		header("Location:login.php");
	}
	
	$para = array("fileName"=>"config-m.js");
	$retMap=execjava('basicConfigBean.getfileUrl', $para, "php");
	$configUrl = $retMap["url"];
	if($configUrl == null)
		die("未经配置的项目");
	
	$para2 = array("fileName"=>"amount_col.js");
	$retMap2=execjava('basicConfigBean.getfileUrl', $para2, "php");
	$amountUrl = $retMap2["url"];
	
	$retMap=execjava('basicConfigBean.getAllConfig', null, "php");
	$logoUrl = $retMap["picUrl"];
	$_slidePic1=$retMap['slidePic1'];
	$_slidePic2=$retMap['slidePic2'];
	$_slidePic3=$retMap['slidePic3'];
	$companyName = $retMap["companyName"];
	$theme = $retMap["mobileTheme"];
	$editAddress = $retMap["editAddress"];
	$categorySearch = $retMap["categorySearch"];
	$showStatisticPanel = $retMap["showStatisticPanel"];

	$specsificJS = $retMap["jsDemo"];

	$release = "";
	if($isreleased==true)
		$release = ".min";
 	//$configUrl = "../~main/config/s3Core/config-m.js";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui,viewport-fit=cover">
    <meta name="renderer" content="webkit">
   
     <!--ios -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-touch-fullscreen" content="yes" />
    <meta name="format-detection" content="telephone=no,email=no" />
    <title>供应链移动客户端</title>
    <script src="<?php echo($configUrl)?>"></script>

	<script>
		var _resource = "<?php echo $_resource;?>";
		config.custid = '<?php echo $context;?>';
	   	config.basic.theme = "<?php echo $theme?>";
		config.basic.showStatisticPanel = "<?php echo $showStatisticPanel?>";
		config.basic.logo= "<?php echo $logoUrl;?>";
		config.basic.companyName = "<?php echo $companyName?>";
		config.modules.products.categorySearch = "<?php echo $categorySearch?>";
		config.modules.profile.editAddress = "<?php echo $editAddress?>";
		config.basic.slides = ["<?php echo $_slidePic1;?>"|| "views/public/img/banner.png",
				"<?php echo $_slidePic2;?>"||"views/public/img/banner2.jpg","<?php echo $_slidePic3;?>"||"views/public/img/banner2.jpg"];
		var version = "<?php echo $version;?>";
		<?php 
		if($amountUrl == null){
		?>
		var typeArray = {
		 0:{
		  bitLength:2,
		  roundOff:2,
		  unit:0
		 },
		 1:{
		  bitLength:2,
		  roundOff:2,
		  unit:0
		 },
		 2:{
		  bitLength:2,
		  roundOff:2,
		  unit:0
		 },
		 3:{
		  bitLength:2,
		  roundOff:2,
		  unit:0
		 }
		}
		<?php }?>
	</script>
	<?php if($amountUrl != null){ 
		echo ('<script src="'.$amountUrl.'"></script>');
	 }?>
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	<link rel="bookmark" href="favicon.ico">
    <link href="<?php echo $_resource;?>CDN/iosselect/1.1.0/iosSelect.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $_resource;?>CDN/fnui/2.0.15/css/fnui.min.css">
    <link rel="stylesheet" href="<?php echo $_resource;?>CDN/font/iconfont/iconfont.css">
    <link rel="stylesheet" href="styles/animate.min.css">
    <link rel="stylesheet" href="styles/app.css?v=<?php echo $version?>">
    <link rel="stylesheet" href="<?php echo $_resource;?>CDN/theme/201801/blue.css" id="cssfile">
</head>


<body ng-app="myApp">
    <head-bar></head-bar>
    <div class="toggle" ui-view></div>
    <bottom-bar></bottom-bar>
    <fn-alert></fn-alert>
	<fn-confirm></fn-confirm>
    <script src="<?php echo $_resource;?>CDN/jquery/3.2.1/jquery.js"></script>
    <script src="<?php echo $_resource;?>CDN/fnui/2.0.15/js/fnui.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/angular.js/1.6.2/angular.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/angular-ui-router/0.3.2/angular-ui-router.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/angular.js/1.6.2/angular-animate.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/oclazyload/1.1.0/ocLazyLoad.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/iscroll/5.2.0/iscroll-probe.min.js"></script>
    <script src="<?php echo $_resource;?>public/s3/rsaoath.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/iosselect/1.1.0/iosSelect.js"></script>
    <script src="<?php echo $_resource;?>CDN/s3js/1.2.11/s3-simple.js"></script>
    <script src="scripts/properties.js?v=<?php echo $version?>"></script>
    <script src="scripts/espresso.js?v=<?php echo $version?>"></script>
    <script src="scripts/plugins.js?v=<?php echo $version?>"></script>
    <script src="scripts/common.js?v=<?php echo $version?>"></script>
    <?php   echo $specsificJS   ?>
    <script src="scripts/app.js?v=<?php echo $version?>"></script>
    <script src="scripts/directives/directive.js?v=<?php echo $version?>"></script>
    <script src="components/components.js?v=<?php echo $version?>"></script>

   
    
    <!--  defered load -->
    <script src="scripts/services/userinfo-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/product-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/payment-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/cart-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/order-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/delivery-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/check-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/easypay-serv.js?v=<?php echo $version?>" defer></script>
	<script src="scripts/services/sysManage-serv.js?v=<?php echo $version?>" defer></script>
	<script src="scripts/services/announcement-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/mstatement-serv.js?v=<?php echo $version?>" defer></script> 
	<script src="scripts/services/receipt-serv.js?v=<?php echo $version?>" defer></script>
    <script src="scripts/services/claimlist-serv.js?v=<?php echo $version?>" defer></script>   
    <script src="scripts/services/relatedOrder-serv.js?v=<?php echo $version?>" defer></script>      
    <script src="<?php echo $_resource;?>doodle/mobile/doodle.js" defer async></script>      
    
</body>
</html>