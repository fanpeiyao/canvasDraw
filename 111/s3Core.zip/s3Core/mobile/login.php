<?php 
	require_once '../~main/sys.config.php';
	require_once '../common/core.class.php';
	$_resource = "http://gyj.icbc.com.cn/resource/";
	if($_ENV['enviroment'] == 'dev'){
		$_resource = "http://resource.gongyinju.com/resource/";
	}
	
	function execjava($ids, $params, $cmd='xml', $appId=null){
		return Core::execjava($ids, Core::treatParams($params), $cmd, $appId);
	}
	function getContextPath(){
		if($_SERVER['HTTP_APPID'])
			$contextPath = $_SERVER['HTTP_APPID'];
		else{
			$uri = $_SERVER['REQUEST_URI'];
			$st = stripos($uri, '/', 1);
			$contextPath = substr($uri, 1, $st-1);
		}
		if($contextPath == null)
			$contextPath = "NOTFOUND";
		return $contextPath;
	}
	$context = getContextPath();
	
	
	$wx_code = htmlspecialchars($_GET["code"]);
	if($wx_code != null){
		$parsMap = array("wx_code" => htmlspecialchars($wx_code),"subappid"=>$context);
		try{
			$loginRes=execjava("userAuthenBean.checkBindUser",$parsMap,"php","usermanage");
			if($loginRes["retCode"] == '200'){
				
				execjava("userInfoBean.setLoginSession",null,"php");
				header("Location:index.php");
			}else{
				$openId = $loginRes["openId"];
			}
		}catch(Exception $e){
			
		}
	}
	
	//
	$retMap=execjava('basicConfigBean.getAllConfig', null, "php");
	$logoUrl = $retMap["picUrl"];
	$companyName = $retMap["companyName"];
	$theme = $retMap["color"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Cache-Control" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no, minimal-ui,viewport-fit=cover">
    <meta name="renderer" content="webkit">
   
     <!--ios -->
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="format-detection" content="telephone=no" />

    <title>供应链移动客户端</title>
    <script>
    	if(localStorage && (localStorage.setItem('testlocal', 123), localStorage.getItem('testlocal') == '123') ){
    		if(!localStorage.getItem("addFlagv1.3")){
    		   	window.location.href = "intro/intro.html";
    		}
        }
		var config = {};
	   	config.custid = '<?php echo $context;?>';
	   	config.basic = {};
		config.basic.theme = "<?php echo $theme?>";
		config.basic.logo= "<?php echo $logoUrl;?>";
		config.basic.companyName = "<?php echo $companyName?>";
		var zddlvxid = "<?php echo $openId?>";
		var _resource = "<?php echo $_resource;?>";
	</script>
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	<link rel="bookmark" href="favicon.ico">
	<link rel="stylesheet" href="<?php echo $_resource;?>CDN/fnui/2.0.15/css/fnui.min.css">
    <link rel="stylesheet" href="<?php echo $_resource;?>CDN/font/iconfont/iconfont.css">
    <link rel="stylesheet" href="<?php echo $_resource;?>CDN/theme/201801/blue.css" id="cssfile">
    <link rel="stylesheet" href="styles/app.css?v=<?php echo $version?>">
    <link rel="stylesheet" href="views/account/css/account.css?v=<?php echo $version?>">
</head>
<body ng-app="myApp">
    <div class="toggle" ui-view></div>
	<div class="fn-modal fn-modal-alert" id="my-alert">
		<div class="fn-modal-dialog">
			<div class="fn-modal-hd"></div>
			<div class="fn-modal-bd"></div>
			<div class="fn-modal-footer">
				<span class="fn-modal-btn fn-modal-btn-bold" data-fn-modal-close>确定</span>
			</div>
		</div>
	</div>
 	<script src="<?php echo $_resource;?>CDN/jquery/3.2.1/jquery.js"></script>
    <script src="<?php echo $_resource;?>CDN/fnui/2.0.15/js/fnui.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/angular.js/1.6.2/angular.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/angular-ui-router/0.3.2/angular-ui-router.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/angular.js/1.6.2/angular-animate.min.js"></script>
    <script src="<?php echo $_resource;?>CDN/oclazyload/1.1.0/ocLazyLoad.min.js"></script>
    <script src="scripts/espresso.js?v=<?php echo $version?>"></script>
    <script src="scripts/plugins.js?v=<?php echo $version?>"></script>
    <script src="scripts/login.js?v=<?php echo $version?>"></script>
    <script src="scripts/controllers/account-ctrl.js?v=<?php echo $version?>"></script>
    
    <script src="<?php echo $_resource;?>public/s3/rsaoath.min.js"></script>
    <script src="scripts/services/login-serv.js?v=<?php echo $version?>"></script>
    <script src="<?php echo $_resource;?>doodle/mobile/doodle.js" defer async></script>      
</body>
</html>