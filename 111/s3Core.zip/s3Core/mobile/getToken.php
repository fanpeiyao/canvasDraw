<?php
require_once '../inc/Token.class.php';
session_start();
Token::set_token();
echo Token::get_token();
?>