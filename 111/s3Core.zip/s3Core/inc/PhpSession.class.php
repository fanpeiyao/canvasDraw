<?php 
class PhpSession {
	public static function set($key, $val){
		if (!isset($_SESSION)) {
			session_start();
		}
		$_SESSION[$key] = $val;
		return 0;
	}
	
	public static function get($key){
		if (!isset($_SESSION))
			session_start();
		return $_SESSION[$key];
	}
	
	public static function clear($key){
		if (!isset($_SESSION))
			session_start();
		unset($_SESSION[$key]);
	}
	
	public static function destroy(){
		unset($_SESSION);
		session_destroy();
	}
	
	public static function getName(){
		return session_name();
	}
	
	public static function getId(){
		if (!isset($_SESSION))
			return null;
		return session_id();
	}
}


?>