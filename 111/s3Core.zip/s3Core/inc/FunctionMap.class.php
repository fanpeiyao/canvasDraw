<?php 
/*
 * 用于保存从配置服务器读回来的信息
 */
class FunctionMap extends BaseClass
{
	public function loadData()
	{
		$d2=new ComplexType("Alan","John");
		$this->setCache($d2);
	}
	
	//public function loadData()
	
}