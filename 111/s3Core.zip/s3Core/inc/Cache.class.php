<?php 
/*
 *  For save user cache 
 *  PHP's cache really a big problem ~
 *  zhaoyc
 *  20140821   
 */

class Cache
{


	public static function set($key,$value)
	{
		return Cache::memcacheset($key,$value);
	}
	
	public static function get($key)
	{
		return Cache::memcacheget($key);
	}
	
	//memcache方式的缓存
	public static function memcacheset($key,$value)
	{
		$mpool = new MemcachePool();
		$mpool->addServer("109.5.13.122",11211,0,true);
		$mpool->set($key,$value);
	}
	
	public static function memcacheget($key)
	{
		$mpool = new MemcachePool();
		$mpool->addServer("109.5.13.122",11211,0,true);
		return $mpool->get($key);
	}
}