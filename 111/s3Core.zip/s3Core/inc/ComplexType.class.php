<?php
class ComplexType
{
	var $s1;
	var $s2;
	var $s3;
	var $s4;
	function __construct($s1="Name", $s2="FName",$s3="S3",$s4="ASDASD") {
		$this->s1=$s1;
		$this->s2=$s2;
		$this->s3=$s3;
		$this->s4=$s4;
	
	}
	public function Out()
	{
		echo $this->s1." ".$this->s2.' '.$this->s3.' '.$this->s4;
	}
}