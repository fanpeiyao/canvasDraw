<?php

Class Menucontroller {
	public static function isValid($uesrTreeMenu, $funcId) {
		return false;
	}
	
	public static function getTrreMenu($treeMenu, $funcMap) {
		$userTreeMenu;
		return $userTreeMenu;
	}
	
}