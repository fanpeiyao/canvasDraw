<?php
class BaseClass
{
	protected function setCache($value)
	{
		Cache::set(__FILE__,$value);
	}
	protected function getCache()
	{
		Cache::get(__FILE__);
	}
}
