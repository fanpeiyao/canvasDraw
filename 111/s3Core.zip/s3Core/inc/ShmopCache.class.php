<?php
Class ShmopCache
{
//shmop方式的缓存
public static function set($key,$value)
{
	$perm=0666;
	$shmkey=ftok(__FILE__);
	if(!$shmkey)
	{
		return 0;
	}
	$shmid=@shmop_open($shmkey,"w",$perm,0);
	if(!$shmid)
	{
		$shmid=shmop_open($shmkey,"c",$perm,_SYS_CACHESIZE);
		$data=array();
	}
	else
	{
		$data=unmpack(shmop_read($shmid,0,_SYS_CACHESIZE));
	}
	$data[$key]=$value;
	$data=mpack($data);
	$shm_bytes_written=shmop_write($shmid,$data,0);
	shmop_close($shmid);
}

public static function get($key)
{
	$perm=0666;
	$shmkey=ftok(__FILE__);
	if(!$shmkey)
	{
		return 0;
	}
	$shmid=shmop_open($shmkey,"a",$perm,0);
	if($shmid)
	{
		$data=unmpack(shmop_read($shmid,0,_SYS_CACHESIZE));
		shmop_close($shmid);
		return $data[$key];
	}
	else
	{
		return 0;
	}
}
}