<?php

class TreeMenu {
	var $treeMenu;
	
	public function getTreeMenu(){
		return $this->$treeMenu;
	}
	public function TreeMenu($treeMenu) {
		$this->$treeMenu = $treeMenu;
	} 
	
	public function generateTreeMenu($funcMap) {
		return $menu;
	}
}