<?php 

class Token {
	static function valid_token($token) {
		if($token === $_SESSION['SESSION_TOKEN_KEY'])
			$return = true;
		else
			$return = false;		
		Token::set_token();
		return $return;
	}
	
	static function set_token() {
		$_SESSION['SESSION_TOKEN_KEY'] = md5(uniqid());
	}
	
	static function get_token() {
		return $_SESSION['SESSION_TOKEN_KEY'];
	}
	
}

?>