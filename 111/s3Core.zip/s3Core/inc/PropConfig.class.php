<?php
class PropConfig
{
	/**
	 * 取得默认配置的参数
	 *
	 * @param key
	 *            键值
	 */
	public static function getDefaultValue($key) {
		$val = PropConfig::getDefaultConfigurationValue($key);
		return $val;
	}
	
	
	/**
	 * 取得默认配置信息
	 *
	 *@param key
	 *            键值
	 * @return
	 */
	private static function getDefaultConfigurationValue($key) {
		//从后台获取相应的配置信息
		$para = array('key'=>$key);
		
		$result = execjava("configBean.getConfig",$para,"php");
		
		return $result;
		
	}
}