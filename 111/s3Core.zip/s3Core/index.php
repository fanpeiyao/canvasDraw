<?php 
/*
 * 用于自动重定向到~main目录下的Login页面
 */
echo header("Location:".getContextPath());

function getContextPath(){
	$protocol = $_SERVER['SERVER_PROTOCOL'];
	if(empty($protocol))
		return '';
	$st = stripos($protocol, '/');
	if($st)
		$protocol = substr($protocol, 0, $st);
	$protocol = strtolower($protocol);
	$host = $_SERVER['SERVER_NAME'];
	if(!empty($_SERVER['SERVER_PORT'])){
		if($_SERVER['SERVER_PORT'] == 443)
			$protocol = 'https';
		
		if($_SERVER['SERVER_PORT'] != 80)
			$host .= ':' . $_SERVER['SERVER_PORT'];
	}
	$uri = $_SERVER['REQUEST_URI'];
	$st = stripos($uri, '/', 1);
	$contextPath = substr($uri, 0, $st);
	
	if(isMobile())
		return $protocol . '://' . $host . $contextPath . '/mobile/index.php';
	else
		return $protocol . '://' . $host . $contextPath . '/~main/login.php';
}


function isMobile(){
	if(isset($_SERVER['HTTP_X_WAP_PROFILE']))
		return true;
	
	if(isset($_SERVER['HTTP_VIA']))
		return stristr($_SERVER['HTTP_VIA'],"wap")?true:false;
	
	if(isset($_SERVER['HTTP_USER_AGENT'])){
		$clientkeywords = array(
				'nokia','sony','ericsson','mot',
				'samsung','htc','sgh','lg','sharp','sie-',
				'philips','panasonic','alcatel','lenovo','iphone',
				'ipod','blackberry','meizu','android','netfront',
				'symbian','ucweb','windowsce','palm','operamini',
				'operamobi','openwave','nexusone','cldc','midp','xiaomi',
				'wap','mobile','oppo','vivo','huawei','nubia','MQQBrowser','360se'
		);
		if (preg_match("/(" . implode('|', $clientkeywords) . ")/i", strtolower($_SERVER['HTTP_USER_AGENT'])))
			return true;
	}
	return false;
}
?>