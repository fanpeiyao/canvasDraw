<?php
function mpack($data)
{
	return msgpack_serialize($data);
}
function unmpack($data)
{
	return @msgpack_unserialize($data);
}