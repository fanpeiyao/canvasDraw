function isArray(obj){
	if(obj == null)
		return false;
	return Object.prototype.toString.apply(obj) === '[object Array]';
};

function myMap(fn, thisObj) { 
    var l = thisObj.length, res = []; 
    for(var i = 0; i < l; i++) { 
        if(i in thisObj) { 
            res[i] = fn.call(thisObj, thisObj[i], i, thisObj); 
        } 
    } 
    return res; 
};

function isIE678(){
	if(navigator.userAgent.indexOf("MSIE")>0) { 
	//是否是IE浏览器 
		if(navigator.userAgent.indexOf("MSIE 6.0")>0)
		{ 
			return true;
		} 
		if(navigator.userAgent.indexOf("MSIE 7.0")>0)
		{
			return true;
		} 
		if(navigator.userAgent.indexOf("MSIE 8.0")>0)
		{
			return true;
		} 
	}
	else {
		return false;
	} 
};

var CoreSupport = function(){};
CoreSupport.PAGE_NO = "_P_N";
CoreSupport.PAGE_SIZE = "_P_S";
CoreSupport.PAGE_CONTAINER = "_P_C";
CoreSupport.DataSetIdList = "__ids";
CoreSupport.DataSetParams = "__params";
CoreSupport.connection = "Close";
// trim方法定义
String.prototype.trim = function(){					
     return this.replace(/(^\s*)|(\s*$)/g, '');
}
CoreSupport.treatParams = function(params, paramMap){
	if(paramMap == null)
		paramMap = {};

	if(params == null)
		return paramMap;
	
	if(typeof(params) == "string"){
		var pary = params.split('&');
		for(var i = 0; i < pary.length; i++){
			if(pary[i] == null || pary[i] == '')
				continue;
			var tary = pary[i].split('=');
			var key = tary[0].trim();
			var val = tary[1];
		
			if(key.length == 0)
				continue;
			paramMap[key] = val;
		}
	}
	else if(typeof(params) == "object"){
		for(var key in params){
			paramMap[key] = params[key];
		}
	}	
	return paramMap;
};


CoreSupport.ajax = function(url, paramstr, callback, async, method, appId){
	if(paramstr == null)
		paramstr = "";
	if(async == null)
		async = false;
	if(method == null)
		method = "GET";

	if(paramstr.indexOf('__port=') < 0){
		paramstr += "&__port=" + location.port;
	}
	
	//var xmlhttp = CoreSupport.getXMLHttpRequest();
	var results;
	try {		
		var isPost = false;
		/*
		if("POST" == method){
			isPost = true;
		}
		else{
			if(paramstr.length > 0)
				url += "?" + paramstr;			
		}*/
		if(async){		
			$.ajax({
                type: method,
                url: url,
               async: true,
               headers:{"Token":S3Config.getConfig("s3_token")},
               contentType:"application/x-www-form-urlencoded; charset=UTF-8",
                data:paramstr,
                cache:false,
                dataType: "html",
                success: callback,
                timeout:3000
            });
			/*
			xmlhttp.onreadystatechange=function()
			{
				if (xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					if(callback){
						callback(xmlhttp.responseText);
					}
				}
			}
			xmlhttp.open(method,url,true);
			xmlhttp.setRequestHeader("Connection", CoreSupport.connection);
			if(isPost){
				xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
				xmlhttp.send(paramstr);		
			}
			else{
				xmlhttp.send();		
			}*/
						
		}
		else{
			
			$.ajax({
                type: method,
                url: url,
               async: false,
               headers:{"Token":S3Config.getConfig("s3_token")},
               contentType:"application/x-www-form-urlencoded; charset=UTF-8",
                data:paramstr,
                dataType: "html",
                cache:false,
                timeout:3000,
                success: function (ajaxData) {
                	results = ajaxData;
                }
            });

/*
			xmlhttp.open(method,url,false);
			xmlhttp.setRequestHeader("Connection", CoreSupport.connection);
			if(isPost){
				xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
				xmlhttp.send(paramstr);		
			}
			else{
				xmlhttp.send();		
			}
			results = xmlhttp.responseText;
			if(callback){
				callback(results);
			}  */
		}
	}
	catch(e){}	
	return results;		
};

CoreSupport.escapeHtml = function(original) {
	if(original){
		original = '' + original;
		return original.replace(/(\r)?\n/g, '<br/>').replace(/(["\\])/g, '\\$1').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
	}
	return '';
};

CoreSupport.unescapeHtml = function(original) {
	if(original){
		original = '' + original;
		return original.replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
	}
	return '';
};

CoreSupport.escapeBR = function(original){
	if(original){
		original = '' + original;
		original = original.replace(/<br\/?>/g, '\r\n');
		return original;
	}
	return '';
};


CoreSupport.toJSONString = function(obj){  
	var THIS = CoreSupport;   
	var type = typeof(obj);
	if(type == 'object' && isArray(obj))
		type = 'array';
		
	switch(type){  
	case 'string':  
		return '"' + CoreSupport.escapeHtml(obj) + '"';
	case 'array':
		if(!isIE678()) {
			return '[' + obj.map(THIS.toJSONString).join(',') + ']'; 
		}
		else {
			return '[' + myMap(THIS.toJSONString,obj).join(',') + ']';
		}
	case 'object':  
		if(obj instanceof Array){  
			var strArr = [];  
			var len = obj.length;  
			for(var i=0; i<len; i++){
				var item = obj[i];
				strArr.push(THIS.toJSONString(item));  
            }  
			return '[' + strArr.join(',') + ']';  
		}else if(obj==null){  
			return '';      
		}else{  
			var string = [];  
			for (var k1 in obj){
				var v1 = obj[k1];
				if(v1 == undefined || k1 == undefined)
					continue;
				string.push(THIS.toJSONString(k1) + ':' + THIS.toJSONString(obj[k1]));
			}
								
			return '{' + string.join(',') + '}';  
		}  
	case 'number':  
		return obj;  
	case 'boolean':
		return obj ? 'true' : 'false';
	default:  
		return obj;  
	}  
};

function getCookie(name){
	var c = document.cookie;
	var arr = c.split(";");
	for (i=0;i<arr.length;i++){
		if(arr[i].indexOf(name)>=0){
			cookie = arr[i].split("=");
			return cookie[1];
		}
	}
	return null;
};