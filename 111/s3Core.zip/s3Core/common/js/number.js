function accAdd(arg1,arg2) {
	var r1,r2,m,n;
	r1=getDotLength(arg1);
	r2=getDotLength(arg2);
	m= Math.pow(10,Math.max(r1,r2));
	n=(r1>=r2)?r1:r2;
	return EToString((Math.round(arg1*m+arg2*m)/m).toFixed(n>20?20:n))
}
Number.prototype.add = function (arg){
	return accAdd(this,arg);
}

function accSub(arg1,arg2){
    var r1,r2,m,n;
    r1=getDotLength(arg1);
	r2=getDotLength(arg2);
    m=Math.pow(10,Math.max(r1,r2));
    n=(r1>=r2)?r1:r2;
    return EToString((Math.round(arg1*m-arg2*m)/m).toFixed(n>20?20:n))
}
Number.prototype.sub = function (arg){
	return accSub(this,arg);
}
String.prototype.sub = function (arg){
	return accSub(this,arg);
}

function accMul(arg1,arg2)
{
	var r1,r2,m=0,
    r1=getDotLength(arg1);
	r2=getDotLength(arg2);
	m=m+r1+r2;
	var n1 = Number(EToString(arg1).replace(".",""));
	var n2 = Number(EToString(arg2).replace(".",""));
	//计算精度
	var degree =r1*r2;
	return EToString((n1*n2)/Math.pow(10,m).toFixed(degree>20?20:degree))
}
Number.prototype.mul = function (arg){
	return accMul(this,arg);
}

function accDiv(arg1,arg2){
	var t1=0,t2=0,r1,r2;
	t1=getDotLength(arg1);
	t2=getDotLength(arg2);
	with(Math){
	r1=Number(arg1.toString().replace(".",""))
	r2=Number(arg2.toString().replace(".",""))
	return EToString((r1/r2)*pow(10,t2-t1));
	}
	}
	//给Number类型增加一个div方法，调用起来更加方便。
	Number.prototype.div = function (arg){
	return accDiv(this, arg);
	}


//返回num(包含科学计数法)应该移动多少位小数点能成为整数
function getDotLength(num){
	var indexE = num.toString().toLowerCase().indexOf("e");
	var indexDot = num.toString().toLowerCase().indexOf(".");
	var E = num.toString().toLowerCase().split('e')[1];
	var length;
	if(indexDot==-1){//num没有小数点
		if(indexE==-1){
			length = 0;
		}else{
			length = E>0?0:-E;
		}
	}else if(indexE==-1){//num有小数点，不是科学计数法
		length = num.toString().split('.')[1].length;
	}else{//num是科学计数法，有小数点
		dotLength = indexE-indexDot-1;
		if(E<0)
			length = E+dotLength;
		else
			length = E>dotLength?0:dotLength-E;
	}
	return length
}
//数字（包含科学计数法）转为字符串
function EToString(num){
	var indexE = num.toString().toLowerCase().indexOf("e");
	var indexDot = num.toString().toLowerCase().indexOf(".");
	var E = num.toString().toLowerCase().split('e')[1];
	var S,E;
	if(indexE==-1){
		S = num.toString();
	}else if(indexDot==-1){
		S = append0(num.toString().toLowerCase().split('e')[0],E);
	}else{
		int0 = num.toString().toLowerCase().split('e')[0].replace(".","");
		E = E -(indexE-indexDot-1);
		S = append0(int0,E);
	}
	return S
}
//科学计数法补0
//例如11e-6,num是11，E是-6,num需为整数
function append0(num,E){
	if(parseInt(num)==num){
		var ret="";
		num=num.toString();
		E = parseInt(E);
		if(E>0){
			ret =num;
			for(i=0;i<E;i++){
				ret=ret+"0";
			}
		}else if(E==0){
			ret = num.toString();
		}else{
			var l = num.toString().length;
			if(l+E<=0){
				if(num.toString().indexOf("-")!=-1){
					for(i=1;i<=-E-l+1;i++){
						ret=ret+"0";
					}
					ret="-0."+ret+num.substring(1,l);
				}else{
					for(i=1;i<=-E-l;i++){
						ret=ret+"0";
					}
					ret="0."+ret+num;
				}
			}else{
				ret=num.toString().substring(0,l+E)+"."+num.toString().substring(l+E,l);
			}
		}
		return ret
	}else{
		return false
	}
}





var i=1;
i.add(2);





