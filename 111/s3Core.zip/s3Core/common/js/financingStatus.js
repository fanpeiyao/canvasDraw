/**
 * 融资状态
 * @author zjfh-tanx
 * @date   2017/07/12
 */
var uploadStatusRelation 
	= [
   //系统状态		   //显示状态
   {sysStatus:'10',disStatus:'001'},	//可上传融资10				未融资001
   {sysStatus:'11',disStatus:'002'},	//待企业审核11 				待企业审核002                               
                               
   {sysStatus:'12',disStatus:'003'},	//企业已拒绝12				企业已拒绝003
   {sysStatus:'7',disStatus:'004'},		//处理成功7				待融资004
   {sysStatus:'0',disStatus:'005'},		//提交成功,等待银行处理0		上传中005
   {sysStatus:'1',disStatus:'005'},		//授权成功,等待银行处理1		上传中005
   {sysStatus:'2',disStatus:'005'},		//等待授权2				上传中005   
   {sysStatus:'5',disStatus:'006'},		//超期作废5				上传失败006
   {sysStatus:'6',disStatus:'006'},		//指令处理失败6				上传失败006
   {sysStatus:'8',disStatus:'006'}		//指令被拒绝授权8			上传失败006
   ];
var financingStatusRelation
	=[
   {sysStatus:'00',disStatus:'007'},	//待确认00				合同待确认007
   {sysStatus:'01',disStatus:'008'},	//申请中01				银行处理中008
   {sysStatus:'02',disStatus:'009'},	//审批成功02				可提款009
   {sysStatus:'03',disStatus:'010'},	//已放款03				已融资010
   {sysStatus:'04',disStatus:'010'},	//已结清04				已融资010
   {sysStatus:'11',disStatus:'010'},	//已逾期11				已融资010
   {sysStatus:'20',disStatus:'011'},	//已拒绝20				已失效011
   {sysStatus:'21',disStatus:'011'},	//银行已拒绝21				已失效011
   {sysStatus:'22',disStatus:'011'},	//用户已拒绝22				已失效011
   {sysStatus:'23',disStatus:'011'}		//已失效23				已失效011
   ];

var displayStatus
	=[
	  {value:'001',text:'未融资',categ:'0'},
	  {value:'002',text:'待企业审核',categ:'0'},
	  {value:'003',text:'企业已拒绝',categ:'0'},
	  {value:'004',text:'待融资',categ:'0'},
	  {value:'005',text:'上传中',categ:'0'},
	  {value:'006',text:'上传失败',categ:'0'},
	  {value:'007',text:'合同待确认',categ:'1'},
	  {value:'008',text:'银行处理中',categ:'1'},
	  {value:'009',text:'可提款',categ:'1'},
	  {value:'010',text:'已融资',categ:'1'},
	  {value:'011',text:'已失效',categ:'1'}
	 ];
/**
 * 获取展示状态（文字）
 * @param status
 * @param type
 * @returns {String}
 */
function getDisplayStatus(uploadStatus,financingStatus){
	var displayStatusValue = '';
	if(financingStatus == '99' || financingStatus == '' || financingStatus == undefined){
		for(var i in uploadStatusRelation){
			if(uploadStatusRelation[i].sysStatus == uploadStatus){
				displayStatusValue = uploadStatusRelation[i].disStatus;
			}				
		}
	}else{
		for(var i in financingStatusRelation){
			if(financingStatusRelation[i].sysStatus == financingStatus){
				displayStatusValue = financingStatusRelation[i].disStatus;
			}
		}
	}
	
	if(displayStatusValue != ''){
		for(var i in displayStatus){
			if(displayStatus[i].value == displayStatusValue){
				displayStatusValue =  displayStatus[i].text;
			}
		}
	}
	return displayStatusValue;
}
/**
 * 获取系统状态（数字）
 * @param disStatus
 * @returns {String}
 */
function getSystemStatus(disStatus){
	var sysStatus = '';
	for(var i in financingStatusRelation){
		if(financingStatusRelation[i].disStatus == disStatus){
			sysStatus += financingStatusRelation[i].sysStatus+",";
		}
	}
	if(sysStatus != ''){
		return sysStatus;
	}else{
		for(var i in uploadStatusRelation){
			if(uploadStatusRelation[i].disStatus == disStatus){
				sysStatus += uploadStatusRelation[i].sysStatus+",";
			}
		}
	}
	return sysStatus;
}

