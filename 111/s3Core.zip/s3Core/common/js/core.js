var Core = function(){};

/**
 * ajax执行一个服务器端Action
 * 一个Action可描述为　类名+方法名+别名(可选) 或 portalConfig中配置的数据集ID + 别名(可选)
 * id: 如 com.longkey.UserBean.test as test1 或 id1 as a 或 userBean.test as b
 * cmd(optional): 执行程序的返回值类型，json/xml/txt/void 默认为json，其中void表示不返回 
 * params(optional): 参数，可以是一个js对象，也可以是 var1=aa&var2=bb&... 这样的字符串
 * async(optional): 异步标记，默认为同步(false)
 * callback(optional): 回调函数
 * loadDivId(optional): 异步调用时，显示loading图片的div的id
 * method(optional):http请求类型 GET/POST, 默认POST
*/
function execajax(id, cmd, params, async, callback, loadDivId, httpMethod){
	return execjava(id, params, cmd, async, callback, loadDivId, httpMethod);
};

/**
 * 判断是否是移动端
 */
function isMobile(){
	var sUserAgent = navigator.userAgent;
	if (sUserAgent.indexOf("Android") > -1 || 
			sUserAgent.indexOf("iPhone") > -1 || 
			sUserAgent.indexOf("iPad") > -1 || 
			sUserAgent.indexOf("iPod") > -1 || 
			sUserAgent.indexOf("Symbian") > -1){
		return true;
	}
	return false;
}

/**
 * ajax执行一个服务器端Action
 * 一个Action可描述为　类名+方法名+别名(可选) 或 portalConfig中配置的数据集ID + 别名(可选)
 * id: 如 com.longkey.UserBean.test as test1 或 id1 as a 或 userBean.test as b
 * params(optional): 参数，可以是一个js对象，也可以是 var1=aa&var2=bb&... 这样的字符串
 * cmd(optional): 执行程序的返回值类型，json/xml/txt/void 默认为json，其中void表示不返回  
 * async(optional): 异步标记，默认为同步(false)
 * callback(optional): 回调函数
 * loadDivId(optional): 异步调用时，显示loading图片的div的id
 * httpMethod(optional): http请求类型 GET/POST, 默认POST
 * invokeCustId(optional): 调用站点，不设时取当前站点
*/
function execjava(id, params, cmd, appId, async, callback, loadDivId, httpMethod, invokeCustId){
	if(!id)
		return;
	if(!async)
		async = false;
	if(!cmd)
		cmd = 'json';
	if(!httpMethod)
		httpMethod = 'POST';
	if(!invokeCustId)
		invokeCustId = getCustId();
	if(!appId)
		appId = getCustId();
	
	var paramObj = CoreSupport.treatParams(params);	
	if (!params)
		var code = "";
	else
		var code = params.code;
	var paramstr = CoreSupport.DataSetIdList + '=' + encodeURIComponent(id) + '&' + CoreSupport.DataSetParams + '=' + encodeURIComponent(CoreSupport.toJSONString(paramObj)) + '&__appId=' + encodeURIComponent(appId) + '&__code=' + encodeURIComponent(code);	
	uri = getRealPath() + '~main/ajax.php';
	if(isForward()=="true")
		uri = getRealPath()+"fwdsvr/index.php?url="+getRealPath() + '~main/module/testForward/ajax.php';
	var results = CoreSupport.ajax(uri, paramstr, callback, async, httpMethod, appId);
	if(async){
		if(loadDivId)
			$$(loadDivId).innerHTML="<table width='100%' height='100%' boder='0'><tr><td align='center' valign='middle'><img src='" + JsSupport.getUISPContextPath() + "/images/loading/001.gif'><img src='" + JsSupport.getUISPContextPath() + "/images/loading/Loading.gif'></td></tr></table>";	
	}
	else{
		try{
			if(cmd == 'json'){
				var returndata =  eval("(" + results + ")");
				//var returndata = eval("({'flag':'0','status':'500', 'retmsg':'有问题有严重问题!','retpage':'http://109.0.14.140','info':{}})");
				if (returndata.ESPRESSO_RETURN_VERSION == "1.0") {
					if (returndata.status == "001" || returndata.status == "002") {
						if (isMobile() == true) {
							var uri = getRealPath() + "mobile/" + "errorInfo.php";
						}
						else {
							var uri = getRealPath() + "~main/" + "errorInfo.php";
						}
						if(returndata.retmsg){
							uri += "?retmsg=" + encodeURIComponent(returndata.retmsg);
						}else{
							uri += "?retmsg=" + encodeURIComponent("您刚才的操作没有成功执行，请稍后再试！");
						}
						if(returndata.url){
							uri += "&retpage=" + getRealPath() + "~main/" + "/"+encodeURIComponent(returndata.url);
						}else{
							uri += "&retpage=" + (getRealPath() + "~main/" + "index.php");
						}
						window.location.href = uri;
						return;
					}
					if (returndata.status == "003")
						return returndata;
					return returndata.data;
				}
				if(returndata.status == "999") 
				{
					if (isMobile() == true) {
						var uri = getRealPath() + "mobile/" + "errorInfo.php";
					}
					else {
						var uri = getRealPath() + "~main/" + "errorInfo.php";
					}
					if(returndata.retmsg){
						uri += "?retmsg=" + encodeURIComponent(returndata.retmsg);
					}else{
						uri += "?retmsg=" + encodeURIComponent("您刚才的操作没有成功执行，请稍后再试！");
					}
					if(returndata.retpage){
						uri += "&retpage=" + getRealPath() + "~main/" + "/"+encodeURIComponent(returndata.retpage);
					}else{
						uri += "&retpage=" + (getRealPath() + "~main/" + "index.php");
					}
					window.location.href = uri;
					return;
				}
				if(returndata.status == "500") 
				{
					var uri = getRealPath() + "p/"+ '~' + invokeCustId + "/" + "connecterror.php";
					window.location.href = uri;
					return;
				}
				return returndata;
			}
			else if(cmd == "void")
				return;
			else
				return results;
		}
		catch(e){
		
		}
	}	
};



