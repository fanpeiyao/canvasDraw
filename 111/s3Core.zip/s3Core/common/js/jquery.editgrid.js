/*
* jQuery editGuid plugin
* Version 1.0 (01/26/2015)
* @requires jQuery v1.10.2 or later
*
* 
*/

(function($) {

    $.fn.editgrid = function(options) {

        var opts = $.extend({}, $.fn.editgrid.defaults, options);

        return this.each(function() {

        // empty out the destination element and then render out the pager with the supplied options
            $(this).empty().append(render(options.metadata, options.data));
            
            // specify correct cursor activity
           // $('.pages li').mouseover(function() { document.body.style.cursor = "pointer"; }).mouseout(function() { document.body.style.cursor = "auto"; });
        });
    };

    // render and return the grid with the supplied options
    function render(metadata, data) {  	
    	switch (metadata.type) {
    		case "table":
    			return renderTable(metadata, data);
    		case "info":
    			return renderInfo(metadata, data);
    		default:
    			return renderTable(metadata, data);
    	}
  
    }
    
    function renderTable(metadata, data) {
    	var columns = metadata.columns;
    	var hcolumns = metadata.hcolumns;

        // setup $grid to hold render
        var $grid = $('<table>');
        if (metadata.width != null)
        	$grid.attr("width", metadata.width);
        if (metadata.height != null)
        	$grid.attr("height", metadata.height);
        if (metadata.id != null)
        	$grid.attr("id", metadata.id);
        if (metadata.tClass != null)
        	$grid.addClass(metadata.tClass);

        // add in the thead row
        var $thead = renderthead(metadata, hcolumns, data);
        $grid.append($thead);
        
        // add in the following rows
        if (data.length == 0 && metadata.nonMsg != null){
        	$grid.append('<tr><td class="f1 fw bg_tr1" colspan="'+hcolumns.length+'">'+metadata.nonMsg+'</td></tr>');
        }
        else {
        	var dtrClass = metadata.dtrClass;
        	for (var i=0;i<data.length;i++){
    			$grid.append(renderrow(columns, data[i], i,dtrClass, metadata.rowId));
    			if (metadata.appendRow != null)
    				$grid.append(renderAppendrow(metadata.appendRow, i));
        	}
        	if (metadata.sumcolumns != null)
        		$grid.append(renderrow(metadata.sumcolumns, data, i, dtrClass, metadata.rowId));
        }

        $grid.append('</table>');

        return $grid;
    }
    
    function renderInfo(metadata, data) {
    	var dhead = metadata.dhead;
    	var dbody = metadata.dbody;

        // setup $grid to hold render
        var $grid = $('<div>');

        // add in the title head
        var $ihead = renderihead(dhead, data);
        $grid.append($ihead);
        
        // add in the body info
        var $ibody = renderibody(dbody, data);
        $grid.append($ibody);
        
        $grid.append('</div>');

        return $grid;
    }
    
    function renderihead(dhead, data) {
    	var $ihead = $('<div>');
    	if (dhead.dClass != null)
    		$ihead.addClass(dhead.dClass);
    	
    	var $p = $('<p>');
    	if (dhead.pClass != null)
    		$p.addClass(dhead.pClass);
    	var pdata = data;
    	if (dhead.data != null)
    		pdata = data[dhead.data];
    	for (var i=0;i<dhead.columns.length;i++)
    		$p.append(renderiheadcol(dhead.columns[i], pdata));
    	$p.append('</p>');
    	
    	$ihead.append($p);
    	$ihead.append('</div>');
    	
    	return $ihead;
    }
    
    function renderibody(dbody, data) {
    	var $ibody = $('<div>');
    	if (dbody.dClass != null)
    		$ibody.addClass(dbody.dClass);
    	var pdata = data;
    	for (var i=0;i<dbody.blocks.length;i++) {
    		if (dbody.blocks[i].data != null)
        		pdata = data[dbody.blocks[i].data];
    		$ibody.append(renderblock(dbody.blocks[i], data, pdata));
    	}
    	$ibody.append('</div>')
    	return $ibody;
    }
    
    function renderblock(block, data, pdata) {
    	var $db = $('<div>');
    	if (block.dClass != null)
    		$db.addClass(block.dClass);
    	
    	var $p = $('<p>');
    	if (block.pClass != null)
    		$p.addClass(block.pClass);
    	$p.append(block.title);
    	$p.append('</p>')
    	$db.append($p);
    	
    	switch (block.type) {
    	case "info":
    		for (var i=0;i<block.rows.length;i++) {
        		if (block.rows[i].data != null)
            		pdata = data[blocks.rows[i].data];
        		$db.append(renderblockrow(block.rows[i], data, pdata));
        	}
    		break;
    	case "table":
    		if (block.data != null)
    			pdata = data[block.data];
    		$db.append(renderTable(block.table, pdata));
    	}
    	
    	
    	$db.append('</div>');
    	return $db;
    }
    
    function renderblockrow(row, data, pdata) {
    	var $dr = $('<div>');
    	
    	if(row.rClass != null)
    		$dr.addClass(row.rClass);
    	if(row.id != null)
    		$dr.attr("id", row.id);
    	
    	for(var i=0;i<row.columns.length;i++) {
    		if (row.columns[i].data != null)
    			pdata = data[row.columns[i].data];
    		$dr.append(renderblockrowcol(row.columns[i], pdata));
    	}
    	
    	$dr.append('</div>');
    	
    	return $dr;
    }
    
    function renderblockrowcol(col, data) {
    	switch (col.type) {
    	case "text":
    		var $p = $('<p>');
    		if (col.pClass != null)
    			$p.addClass(col.pClass);
    		if (col.id != null)
    			$p.attr("id", col.id);
    		var $f = $('<font>');
    		if(col.fClass != null)
    			$f.addClass(col.fClass);
    		$f.append(col.title);
    		$f.append('</font>');
    		$p.append($f);
    		var v = data[col.field];
    		if (col.values != null)
    			v = col.values[v];
    		$p.append(v);
    		$p.append('</p>');
    		return $p;
    	case "textArea":
    		var $p = $('<p>');
    		if (col.pClass != null)
    			$p.addClass(col.pClass);
    		if (col.id != null)
    			$p.attr("id", col.id);
    		var $f = $('<font>');
    		if(col.fClass != null)
    			$f.addClass(col.fClass);
    		$f.append(col.title);
    		$f.append('</font>');
    		$p.append($f);
    		
    		var $s = $('<span>');
    		var $t = $('<textarea readonly="true">');
    		if (col.tClass != null)
    			$t.addClass(col.tClass);
    		$t.append(data[col.field]);
    		$t.append('</textarea>');
    		$s.append($t);
    		$s.append('</span>');
    		$p.append($s);
    		
    		$p.append('</p>');
    		return $p;
    	default :
    		var $p = $('<p>');
			if (col.pClass != null)
				$p.addClass(col.pClass);
			if (col.id != null)
				$p.attr("id", col.id);
			var $f = $('<font>');
			if(col.fClass != null)
    			$f.addClass(col.fClass);
			$f.append(col.title);
			$f.append('</font>');
			$p.append($f);
			var v = data[col.field];
			if (col.values != null)
				v = col.values[v];
			$p.append(v);
			$p.append('</p>');
			return $p;
    	}
    }
    
    function renderthead(metadata, columns, data) {
    	 var $thead = $('<tr>');
    	 var thClass = "";
    	 if (metadata.trClass != null)
				$thead.addClass(metadata.trClass);
    	 if (metadata.thClass != null)
    		 	thClass = metadata.thClass;
         for (var i=0;i<columns.length;i++)
         	$thead.append(rendertheadcol(columns[i],thClass, data));
         
         $thead.append('</tr>')
    	
    	return $thead;
    }
    
    function renderiheadcol(col, data) {
    	var $ts = $('<span>');
    	if(col.sClass != null){
    		$ts.addClass(col.sClass);
    	}
    	$ts.append(col.title);
    	$tf = $('<font>');
    	
    	var v = data[col.field];
    	if (col.values != null)
    		v = col.values[v];
    	
    	$tf.append(v);
    	if (col.fClass != null)
    		$tf.addClass(col.fClass);
    	$tf.append('</font>')
    	$ts.append($tf);
    	$ts.append('</span>');
    	
    	return $ts;
    }
    
    function rendertheadcol(col,thc,data) {
    	var $th = $('<th>');
    	if(thc != ""){
    		$th.addClass(thc);
    	}
    	
    	switch (col.type) {
    		case "checkbox":
    			$ti = $('<input type="checkbox" value="" />');
    			if (col.name != null)
    				$ti.attr("name", col.name);
    			if (col.callback != null)
    				$ti.bind(col.callback.eventType,col.callback.listener);
    			if (col.width != null)
    				$th.attr("width", col.width);
    			if (col.val != null)//tc
    				$ti.attr("checked", col.val);
    			if(col.valueCheck!=null){
    				$ti.val(eval("col."+col.valueCheck));
    			}
    			if(col.css!=null){
    				$ti.addClass(col.css);
    			}
    			$th.append($ti);
    			break;
    			
    		case "select":
    			var options = col.options;
    			if(options!=null&&options.length>0){
    				$sl = $("<select>");
    				for(var s = 0;s<options.length;s++){
    					if (options[s].val == data[col.field])
        					$op = $("<option value='"+options[s].val+"' selected>"+options[s].text+"</option>");
    					else
    						$op = $("<option value='"+options[s].val+"'>"+options[s].text+"</option>");
    					$sl.append($op);
    				}
    				$sl.append("</select>");
    				
    				if(col.callback!=null){
    					$sl.bind(col.callback.eventType,col.callback.listener);
    				}
    				if (col.id != null)
        				$sl.attr("id", col.id);
    				if (col.width != null)
        				$th.attr("width", col.width);
    				$th.append($sl);
    			}
    			break;
    		default:
    			$th.append(col.title);
    			if (col.width != null)
    				$th.attr("width", col.width);
    			if(col.css!=null){
    				$th.addClass(col.css);
    			}
    			break;
    	}
    	
    	$th.append('</th>');
    	
    	return $th;
    }
    
    function renderrow(columns, data, row, dtrc, rowId) {
    	var $tr = $('<tr>');
    	if (rowId != null)
    		$tr.attr("id",rowId+row);
    			
    	//隔行换色
    	if(dtrc!=null){
    		if((row+1)%2 == 0 ){
    			$tr.addClass(dtrc);
    		}
    	}
    	
		for (var j=0;j<columns.length;j++){
			$tr.append(rendercol(columns[j],data,row));
		}
    	
    	$tr.append('</tr>');
    	
    	return $tr;
    }
    
    function renderAppendrow(row, i) {
    	var $tr = $('<tr style:"dispaly:none;">');
    	if (row.css != null)
    		$tr.addClass(row.css);
    	if (row.id != null)
    		$tr.attr("id",row.id+i);
    	$tr.append('</tr>');
    	
    	return $tr;
    }
    
    function rendercol(col, data, i) {
    	var $td = $('<td>');
    	
    	switch (col.type) {
    		case "seq":
    			$td.append(i+1);
    			break;
    		case "radio":
    			$ti = $("<input type='radio' value='"+data[col.field]+"'/>");
    			$ti.attr("name",col.name);
    			if(col.callback != null)
    				$ti.bind(col.callback.eventType,col.callback.listener);
    			$ti.attr("rid", i);
    			$td.append($ti);
    			break;
    		case "img":
    			if (col.css != null)
    				$td.addClass(col.css);
    			$ti = $("<img/>");
    			if (col.id != null)
    				$ti.attr("id", col.id+i);
    			if (data[col.field]　!= null)
    				$ti.attr("src", data[col.field]);
    			if (col.height != null)
    				$ti.attr("height", col.height);
    			if (col.width != null)
    				$ti.attr("width", col.width);
    			if (col.callback != null) {
    				for (var t=0; t<col.callback.length;t++)
    					$ti.bind(col.callback[t].eventType,col.callback[t].listener);
    			}
    			$ti.attr("rid", i);
    			$td.append($ti);
    			break;
    		case "checkbox":
    			$ti = $('<input type="checkbox" value="" />');
    			if (col.name != null)
    				$ti.attr("name", col.name);
    			if (col.id != null)
    				$ti.attr("id", col.id+i);
    			if (col.val != null)
    				$ti.attr("checked", col.val);
    			if (col.callback != null)
    				$ti.bind(col.callback.eventType,col.callback.listener);
    			$ti.val(data[col.field]);
    			$ti.attr("rid", i);
    			$td.append($ti);
    			break;
    		case "text":
    			var v = data[col.field];
        		if (col.values != null)
        			v = col.values[v];
    			$td.append(v);
    			if (col.css != null)
    				$td.addClass(col.css);
    			if (col.name != null)
    				$td.attr("name", col.name);
    			if(typeof col.id != 'undefined'&& col.id!=""){
    				if(typeof data[col.id] != 'undefined')
    				$td.attr("id", data[col.id]);
    			}
    			$td.attr("rid", i);
    			break;
    		case "hypertext":
    			$ta = $('<a>'+data[col.field]+'</a>');
	    		$ta.attr("href","javascript:void(0);");
	    		$ta.attr(col.field,data[col.id]);
	    		if(col.callback!=null)
	    			$ta.bind(col.callback.eventType,col.callback.listener);
	    		$td.append($ta);
	    		if (col.css != null)
    				$td.addClass(col.css);
    			$td.attr("rid", i);
    			break;
    		case "money":
    			if(data[col.field]==null || data[col.field] == ""){
    				$td.append("￥0.00");
    			}else{
    				$td.append("￥"+addCommafy(data[col.field]));
    			}
    			if (col.css != null)
    				$td.addClass(col.css);
    			if (col.id != null)
    				$td.attr("id", col.id+i);
    			if (col.name != null)
    				$td.attr("name", col.name);
    			$td.attr("rid", i);
    			break;
    		case "button":
    			$tb = $('<a>'+col.val+'</a>');
    			if (col.css != null)
    				$tb.addClass(col.css);
    			if (col.callback != null)
    				$tb.bind(col.callback.eventType,col.callback.listener);
    			$tb.attr("rid", i);
    			$td.append($tb);
    			break;	
    		case "buttons":
    			for (var j=0;j<col.val.length;j++) {
    				$tb = $('<a>'+col.val[j]+'</a>');
        			if (col.css[j] != null)
        				$tb.addClass(col.css[j]);
        			if (col.callback[j] != null)
        				$tb.bind(col.callback[j].eventType,col.callback[j].listener);
        			$tb.attr("rid", i);
        			$td.append($tb); 
    			}
    			break;
    		case "input":
    			$ti = $('<input type="text" />');
    			if (data[col.field] != null)
    				$ti.val(data[col.field]);
    			if (col.css != null)
    				$ti.addClass(col.css);
    			if (col.name != null)
    				$ti.attr("name", col.name);
    			if (col.id != null)
    				$ti.attr("id", col.id+i);
    			if (col.callback != null) {
    				for (var t=0; t<col.callback.length;t++)
    					$ti.bind(col.callback[t].eventType,col.callback[t].listener);
    			}
    			$ti.attr("rid", i);
    			$td.append($ti);
    			break;
    		case "input default":
    			$ti = $('<input type="text" value='+col.val+' />');
    			if (col.css != null)
    				$ti.addClass(col.css);
    			if (col.name != null)
    				$ti.attr("name", col.name);
    			if (col.id != null)
    				$ti.attr("id", col.id+i);
    			$ti.attr("rid", i);
    			$td.append($ti);
    			break;
    		case "select":
    			var sval = data[col.field];
    			if (sval == null || sval == "") {
    				$td.append("-");
    				break;
    			}
    			$ts = $('<select></select>');
    			if (col.id != null)
    				$ts.attr("id", col.id+i);
    			$to = $('<option value='+col.val[0]+'>'+col.val[1]+'</option>')
    			$ts.append($to);
    			var svals = sval.split("|");
				for(var j=0;j<svals.length;j++) {
					$to = $('<option value='+svals[j]+'>'+svals[j]+'</option>')
	    			$ts.append($to);
				}
				$ts.attr("rid", i);
				$td.append($ts);
    			break;	
    		case "c_select":
    			var sval = data[col.field];
    			if (sval == null || sval == "") {
    				$td.append("-");
    				break;
    			}
    			$ts = $('<select></select>');
    			if (col.id != null)
    				$ts.attr("id", col.id+i);
    			if (col.callback != null)
    				$ts.bind(col.callback.eventType,col.callback.listener);
    			$to = $('<option value='+col.val[0]+'>'+col.val[1]+'</option>')
    			$ts.append($to);
    			var svalue = sval.split(",");
				var svals = svalue[0].split("|");
				var chooseval = svalue[1];
				for(var j=0;j<svals.length;j++) {
					if (svals[j] == chooseval)
						$to = $('<option value='+svals[j]+' selected="selected">'+svals[j]+'</option>');
					else
						$to = $('<option value='+svals[j]+'>'+svals[j]+'</option>');
	    			$ts.append($to);
				}
				$ts.attr("rid", i);
				$td.append($ts);
    			break;	
    		case "selected":
    			var sval = data[col.field];
    			if (sval == null || sval == "") {
    				$td.append("-");
    				break;
    			}
    			var svalue = sval.split(",");
				var svals = svalue[0].split("|");
				var chooseval = svalue[1];
				$td.append(chooseval);
    			break;
    		case "hidden":
    			$ti = $('<input type="hidden" value='+data[col.field]+' />');
    			if (col.css != null)
    				$ti.addClass(col.css);
    			if (col.name != null)
    				$ti.attr("name", col.name);
    			if (col.id != null)
    				$ti.attr("id", col.id+i);
    			$ti.attr("rid", i);
    			return $ti;
    		case "value":
    			if(col.css != null )
    				$td.addClass(col.css);
    			$td.append(col.title);
    			break;
    		case "plus-minus":
				var flag = data[col.condition]>0;
				if (flag == false)
					break;
				
    			//plus
    			$tp = $('<a>+</a>');
	    		$tp.attr("href","javascript:void(0);");
	    		if(col.callback!=null)
	    			$tp.bind(col.callback.p.eventType,col.callback.p.listener);
	    		if (col.css.p != null)
    				$tp.addClass(col.css.p);
	    		if (col.id.p != null)
	    			$tp.attr("id", col.id.p+i);
    			$tp.attr("rid", i);
    			
    			//minus
    			$tm = $('<a>-</a>');
	    		$tm.attr("href","javascript:void(0);");
	    		if(col.callback!=null)
	    			$tm.bind(col.callback.m.eventType,col.callback.m.listener);
	    		if (col.css.m != null)
    				$tm.addClass(col.css.m);
	    		if (col.id.m != null)
	    			$tm.attr("id", col.id.m+i);
	    		$tm.attr("style", "display:none");
    			$tm.attr("rid", i);
    			
    			$td.append($tp);
    			$td.append($tm);
    			break;
    		default:
    			$td.append(data[col.field]);
    			$td.attr("rid", i);
    			break;
    	}
    	
    	$td.append('</td>');
    	
    	return $td;
    }

    // pager defaults. hardly worth bothering with in this case but used as placeholder for expansion in the next version
    $.fn.editgrid.defaults = {
        rowheight: 1,
        rows: 1
    };

})(jQuery);