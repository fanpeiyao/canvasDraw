

String.prototype.len=function(){
	return this.replace(/[^\x00-\xff]/g,"rr").length;
};
//add by kfzx-xuqq:去除千分位  
function delCommafy(num){
	num=num.replace(/,/gi,'');
	return num;
}
//add by kfzx-xuqq: 以千分位显示     
function addCommafy(s) {
	if(typeof(s)=='undefined' || s.length<0){
		return '';
	}
    s=parseFloat(s);//去除首位输入的0，如002，小数不影响parseFloat字符串转数字  
    s=s.toFixed(2);//四舍五入保留两位小数
    s=s.toString();  
    s = s.replace(/^(\+|-?\d*)$/, "$1.");  
    s = (s + "00").replace(/(\d*\.\d\d)\d*/, "$1");  
    s = s.replace(".", ",");  
    var re = /(\d)(\d{3},)/;  
    while (re.test(s))  
    s = s.replace(re, "$1,$2");  
    s = s.replace(/,(\d\d)$/, ".$1");  
    return s.replace(/^\./, "0.");
}
Number.prototype.toFixed=function (d) { 
    var s=this+""; 
   if(!d)d=0; 
    if(s.indexOf(".")==-1)s+="."; 
    s+=new Array(d+1).join("0"); 
   if(new RegExp("^(-|\\+)?(\\d+(\\.\\d{0,"+(d+1)+"})?)\\d*$").test(s)){
       var s="0"+RegExp.$2,pm=RegExp.$1,a=RegExp.$3.length,b=true;
       if(a==d+2){
           a=s.match(/\d/g); 
           if(parseInt(a[a.length-1])>4){
              for(var i=a.length-2;i>=0;i--){
                   a[i]=parseInt(a[i])+1;
                  if(a[i]==10){
                      a[i]=0;
                       b=i!=1;
                   }else break;
               }                         }
          s=a.join("").replace(new RegExp("(\\d+)(\\d{"+d+"})\\d$"),"$1.$2");

      }if(b)s=s.substr(1); 
       return (pm+s).replace(/\.$/,"");
 }return this+"";

};

//kfzx-yudh：将JSON字符串转成购物车和订单详情展示的字符串
function jsonStringToOrderString(proJsonString, oldJsonString, length){
	//add by kfzx-xuqq
	var proJson = new Object();
	var oldJson = new Object();
	var b = new Base64();
	if(proJsonString!=""){
		proJson=eval('('+ proJsonString +')');
	}
	if(oldJsonString!=""){
		oldJson=eval('('+ oldJsonString +')');
	}	
	var totalLength=0;
	var productdetail = ""; //拼新订单属性字符串
	var productdiff = '<h1 align="center"><strong>原始订单</strong></h1></br>';//拼原始订单属性字符串
	for (var m=0; m < proJson.length; m++) {
   		for(var n=0; n< oldJson.length; n++){
   			if (proJson[m].attrId == oldJson[n].attrId) {
   				//add by luzhao 对备注信息进行2次解码
				
   				if(proJson[m].attrName != undefined && proJson[m].attrName != "" && proJson[n].attrId !="RMK"){
   					var tlength=0;
   					if(proJson[m].attrValueText == ""){
	   					tlength = proJson[m].attrName.len()
							+(6>oldJson[m].attrValueText.len()?
									6:oldJson[m].attrValueText.len())
							+4;
   					}else if(oldJson[m].attrValueText == ""){
	   					tlength = proJson[m].attrName.len()
							+(proJson[m].attrValueText.len()>6?
									proJson[m].attrValueText.len():6)
							+4;
   					}else{
   						tlength = proJson[m].attrName.len()
						+(proJson[m].attrValueText.len()>oldJson[m].attrValueText.len()?
								proJson[m].attrValueText.len():oldJson[m].attrValueText.len())
						+4;
   					}	
   					
					if(totalLength+tlength > length){
						productdetail+="<br/>";
						productdiff+="<br/>";
						totalLength = tlength;	
					}
					else{
						totalLength+=tlength;
					}
	   				//对属性进行飘红和加粗处理,add by kfzx-xuqq
	   				if (proJson[m].attrValueText != oldJson[n].attrValueText) {
	   					productdetail += "<font color='#333333'>" + proJson[m].attrName + "：</font>";
	   					if(proJson[m].attrName!=""){
	   						productdetail = productdetail + "<span><font color='red'>" + proJson[m].attrValueText+"</font></span>" + "；";
	   					}else{
	   						productdetail = productdetail + "<span><font color='red'>" + "未选择" + "</font></span>" + "；";
	   					}
	   					productdiff += "<font color='#333333'>" + oldJson[n].attrName + "：</font>";
	   					if(oldJson[n].attrValueText!=""){
	   						productdiff  = 	productdiff + "<span><font color = 'red'>" + oldJson[n].attrValueText+"</font></span>" + "；";
	   					}else{
	   						productdiff  = 	productdiff + "<span><font color = 'red'>" + "未选择" +"</font></span>" + "；";
	   					}
	   				}else{
	   					productdetail += "<font color='#333333'>" + proJson[m].attrName + "：</font>";
	   					if(proJson[m].attrValueText!=""){
	   						productdetail += "<font color='#666666'>" + proJson[m].attrValueText + "；</font>";
	   					}else{
	   						productdetail += "<font color='#666666'>" + "未选择" + "；</font>";
	   					}
	   					productdiff += "<font color='#333333'>" + oldJson[n].attrName + "：</font>";
	   					if(oldJson[n].attrValueText!=""){
	   						productdiff += "<font color='#666666'>" + oldJson[n].attrValueText + "；</font>";
	   					}else{
	   						productdiff += "<font color='#666666'>" + "未选择" + "；</font>";
	   					}
	   				}
   				}
   				else if(proJson[n].attrId =="RMK"){
					proJson[m].attrValueText = b.decode(proJson[m].attrValueText);
					oldJson[n].attrValueText = b.decode(oldJson[n].attrValueText);
					productdetail += "<br/><font color='#333333'>" + proJson[m].attrName + "：</font>";
					if(proJson[m].attrValueText!=""){
	   					productdetail += "<font color='#666666'>" + proJson[m].attrValueText + "</font>";
					}
					productdiff += "<br/><font color='#333333'>" + oldJson[n].attrName + "：</font>";
					if(oldJson[n].attrValueText!=""){
	   					productdiff += "<font color='#666666'>" + oldJson[n].attrValueText + "</font>";
					}	
				}
				
   			}
	   	}
   	}
	var returnValue = [];
	returnValue[0]=productdetail;
	returnValue[1]=productdiff;
	return returnValue;
}
//kfzx-yudh：将JSON字符串转成购物车和订单详情展示的字符串，无修改后订单
function jsonStringToOrderStringOld(oldJsonString, length){
	//add by kfzx-xuqq
	var oldJson = new Object();
	var b = new Base64();
	if(oldJsonString!=""){
		oldJson=eval('('+ oldJsonString +')');
	}
	var totalLength=0;
	var productdiff = ""; //拼新订单属性字符串
	for(var n=0; n< oldJson.length; n++){
		
		if(oldJson[n].attrId !="RMK"){
			var tlength = oldJson[n].attrName.len()
			+(oldJson[n].attrValueText.len()==""?6:oldJson[n].attrValueText.len())
			+4;
			
			if(totalLength+tlength > length){
				productdiff+="<br/>";
				totalLength = tlength;	
			}
			else{
				totalLength+=tlength;
			}
			productdiff += "<font color='#333333'>" + oldJson[n].attrName + "：</font>";
			if(oldJson[n].attrValueText!=""){
				productdiff += "<font color='#666666'>" + oldJson[n].attrValueText + "；</font>";
			}else{
				productdiff += "<font color='#666666'>" + "未选择" + "；</font>";
			}
		}	
		//add by luzhao 对备注信息进行2次解码
		else {
			oldJson[n].attrValueText = b.decode(oldJson[n].attrValueText);
			if(oldJson[n].attrValueText!=""){
				productdiff += "<br/><font color='#333333'>" + oldJson[n].attrName + "：</font>";
				productdiff += "<font color='#666666'>" + oldJson[n].attrValueText + "</font>";
			}	
		}
			
   	}	
	return productdiff;
}

//数量文本框校验
function validateNum(object) {
	var  number_pattern = /^[1-9][0-9]*$/;
	if (!number_pattern.test(object.value)) {
		info("请输入正整数！");
		object.value = "1";
		return 1;
	}	
	return 0;
}

function validateRMKLength(RMKId,tipId, length) {
	if($.trim($("#"+RMKId).val()).length > Number(length)){
		$("#"+tipId).html("您已输入" + $("#"+RMKId).val().length +"个字，备注请勿超过"+length+"字");
		document.getElementById(tipId).style.display = "block";
		return 1;
	}		
	if($.trim($("#"+RMKId).val()).length == 0 || $("#"+RMKId).val() == "备注请勿超过"+length+"字"){
		$("#"+RMKId).addClass("RMKTip");
		$("#"+RMKId).val("备注请勿超过"+length+"字");
	}		
	
	document.getElementById(tipId).style.display = "none";

	return 0;		
}	 

function clearText(RMKId,tipId, length){
	if($("#"+RMKId).val() == "备注请勿超过"+length+"字"){
		document.getElementById(tipId).style.display = "none";
		$("#"+RMKId).removeClass("RMKTip");
		$("#"+RMKId).val('');
	}
}

//虚拟一个Div通过赋值和取值得到html编码
escapeHTML = function(text) {
    return $("<div/>").text(text).html();
} 

//除法函数，用来得到精确的除法结果 
//说明：javascript的除法结果会有误差，在两个浮点数相除的时候会比较明显。这个函数返回较为精确的除法结果。 
//调用：accDiv(arg1,arg2) 
//返回值：arg1除以arg2的精确结果
function accDiv(arg1,arg2){ 
var t1=0,t2=0,r1,r2; 
try{t1=arg1.toString().split(".")[1].length}catch(e){} 
try{t2=arg2.toString().split(".")[1].length}catch(e){} 
with(Math){ 
r1=Number(arg1.toString().replace(".","")) 
r2=Number(arg2.toString().replace(".","")) 
return (r1/r2)*pow(10,t2-t1); 
} 
} 
//给Number类型增加一个div方法，调用起来更加方便。 
Number.prototype.div = function (arg){ 
return accDiv(this, arg); 
}
//乘法函数，用来得到精确的乘法结果 
//说明：javascript的乘法结果会有误差，在两个浮点数相乘的时候会比较明显。这个函数返回较为精确的乘法结果。 
//调用：accMul(arg1,arg2) 
//返回值：arg1乘以arg2的精确结果 
//function accMul(arg1,arg2) 
//{ 
//var m=0,s1=arg1.toString(),s2=arg2.toString(); 
//try{m+=s1.split(".")[1].length}catch(e){} 
//try{m+=s2.split(".")[1].length}catch(e){} 
//return Number(s1.replace(".",""))*Number(s2.replace(".",""))/Math.pow(10,m) 
//} 
//给Number类型增加一个mul方法，调用起来更加方便。 
//Number.prototype.mul = function (arg){ 
//return accMul(arg, this); 
//}
//加法函数，用来得到精确的加法结果 
//说明：javascript的加法结果会有误差，在两个浮点数相加的时候会比较明显。这个函数返回较为精确的加法结果。 
//调用：accAdd(arg1,arg2) 
//返回值：arg1加上arg2的精确结果 
function accAdd(arg1,arg2){ 
var r1,r2,m; 
try{r1=arg1.toString().split(".")[1].length}catch(e){r1=0} 
try{r2=arg2.toString().split(".")[1].length}catch(e){r2=0} 
m=Math.pow(10,Math.max(r1,r2)) 
return (arg1*m+arg2*m)/m 
} 
//给Number类型增加一个add方法，调用起来更加方便。 
Number.prototype.add = function (arg){ 
return accAdd(arg,this); 
}
//减法函数，用来得到精确的减法结果 
//说明：javascript的减法结果会有误差，在两个浮点数相加的时候会比较明显。这个函数返回较为精确的减法结果。 
//调用：accSubtr(arg1,arg2) 
//返回值：arg1减去arg2的精确结果 
function accSubtr(arg1,arg2){
var r1,r2,m,n;
try{r1=arg1.toString().split(".")[1].length}catch(e){r1=0}
try{r2=arg2.toString().split(".")[1].length}catch(e){r2=0}
m=Math.pow(10,Math.max(r1,r2));
//动态控制精度长度
n=(r1>=r2)?r1:r2;
return ((arg1*m-arg2*m)/m).toFixed(n);
} 
//给Number类型增加一个subtr 方法，调用起来更加方便。 
Number.prototype.subtr = function (arg){ 
return accSubtr(arg,this); 
}


/**
 * 兼容IE8以下版本，给数组原型添加 indexOf 方法
 * 获取元素在数组中的索引，如果数组中不存在元素，返回 -1；
 */
if(!Array.prototype.indexOf){
	Array.prototype.indexOf = function(item){
		var result = -1, a_item = null;
		if(this.length == 0){
			return result;
		}
		for(var i = 0, len = this.length;i < len; i++){
			a_item = this[i];
			if(a_item === item){
				result = i;
				break;
			}
		}
		return result;
	}
}

/**
 * 全选功能
 */
var checkedObj = (function(){
	// 获取数据存储的数据
	var checkedData = [];
	/**
	 * 单击全选
	 * @param obj 当前全选框
	 * @param one 单个checkbox的name属性值
	 */
	function checkAll(obj, one){
		var checkOneNodes = $("input:checkbox[name='"+ one +"']");
		$.each(checkOneNodes, function(index, item){
			item.checked = obj.checked;
		});
	}
	/**
	 * 单击单个选择框
	 * @param obj 当前事件框
	 * @param all 全选框的名称
	 */
	function checkOne(obj, all){
		var checkAllNode = $("input:checkbox[name='" + all +"']")[0];
		var checkOneNodes = $("input:checkbox[name='"+ obj.name +"']");
		$.each(checkOneNodes, function(index, item){
			if(!item.checked){
				checkAllNode.checked = false;
				return false;
			}
			checkAllNode.checked = true;
		});
	}
	
	/**
	 * 全选，并将全部选中的数据填充到一维数组中；取消选中，则将数据从数组中移除
	 * @param obj
	 */
	function checkedAllData(obj, one){
		var ones = $("input:checkbox[name='" + one + "']");
		$.each(ones, function(index, item){
			item.checked = obj.checked;
			// 获取当前未被选择元素的编号在数组中所处的位置
			var i = checkedData.indexOf($(item).attr("data"));
			if(item.checked){
				if(i == -1){
					checkedData.push($(item).attr("data"));
				}
			}else{
				checkedData.splice(i,1);
			}
		});
	}
	
	/**
	 * 单选，并将选中的数据填充到数组中，如果未选中，则将其从数组中移除
	 * @param obj
	 */
	function checkedOneData(obj, all){
		var all = $("input:checkbox[name='" + all +"']")[0];
		var ones = $("input:checkbox[name='" + obj.name + "']");
		$.each(ones, function(index, item){
			if(!item.checked){
				all.checked = false;
				return false;
			}
			all.checked = true;
		});
		if(obj.checked){
			checkedData.push($(obj).attr("data"));
		}else{
			// 获取当前未被选择元素的编号在数组中所处的位置
			var i = checkedData.indexOf($(obj).attr("data"));
			checkedData.splice(i,1);
		}
	}
	/**
	 * 返回存储的数据
	 */
	function getData(){
		return checkedData;
	}
	/**
	 * 将数组置为空
	 */
	function clearData(){
		checkedData = [];
	}
	return {
		checkedAll : checkAll,
		checkedOne : checkOne,
		checkedAllData : checkedAllData,
		checkedOneData : checkedOneData,
		getData : getData,
		clear : clearData
	};
})();

///**
// * 全选功能
// * 
// * @param obj 当前全选框
// * @param one 单个checkbox的name属性值
// */
//function checkAll(obj, one){
//	var checkOneNodes = $("input[name='"+ one +"']");
//	$.each(checkOneNodes, function(index, item){
//		item.checked = obj.checked;
//	});
//}
//
///**
// * 当前单个checkbox事件
// * @param obj 当前事件框
// * @param all 全选框的名称
// */
//function checkOne(obj, all){
//	var checkAllNode = $("input[name='" + all +"']")[0];
//	var checkOneNodes = $("input[name='"+ obj.name +"']");
////	checkAllNode.checked = obj.checked;
//	$.each(checkOneNodes, function(index, item){
//		if(!item.checked){
//			checkAllNode.checked = false;
//			return false;
//		}
//		checkAllNode.checked = true;
//	});
//}
///**
//* 全选，并将全部选中的数据填充到数组中；取消选中，则将数据从数组中移除
//* @param obj
//*/
//function checkedAllData(obj){
//	var ones = $("input:checkbox[name='oneData']");
//	$.each(ones, function(index, item){
//		item.checked = obj.checked;
//		// 获取当前未被选择元素的编号在数组中所处的位置
//		var i = checkedPurchase.indexOf($(item).attr("purchaseNo"));
//		if(item.checked){
//			if(i == -1){
//				checkedPurchase.push($(item).attr("purchaseNo"));
//			}
//		}else{
//			checkedPurchase.splice(i,1);
//		}
//	});
//}
//
///**
//* 单选，并将选中的数据填充到数组中，如果未选中，则将其从数组中移除
//* @param obj
//*/
//function checkedOneData(obj){
//	var all = $("input:checkbox[name='allData']")[0];
//	var ones = $("input:checkbox[name='oneData']");
//	$.each(ones, function(index, item){
//		if(!item.checked){
//			all.checked = false;
//			return false;
//		}
//		all.checked = true;
//	});
//	if(obj.checked){
//		checkedPurchase.push($(obj).attr("purchaseNo"));
//	}else{
//		// 获取当前未被选择元素的编号在数组中所处的位置
//		var i = checkedPurchase.indexOf($(obj).attr("purchaseNo"));
//		checkedPurchase.splice(i,1);
//	}
//}



