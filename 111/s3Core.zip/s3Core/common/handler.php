<?php
require_once '../~main/sys.config.php';
require_once 'core.class.php';

header('Content-Type:text/html;charset=UTF-8');

if(!class_exists('CURLFile'))
{
	$results->retCode = '500';
	$results->retMsg = "PHP版本过低，必须高于5.5.0";
	echo json_encode($results);
	exit(0);
}
	// 判断是否存在文件
	if (empty($_FILES)) {

		$results->retCode = '500';
		$results->retMsg = "文件不能为空";
		echo json_encode($results);
		exit(0);
	}

	
	$custId = _CUSTID;
	//$custId = "ultimate";
	// 上传文件的扩展名，并将其专为小写
/* 	$fileparts = pathinfo($source_file_name);
	$filextension = strtolower($fileparts['extension']); */	

	$appId = Core::getRealContext();
	$processDataUrl=Core::getBackEndUrl($custId);
	$cend = strripos($processDataUrl, '/');
	$contexturl = substr($processDataUrl,0, $cend);
	$remote_url =$contexturl.'/uploadHandler?INVOKE_CUST_ID=' . $appId;
	//$remote_url ='http://127.0.0.1:8888/ultimate/upload?INVOKE_CUST_ID=' . $custId;
	//$remote_url.=$param_str;
	//echo 0;
	
	$data=array();
	while(list($key,$val)=each($_FILES))
	{	

		
		// 上传文件原始名称
		$source_file_name = $val['name'];
		
		if($val["error"]>0)
		{
			$results->retCode = '500';
			$results->retMsg = "文件:(".$source_file_name.')上传失败，请检查文件上传限制，当前为：Size<='.ini_get("upload_max_filesize");
			echo json_encode($results);
			exit(0);
		}
		
		// 上传文件的临时路径文件
		$temp_file = $val['tmp_name'];
		
		
		if(!is_uploaded_file($temp_file)){
			continue;
		}
		
		// 上传文件大小
		//$filesize = $val['size'];
		
		$data[$key]=new CURLFile(realpath($temp_file));
		$data[$key]->setPostFilename($source_file_name);
		//$data[]
	
	}
	while(list($key,$val)=each($_REQUEST))
	{	
		$data[$key]=$val;
		//$data[]
		//echo $val;
	}
	$ckstr = '';
	$cks = array();
	foreach ($_COOKIE as $k => $v){
		$cks[$k] = $v;
	}
	foreach ($cks as $k => $v){
		$ckstr .= $k . '=' . $v . '; ';
	}
	
	//echo 1;
	$ch = curl_init();
	//echo $remote_url;
	
	
	//curl_setopt($ch,CURLOPT_URL,'http://109.6.29.155:19080/common/query/containerList');
	
	curl_setopt($ch,CURLOPT_URL,$remote_url);
	curl_setopt($ch,CURLOPT_POST,true);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
	curl_setopt($ch,CURLOPT_COOKIE,$ckstr);
	//curl_setopt($ch, CURLOPT_HEADER, false);

	//error_log(print_r($ch,1),3,'d:/logs/handler.php.log');
	
	//echo print_r($ch,1);
	if( ! $info = curl_exec($ch))
	{
		trigger_error(curl_error($ch));
	}
	curl_close($ch);
	
	//echo 2;
	//echo $info;
	$info = unserialize($info);
	//echo $info;
	$info = json_encode($info);
	echo $info;
	exit(0);
	/*
	 //返回的数据格式
	$retdata = array(
			'filename' => $arr['filename'],
			'filesize' => $infoArr['file_size'],
			'server_ip_addr' => $infoArr['source_ip_addr'],
			'fileurl' => $file_url,
	);
	*/
	
























