<?php
/****************************
* SessionManager obtaining session data
****************************/
require_once 'module_db.php';
require_once('core.class.php');
require_once('core.php');

class SessionManager{
	var $sessionid='';
	var $custid='';
	var $values=Array();
	var $redis = null;
	var $db = null;
	
	function __construct($custid,$sessionid){
		$this->custid = $custid;
		$this->sessionid = $sessionid;
	}
	
	function init(){
		$this->redisInit();
		//$this->dbInit();
	}
	
	function redisInit(){
		$this->redis = new Redis();
		$this->redis->connect(_REDISADDR,_REDISPORT);
	}
	
	function dbInit(){
		$this->db = new mysql(DB_ADDRESS, DB_USER, DB_PASSWORD, "uisp_union");
	}
	
	function getuserinfo($unionId){
		$param = array(
			'appname' => $this->custid,
			'unionId' => $unionId
		);
		$result = execjava('userInfoBean.getUserInfoByUnionId', $param, "php","usermanage",$this->custid);
		return $result;
	}
	
	function getuserrole($custid, $unionId){
		$param = array(
			'appId' => $custid,
			'unionId' => $unionid
		);
		//$retMap = execjava('b2bUserBean.userRole', $param, "php","s3Config");
		$retMap = Array('1', '2');
		return $retMap;
	}
	
	function redisget($key){
		//if($redis==null)
		//	$this->redisInit();
		return $this->redis->get($key);
	}
	
	function redisex($key,$value,$expire=0){
		return $this->redis->setex($key,$expire,$value);
	}
	
	function redishget($key,$field){
		//if($redis==null)
		//	$this->redisInit();
		return $this->redis->hget($key,$field);
	}
	
	function makerediskey(){
		return 'SK_'.$this->custid.'_'.$this->sessionid;
	}
	
	function makerediskey2(){
		return 'SV_'.$this->sessionid;
	}
	
	function makerediskey3($unionId){
		return 'SU_'.$unionId;
	}
	
	function getValues(){
		return $this->values;
	}
}

?>