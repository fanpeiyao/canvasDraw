<?php 
require_once '~main/sys.config.php';
require_once  'core.class.php';

//if (!ini_get('display_errors')) {
//    ini_set('display_errors', 1);
//}
Core::init();
/**
 * 
 * 执行一个或多个action<br/>
 * 一个Action指的是一个类的一次方法调用，可描述为： 类名(含名称空间) + 方法名 + 别名(可选) 或 portalConfig中定义的数据集ID + 别名<br/>
 * 例如： com.longkey.AClass.method1 as a1，其中 a1 作为别名将成为返回值的xml中的tagName，及json中的key值<br/>
 * 如果别名未定义，则自动将方法名或数据集ID作为别名
 * @param string $ids action列表, 如：com.longkey.AClass.method1 as a1, com.longkey.BClass.bmethod, com.longkey.AClass.method2 as a2<br/>
 * @param mixed $params (可选)参数，可以是一个字符串或数组，如 var1=a&var2=b 或：
 * $params = array(
 * 'uid' => '123456',    //公共参数
 * 'a1' => array(		//com.longkey.AClass.method1 的参数
 * 	   PAGE_SIZE => 6,	//每页条目, PAGE_SIZE为常量，无需加引号
 * 	   PAGE_NO => 2,		//页码, PAGE_NO为常量，无需加引号
 *     'title' => '11',  //自定义变量
 * ),
 * 'bmethod' => array(	//com.longkey.BClass.bmethod的参数
 * 		'name' => 'aaa',  //自定义变量
 * ),
 * );
 * @param string $cmd (可选)执行程序的返回值类型，json/xml/txt/void 默认为xml，其中void表示不返回  
 * @param string $appId (可选)应用名，默认为当前应用
 * @return 
 * <ul>根据$cmd返回不同格式的结果
 * <li>xml: 返回一个 DOMDocument 对象，每一个方法执行的结果为其中的一个 DOMNode，以id的别名为TagName，并且将该DomNode用该别名注册为一个全局变量
 * <li>json: 返回一个Array对象，每一个方法执行的结果为其中的一个子Array，该子Array的key值为ID的别名
 * <li>txt: 返回字符串，每一个方法返回的字符串由 || 分隔
 * </ul>
 */
function execjava($ids, $params, $cmd='xml', $appId=null){
	return Core::execjava($ids, Core::treatParams($params), $cmd, $appId);
}


function getContextPath(){
	return Core::getContextPath();
}

function getCustId(){
	return Core::getCustId();
}

function getRealPath(){
	return Core::getRealPath();
}



?>
