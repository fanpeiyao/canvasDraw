<?php
/**
 * 调试配置
 */
define ('debugPort', 8080);	//以php script方式调试时，默认的当前apache端口
define ('debugContext', 'framework'); //以php script方式调试时，默认的当前工程名称

/**
 * 存储自定义的变量，包括分页标记、当前页、
 */
define ('SESSION_TIME', '_S_T');	//java端session开始时间
define ('SESSION_REFRESH', 600); //java端session刷新间隔，即超过多少秒未访问java端时，自动刷新java端session

class Core{
	public static function getCustId($path = null){
		return _CUSTID;	
	}
	
	public static function init(){
		Core::initCVars();
		ini_set('session.cookie_path','/');
		session_start();
		
		//如超过指定时间(SESSION_REFRESH)未访问java端，则刷新java端session
		if(array_key_exists(SESSION_TIME, $_SESSION)){
			$st = $_SESSION[SESSION_TIME];
			if(time()-$st > SESSION_REFRESH){
				/* Core::httpLoad('nop', array(), 'nop', null); */
			}			
		}
		
		
	}
	
	private static function initCVars(){
		global $_CVARS;
		if($GLOBALS['_CVARS'] == null){
			$GLOBALS['_CVARS'] = array();
		}
	}
	
	public static function treatParams($params, $paramMap = array()){
		if(empty($params))
			return $paramMap;
			
		if(is_array($params)){
			while(list($key,$val) = each($params))
				$aa[$key] = htmlspecialchars($val);
			$paramMap = array_merge($paramMap, $params);
		}
		else if(is_string($params)){
			$ary = explode('&', $params);
			foreach ($ary as $item){
				$item = trim($item);
				if(empty($item))
					continue;
				$child = explode('=', $item);
				if(count($child) < 2)
					continue;
				$paramMap[trim($child[0])] = htmlspecialchars($child[1]);
			}
		}		
		return $paramMap;
	}
	
	
	public static function execjava($ids, $params = array(), $cmd='xml', $appId=null){
		$ret;
		if(!empty($ids))
			$ret = Core::httpLoad($ids, $params, $cmd, $appId);
		
		if(empty($ret))
			$ret = '';
			
		switch ($cmd){
			case 'xml':
				$doc = new DOMDocument();
				if($ret==null||$ret=="")
					break;
				$doc->loadXML($ret);
				$root = $doc->documentElement;
				if($root->nodeName == 'root'){
					for($i = 0; $i < $root->childNodes->length; $i++){
						$child = $root->childNodes->item($i);
						$tag = $child->nodeName;
						$GLOBALS[$tag] = $child;
					}
				}
				else{
					$GLOBALS[$root->nodeName] = $root;
				}				
				$ret = $doc;
				break;
			case 'json':
				$ret = json_decode($ret, true); 
				break;
			case 'txt':
			case 'text':
			case 'void':
				break;
			//add by licj 2016/01/04 
			//return type 
			case 'php':
				$ret = unserialize($ret);
				if(!is_array($ret))
					break;
				if ($ret['ESPRESSO_RETURN_VERSION'] == '1.0')
					$ret = $ret['data'];
				break;
			default:
				$ret = unserialize($ret);
				break;
		}		
		return $ret;
	}	
	
	
	
	

	
	public static function getBackEndUrl($appId){
		$url = '';
		
		if ($appId == null)
			$appId = _CUSTID;
		
		$array_url = $GLOBALS['_APP_ADDRESS'][$appId]; 
		//以本地sys.config.php中的配置地址为准
		if(!is_null($array_url)) {
			$url = $array_url[0] . 'process.data';
		}
		else {
			$eso=new espresso();
			$url = $eso->get_service_address($appId);
		}
		
		$contextPth;
		$uri = $_SERVER['REQUEST_URI'];
		$cend = stripos($uri, '/', 1);
		$contextPth = substr($uri, 1, $cend-1);
		
		return $url;
	}
	
	private static function httpLoad($ids, $params = array(), $cmd = 'xml', $appId=null){
		if($ids == null)
			return '';
			
		$_SESSION[SESSION_TIME] = time(); //刷新php中记录的服务器端session开始时间
		
		$__ids = '';
		if(is_array($ids)){
			foreach ($ids as $id){
				$__ids .= $id . ',';
			}
		}
		else{
			$__ids = $ids;
		}
		
		//add by licj 2014/09/17
		//在param_str中加入 custId
		$custId = _CUSTID;
		$nginx_http_appid=$_SERVER['HTTP_APPID'];
		if($nginx_http_appid!=null)
			$custId = $nginx_http_appid;
		
		$__params = '';
		if(!empty($params)){
			switch ($cmd){
				case 'json':
				case 'xml':
				case 'txt':
				case 'text':
				case 'void':
				case 'php':
					$__params = urlencode(json_encode($params));
					break;
				default:
					$__params = urlencode(serialize($params));
					break;
			}
		}
		$port = ($_SERVER['SERVER_PORT'] == null) ? debugPort : $_SERVER['SERVER_PORT'];
		if($port == 443)
			$port = 80;
		$param_str = '__ids=' . urlencode($__ids) . '&__params=' . $__params . '&__port=' . $port;
		if(!empty($custId)){
			$param_str .= '&INVOKE_CUST_ID=' . $custId;
		}
		
		if(!empty($_GET)){
			foreach ($_GET as $k => $v){
				if(!Core::startsWith($k, '___')){
					$param_str .= '&' . urlencode($k) . '=' .urlencode($v);
				}
			}
		}
		if(!empty($_POST)){
			foreach ($_POST as $k => $v){
				if(!Core::startsWith($k, '___')){
					$param_str .= '&' . urlencode($k) . '=' . urlencode($v);
				}
			}
		}
		
		$postUrl = Core::getBackEndUrl($appId);
		return Core::httpPost($postUrl, $param_str);
	}

	public static function httpPost($url, $paramstr){
	    $ckstr = '';
	    $tempCookie = Core::getTempCookie();
	    $cks = array();
		foreach ($_COOKIE as $k => $v){
	    	$cks[$k] = $v;
	    }
	    foreach ($tempCookie as $k => $v){
	    	$cks[$k] = $v;
	    }
		foreach ($cks as $k => $v){
	    	$ckstr .= $k . '=' . $v . '; ';
	    }
	    
	    $defaults = array(
	        CURLOPT_POST => 1,
	        CURLOPT_HEADER => 1,
	        CURLOPT_URL => $url,
	        CURLOPT_FRESH_CONNECT => 1,
	        CURLOPT_RETURNTRANSFER => 1,
	        CURLOPT_FORBID_REUSE => 1,
	        CURLOPT_TIMEOUT => 500,
	        CURLOPT_POSTFIELDS => $paramstr,	
	        CURLOPT_COOKIE => $ckstr
    	); 
		$ch = curl_init();
    	curl_setopt_array($ch, $defaults);
    	curl_setopt($ch,CURLOPT_HTTPHEADER,array('X-Forwarded-For: ' . Core::getip(), 'Expect:'));
    	if( ! $response = curl_exec($ch))
    	{
        	trigger_error(curl_error($ch));
    	}
    	curl_close($ch);    
    	list($header, $body) = explode("\r\n\r\n", $response, 2);
		$headers = explode("\r\n", $header);
		foreach ($headers as $line){
			if(substr($line, 0, 9) === "Location:"){
				 header($line);
				 echo $line;
				 exit();
			}
			if(substr($line, 0, 11) === "Set-Cookie:"){// set cookie
	    		$item = substr($line, 11, strlen($line) - 11);
	    		$ary = explode(';', $item);
	    		$ckey;
	    		$cval;
				$cpath = '/';
				$cexp = 0;
				$domain = null;
				$HttpOnly = false;
	    		foreach ($ary as $key => $value){
	    		    $ay = explode('=', $value);
	    		    
	    		  	if($key == 0){
	    				$ckey = trim($ay[0]);
	    				$cval = trim($ay[1]);
	    			}
	    			else if('Path' === trim($ay[0])){
	    				//$cpath = trim($ay[1]);
	    			}   
	    			else if('Domain' === trim($ay[0])){
	    				$domain = trim($ay[1]);
	    			}
	    			else if('HttpOnly' === trim($ay[0])){
	    				$HttpOnly = true;
	    			}      					
	    		}
				if($ckey != null){
					$cval = ($cval == null) ? "" : $cval;
	    			$cpath = ($cpath == null) ? "/" : $cpath;	    			
	    			//$cexp = ('JSESSIONID' === $ckey) ? $cexp : time() + (1000*60*60*24*30);
	    			$domain = ($domain == null ) ? "" : $domain;
	    			try{			
	    				Core::setTempCookie($ckey, $cval);
	    				setcookie($ckey, $cval, $cexp, $cpath,$domain,null,$HttpOnly);
	    			}
	    			catch (Exception $e){
	    				
	    			}	    			
	    		}   		
	    	}			
		}
    	return $body;
	}	
	
	private static function setTempCookie($key, $val){
		if(!key_exists('_COOKIE', $GLOBALS['_CVARS']))
			$GLOBALS['_CVARS']['_COOKIE'] = array();
		$GLOBALS['_CVARS']['_COOKIE'][$key] = $val;
	}
	
	private static function getTempCookie(){
		if(!key_exists('_COOKIE', $GLOBALS['_CVARS']))
			return array();
		return $GLOBALS['_CVARS']['_COOKIE'];
	}
	

	public static function getip() {
		$unknown = 'unknown';
		if ( isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], $unknown) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} elseif ( isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], $unknown) ) {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		/*
		处理多层代理的情况
		或者使用正则方式：$ip = preg_match("/[\d\.]{7,15}/", $ip, $matches) ? $matches[0] : $unknown;
		*/
		if (false !== strpos($ip, ','))
			 $ip = reset(explode(',', $ip));
		return $ip;
	}	
	
	public static function getRealContext(){
		$context = $_SERVER['HTTP_CONTEXT'];
		if($context==null){
		$uri = $_SERVER['REQUEST_URI'];
		$st = stripos($uri, '/', 1);
		$context = substr($uri, 1, $st-1);
		}
		return $context;
	}
	
	public static function getContextPath(){
		$protocol = $_SERVER['SERVER_PROTOCOL'];
		if(empty($protocol))
			return '';
		$st = stripos($protocol, '/');
		if($st)
			$protocol = substr($protocol, 0, $st);
		$protocol = strtolower($protocol);		
		$host = $_SERVER['SERVER_NAME'];
		if(!empty($_SERVER['SERVER_PORT'])){
			if($_SERVER['SERVER_PORT'] == 443)
				$protocol = 'https';
			$host .= ':' . $_SERVER['SERVER_PORT'];
		}
		$uri = $_SERVER['REQUEST_URI'];
		$st = stripos($uri, '/', 1);
		$contextPath = substr($uri, 0, $st);
		return $protocol . '://' . $host . $contextPath . '/';	
	}
	
	public static function getRealPath(){
		$protocol = $_SERVER['SERVER_PROTOCOL'];
		if(empty($protocol))
			return '';
		$st = stripos($protocol, '/');
		if($st)
			$protocol = substr($protocol, 0, $st);
		$protocol = strtolower($protocol);
		$host = $_SERVER['SERVER_NAME'];
		if(!empty($_SERVER['SERVER_PORT'])){
			if($_SERVER['SERVER_PORT'] == 443)
				$protocol = 'https';
			$host .= ':' . $_SERVER['SERVER_PORT'];
		}
		$contextPath=Core::getRealContext();
		
		return $protocol . '://' . $host . '/' . $contextPath . '/';
	}
	
	
	public static function startsWith($haystack, $needle)
	{
		$length = strlen($needle);
		return (substr($haystack, 0, $length) === $needle);
	}
	
	public static function endsWith($haystack, $needle)
	{
		$length = strlen($needle);
		if ($length == 0) {
			return true;
		}
		return (substr($haystack, -$length) === $needle);
	}
	
}

?>