/**
 * Created by chent on 2017/3/3.
 */
var config = {
		
	version:"1.1.2",
	
    app:{
        'custid':'kuaijishan',
        'userservice':'usermanage',
        'paymentservice':'paymentservice'
    },
    
    basic:{
        companyName:"ABC有限公司电子供应链平台",
        logo:"views/account/img/logo.png"
    },
    
    roles : {
        "1":{
            name:"经销商"
        },
        "2":{
            name:"业务员"
        }
    },
    
    display:{
    	products:{
    		productName:'产品名称',
    		productType:'产品类型',
    		productSize:'规格',
    		productAddress:'规格',
    		batch:'批号',
    		standardLen:'批号',
    		count:'数量',
    		arrangedCount:'发货数量',
    		weight:'重量',
    		countUnit:'单位',
    		weightUnit:'重量单位',
    		cost:'重量单位',
    		price:'单价',
    		realPrice:'单价',
    		note:'备注',
    		toDate:'要货日期',
    		categoryId:'分类号',
    		createTime:'要货日期',
    		picFilePath:'要货日期',
    		picFileName:'要货日期',
    		shipFee:'要货日期',
    		companyId:'分公司编号',
    		salesmanId:'要货日期',
    		parentId:'分公司编号',
    		lastUpdateTime:'分公司编号',
    		rd1:'属性',
    		rd2:'产品颜色',
    		rd3:'属性',
    		rd4:'属性',
    		rd5:'属性',
    		rd6:'属性',
    		rd7:'属性',
    		rd8:'属性',
    		rd9:'属性',
    		rd10:'属性',
    		rd11:'属性',
    		rd12:'属性',
    		rd13:'属性',
    		rd14:'属性',
    		rd15:'属性',
    		rd16:'属性',
    		rd17:'属性',
    		rd18:'属性',
    		rd19:'属性',
    		rd20:'属性',
    		rd21:'属性',
    		rd22:'属性',
    		rd23:'属性',
    		rd24:'属性',
    		rd25:'属性',
    		rd26:'属性',
    		rd27:'属性',
    		rd28:'属性',
    		rd29:'属性',
    		rd30:'属性'

    	}
    },
    
    modules : {
        products:{
        	pic:true,
        	props:['productName','categoryId','productSize','rd2','countUnit'],
            productDetail:['productName','productSize','categoryId','countUnit']
        },
        cart:{
        	pic:true,
        	payMethod:[
        	    {type:0,name:'汇款'},
        	    {type:1,name:'票据'},
        	    {type:2,name:'信用证'},
        	    {type:3,name:'在线支付'},
        	    {type:4,name:'其他方式'}
        	],
        	deliveryType:[
        	    {
        	    	type:0,
        	    	name:"自提"
        	    },
        	    {
        	    	type:1,
        	    	name:"配送"
        	    }
        	],
        	toDate:true,
        	props:['productName','categoryId','productSize','rd2']
        },
        myorder:{
        	props:['categoryId','productSize','rd2','count','countUnit']
        },
        shenhe:{
        },
//        付款单
//        payment:{
//        },
        delivery:{
        	props:['categoryId','productSize','rd2','count','countUnit']
        },
        profile:{
        	editAddress:true
        },
        //易付
//        easyPay:{
//        },
        check:{
        }
    },
    remote:{
    		licai:{
    			 name:'融资',
    		     url:'http://gyj.icbc.com.cn/eloans/~main/WXMain.php',
    		     icon:'icon-rongzi'
    		},
    		fund:{
    			name:'理财',
    	        url:'http://gyj.icbc.com.cn/eloans/~main/WXMain.php',
    	        icon:'icon-licai'
    		},
    		/*products:{
    			//表示是否需要在底部栏展示 ，不管配多少，首页和个人信息一定有，因此最多还能容纳2个
    			 bottom:true, 
    			 name:'理财',
                 icon:'icon-shenpi',
                 url:'http://109.5.61.51/test/index.php'
    		},*/
            desktop:{
            	bottom:true,
                name:'特色入口',
                icon:'icon-fill1fill2',
                url:'http://gyj.icbc.com.cn/tszm/index.html#app'
            }
    }
};


