//上游付款单（供应商）
var colArray = [
["收款单号","paymentNo"],
["付款人","payAccName"],
["公司名称","companyName",150],
["收款金额","payAmt"],
["收款日期","payTime",150],
["收款单状态","status"],
["收款单转账状态","transferStatus",150]
];

//上游付款单（业务员）
var colArray1 = [
["付款单号","paymentNo"],
["公司名称","companyName",150],
["收款人","reciverName"],
["付款金额","payAmt"],
["付款日期","payTime",150],
["付款单状态","status"],
["付款单转账状态","transferStatus",150],
["操作","operation"]
];


