//物料视图
var colArray = [
["单据编号","orderNo"],
["采购公司","companyName"],
["供应商","userName"],
["备货单状态","orderStatus"],
["物料编号","productId"],
["物料名称","productName"],
["物料规格","productSize"],
["单价","price"],
["单位","countUnit"],
["数量","count"],
["交货日期","toDate"],
["备注","note"],
["税额","taxAmount"],
["总价","total"],
["计划（建议）交货日期27","planedDeliveryDate"],
["操作","operation"]
];

//备货计划视图
var colArray1 = [
//["","checkBox",15],
["单据编号","orderNo"],
["采购公司","companyName",120],
["供应商","userName"],
["制单时间","createTime",120],
["备货单状态","orderStatus",100],
["订单金额","orderAmount"],
["税额","taxAmount"],
["操作","operation"]
];

//采购订单明细
var colArray2 = [
["序号","seq",5],
["物料编号","productId"],
["物料名称","productName"],
["物料规格","productSize"],
["单价","price"],
["单位","countUnit"],
["数量","count"],
["备注","note"],
["交货日期","toDate"],
["总价","total"]
];

//确认弹窗：物料视图
var colArray3 = [
["订单编号","orderNo"],
["采购公司","companyName"],
["供应商","userName"],
["订单状态","orderStatus"],
["物料状态","detailStatus"],
["物料编号","productId"],
["物料名称","productName"],
["物料规格","productSize"],
["单价","price"],
["单位","countUnit"],
["数量","count"],
["交货日期","toDate"],
["确认备注","currConfirmNote"],
["总价","total"],
//由于不能重复确认，所以取消当前确认信息展示
//["当前确认数量","confirmCount"],
//["当前确认交货时间","planedDeliveryDate"],
["确认数量","currConfirmCount"],
["确认交货时间","currPlanedDeliveryDate"]
];

//备货计划物料视图搜索条件
var porequestProductSearchArray = [
["单据编号","porequestOrderNo"],
["物料编号","productId"],
["采购交期","porequestStartDate|porequestEndDate"],
["物料名称","productName"],
["物料规格","productSize"],
["制单时间","start_date|end_date"],
["采购公司","porequestCompanyName"],
["供应商","supplierName"]
];

//备货计划订单视图搜索条件
var porequestSearchArray = [
["单据编号","porequestOrderNo"],
["创建日期","start_date|end_date"],
["采购公司","porequestCompanyName"],
["供应商","supplierName"]
];