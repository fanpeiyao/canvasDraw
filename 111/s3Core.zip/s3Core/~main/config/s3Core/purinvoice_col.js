//上游发票物料视图
var colArray = [
["发票号码","purchaseNo"],
["供应商","customerName"],
["发票金额","totalAmount"],
["开票人","marker"],
["付款人","payerName"],
["发票日期","purchaseDate"],
["发票状态","purchaseStatus"],
["融资状态","financingStatus"],
["物料编号","productId"],
["物料名称","productName"],
["物料规格","productSize"],
["物料单价","price"],
["单位","countUnit"],
["批次","batch"],
["数量","count"],
["备注","note"],
["交期","toDate"],
["物料总价","amount"]
];

//上游发票视图(上游业务员)
var colArray1 = [
["发票号码","purchaseNo"],
["发票代码","certificateCode"],
["供应商名称","customerName"],
["发票金额","totalAmount"],
["发票日期","purchaseDate"],
["发票状态","purchaseStatus",120],
["融资状态","displayStatus",120],
["计划还款日期","endDate"],
["备注","note"],//当前登录用户角色role != 11时展示
["付款人名称","payerName"],
["收款单位名称","reveiver"],
["操作","operation"]

];

//上游发票视图（供应商）
var colArray2 = [
["发票号码","purchaseNo"],
["发票代码","certificateCode"],
["发票金额","totalAmount"],
["发票日期","purchaseDate"],
["发票状态","purchaseStatus",120],
["融资状态","displayStatus",120],
["计划还款日期","endDate"],
["备注","note"],//当前登录用户角色role == 11时展示
["付款人名称","payerName"],
["收款单位名称","reveiver"],
["操作","operation"]
];

//上游发票详情
var colArray3 = [
["序号","sequence",10],
["物料编号","productId"],
["物料名称","productName",130],
["物料规格","productSize",90],
["单价","price"],
["单位","countUnit"],
["数量","count"],
["备注","note"],
["交期","toDate"],
["总价","amount"]
];
