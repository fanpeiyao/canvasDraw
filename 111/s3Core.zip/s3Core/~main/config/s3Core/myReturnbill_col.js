//上游退货单
var colArray = [
//退货单 单据视图               
["退货单编号","returnBillNo"],
["供应商名称","customerName"],
["创建时间","createTime"],
["退货时间","returnTime"],
["货运方式","dictName"],
["分公司名称","companyName"],
["备注","note"],
["状态","status"]
];

//退货单产品信息
var colArray1 = [
["物料编号","productId"],
["物料名称","productName"],
["物料类型","productType"],
["产地","productAddress"],
["批号","batch"],
["物料标长","standardLen"],
["价格","price"],
["保留字段1","rd1"],
["保留字段2","rd2"],
["保留字段30","rd30"],
["数量","count"]
];


//退货单明细
var colArray2 = [
["物料编号","productId"],
["退货单编号","returnBillNo"],
["创建时间1","createTime"],
["退货时间2","returnTime"],
["退货单状态3","status"],
["退货单金额4","amount"],
["制单人编号5","authorId"],
["业务员编号6","salesmanId"],
["企业ERP客户号7","customerId"],
["分公司编号8","companyId"],
["备注9","note"],
["总保留字段1","F1"],
["总保留字段16","F16"],
["退货单明细状态10","detailStatus"],
["退货单产品分录号11","productEntry"],
["物料名称12","productName"],
["物料类型","productType"],
["物料规格","productSize"],
["物料产地","productAddress"],
["仓库13","wareHouse"],
["物料标长","standardLen"],
["物料批次","batch"],
["物料标长","standardLen"],
["数量14","count"],
["产品重量15","weight"],
["物料数量单位","countUnit"],
["物料辅助单位","weightUnit"],
["成本价16","cost"],
["单价17","price"],
["总价18","totalPrice"],
["税率19","taxRate"],
["税额20","taxAmount"],
["物料保留字段1","rd1"],
["物料保留字段30","rd30"],
];

//退货单产品列表搜索区域字段
var myReturnbillProductSearchArray = [
["退货单编号","returnBillNo"],
["退货时间","returnBeginTime|returnEndTime"],
["物料名称","productName"],
["物料编号","productId"],
["物料规格","productSize"],
["供应商名称","customerName"]
];


//退货单单据视图搜索页面
var myReturnbillSearchArray = [
["退货单编号","returnBillNo"],
["退货时间","returnBeginTime|returnEndTime"],
["供应商名称","customerName"]
];