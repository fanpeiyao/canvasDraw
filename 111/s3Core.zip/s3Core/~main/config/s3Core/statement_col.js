//下游对账单列表
var colArray = [
["","jiajian",10],
["单据号","statementNo"],
["经销商名称","userName"],
["","statementType"],//单据类型下拉框
["对账日期","statementTime"],
["应付金额[贷]","payAmount"],
["实付金额[借]","paidAmount"],
["备注","note"]
];

