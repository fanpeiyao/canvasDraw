
//订单视图
var colArray = [
["","checkBox",10],
["发票号码","purchaseNo"],
["发票代码","certificateCode"],
["发票金额","totalAmount"],
["发票日期","purchaseDate"],
["税率(%)","tax"],
["不含税金额","excludTaxAmount"],
["创建时间","createTime",80],
["操作","operation"]
];

