//下游发货单
var colArray = [
["","jiajian",10],
["发货单编号","deliveryId"],
["车牌号","carNum"],
["类型","type"],//发货单or退货确认单
["发货时间","deliveryTime"],
["手机号码","mobile"],
["状态","deliveryStatus"]
];

//下游发货单明细
var colArray1 = [
["发货单编号","orderNo"],
["产品编号","productId"],
["产品名称","productName"],
["数量","count"],
["安排发运数量","arragedQty"],
["确认收货数量","affirmQty"],
["累计出库数量","outedQty"]
];

//下游退货确认单明细
var colArray2 = [
["退货单编号","orderNo"],
["产品编号","productId"],
["产品名称","productName"],
["数量","count"],
["安排发运数量","arragedQty"],
["确认收货数量","affirmQty"],
["累计出库数量","outedQty"]
];

