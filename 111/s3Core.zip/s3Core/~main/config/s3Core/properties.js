
var properties = {
		's3Core':{
			'common':{
				'company':'分公司'
			}
		},
		'zhongdian':{
			'common':{
				'company':'事业部'
			}
		}
}