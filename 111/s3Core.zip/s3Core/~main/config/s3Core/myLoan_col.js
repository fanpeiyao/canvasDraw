//上游供应商我的贷款
var colArray = [
["供应商名称","userName"],
["融资品种","financeVarieties"],
["提款金额","applyAmount"],
["提款日期","applyDateBegin"],
["提款到期日","applyDateEnd"],
["已还款金额","relAmount"],
["待还款金额","reloAmount"],
["还款状态","contractStatus"]
];

