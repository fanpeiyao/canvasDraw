//物料视图
var colArray = [
["结账清单编号","checkNo"],
["分公司名称","companyName"],
["供应商","userName"],
["结账清单状态","checkStatus",130],
["物料状态","detailStatus"],
["物料编号","productId"],
["物料名称","productName"],
["物料规格","productSize"],
["单价","price"],
["单位","countUnit"],
["数量","count"],
["发货日期","toDate"],
["备注","note"],
["f1","f1"],
["f2","f2"],
["rd1","rd1"],
["rd2","rd2"]
];

//订单视图
var colArray2 = [
/*["","jiajian",10],*/
["结账清单编号","checkNo"],
["分公司名称","companyName",120],
["供应商","userName"],
["创建时间","createTime",120],
["结账清单状态","checkStatus",130],
["发货金额","totalAmount"],
["rd1","rd1"]
];

//结账清单明细
var colArray3 = [
["序号","seq"],
["物料编号","productId"],
["物料名称","productName"],
["物料规格","productSize"],
["单价","price"],
["单位","countUnit"],
["数量","count"],
["备注","note"],
["发货日期","toDate"],
["总价","total"]
];


//结账清单（物料视图）搜索区域字段
var settleOrderSearchArray = [
["结账清单编号","checkNo"],
["物料编号","productId"],
["发货日期","settleStartDate|settleEndDate"],
["物料名称","productName"],
["物料规格","productSize"],
["分公司名称","settleCompanyName"],
["创建时间","start_date|end_date"],
["供应商","customerName"]
];

//结账清单（单据视图）搜索区域字段
var settleOrderSearchArray2 = [
["结账清单编号","checkNo"],
["分公司名称","settleCompanyName"],
["创建时间","start_date|end_date"],
["供应商","customerName"]
];

