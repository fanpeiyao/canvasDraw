var colArray = [
["","checkBox","10"],
["缩略图","image"],
["产品编号","productId"],
["产品名称","productName"],
["产品规格","productSize"],
["产品颜色","rd2"],
["单位","countUnit"],
["标准价","price"],
["数量","count","100"],
["要货日期","toDate","100"],
["备注","note","100"],
["小计","total"],
["操作","operation","100"]
];
