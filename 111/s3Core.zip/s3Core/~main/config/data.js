/**
 * 是否存在分公司
 * true：表示存在
 * false：表示没有分公司，只有一个核心企业
 */
var isHasBranchCompany = true;