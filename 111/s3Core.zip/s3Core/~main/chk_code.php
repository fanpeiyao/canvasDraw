<?php 
	session_start();
	
	$code = trim($_POST['code']);
	$code = strtolower($code);
	if($code == $_SESSION['authnum_session']){
		echo '1';
	}
?>