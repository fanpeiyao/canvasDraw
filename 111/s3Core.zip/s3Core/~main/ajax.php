<?php
error_log("111",3,"d:\\1.txt");
require_once 'sys.config.php';
require_once  'common/core.php';
require_once 'validate.config.php';
require_once '../inc/Token.class.php';
require_once 'common/module_sessionmanager.php';

/**
 * 获取http请求函数
 * @param unknown $key
 * @return unknown
 */
function getParameter($key){
	if(isset($_POST[$key]))
		return $_POST[$key];
	if(isset($_GET[$key]))
		return $_GET[$key];
}
$ids = getParameter('__ids');
$cmd = getParameter('__cmd');
if(empty($cmd))
	$cmd = 'json';
$params = getParameter('__params');
$appId = getParameter('__appId');
$code = htmlspecialchars(getParameter('__code'));
$token = $_SERVER['HTTP_TOKEN'];
/**
 * 添加被调用方调用地址
 */
$postUrl = Core::getBackEndUrl($appId);
header("Posturl:".$postUrl);
/**
 * 获取redis session
 * $user为redis中SU_UNIONID的值
 */
$sessionid = $_COOKIE['Cookie1'];
$custId = _CUSTID;
$nginx_http_custid=$_SERVER['HTTP_CUSTID'];
if($nginx_http_custid!=null)
	$custId = $nginx_http_custid;
$sm = new SessionManager($custId,$sessionid);
$sm->redisInit();
$unionid = $sm->redisget($sm->makerediskey2());
$user = $sm->redishget($sm->makerediskey3($unionid),$sessionid);
$user=json_decode($user);
/**
 * 调用方法判空
 */
if(empty($ids)){
	exit(0);
}
/**
 * 用户是否登录判断
 */
if ($user == null && in_array($ids, $logon_validate) == false) {
	$results->retCode = '500';
	$results->status = '004';
	$results->retMsg = '用户信息过期，请重新登录！';
	echo json_encode($results);
	exit(0);
}
/**
 * 用户若是首次登录，不允许调用白名单$first_login_validate外的后台函数
 */
if(in_array($ids, $first_login_validate) == false && $user->mobilephone == null){
	$results->retCode = '500';
	$results->retMsg = '首次登录请填写手机并修改密码';
	echo json_encode($results);
	exit(0);
}
/**
 * 交易token校验
 */
if (in_array($ids, $token_validate) == true) {
	if (Token::valid_token($token) == false) {
		$results->retCode = '500';
		$results->retMsg = '重复提交！';
		echo json_encode($results);
		exit(0);
	}
	/*else {
		Token::valid_token($code);
		$results->retCode = '200';
		$results->retmsg = 'token校验成功！';
		$results->token = $code;
		echo json_encode($results);
		exit(0);
	}*/
}
/**
 * 验证码校验
 */
if ($_SESSION['authnum_session'] != null){
	if (in_array($ids, $code_validate) == true) {
		$code = strtolower($code);
		if(time() - $_SESSION['code_create_time'] > 300){
			$results->retCode = '40006';
			$results->retMsg = '验证码已过期';
			$results->token = $code;
			echo json_encode($results);
			//$_SESSION['authnum_session'] = null;
			exit(0);
		}
		if ($code != $_SESSION['authnum_session']) {
			$results->retCode = '40005';
			$results->retMsg = '验证码错误，请输入正确的验证码';
			$results->token = $code;
			echo json_encode($results);
			$_SESSION['authnum_session'] = null;
			exit(0);
		}
		else {
			$_SESSION['authnum_session'] = null;
	//		$results->retCode = '200';
	//		$results->retmsg = 'token校验成功！';
	//		$results->token = $code;
	//		echo json_encode($results);
	//		exit(0);
		}
	}
}

//清除输出缓冲区
ob_end_flush();
//关闭session锁
session_write_close();

/**
 * 调用后台函数
 */
$params_str = '__ids=' . $ids . '&__params=' . urlencode($params);

$custId = _CUSTID;
$nginx_http_appid=$_SERVER['HTTP_APPID'];
if($nginx_http_appid!=null)
	$custId = $nginx_http_appid;
if(!empty($custId)){
	$params_str .= '&INVOKE_CUST_ID=' . $custId;
}

$postUrl = Core::getBackEndUrl($appId);
$_SESSION[SESSION_TIME] = time(); //刷新php中记录的服务器端session开始时间

$results = Core::httpPost($postUrl, $params_str);
$results = unserialize($results);
$results = json_encode($results);

if(!empty($results)){
	echo $results;
}
?>