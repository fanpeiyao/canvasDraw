<!DOCTYPE html>
<html>
	<head>
		<?php 
			include_once '~main/ctx.php';
			include_once 'modules/uploader/upload.php';
		?>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>用户登录</title>
		<script type="text/javascript">
			$(function(){
				$("#uploadForm").uploadForm({
					//cache : true
				});
			});
			function uploadHandler(err,data) {
				//alert(err);
				console.info(err);	
				console.info(data);	
			}
		</script>
	</head>
	<body>
	
	<div class="btn">
		<span>上传文件</span>
		<input id="fileupload" type="file" name="filename" onchange="uploadfile(this,uploadHandler)">
	</div>
	
	<form action="http://fastdfs.gyj.com/upload.php" method="post" enctype="multipart/form-data">
			<input  type="file" name="filename" />
			<input type="submit" value ="上传" />
	</form>
	<!-- 
		
		var uploadForm;
		
		$(function(){
			uploadForm= $('#uploadForm').uploadForm({
				url : 'http://127.0.0.1:8888/admincenter/~main/handler.php',
				cache : true,
				overWrite : false,
				keepOriginal : true,
				success : function(data){
					console.info(data);
				}
			});
		});
	
		function uploadfile1(){
			uploadForm.submit();
		}

		<div class="btn">
			<span>上传文件</span>
			<form id="uploadForm">
				<input id="fileupload" type="file" name="filename" onchange="uploadfile1()"/>
			</form>
		 </div>	
		 	-->
	</body>
</html>
