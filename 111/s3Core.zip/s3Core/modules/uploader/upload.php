<script type="text/javascript" src="<?php echo $root_path ?>modules/uploader/js/jquery.uploadform.js"></script>
<script type="text/javascript" src="<?php echo $root_path ?>modules/uploader/js/jquery.form.js"></script>
<script type="text/javascript">
//上传文件
function uploadfile(elem,func) {
	var bar = $(".bar");
	var percent = $(".percent");
	//var progress = $(".progress");
	var progress = $("#progress");
	var files = $(".files");
	var id = $(elem).parent().attr("id");
	var btn = $(elem).parent().prev("span")[0];
	$(elem).parent().ajaxSubmit({
		dataType : 'json',
		beforeSend : function() {
			progress.show();
			var percentVal = '0%';
			showBg('upload_file_progress');
			progress.css("width",percentVal);
			percent.html(percentVal);
			btn.innerHTML = "上传中...";
		},
		uploadProgress : function(event, position, total, percentComplete) {
			var percentVal = percentComplete + '%';
			progress.css("width",percentComplete * 10);
			percent.html(percentVal);
			progress.html(percentVal);
		},
		success : function(data){
			files.html("<b>" + data.source_file_name + "("+ data.filesize + "k)上传成功</b>");
			btn.innerHTML = "上传成功";			
			// 处理上传文件后返回的信息
			if(data.status == '000'){
				func(null,data);				
			}else{ 
				func("Fialed to recorde in database!",data);
			}
			//上传成功之后3秒关闭弹窗
			setTimeout(function() {
				closeBg('upload_file_progress');
				//btn.innerHTML = "上传文件";	
			}, 3000);
		},
		error : function(xhr) {
			btn.innerHTML = "上传失败";
			progress.html(0);
			files.html(xhr.responseText);
			//alert("文件上传失败");
			func("Fialed to upload file!"); 
			//closeBg('upload_file_progress');
		}
	});
}
//初始化form
function initForm(){
	var inputFile = $("input[type='file']");
	$.each(inputFile,function(index,item){
	var id = item.id;
	$("#"+id).wrap("<form id='upload_file_" + id +"' action='<?php echo $root_path ?>modules/uploader/handler.php' "
			+ " method='post' enctype='multipart/form-data'></form>");
	})	
}
$(function(){
	initForm();
})
</script>
<link href="<?php echo $root_path ?>modules/uploader/css/upload.css" rel="stylesheet" type="text/css" media="all" />
<link href="<?php echo $root_path ?>modules/uploader/css/stilearn.css" rel="stylesheet" />

<div id="fullbg"></div>
<div id="upload_file_progress" class="form_upload_box">
	<div class="upload_box_content">
		<div class="progress" style="margin: 20px 0px 0px 20px;">
			<span class="percent">0%</span>
		</div>
		<div class="bar-st bar-stripe" style="margin-bottom: 0px;">
		    <span class="active" id="progress">0%</span>
		</div>
		<div class="files" style="margin-left: 103px;"></div>
	</div>
</div>
<!-- 
	文档地址：http://wiki.gyj.com/%E4%BA%A7%E5%93%81%E6%9C%8D%E5%8A%A1%E4%B8%AD%E5%BF%83/%E6%96%87%E4%BB%B6%E4%B8%8A%E4%BC%A0%E8%AF%B4%E6%98%8E%E6%96%87%E6%A1%A3.html
	注意几点：
	1、input控件name属性值必须为：filename，否则文件无法实现上传；
	2、input控件添加onchange事件，调用uploadfile()方法，参数为当前input对象；
	3、如果页面有多个文件上传，其id不能重复；
-->
<!--
<div class="btn">
	<span>上传文件</span>
	<input id="fileupload" type="file" name="filename" onchange="uploadfile(this,function_name)">
</div>
-->


