(function($) {
	/**
	 * 为form表单增加参数
	 */
	function setForm(target, options) {
		var opts = $.data(target, "form").options;
		var form = $(target);
		form.attr({
			"action":options.url,
			"method" : "post",
			"enctype" : "multipart/form-data"
		});
		$.each(options, function(key, value) {
			if(key !="url" && value){
				if (typeof value != "function") {
					var content = "<input type='hidden' name='" + key
							+ "' value='" + value + "'/>";
					form.append(content);
				}
			}
		});
		form.unbind(".form").bind("submit.form", function() {
			setTimeout(function() {
				uploadfile(target, opts);
			}, 0);
			return false;
		});
	}

	/**
	 * form表单submit时调用
	 */
	function uploadfile(target, options) {
		options = options || {};
		if (options.beforeSubmit) {
			if (options.beforeSubmit.call(target) == false) {
				return;
			}
		}
		var form = $(target);
		if (options.url) {
			form.attr("action", options.url);
		}
		var frameId = "icbc_frame_" + (new Date().getTime());
		var frame = $(
				"<iframe id=" + frameId + " name=" + frameId + "></iframe>")
				.attr(
						"src",
						window.ActiveXObject ? "javascript:false"
								: "about:blank").css({
					position : "absolute",
					top : -1000,
					left : -1000
				});
		var t = form.attr("target"), a = form.attr("action");
		form.attr("target", frameId);
		try {
			frame.appendTo("body");
			frame.bind("load", cb);
			form[0].submit();
		} finally {
			form.attr("action", a);
			t ? form.attr("target", t) : form.removeAttr("target");
		}
		var checkCount = 10;
		function cb() {
			frame.unbind();
			var body = $("#" + frameId).contents().find("body");
			var data = body.html();
			if (data == "") {
				if (--checkCount) {
					setTimeout(cb, 100);
					return;
				}
				return;
			}
			var ta = body.find(">textarea");
			if (ta.length) {
				data = ta.val();
			} else {
				var pre = body.find(">pre");
				if (pre.length) {
					data = pre.html();
				}
			}
			if (options.success) {
				options.success(data);
			}
			setTimeout(function() {
				frame.unbind();
				frame.remove();
			}, 100);
		}
	}

	/**
	 * 初始化uploadForm
	 */
	$.fn.uploadForm = function(options) {
		if (typeof options == "string") {
			return $.fn.form.methods[options](this, param);
		}
		return this
				.each(function() {
					if (!$.data(this, "form")) {
						$.data(this, "form", {
							options : $.extend({}, $.fn.uploadForm.defaults,
									options || {})
						});
					}
					setForm(this, $.extend({}, $.fn.uploadForm.defaults,
							options || {}));
				});
	}

	$.fn.uploadForm.methods = {
		submit : function(jq, param) {
			return jq.each(function() {
				uploadFile(this, $.extend({}, $.fn.uploadForm.defaults, param || {}));
			});
		}
	}
	/**
	 * uploadForm 默认属性
	 */
	$.fn.uploadForm.defaults = {
		customerId : null,
		url : "handler.php",
		cache : false,
		size : null,
		beforeSubmit : function() {

		},
		success : function(data) {

		}
	}
})(jQuery);