<?php
require_once 'common/core.php';
require_once 'inc/PropConfig.class.php';

if($_FILES["filename"]["error"] > 0){
	echo "Error: ".$_FILES["filename"]["error"];
}else{
	// 判断是否存在文件
	if (empty($_FILES)) {
		echo "文件不能为空";
		exit;
	}
	// 上传文件原始名称
	$source_file_name = $_FILES['filename']['name'];
	// 上传文件大小
	$filesize = $_FILES['filename']['size'];
	// 上传文件的临时路径文件
	$temp_file = $_FILES['filename']['tmp_name'];
	
	if(empty($source_file_name)){
		echo "文件名不能为空";
		exit;
	}
	
	// 1M大小
	$max_file_size = PropConfig::getDefaultValue('max.file.size');
	if(empty($max_file_size)){
		$max_file_size = 1024 * 1024 * 2;
	}
	// 判断文件大小
	if ($filesize > $max_file_size) {
		echo "文件大小不能超过2M";
		exit;
	}
	// 上传文件的扩展名，并将其专为小写
	$fileparts = pathinfo($source_file_name);
	$filextension = strtolower($fileparts['extension']);	
	// 支持上传的文件扩展名,根据配置获取
	$config_extension = PropConfig::getDefaultValue('support.file.extension');
	// 判断是否配置，如果可获取配置则判断扩展，否则支持所有文件	
	if(empty($config_extension)){
		$support_file_extension = array();
	}else{
		$support_file_extension = array($config_extension);
		// 判断是否为支持的扩展名
		if (!in_array($filextension, $support_file_extension)) {
			echo "不支持的扩展名";
			exit;
		}
	}
	
	$remote_url = PropConfig::getDefaultValue('FastDFS.remoteurl');
	//$remote_url = "http://tongkun.gyj.com/upload.php";
	$isCache=$_POST['cache'];
	$imgSize=$_POST['size'];
	$customerId=$_POST['customerId'];
	
	$imgUploadServer=PropConfig::getDefaultValue('imgUploadServer');
	
	//$remote_url=$imgUploadServer."?isCache=".$isCache."&&saveFileName=".urlencode(json_encode($saveFileName));
	$goImageServer=false;
	if($isCache=="true" || !empty($imgSize)){
		$saveFileName=array(
				"saveFileName"=>$source_file_name,
				"customerId"=>$customerId
		);
		$remote_url=$imgUploadServer.'?isCache='.trim($isCache);
		if(!empty($imgSize)){
			$remote_url = $remote_url.'&size='.trim($imgSize);
		}
		$remote_url = $remote_url.'&saveFileName='.urlencode(json_encode($saveFileName));
		$goImageServer=true;
	}else{
		$remote_url = PropConfig::getDefaultValue('FastDFS.remoteurl');
		//$remote_url = "http://tongkun.gyj.com/upload.php";
	}
	
	$ch = curl_init();
	//兼容版本信息
	if(class_exists('CURLFile')){
		$data = array(
				'filename' => new CURLFile(realpath($temp_file)),
				'fileextension' => $filextension
		);
	}else{
		$data = array(
				'filename' => '@'.$temp_file,
				'fileextension' => $filextension
		);
	}
	curl_setopt($ch,CURLOPT_URL,$remote_url);
	curl_setopt($ch,CURLOPT_POST,true);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$data);
	
	$info = curl_exec($ch);
	curl_close($ch);
	
	$retArr = json_decode($info,true);
	
	if(!$goImageServer){//没有走图片服务器
		$retArr['source_file_name'] = $source_file_name;
		// 先处理返回的数据保存到管理系统数据库
		
		$arr = execjava("fileManageBean.saveUploadFileInfo",$retArr,"php","asmc");
		$retArr['status'] = $arr['status'];
		$retArr['regMsg'] = $arr['retmsg']; 
		
	}
	
	echo json_encode($retArr);	
}	
?>























