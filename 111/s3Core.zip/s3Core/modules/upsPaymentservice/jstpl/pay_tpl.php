<!-- 付款单详情显示的数据 -->
<script id="paymentDetailTpl" type="text/html">
<div class="pad10 pad_b0 f12 mar_b10">
	<div class="mt0 transeferpay">
		<div class="payDetail">
			<ul>
				<li id="companyInfoLi" style="display: none;">
					<label>分公司信息：</label>
					<span>
						<input type="text" class="w250 input-text" id="companyInfoSelect" value="<%=payment.companyName==null?"":payment.companyName%>" readonly />
					</span>
				</li>
				<li id="supplierInfoLi">
					<label>供应商信息：</label>
					<span>
						<input type="text" class="w250 input-text" id="supplierNameSelect" value="<%=payment.reciverName==null?"":payment.reciverName%>" readonly />
					</span>
				</li>
				<li>
					<label>转账处理方式：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="payType" <%if(payment.payType == "1"){%>checked="checked"<%}%> disabled/> 加急
					</span>
					<span class="pad_l60">
						<input type="radio" value="2" name="payType" <%if(payment.payType == "2"){%>checked="checked"<%}%> disabled/> 普通
					</span>
				</li>
				<li>
					<label>付款账号：</label>
					<input type="text" class="w250 input-text" id="payAccountNo" name="payAccNo" value="<%=payment.payAccNo==null?"":payment.payAccNo%>" readonly/>
					<label class="pad_l100">付款账号名称：</label>
					<input type="text" class="w250 input-text" id="payAccountName" name="payAccName" value="<%=payment.payAccName==null?"":payment.payAccName%>" readonly/>
				</li>
				<li>
					<label>收款账号：</label>
					<input type="text" class="w250 input-text" name="recAccNo" id="recAccNo" value="<%=payment.recAccNo==null?"":payment.recAccNo%>" readonly/>
					<label class="pad_l100">收款账号名称：</label>
					<input type="text" class="w250 input-text" name="recAccName" id="recAccName" value="<%=payment.recAccName==null?"":payment.recAccName%>" readonly/>
				</li>
				<li>
					<label>系统内外标志：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="sysIOFlg" <%if(payment.sysIOFlg == "1"){%>checked="checked"<%}%> disabled/> 系统内
					</span>
					<span class="pad_l60">
						<input type="radio" value="2" name="sysIOFlg" <%if(payment.sysIOFlg == "2"){%>checked="checked"<%}%> disabled/> 系统外
					</span>
				</li>
				<li>
					<label>对公对私标志：</label>
					<span class="pad_l30">
						<input type="radio" value="0" name="isPub" <%if(payment.isPub == "0"){%>checked="checked"<%}%> disabled/> 对公账户
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="1" name="isPub" <%if(payment.isPub == "1"){%>checked="checked"<%}%> disabled//> 个人账户
					</span>
				</li>
				<li id="ReceiveCityName" style="display: none;">
					<label>收款方所在城市名称：</label>
					<input type="text" class="w200 input-text" id="recCityName" name="recCityName" value="<%=payment.recCityName==null?"":payment.recCityName%>" readonly/>
				</li>
				<li id="RecordType" style="display: none;">
					<label>录入方式：</label>
				<%if(payment.recBankNo != null && payment.recBankNo != ""){%>
					<span style="padding-left:53px;">
						<input type="radio" value="0" name="recordType" checked="checked" disabled/> 级联查询
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="1" name="recordType" disabled/> 手工输入
					</span>
				<%}else{%>
					<span style="padding-left:53px;">
						<input type="radio" value="0" name="recordType" disabled/> 级联查询
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="1" name="recordType" checked="checked" disabled /> 手工输入
					</span>
				<%}%>
				</li>
				<li id="InputRecordType" style="display: none;">
					<label>收款人账户所属银行：</label>
					<input type="text" class="w200 input-text" id="inputBankName" name="inputBankName" value="<%=payment.recBankName==null?"":payment.recBankName%>" readonly/>
				</li>
				<li id="BankList" style="display: none;">
					<label>收款人账户所属银行：</label>
					<select id="bankNoSelect" disabled>
						<option value="<%=payment.recBankNo%>"><%=payment.recBankName==null?"":payment.recBankName%></option>
					</select>
				</li>
				<li>
					<label>货币种类：</label>
					<span style="padding-left:53px;">
						<input type="radio" name="currType" checked value="人民币"/> 人民币
					</span>
				</li>
				<li>
					<label>付款金额：</label>
					<input type="text" class='w200 input-text' name="payAmt" maxLength="11" id="payAmount" value="<%=payment.payAmt==null?"":payment.payAmt%>" readonly/> 元
				</li>
				<li>
					<label>备注：</label>
					<input type="text" class='w200 input-text' name="payNote" id="payNote" maxLength="20" value="<%=payment.postScript==null?"":payment.postScript%>" readonly/>
				</li>
			</ul>
		</div>
	</div>
</div>
</script>

<!-- 有付款单支付时显示的数据 -->
<script id="payDetailTpl" type="text/html">
<div class="pad10 pad_b0 f12 mar_b10">
	<div class="mt0 transeferpay">
		<div class="pay">
			<ul>
				<!--<li >
					<p class="fl_l f14 " style="margin-top:10px">
						<span class="fw lin_h25">
						付款单号：<font class="f4 fw"><%=paymnetNo%></font> 详情信息:
						</span>
					</p>
				</li>-->
				<li id="companyInfoLi" style="display: none;">
					<label>分公司信息：</label>
					<select id="companyInfoSelect_<%=i%>" disabled></select>
				</li>
				<li id="supplierInfoLi_<%=i%>">
					<label>供应商信息：</label>
					<select id="supplierNameSelect_<%=i%>" disabled></select>
				</li>
				<li id="handleWay_<%=i%>">
					<label>转账处理方式：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="payType_<%=i%>" checked="checked"/> 加急
					</span>
					<span class="pad_l60">
						<input type="radio" value="2" name="payType_<%=i%>" /> 普通
					</span>
				</li>
				<li>
					<label>付款账号：</label>
					<select id="payAccountNo_<%=i%>" name="payAccNo" onchange="changeAccName(this, this.value,'payAccountName',<%=i%>);"></select>
					<label class="pad_l120">付款账号名称：</label>
					<select id="payAccountName_<%=i%>" name="payAccName"></select>
				</li>
				<li style="position: relative;">
					<label>收款账号：</label>
                     <span>
                     <select id="recAccNo_<%=i%>" name="recAccNo"  onchange="changeAccName(this, this.value,'recAccName',<%=i%>);">
                      </select>
                        <span style="position: absolute; top: 13px;left: 68px" >
                        <input id="inputrecAccNo_<%=i%>" type="text" style="border: none;  width: 230px;" /></span>
                     </span>		
					<label class="pad_l120">收款账号名称：</label>
					<select id="recAccName_<%=i%>" name="recAccName"></select>
				</li>
				<li id="insideAndOutside_<%=i%>">
					<label>系统内外标志：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="sysIOFlg_<%=i%>" checked="checked"/> 系统内
					</span>
					<span class="pad_l60">
						<input type="radio" value="2" name="sysIOFlg_<%=i%>" /> 系统外
					</span>
				</li>
				<li id="PublicAndPrivate_<%=i%>">
					<label>对公对私标志：</label>
					<span class="pad_l30">
						<input type="radio" value="0" name="isPub_<%=i%>" checked="checked"/> 对公账户
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="1" name="isPub_<%=i%>" /> 个人账户
					</span>
				</li>
				<li id="ReceiveCityName_<%=i%>" style="display: none;">
					<label>收款方所在城市名称：</label>
					<input type="text" class="w200 input-text" id="recCityName_<%=i%>" name="recCityName"/>
				</li>
				<li id="RecordType_<%=i%>" style="display: none;">
					<label>录入方式：</label>
					<span style="padding-left:53px;">
						<input type="radio" value="0" name="recordType_<%=i%>" checked="checked"/> 级联查询
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="1" name="recordType_<%=i%>" /> 手工输入
					</span>
				</li>
				<li id="InputRecordType_<%=i%>" style="display: none;">
					<label>收款人账户所属银行：</label>
					<input type="text" class="w200 input-text" id="inputBankName_<%=i%>" name="inputBankName"/>
				</li>
				<li id="BankList_<%=i%>" style="display: none;">
					<label>收款人账户所属银行：</label>
					<select id="bankNoSelect_<%=i%>" onchange='$("#branchBankNoSelect").html("");'>
					</select>
				</li>
				<li id="BankBranchList_<%=i%>" style="display: none;">
					<label>所属银行网点关键字：</label>
					<input type="text" class="w200 input-text" id="branchKeyWord_<%=i%>"/>
					<input type="button" value="查询" class="btn btn-buy" onclick="queryBankBranch(<%=i%>)"/>
					<span class="pad_l80">
						<select id="branchBankNoSelect_<%=i%>" name="recBankName">
						</select>
					</span>
				</li>
				<li>
					<label>货币种类：</label>
					<span style="padding-left:53px;">
						<input type="radio" name="currType_<%=i%>" checked value="人民币"/> 人民币
					</span>
				</li>
				<li>
					<label>付款金额：</label>
					<input type="text" class='w200 input-text' name="payAmt_<%=i%>" maxLength="11" id="payAmount_<%=i%>" value="<%=result.payAmt%>" readonly/> 元
				</li>
				<li>
					<label>备注：</label>
					<input type="text" class='w200 input-text' name="payNote" id="payNote_<%=i%>" maxLength="20"/>
					<span class="f1 fw">（注意：字数不能超过20个！）</span>
				</li>
			</ul>
		</div>
	</div>
</div>
</script>

<!-- 合并付款单 支付页面  -->
<script id="mergePayTpl" type="text/html">
<div class="pad10 pad_b0 f12 mar_b10">
	<div class="mt0 transeferpay">
		<div class="pay">
			<ul>
				<li id="companyInfoLi" style="display: none;">
					<label>分公司信息：</label>
					<select id="companyInfoSelect" onchange="selectBranchCompany();"></select>
				</li>
				<li>
					<label>转账处理方式：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="payType" checked="checked"/> 加急
					</span>
					<span class="pad_l60">
						<input type="radio" value="2" name="payType" /> 普通
					</span>
				</li>
				<li>
					<label>付款账号：</label>
					<select id="payAccountNo" name="payAccNo" onchange="changeAccName(this, this.value,'payAccountName');changePayAccNo();" style="margin-left:13px;"></select>
					<label class="pad_l120">付款账号名称：</label>
					<select id="payAccountName" name="payAccName"></select>
				</li>
				<li id="supplierInfoLi">
					<label>供应商信息：</label>
					<select id="supplierNameSelect" onchange="changeCustomer(this.value);"></select>
				</li>
				<li>
					<label>收款账号：</label>
					<select id="recAccNo" name="recAccNo"  onchange="changeAccName(this, this.value,'recAccName');" style="margin-left:13px;"></select>
					<label class="pad_l120">收款账号名称：</label>
					<select id="recAccName" name="recAccName"></select>
				</li>
				<li>
					<label>选择发票：</label>
                    <span id="choosePurinvoiceNo"></span>
					<a class="f1" onclick='choosePurinvoice()'>选择</a>
				</li>
				<li>
					<label>系统内外标志：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="sysIOFlg" checked="checked"/> 系统内
					</span>
					<span class="pad_l60">
						<input type="radio" value="2" name="sysIOFlg" /> 系统外
					</span>
				</li>
				<li>
					<label>对公对私标志：</label>
					<span class="pad_l30">
						<input type="radio" value="0" name="isPub" checked="checked"/> 对公账户
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="1" name="isPub" /> 个人账户
					</span>
				</li>
				<li id="ReceiveCityName" style="display: none;">
					<label>收款方所在城市名称：</label>
					<input type="text" class="w200 input-text" id="recCityName" name="recCityName"/>
				</li>
				<li id="RecordType" style="display: none;">
					<label>录入方式：</label>
					<span style="padding-left:53px;">
						<input type="radio" value="0" name="recordType" checked="checked"/> 级联查询
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="1" name="recordType" /> 手工输入
					</span>
				</li>
				<li id="InputRecordType" style="display: none;">
					<label>收款人账户所属银行：</label>
					<input type="text" class="w200 input-text" id="inputBankName" name="inputBankName"/>
				</li>
				<li id="BankList" style="display: none;">
					<label>收款人账户所属银行：</label>
					<select id="bankNoSelect" onchange='$("#branchBankNoSelect").html("");'>
					</select>
				</li>
				<li id="BankBranchList" style="display: none;">
					<label>所属银行网点关键字：</label>
					<input type="text" class="w200 input-text" id="branchKeyWord"/>
					<input type="button" value="查询" class="btn btn-buy" onclick="queryBankBranch()"/>
					<span class="pad_l80">
						<select id="branchBankNoSelect" name="recBankName">
						</select>
					</span>
				</li>
				<li>
					<label>货币种类：</label>
					<span style="padding-left:53px;">
						<input type="radio" name="currType" checked value="人民币"/> 人民币
					</span>
				</li>
				<li>
					<label>付款金额：</label>
					<input type="text" name="payAmt" value="<%=result.payAmt%>" maxLength="11" id="payAmount" readonly/> 元
					<!-- <label class="pad_l50">账户余额：<label>
					<input type="text" name="accountBalance"  id="accountBalance" value="" disabled/> -->
				</li>
				<li>
					<label>备注：</label>
					<input type="text" name="payNote" id="payNote" maxLength="20"/>
					<span class="f1 fw">（注意：字数不能超过20个！）</span>
				</li>
			</ul>
		</div>
	</div>
	<div class="fl_r mar_b10 mar_r30">
		<input type="button" value="支付" id="payButton" class="btn btn-next skin_btn_light"/>
	<div>
</div>
</script>
<!-- 可合并支付付款单列表 -->
<script id="mergePurinvoiceTpl" type="text/html">
<table width="100%">
	<thead>
		<tr>
			<th><input type='checkbox' name='allData' <%if(currentTotalChecked == limit){%>checked<%}%> onclick='checkedObj.checkedAllData(this, "oneData")'/></th>
	 		<th>发票号码</th>
			<th>付款单号</th>
            <th>金额</th>
		</tr>
	</thead>
	<tbody>
		<%if(purchaseList.length > 0){%>
			<%for(var i=0, len=purchaseList.length; i < len;i++){%>
				<%if(i % 2 != 0){%>
				<tr class='bg_tr1 bb_tb'>
				<%} else {%>
				<tr>
				<%} %>
					<td><input type='checkbox' name='oneData' data="<%=purchaseList[i].purchaseNo%>_<%=purchaseList[i].totalAmount%>" <%if(checkedPurchase.indexOf(purchaseList[i].purchaseNo+'_'+purchaseList[i].totalAmount) > -1){%>checked<%}%> onclick='checkedObj.checkedOneData(this, "allData")'/></td>
					<td><%=purchaseList[i].purchaseNo%></td>
                    <td><%=purchaseList[i].paymentNo == null ? "" : purchaseList[i].paymentNo%></td>
					<td class="f1 fw">￥<%=purchaseList[i].totalAmount%></td>
				</tr>
			<%}%>
		<%}%>
	</tbody>
</table>
</script>
