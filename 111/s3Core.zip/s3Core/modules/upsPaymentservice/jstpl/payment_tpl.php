<!-- 供应商所对应付款单的搜索条件 -->
<script type="text/html" id="paymentSearchTypeTpl_lookUp">
<form id="keySearchForm">
	<div class="condit2">
		<div class="inpSearch">
			<span name="paymentNo" class="choice_list">收款单号:</span>
			<input id="paymentNo" name="paymentNo" type="text" class="inputData" />
		</div>
		<div class="inpSearch">
			<span name="payAmount" class="choice_list">收款金额:</span>
			<input id="startPayAmount" name="startAmount" type="text" class="inputMoney" onkeyup="this.value=this.value.replace(/[^\d]/g,'')"/>-<input id="endPayAmount" name="endAmount" type="text" class="inputMoney" onkeyup="this.value=this.value.replace(/[^\d]/g,'')"/>
		</div>
	</div>
	<div class="condit2">
		<div class="inpSearch">
			<span name="companyName" class="choice_list">公司名称:</span>
			<input id="companyName" name="companyName" type="text" class="inputData" />
		</div>
		<div class="inpSearch">
			<span name="start_date" class="choice_list">收款日期:</span>
			<input name="startTime" type="text" class="inputTime" id="start_date" onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });"/>-<input name="endTime" type="text" class="inputTime" id="end_date"  onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });"/>
		</div>
		
		<div class="positionBtn3">
			<a href="javascript:search(1);" class="btn_small skin_btn_light" id="searchBtn" >搜索</a>
			<a href="javascript:clean();" class="btn_small skin_btn_dark" id="clearBtn" >重置</a>
		</div>
	</div>

</form>
</script>

<!-- 业务员所对应付款单的搜索条件 -->
<script type="text/html" id="paymentSearchTypeTpl_payOff">
<form id="keySearchForm">
	<div class="condit2">
		<div class="inpSearch">
			<span name="paymentNo" class="choice_list">付款单号:</span>
			<input id="paymentNo" name="paymentNo" type="text" class="inputData" />
		</div>
		<div class="inpSearch">
			<span name="payAmount" class="choice_list">付款金额:</span><input id="startPayAmount" name="startAmount" type="text" class="inputMoney" onkeyup="this.value=this.value.replace(/[^\d]/g,'')"/>-<input id="endPayAmount" name="endAmount" type="text" class="inputMoney" onkeyup="this.value=this.value.replace(/[^\d]/g,'')"/>
		</div>
		<div class="inpSearch">
			<span name="reciverName" class="choice_list">收款人:</span>
			<input id="reciverName" name="reciverName" type="text" class="inputData" />
		</div>
	</div>

	<div class="condit2">
		<div class="inpSearch">
			<span name="companyName" class="choice_list">公司名称:</span>
			<input id="companyName" name="companyName" type="text" class="inputData" />
		</div>
		<div class="inpSearch">
			<span name="start_date" class="choice_list">付款日期:</span><input name="startTime" type="text" class="inputTime" id="start_date" onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });"/>-<input name="endTime" type="text" class="inputTime" id="end_date"  onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });"/>
		</div>

		<div class="positionBtn3">
			<a href="javascript:search(1);" class="btn_small skin_btn_light" id="searchBtn" >搜索</a>
			<a href="javascript:clean();" class="btn_small skin_btn_dark" id="clearBtn" >重置</a>
		</div>
	</div>

</form>
</script>


<!-- 付款单列表_1, 对应核心业务员 -->
<script type='text/html' id='paymentListTpl_payOff'>
	<table width='100%' class='mypayment_table'>
		<thead>
			<tr>
				<th width="1%">
				<input type="checkbox" name="allData" onclick='checkedObj.checkedAllData(this, "oneData")'>
				</th>
				<!--<th width="1%" class="fn"></th>-->
				<th width="12%">付款单号</th>
				<th width="12%">公司名称</th>
				<th width="12%">收款人</th>
				<th width="15%">付款金额</th>
				<th width="12%">
					<select id="choosePaymentStatus" onchange="searchPaymentInfoList(1, this.value, $('#chooseTransferStatus').val());">
						<option value="">付款单状态</option>
						<%for(var j in paymentStatus){%>
							<%if(paymentStatus.hasOwnProperty(j)){%>
								<%if(status == j){%>
									<option value='<%=j%>' selected><%=paymentStatus[j]%></option>
								<%}else{%>
									<option value='<%=j%>'><%=paymentStatus[j]%></option>
								<%}%>
							<%}%>
						<%}%>
					</select>
				</th>
				<th width="10%">付款日期</th>
				<th width="12%">
					<select id="chooseTransferStatus" onchange="searchPaymentInfoList(1, $('#choosePaymentStatus').val(), this.value);">
						<option value="">付款单转账状态</option>
						<%for(var j in transferStatus){%>
							<%if(transferStatus.hasOwnProperty(j)){%>
                                <%if(j!='getTransferStatusValue'){%>
                                <%if(choosedTransferStatus == j){%>
									<option value='<%=j%>' selected><%=transferStatus[j]%></option>
								<%}else{%>
									<option value='<%=j%>'><%=transferStatus[j]%></option>
								<%}}%>
							<%}%>
						<%}%>
					</select>
				</th>
				<th width="8%">操作</th>
			</tr>
		</thead>
		<tbody>
			<%if(paymentList.length > 0){%>
				<%for(var i=0, len=paymentList.length; i < len;i++){%>
					<%if(i % 2 != 0){%>
					<tr class='bg_tr1 bb_tb'>
					<%} else {%>
					<tr>
					<%}%>
					<%if(paymentList[i].status == "0" || paymentList[i].status == "3"){%>
					<td>
					<input type="checkbox"  name="oneData" data="<%=paymentList[i].paymentNo%>" onclick='checkedObj.checkedOneData(this, "allData")'>
					</td>
					<%}else{%>
					<td></td>
					<%}%>
						<!--<%if(paymentList[i].num>0){%>
						<td>
                            <span id="jia<%=paymentList[i].paymentNo%>" class="pay-add" onclick="jiaordershow('<%=paymentList[i].paymentNo%>')">+</span>
                 			<span id="jian<%=paymentList[i].paymentNo%>" class="pay-add" onclick="jianordernone('<%=paymentList[i].paymentNo%>')" style="display: none;">-</span>                 			
                        </td>
                        <%}else{%><td></td><%}%>-->
						<td class="f4 fw">
							<%if(paymentList[i].status != "0" && paymentList[i].status != "3"){%>
								<a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 1, 'uppaymentDetail')"><%=paymentList[i].paymentNo%></a>
							<%}else{%>
								<%=paymentList[i].paymentNo%>
							<%}%>
						</td>
						<td><%=paymentList[i].companyName == null ? "" : paymentList[i].companyName%></td>
						<td><%=paymentList[i].reciverName == null ? "" : paymentList[i].reciverName%></td>
						<td class="f1 fw" id="payAmt_<%=i%>">￥<%=paymentList[i].payAmt%></td>
						<td id="paymentStatus_<%=i%>">
							<%if(paymentList[i].num>0){%>
							<%=paymentStatus[paymentList[i].status]%>
							<%}else{%>
							<%=paymentStatus[0]%>
							<%}%>
                        </td>
						<td><%=paymentList[i].payTime == null ? "" :paymentList[i].payTime%></td>
						<td id="transferStatus_<%=i%>">
							<%if(paymentList[i].num>0){%>
							<%=transferStatus.getTransferStatusValue([paymentList[i].transferStatus])%>
							<%}else{%>
							<%}%>
                        </td>
						<td>
                            <%if(paymentList[i].status == "0" || paymentList[i].status == "3"){%>
                                <%if(paymentList[i].isUpload!=null){%>
                                     <%if(way=='1'){%>
                                       <%if(paymentList[i].isUpload=='0'){%>
								           <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','0');" class="btn_small skin_btn_light">支付<a>
                                       		<%if(paymentList[i].num>0){%>
											 <a href="javascript:financeWin("financeWindow",'<%=i%>');" class="btn_small skin_btn_light">支付指令<a>	
											 <%}%>
										   <%}else{%>
								           <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">还款<a>
                                       <%}%>
                                     <%}else if(way=='2'){%>
                                        <%if(paymentList[i].isUpload=='0'){%>
								             <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">支付<a>
											 <%if(paymentList[i].num>0){%>
											 <a href="javascript:financeWin("financeWindow",'<%=i%>');" class="btn_small skin_btn_light">支付指令<a>	
											 <%}%>
                                        <%}else{%>
								             <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">还款<a>
                                        <%}%>
                                     <%}else if(way=='3'){%>
                                         <%if(paymentList[i].isUpload=='0'){%>
								                <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">支付<a>
                                         		<%if(paymentList[i].num>0){%> <a href="javascript:financeWin("financeWindow",'<%=i%>');" class="btn_small skin_btn_light">支付指令<a>	
											    <%}%>
										 <%}else{%>
								                <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">还款<a>
                                         <%}%>
                                      <%}else if(way=='4'){%>
								          <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">还款<a>
                                      <%}%>
                                  <%}else{%>
                                       <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','0');" class="btn_small skin_btn_light">支付<a>
									   <%if(paymentList[i].num>0){%>
										 <a href="javascript:financeWin('financeWindow','<%=i%>');" class="btn_small skin_btn_dark">支付指令<a>	
									   <%}%>
                                  <%}%>
                            <%}else{%>
									<a href="javascript:financeWin('financeWindow','<%=i%>');" class="btn_small skin_btn_dark">支付指令<a>	
							<%}%>
						</td>
					</tr>
					<!--<tr id="showrelatepaymentorder<%=paymentList[i].paymentNo%>" style="display: none;"></tr>-->
				<%}%>
			<%}else{%>
				<tr>
					<td colspan='9' class='f4 fw'>无查询结果</td>
				</tr>
			<%}%>
		</tbody>
	</table>
</script>

<!-- 付款单列表, 对应供应商 -->
<script id='paymentListTpl_lookUp' type="text/html">
	<table width='100%' class='mypayment_table'>
		<thead>
			<tr>
				<th>收款单号</th>
				<th>付款人</th>
				<th>公司名称</th>
				<th>收款金额</th>
				<th>收款日期</th>
				<th>
					<select id="choosePaymentStatus" onchange="searchPaymentInfoList(1, this.value, $('#chooseTransferStatus').val());">
						<option value="">收款单状态</option>
						<%for(var j in paymentStatus){%>
							<%if(paymentStatus.hasOwnProperty(j)){%>
								<%if(status == j){%>
									<option value='<%=j%>' selected><%=paymentStatus[j]%></option>
								<%}else{%>
									<option value='<%=j%>'><%=paymentStatus[j]%></option>
								<%}%>
							<%}%>
						<%}%>
					</select>
				</th>
				<th>
					<select id="chooseTransferStatus" onchange="searchPaymentInfoList(1, $('#choosePaymentStatus').val(), this.value);">
						<option value="">收款单转账状态</option>
						<%for(var j in transferStatus){%>
							<%if(transferStatus.hasOwnProperty(j)){%>
                                <%if(j!='getTransferStatusValue'){%>
								    <%if(choosedTransferStatus == j){%>
									    <option value='<%=j%>' selected><%=transferStatus[j]%></option>
								    <%}else{%>
									    <option value='<%=j%>'><%=transferStatus[j]%></option>
								<%}}%>
							<%}%>
						<%}%>
					</select>
				</th>
			</tr>
		</thead>
		<tbody>
			<%if(paymentList.length > 0){%>
				<%for(var i=0, len=paymentList.length; i < len;i++){%>
					<%if(i % 2 != 0){%>
					<tr class='bg_tr1 bb_tb'>
					<%} else {%>
					<tr>
					<%}%>
						<td class="f4 fw">
							<%if(paymentList[i].status != "0"){%>
								<a href="javascript:;" onclick="jumpTo('<%=paymentList[i].paymentNo%>', 1, 'dibetNoteDetail');return false;"><%=paymentList[i].paymentNo%></a>
							<%}else{%>
								<%=paymentList[i].paymentNo%>
							<%}%>
						</td>
						<td><%=paymentList[i].payAccName == null ? "" : paymentList[i].payAccName%></td>
						<td><%=paymentList[i].companyName == null ? "" : paymentList[i].companyName%></td>
						<td class="f1 fw">￥<%=paymentList[i].payAmt%></td>
						<td><%=paymentList[i].payTime == null ? "" : paymentList[i].payTime%></td>
						<td><%=paymentStatus[paymentList[i].status]%></td>
						<td><%=transferStatus.getTransferStatusValue(paymentList[i].transferStatus)%></td>
					</tr>
				<%}%>
			<%}else{%>
				<tr>
					<td colspan='9' class='f4 fw'>无查询结果</td>
				</tr>
			<%}%>
		</tbody>
	</table>
</script>
<!-- 付款单总表 -->
<script id='paymentListEnsembleTpl' type="text/html">
	<table width='100%' class='mypayment_table'>
		<thead>
			<tr>
				<th ></th>
				<th>付款单号</th>
				<th>公司名称</th>
				<th>付款金额</th>
				<th>付款日期</th>
				<th>
					<select id="choosePaymentStatus" onchange="searchPaymentParentInfoList(1, this.value, $('#chooseTransferStatus').val());">
						<option value="">付款单状态</option>
						<%for(var j in paymentStatus){%>
							<%if(paymentStatus.hasOwnProperty(j)){%>
								<%if(status == j){%>
									<option value='<%=j%>' selected><%=paymentStatus[j]%></option>
								<%}else{%>
									<option value='<%=j%>'><%=paymentStatus[j]%></option>
								<%}%>
							<%}%>
						<%}%>
					</select>
				</th>
				<th>
					<select id="chooseTransferStatus" onchange="searchPaymentParentInfoList(1, $('#choosePaymentStatus').val(), this.value);">
						<option value="">付款单转账状态</option>
						<%for(var j in transferStatus){%>
							<%if(transferStatus.hasOwnProperty(j)){%>
                                <%if(j!='getTransferStatusValue'){%>								
                                    <%if(choosedTransferStatus == j){%>
									    <option value='<%=j%>' selected><%=transferStatus[j]%></option>
								    <%}else{%>
									    <option value='<%=j%>'><%=transferStatus[j]%></option>
								<%}}%>
							<%}%>
						<%}%>
					</select>
				</th>
<th>操作</th>
			</tr>
		</thead>
		<tbody>
			<%if(paymentList.length > 0){%>
				<%for(var i=0, len=paymentList.length; i < len;i++){%>
					<%if(i % 2 != 0){%>
					<tr class='bg_tr1 bb_tb'>
					<%} else {%>
					<tr>
					<%}%>
                        <%if(paymentList[i].num>0){%>
						<td>
                            <span id="jia<%=i%>" class="pay-add" onclick="jiaordershow(<%=i%>,'<%=paymentList[i].paymentNo%>')">+</span>
                 			<span id="jian<%=i%>" class="pay-add" onclick="jianordernone('<%=i%>')" style="display: none;">-</span>                 			
                        </td>
                       <%}else{%><td></td><%}%>
						<td class="f4 fw">
							<%=paymentList[i].paymentNo%>
						</td>
						<td><%=paymentList[i].companyName == null ? "" : paymentList[i].companyName%></td>
						<td class="f1 fw">￥<%=paymentList[i].payAmt%></td>
						<td><%=paymentList[i].payTime == null ? "" : paymentList[i].payTime%></td>
						<td><%=paymentStatus[paymentList[i].status]%></td>
						<td><%=transferStatus.getTransferStatusValue(paymentList[i].transferStatus)%></td>
					</tr>
                    <tbody id="showrelatedorder<%=i%>"></tbody>
				<%}%>
			<%}else{%>
				<tr>
					<td colspan='9' class='f4 fw'>无查询结果</td>
				</tr>
			<%}%>
		</tbody>
	</table>
</script>

<script id="relatedOrder_tpl" type="text/html">
                <%if(paymentList.length > 0){%>
				<%for(var i=0, len=paymentList.length; i < len;i++){%>
                      <tr>
                        <td>&nbsp</td>
						<td class="f4 fw">
							<%if(paymentList[i].status != "0"){%>
								<a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 1, 'uppaymentDetail')"><%=paymentList[i].paymentNo%></a>
							<%}else{%>
								<%=paymentList[i].paymentNo%>
							<%}%>
						</td>
						<td><%=paymentList[i].companyName == null ? "" : paymentList[i].companyName%></td>
						<!--<td><%=paymentList[i].reciverName == null ? "" : paymentList[i].reciverName%></td>-->
						<td class="f1 fw">￥<%=paymentList[i].payAmt%></td>
						<td><%=paymentList[i].payTime == null ? "" : paymentList[i].payTime.substr(0,10)%></td>
						<td><%=paymentStatus[paymentList[i].status]%></td>
						<td><%=transferStatus.getTransferStatusValue(paymentList[i].transferStatus)%></td>
						<td>
                            <%if(paymentList[i].status == "0" && role == 'payOff'){%>
                                <%if(paymentList[i].isUpload!=null){%>
                                     <%if(way=='1'){%>
                                         <%if(paymentList[i].isUpload=='0'){%>
								           <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','0');" class="btn_small skin_btn_light">支付<a>
                                         <%}else{%>
								            <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">还款<a>
                                         <%}%>
                                      <%}else if(way=='2'){%>
                                         <%if(paymentList[i].isUpload=='0'){%>
								             <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">支付<a>
                                         <%}else{%>
								             <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">还款<a>
                                         <%}%>
                                      <%}else if(way=='3'){%>
                                         <%if(paymentList[i].isUpload=='0'){%>
								                <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">支付<a>
                                         <%}else{%>
								                <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">还款<a>
                                         <%}%>
                                      <%}else if(way=='4'){%>
								          <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','<%=paymentList[i].isUpload%>');" class="btn_small skin_btn_light">还款<a>
                                      <%}%>
                                  <%}else{%>
                                       <!-- 没有关联发票或者关联发票按照未上传到总行处理-->
                                       <a href="javascript:jumpTo('<%=paymentList[i].paymentNo%>', 0, 'upPay','0');" class="btn_small skin_btn_light">支付</a>
                                  <%}%>
                            <%}%>
						</td>
                     </tr>
				<%}%>
			<%}else{%>
				<tr>
					<td colspan='9' class='f4 fw'>无查询结果</td>
				</tr>
			<%}%>
</script>



<script id="relatedPaymentOrder_tpl" type="text/html">
<td colspan='9' id='paymentorder<%=paymentNo%>' class='pay-add_td'>
<table style="width:500px">         
	    <tr>
            <th>收款人名称</th>
       		<th>付款时间</th>
            <th>付款指令状态</th>
	    </tr>
        <tbody >
               <%
                  if(payCommandList.length==0)
                  {%>
                    <tr>
            		   <td colspan="5" class="pay-no_order"><strong>无查询结果！</strong></td>
            	   </tr>
                  <%}
                for(var i=0;i<payCommandList.length;i++){ 				
                    var payCommand = payCommandList[i];
                    var reciverName = payCommand.reciverName;
                    var payTime = payCommand.payTime == undefined ? "":payCommand.payTime;
	                var transferStatus1 = payCommand.transferStatus;
                 %>
                  <tr <% if(i%2==1){%>class="pay-bg1"<% }else{ %> class="pay-bg"<% } %> >                      
                 		<td ><%=reciverName%></td>                 		  
		                <td ><%=payTime%></td> 
                        <td ><%=transferStatus.getTransferStatusValue(transferStatus1)%></td>            		
             	  </tr> 
                <%}%>                 
        </tbody>             
</table> 
</script>

