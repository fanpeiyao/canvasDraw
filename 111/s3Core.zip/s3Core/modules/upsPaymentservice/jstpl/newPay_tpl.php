<!-- 无付款单支付时显示的数据 -->
<script id="newpayTpl" type="text/html">
<div class="pad10 pad_b0 f12 mar_b10">
	<div class="mt0 transeferpay">
		<div class="pay">
			<ul>
				<li id="companyInfoLi">
					<label>分公司信息：</label>
					<select id="companyInfoSelect" onchange="selectBranchCompany();"></select>
				</li>
				<li>
					<label>转账处理方式：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="payType" checked="checked"/> 加急
					</span>
					<span class="pad_l60">
						<input type="radio" value="2" name="payType" /> 普通
					</span>
				</li>
				<li>
					<label>付款账号：</label>
					<select id="payAccountNo" name="payAccNo" onchange="changeAccName(this, this.value,'payAccountName');changePayAccNo();" style="margin-left:13px;"></select>
					<label class="pad_l120">付款账号名称：</label>
					<select id="payAccountName" name="payAccName"></select>
				</li>
				<li id="supplierInfoLi">
					<label>供应商信息：</label>
					<select id="supplierNameSelect" onchange="changeCustomer(this.value);"></select>
				</li>
				<li>
					<label>收款账号：</label>
					<select id="recAccNo" name="recAccNo"  onchange="changeAccName(this, this.value,'recAccName');" style="margin-left:13px;"></select>
					<label class="pad_l120">收款账号名称：</label>
					<select id="recAccName" name="recAccName"></select>
				</li>
				<li>
					<label>系统内外标志：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="sysIOFlg" checked="checked"/> 系统内
					</span>
					<span class="pad_l60">
						<input type="radio" value="2" name="sysIOFlg" /> 系统外
					</span>
				</li>
				<li>
					<label>对公对私标志：</label>
					<span class="pad_l30">
						<input type="radio" value="1" name="isPub" checked="checked"/> 对公账户
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="2" name="isPub" /> 个人账户
					</span>
				</li>
				<li id="ReceiveCityName" style="display: none;">
					<label>收款方所在城市名称：</label>
					<input type="text" class="w200 input-text" id="recCityName" name="recCityName"/>
				</li>
				<li id="RecordType" style="display: none;">
					<label>录入方式：</label>
					<span style="padding-left:53px;">
						<input type="radio" value="0" name="recordType" checked="checked"/> 级联查询
					</span>
					<span style="padding-left:48px;">
						<input type="radio" value="1" name="recordType" /> 手工输入
					</span>
				</li>
				<li id="InputRecordType" style="display: none;">
					<label>收款人账户所属银行：</label>
					<input type="text" class="w200 input-text" id="inputBankName" name="inputBankName"/>
				</li>
				<li id="BankList" style="display: none;">
					<label>收款人账户所属银行：</label>
					<select id="bankNoSelect" onchange='$("#branchBankNoSelect").html("");'>
					</select>
				</li>
				<li id="BankBranchList" style="display: none;">
					<label>所属银行网点关键字：</label>
					<input type="text" class="w200 input-text" id="branchKeyWord"/>
					<input type="button" value="查询" class="btn btn-buy" onclick="queryBankBranch()"/>
					<span class="pad_l80">
						<select id="branchBankNoSelect" name="recBankName">
						</select>
					</span>
				</li>
				<li>
					<label>货币种类：</label>
					<span style="padding-left:53px;">
						<input type="radio" name="currType" checked value="人民币"/> 人民币
					</span>
				</li>
				<li>
					<label>付款金额：</label>
					<input type="text" class='w200 input-text' name="payAmt" maxLength="11" id="payAmount" value="<?php echo $_POST['paymentAmount']?>"/> 元
					<!-- <label class="pad_l50">账户余额：<label>
					<input type="text" name="accountBalance" id="accountBalance" value="" disabled/> -->
				</li>
				<li>
					<label>备注：</label>
					<input type="text" class='w200 input-text' name="payNote" id="payNote" maxLength="20"/>
					<span class="f1 fw">（注意：字数不能超过20个！）</span>
				</li>
			</ul>
		</div>
	</div>
	<div class="fl_r mar_b10 mar_r30">
		<input type="button" value="支付" class="btn btn-next skin_btn_light" onclick="transferPay(this)"/>
	<div>
</div>
</script>
<script id="addPayAccTpl" type="text/html">
<div class="acc_add mar_l37">
	<form id="payAccForm">
		<table>
			<tr id="companyTr" >
				<td>公司名称：</td>
				<td>
					<!--<input type="text" id="addpay_companyName" value="" name="companyName" readonly/>-->
                    <select id="addPayAccCompanyInfo" ></select>
					<input type="hidden" name="type" value="0"/>
					<input type="hidden" name="customerId" value="<?php echo $userId?>"/>
					<input type="hidden" name="customerName" value="<?php echo $userName?>"/>
				</td>
			</tr>
			<tr>
				<td>付款账号名称：</td>
				<td>
					<input type="text" style="height:22px" class='w200 input-text' value="" name="accName"/>
				</td>
			</tr>
			<tr>
				<td>付款账号：</td>
				<td>
					<input type="text" style="height:22px" class='w200 input-text' value="" name="accNo" onkeyup="this.value=this.value.replace(/[^\d]/g,'')"/><span class="f1"> 请输入数字</span>
				</td>
			</tr>
		</table>
	</form>
</div>
</script>
<!-- 收款账户 -->
<script id="addRecAccTpl" type="text/html">
<div class="acc_add mar_l37">
<form id="recAccForm">
		<table class="">
			<input type="hidden" name="type" value="1"/>
			<tr>
				<td>公司名称：</td>
				<td>
					<select id="addRecAccCompanyInfo" disabled="true" onchange="addRecAccCompanyInfoEvent(this);"></select>
				</td>
			</tr>
			<tr>
				<td>供应商：</td>
				<td>
					<select id="addrec_recCustomer" name="customerId" disabled="true">
					</select>
				</td>
			</tr>
            <tr>
				<td>收款账号名称：</td>
				<td>
					<input type="text" style="height:22px" class='w200 input-text' value="" name="accName"/>
				</td>
			</tr>
			<tr>
				<td>收款账号：</td>
				<td>
					<input type="text" style="height:22px" class='w200 input-text' value="" name="accNo" onkeyup="this.value=this.value.replace(/[^\d]/g,'')"/><span class="f1"> 请输入数字</span>
				</td>
			</tr>
		</table>
</form>
</div>
</script>

