<div class="clear">
    <div class="cent-border clear" >
    	<div class="bg_td bb_tb pad10 h25 f7" id="paymentDetailDom">
    		<p class="fl_l f14">
				<span class="fw lin_h25">
					<?php echo iconv_substr($title, 0,1,'utf-8'); ?>款单号：<font class="f4 fw" id="paymentIdFont"></font>
				</span>
			</p>
    		<p class="fl_r f14" id="addAccDom">
				<span class="f1 fw lin_h25">
					<a href="javascript:;" onclick="openAddWin('addWindow')">添加账号</a>
				</span>
			</p>
		</div>
    	<div id='newPaymenDom' class="border-top skin-border">
		</div>
	</div>
</div>
<div class="clear"></div>
<?php 
	include_once 'jstpl/pay_tpl.php';
?>
<script src="<?php echo $root_path ?>~main/js/Utils.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>common/js/number.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo $root_path ?>modules/upsPaymentservice/js/paymentDetail.js"></script>
<script type="text/javascript">
	var paymentId = S3Params.getData("paymentId");
	$("#paymentIdFont").html(paymentId);
	$(document).ready(function(){
		renderData();
	});
</script>
