//上游供应商
var upPaymentlookUp_col = {
		paymentNo : {
			"class":"center",
			render : function(row, type, data, meta) {
				var content;
				if(data.status != "0"){
					content = '<a href="javascript:;" class="skin-color" onclick="jumpTo(&quot;'+data.paymentNo+'&quot;, 1, &quot;dibetNoteDetail&quot;);return false;">'+data.paymentNo+'</a>';
				}else{
					content = data.paymentNo;
				}
				return content;
			}
		},
		payAccName :　{
			data:"payAccName"
		},
		companyName :　{
			data:"companyName"
		},
		payAmt : {
			render : function(row, type, data, meta) {
				var payAmt = (data.payAmt == ""|| data.payAmt == undefined )? "":"￥"+addCommafy(data.payAmt);
				var content = "<div class='skin-color fw tex_c' id='payAmt_" + meta.row
				+ "' rid='" + meta.row + "'>" + payAmt
				+ "</div>";
				return content;
			}
		},
		payTime : {
			data:"payTime"
		},
		status : {
			render : function(row, type, data, meta) {
				var value = data.num > 0 ? paymentStatus[data.status] : paymentStatus[0];
				var content ="<div id='paymentStatus_"+meta.row+"'>"+value+"</div>";
				return content;
			}
		},
		transferStatus : {
			render : function(row, type, data, meta) {
				var value = data.num > 0 ? transferStatus.getTransferStatusValue(data.transferStatus) : "";
				var content ="<div id='transferStatus_"+meta.row+"'>"+value+"</div>";
				return content;
			}
		},
		operation : {
			render : function(row, type, data, meta) {
				var confirmBtn = '';
				if(data.orderStatus == 0){
					confirmBtn += '<a href="javascript:confirmPurOrderInfo(&quot;'+data.id+'&quot;)" class="btn_small skin_btn_light">确认</a>';
				}
				return confirmBtn;
			}
		},
		rd1 : {
			data : 'rd1'
		},
		rd2 : {
			data : 'rd2'
		},
		rd3 : {
			data : 'rd3'
		},
		rd4 : {
			data : 'rd4'
		},
		rd5 : {
			data : 'rd5'
		},
		rd6 : {
			data : 'rd6'
		},
		rd7 : {
			data : 'rd7'
		},
		rd8 : {
			data : 'rd8'
		},
		rd9 : {
			data : 'rd9'
		},
		rd10 : {
			data : 'rd10'
		},
		rd11 : {
			data : 'rd11'
		},
		rd12 : {
			data : 'rd12'
		},
		rd13 : {
			data : 'rd13'
		},
		rd14 : {
			data : 'rd14'
		},
		rd15 : {
			data : 'rd15'
		},
		rd16 : {
			data : 'rd16'
		},
		rd17 : {
			data : 'rd17'
		},
		rd18 : {
			data : 'rd18'
		},
		rd19 : {
			data : 'rd19'
		},
		rd20 : {
			data : 'rd20'
		},
		rd21 : {
			data : 'rd21'
		},
		rd22 : {
			data : 'rd22'
		},
		rd23 : {
			data : 'rd23'
		},
		rd24 : {
			data : 'rd24'
		},
		rd25 : {
			data : 'rd25'
		},
		rd26 : {
			data : 'rd26'
		},
		rd27 : {
			data : 'rd27'
		},
		rd28 : {
			data : 'rd28'
		},
		rd29 : {
			data : 'rd29'
		},
		rd30 : {
			data : 'rd30'
		}
};

//上游业务员
var upPaymentpayOff_col = {
		checkBox : {
			title : '<input type="checkbox" id="checkAllBox" name="allData" onclick="checkedObj.checkedAllData(this, &quot;oneData&quot;)">',
			render : function(row, type, data, meta) {
				var checkOne;
				if(data.status == "0"){
					checkOne = "<td>"
					+"<input type='checkbox'  name='oneData' data=&quot;"+data.paymentNo+"&quot; onclick='checkedObj.checkedOneData(this, &quot;allData&quot;)'>";
					+"</td>";
				}else{
					checkOne ="<td></td>";
				}
				return checkOne;
			}
		},
		paymentNo : {
			"class":"center",
			render : function(row, type, data, meta) {
				var content;
				if(data.status != "0"&&data.status != "3"){
					content = '<a href="javascript:;" class="skin-color" onclick="jumpTo(&quot;'+data.paymentNo+'&quot;, 1, &quot;uppaymentDetail&quot;);return false;">'+data.paymentNo+'</a>';
				}else{
					content = "<div class='skin-color'>"+data.paymentNo+"</div>";
				}
				return content;
			}
		},
		payAccName :　{
			data:"payAccName"
		},
		companyName :　{
			data:"companyName"
		},
		reciverName :　{
			data:"reciverName"
		},
		payAmt : {
			render : function(row, type, data, meta) {
				var payAmt = (data.payAmt == ""|| data.payAmt == undefined )? "":"￥"+addCommafy(data.payAmt);
				var content = "<div class='skin-color fw tex_c' id='payAmt_" + meta.row
				+ "' rid='" + meta.row + "'>" + payAmt
				+ "</div>";
				return content;
			}
		},
		status : {
			render : function(row, type, data, meta) {
				var value = paymentStatus[data.status] == undefined ? "":paymentStatus[data.status];
				var content ="<div id='paymentStatus_"+meta.row+"'>"+value+"</div>";
				return content;
			}
		},
		payTime : {
			data:"payTime"
		},
		transferStatus : {
			render : function(row, type, data, meta) {
				var value = data.num > 0 ?( transferStatus.getTransferStatusValue(data.transferStatus)== undefined ?"": transferStatus.getTransferStatusValue(data.transferStatus) ): "";
				var content ="<div id='transferStatus_"+meta.row+"'>"+value+"</div>";
				return content;
			}
		},
		operation : {
			render : function(row, type, data, meta) {
			 var oper = "";
             if(data.status == "0" ){//去掉“付款失败”状态的判断，只有“未付款”的付款单才可以支付。
                   if(data.isUpload!=null){
                     if(way=='1'){
                       if(data.isUpload=='0'){
                     	  oper = "<a href='javascript:jumpTo(&quot;"+data.paymentNo+"&quot;, 0, &quot;upPay&quot;,&quot;0&quot;);' class='btn_small skin_btn_light'>支付<a>";
                       		if(data.num>0){
                       			oper += " ";
    							oper += "<a href='javascript:financeWin(&quot;financeWindow&quot;,&quot;"+meta.row+"&quot;);' class='btn_small skin_btn_light'>支付指令<a>";	
							 }
						}else{
							oper = "<a href='javascript:jumpTo(&quot;"+data.paymentNo+"&quot;, 0, &quot;upPay&quot;,&quot;"+data.isUpload+"&quot;);' class='btn_small skin_btn_light'>还款<a>";
                       }
                     }else if(way=='2'){
                        if(data.isUpload=='0'){
                       	  oper = "<a href='javascript:jumpTo(&quot;"+data.paymentNo+"&quot;, 0, &quot;upPay&quot;,&quot;"+data.isUpload+"&quot;);' class='btn_small skin_btn_light'>支付<a>";
							 if(data.num>0){
								oper += " ";
	    						oper += " <a href='javascript:financeWin(&quot;financeWindow&quot;,&quot;"+meta.row+"&quot;);' class='btn_small skin_btn_light'>支付指令<a>";	
							 }
                        }else{
                        	oper = "<a href='javascript:jumpTo(&quot;"+data.paymentNo+"&quot;, 0, &quot;upPay&quot;,&quot;"+data.isUpload+"&quot;);' class='btn_small skin_btn_light'>还款<a>";
                        }
                     }else if(way=='3'){
                         if(data.isUpload=='0'){
                        	  oper = "<a href='javascript:jumpTo(&quot;"+data.paymentNo+"&quot;, 0, &quot;upPay&quot;,&quot;"+data.isUpload+"&quot;);' class='btn_small skin_btn_light'>支付<a>";
                         	if(data.num>0){
                         		oper += " ";
	    						oper += " <a href='javascript:financeWin(&quot;financeWindow&quot;,&quot;"+meta.row+"&quot;);' class='btn_small skin_btn_light'>支付指令<a>";	
							 }
						 }else{
	                        	oper = "<a href='javascript:jumpTo(&quot;"+data.paymentNo+"&quot;, 0, &quot;upPay&quot;,&quot;"+data.isUpload+"&quot;);' class='btn_small skin_btn_light'>还款<a>";
                         }
                      }else if(way=='4'){
                      	oper = "<a href='javascript:jumpTo(&quot;"+data.paymentNo+"&quot;, 0, &quot;upPay&quot;,&quot;"+data.isUpload+"&quot;);' class='btn_small skin_btn_light'>还款<a>";
                      }
                  }else{
                	  oper = "<a href='javascript:jumpTo(&quot;"+data.paymentNo+"&quot;, 0, &quot;upPay&quot;,&quot;0&quot;);' class='btn_small skin_btn_light'>支付<a>";
					   if(data.num>0){
						    oper += " ";
							oper += "<a href='javascript:financeWin(&quot;financeWindow&quot;,&quot;"+meta.row+"&quot;);' class='btn_small skin_btn_dark'>支付指令<a>";	
					   }
                  }
             }else{
				oper = "<a href='javascript:financeWin(&quot;financeWindow&quot;,&quot;"+meta.row+"&quot;);' class='btn_small skin_btn_dark'>支付指令<a>";	
			 }
				
				return oper;
			}
		},
		rd1 : {
			data : 'rd1'
		},
		rd2 : {
			data : 'rd2'
		},
		rd3 : {
			data : 'rd3'
		},
		rd4 : {
			data : 'rd4'
		},
		rd5 : {
			data : 'rd5'
		},
		rd6 : {
			data : 'rd6'
		},
		rd7 : {
			data : 'rd7'
		},
		rd8 : {
			data : 'rd8'
		},
		rd9 : {
			data : 'rd9'
		},
		rd10 : {
			data : 'rd10'
		},
		rd11 : {
			data : 'rd11'
		},
		rd12 : {
			data : 'rd12'
		},
		rd13 : {
			data : 'rd13'
		},
		rd14 : {
			data : 'rd14'
		},
		rd15 : {
			data : 'rd15'
		},
		rd16 : {
			data : 'rd16'
		},
		rd17 : {
			data : 'rd17'
		},
		rd18 : {
			data : 'rd18'
		},
		rd19 : {
			data : 'rd19'
		},
		rd20 : {
			data : 'rd20'
		},
		rd21 : {
			data : 'rd21'
		},
		rd22 : {
			data : 'rd22'
		},
		rd23 : {
			data : 'rd23'
		},
		rd24 : {
			data : 'rd24'
		},
		rd25 : {
			data : 'rd25'
		},
		rd26 : {
			data : 'rd26'
		},
		rd27 : {
			data : 'rd27'
		},
		rd28 : {
			data : 'rd28'
		},
		rd29 : {
			data : 'rd29'
		},
		rd30 : {
			data : 'rd30'
		}
};