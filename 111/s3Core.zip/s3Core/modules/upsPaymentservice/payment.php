<?php 
	$para["module"] = 'uppayment';
	$para["subModule"] = 'paymentlist';
	$retMap=execjava('basicConfigBean.getResourceUrl', $para, "php");
	$paymentNoUrl = $retMap["paymentNo"];
	$paymentNoType = $retMap["paymentNoType"];
	
	$para["module"] = 'myDibetNote';
	$para["subModule"] = 'dibetList';
	$retMap=execjava('basicConfigBean.getResourceUrl', $para, "php");
	$dibetNoUrl = $retMap["dibetNo"];
	$dibetNoType = $retMap["dibetNoType"];
	
?>
<input type='hidden', value='<?php echo $id?>' id='currentRoleId'/>
<form id="paymentDetailForm" action="" method="post" target="_blank">
	<input type="hidden" id="paymentId" name="paymentId" value=""/>
	<input type="hidden" id="showFlag" name="flag" value=""/>
	<input type="hidden" id="way" name="way" value=""/>
	<input type="hidden" id="isUpload" name="isUpload" value=""/>
</form>
<!-- 我的付款单开始 -->
<div class="right skin-border">
	<div class="cent-border">
    	<div class="title-side">
    		<i class="iconfont icon-sousuo skin-color"></i> 
    		请选择筛选条件:
    	</div>	    		
  		<div class="condit2" id="paymentSearchDom">
		</div>
			<!--标题栏-->
		<div class="title-inner clear">
			<span><i style="left:-2px;top:1px;" class="iconfont icon-zhangdan skin-color"></i><?php echo $title; ?></span>
			
		</div>
		<!--付款单列表-->
		<!--付款单table栏-->
		<div id="mypayment_table" >
		</div>
		<!-- 页码显示模块 -->
		<p class="page" id="pager" ></p>
		<div class="clear"></div>
	</div>
</div>
<!-- 我的付款单结束 -->
<!-- 付款单指令历史弹窗 Start -->
<div id="fullbg" class="pop_shadow"></div>
<div class="popupsty pop_window_box w500" id="financeWindow" style="top:35%;">
		<div class="pop_window_title">
			<i></i>付款单指令历史
			<span><a href="javascript:closeBg('financeWindow');">×</a></span>
		</div>
		<div  id="contentBody">
	      	<div id="paymentDetailListDom"></div>
	    </div>
	</div>
<!-- 付款单指令历史弹窗 End -->
<?php include_once 'jstpl/payment_tpl.php';?>
<?php require_once 'inc/PropConfig.class.php';?>
<script src="<?php echo $root_path ?>~main/js/Utils.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>common/js/number.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/upsPaymentservice/js/payment.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/upsPaymentservice/config/payment_data.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>~main/config/s3Core/upsPaymentService_col.js" type="text/javascript"></script>
<script type="text/javascript">
	/**
	 * 工银聚付款模式：1：企业ERP根据贷款状态分别付款 2：企业不区分贷款状态，逐笔付款且同意修改收款账户 
	 * 3：企业不区分贷款状态，逐笔付款且不同意修改收款账户 4：企业不区分贷款状态，一笔付款对应多张发票
	 */
	var way="<?php echo PropConfig::getDefaultValue("refundMode");?>";
	//var way=2;
	var paymentNoUrl = "<?php echo $paymentNoUrl?>";
	var paymentNoType = "<?php echo $paymentNoType?>";
	var dibetNoUrl = "<?php echo $dibetNoUrl?>";
	var dibetNoType = "<?php echo $dibetNoType?>";
	$(document).ready(function(){
		pageInitialize();
		//$("#checkAll").click(checkAll);
		//$("#multipayment").bind('onclick',function(){multiPay()});
		
	});
</script>




