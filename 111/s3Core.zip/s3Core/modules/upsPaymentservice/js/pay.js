template.openTag = "<%";
template.closeTag = "%>";
//上游保理服务
var factoringservice = "factoringservice";
var content=new Array();
var getAccinFo;
var isdispaly={};
var falgForNull={};
var flagForInsert={};
var resubmit = true;
/**
 * 查询类型，0-支付类型发票  1-还款类型发票
 */
var type = 0;
var limit = 5;
/**
 * 页面上付款单个数
 */
var payCount=0;
//isHasBranchCompany=false;

function renderData1(){
	var paymnetNoArray=S3Params.getData("paymentId");
	var paymnetNoArray1=paymnetNoArray.split(',');
	payCount=paymnetNoArray1.length;
	for(var i=0;i<payCount;i++){
		renderData(paymnetNoArray1[i],i);
	}
	//$("#newPaymenDom1").html(content);
	var way=S3Params.getData("way");
	var isUpload=S3Params.getData("isUpload");
   // $("#payButton").unbind('click');
    switch (way){
    case "1":
    	if(isUpload=="1"){
			$("#payButton").bind('click',function (){shouldPay(this)});//绑定支付事件
		}else if(isUpload=="0"){
			$("#payButton").bind('click',function(){mergePay(this)});
		}
		break;
    case "2":
    	if(isUpload=="1"){
    		$("#payButton").bind('click',function (){shouldPay(this)});//绑定支付事件
		}else if(isUpload=="0"){
			$("#payButton").bind('click',function (){transferPay(this)});//绑定支付事件
		}
		break;
    case "3":
    	if(isUpload=="1"){
    		$("#payButton").bind('click',function (){shouldPay(this)});//绑定支付事件
		}else if(isUpload=="0"){
			$("#payButton").bind('click',function (){transferPay(this)});//绑定支付事件
		}
		break;
    case "4":
    	$("#payButton").bind('click',function (){transferPay(this)});//绑定支付事件
		break;
    }
    
}
/**
 * 数据渲染
 */
function renderData(paymnetNo,i){
	/*
	 * 工银聚付款模式：1：企业ERP根据贷款状态分别付款 2：企业不区分贷款状态，逐笔付款且同意修改收款账户 
	 * 3：企业不区分贷款状态，逐笔付款且不同意修改收款账户 4：企业不区分贷款状态，一笔付款对应多张发票
	 */
	var way=S3Params.getData("way");
    /* 
     * 是否是上传到总行 0-未上传，1-已经上传
     */
    var isUpload=S3Params.getData("isUpload");
    $("#payButton").unbind('click');
	switch (way) {
	case "1"://1：企业ERP根据贷款状态分别付款
		if(isUpload=="1"){//以上传到总行的
			var result = getPaymentDetail(paymnetNo);
			// 获取分公司数据
			renderPayData("payDetailTpl", result.paymentList[0],paymnetNo,i);
			setPayPageValue(result.paymentList[0],false);
			//应付账款付款接口
			//$("#payButton").bind('click',function (){shouldPay(this)});//绑定支付事件
		}else if(isUpload=="0"){//未上传到总行的 合并付款
			var result = getPaymentDetail(paymnetNo);
			renderPayData("mergePayTpl",result.paymentList[0],paymnetNo,i);
			setPayPageValue(result.paymentList[0],false);
			//console.log(JSON.stringify(result));
			//$("#payButton").bind('click',function(){mergePay(this)});
		}
		break;
	case "2"://2：企业不区分贷款状态，逐笔付款且同意修改收款账户 
		if(isUpload=="1"){//以上传到总行的
			var result = getPaymentDetail(paymnetNo);
			// 获取供应商数据
			renderPayData("payDetailTpl", result.paymentList[0],paymnetNo,i);
			setPayPageValue(result.paymentList[0],true);
			//$("#payButton").bind('click',function (){shouldPay(this)});//绑定支付事件
		}else if(isUpload=="0"){//未上传到总行的
			var result = getPaymentDetail(paymnetNo);
			// 获取供应商数据
			renderPayData("payDetailTpl", result.paymentList[0],paymnetNo,i);
			setPayPageValue(result.paymentList[0],false,i);
			//$("#payButton").bind('click',function (){transferPay(this)});//绑定支付事件
		}
		break;
	case "3"://3：企业不区分贷款状态，逐笔付款且不同意修改收款账户
	    if(isUpload=="1"){//以上传到总行的
	    	var result = getPaymentDetail(paymnetNo);
			// 获取供应商数据
			renderPayData("payDetailTpl", result.paymentList[0],paymnetNo,i);
			setPayPageValue(result.paymentList[0],false);
			//应付账款付款接口
			//$("#payButton").bind('click',function (){shouldPay(this)});//绑定支付事件
		}else if(isUpload=="0"){//未上传到总行的
			var result = getPaymentDetail(paymnetNo);
			// 获取供应商数据
			renderPayData("payDetailTpl", result.paymentList[0],paymnetNo,i);
			setPayPageValue(result.paymentList[0],false);
			//$("#payButton").bind('click',function (){transferPay(this)});//绑定支付事件
		}
		break;
	case "4"://4：企业不区分贷款状态，一笔付款对应多张发票
	    //按照3未上传到总行处理
		var result = getPaymentDetail(paymnetNo);
		// 获取供应商数据
		renderPayData("payDetailTpl", result.paymentList[0],paymnetNo,i);
		setPayPageValue(result.paymentList[0],false);
		//$("#payButton").bind('click',function (){transferPay(this)});//绑定支付事件
		//发送短信通知
		break;
	}
	/**
	 * 判断是否显示分公司：isHasBranchCompany 【该变量定义在： "~main/config/data.js"】
	 * true：表示存在
	 * false：表示没有分公司，只有一个核心企业
	 */
	if(isHasBranchCompany){
		$("#companyInfoLi").css("display","block");
	}else{
		$("#companyInfoLi").css("display","none");
	}
}
/**
 * 有付款单页面显示值设置值 如果账号不在账号信息里不显示
 */
function setPayPageValue_(payment,isSupervision){
	if(isHasBranchCompany){
		getBranchCompany(payment.companyId);
	}
	//加载供应商信息
	getCustomerInfo(payment.reciverId);
	// 获取付款账户信息
	getPayerAccInfo(payment.payAccNo);
	// 加载收款账户信息
	isSupervision? getSupervisionAccount(payment.reciverId):renderRecAccInfo(getRecAccInfo(payment.reciverId),payment.recAccNo);
	$("#handleWay").hide();
	$("#insideAndOutside").hide();
	$("#PublicAndPrivate").hide();
}

/**
 * 有付款单页面显示值设置值
 */
function setPayPageValue(payment,isSupervision,i){
	//加载分公司,isHasBranchCompany的值在【~main/config/data.js】中，默认情况下此值为false
	if(isHasBranchCompany){
		getBranchCompany(payment.companyId,i);
		if(payment.companyId){
			var $select = $("#companyInfoSelect_"+i);
			var option = makeOption(null,payment.companyId,payment.companyName,true);
			$select.attr("disabled","disabled");
			$select.append(option);
		}else{
			getBranchCompany();
		}
	}
	//加载供应商信息
	if(payment.reciverId){
		var $select = $("#supplierNameSelect_"+i);
		var option = makeOption(null,payment.reciverId,payment.reciverName,true);
		$select.attr("disabled","disabled");
		$select.append(option);
	}else{
		//$("#supplierNameSelect").removeAttr("disabled");
		getCustomerInfo(i);
	}
	//加载付款账户
	if(payment.payAccNo){
		var $selectName = $("#payAccountName_"+i);
		var option = makeOption(null,payment.payAccNo,payment.payAccName,true);
		$selectName.attr("disabled","disabled");
		$selectName.append(option);
		var $selectNo = $("#payAccountNo_"+i);
		var option1 = makeOption(null,payment.payAccNo,payment.payAccNo,true);
		$selectNo.attr("disabled","disabled");
		$selectNo.append(option1);
	}else{
		getPayerAccInfo(i);
	}
	// 加载收款账户信息
	if (isSupervision) {//是否将收款账户调换成监管账户
		getSupervisionAccount(payment.reciverId)
	} else {
		if (payment.recAccNo) {
			var $selectNo = $("#recAccNo_"+i);
			var option = makeOption(null, payment.recAccNo, payment.recAccNo,true);
			$selectNo.attr("disabled", "disabled");
			$selectNo.append(option);
			var $selectName = $("#recAccName_"+i);
			var option1 = makeOption(null, payment.recAccNo,payment.recAccName, true);
			$selectName.attr("disabled", "disabled");
			$selectName.append(option1);
			$("#inputrecAccNo_"+i).hide();
			//$('#inputrecAccNo_'+i).val(payment.recAccNo);
			autoReceivingInfo(payment.recAccNo,i);
		} else {
			var index='index'+i;
			isdispaly.index='1';
			renderRecAccInfo(getRecAccInfo(payment.reciverId,payment.recAccName,i), payment.recAccNo,payment.recAccName,i);
		}
	}
	//金额
	if(payment.payAmt!=null&&payment.payAmt!=""){
		$("input[name=payAmt_"+i+"]").val(payment.payAmt);
	}
	//对公对私标志
	if(payment.isPub!=null&&payment.isPub!=""){
		$("input[name=isPub_"+i+"][type='radio'][value="+payment.isPub+"]").attr("checked","checked");
		$("input[name=isPub_"+i+"][type='radio'][value="+0+"]").attr("disabled","disabled");
		$("input[name=isPub_"+i+"][type='radio'][value="+1+"]").attr("disabled","disabled");
	}
	//系统内外
	if(payment.recAccNo&&payment.sysIOFlg!=null&&payment.sysIOFlg!=""){
		$("input[name=sysIOFlg_"+i+"][type='radio'][value= "+payment.sysIOFlg+"]").attr("checked","checked");
		$("input[name=sysIOFlg_"+i+"][type='radio'][value=2]").attr("disabled","disabled");
		$("input[name=sysIOFlg_"+i+"][type='radio'][value=1]").attr("disabled","disabled");
		//系统外
		if(payment.sysIOFlg=="2"){	
			//银行名称
			if(payment.recBankName&&payment.recBankNo){
				//获取参数时候  走手工输入
				$("input[name=recordType_"+i+"][type='radio'][value='1']").attr("checked","checked");
				$("#ReceiveCityName_"+i).show();
				$("#InputRecordType_"+i).show();
				$("#recCityName_"+i).val(payment.recCityName?payment.recCityName:"");
				$("#inputBankName_"+i).val(payment.recBankName);//银行名称
				$("#branchBankNoSelect_"+i).append(makeOption("ii3",payment.recBankNo,"",true));//银行账号
				$("#RecordType_"+i).hide();
				$("#recCityName_"+i).attr("disabled","disabled");
				$("#inputBankName_"+i).attr("disabled","disabled");
			}else{
				//设置级联查询
				$("input:radio[name='recordType_"+i+"']").eq('0').prop("checked", true);
				$("#BankList_"+i).show();
				$("#BankBranchList_"+i).show();
				$("#RecordType_"+i).show();
				$("#ReceiveCityName_"+i).show();
				$("#InputRecordType_"+i).hide();
				getBankBrankList(i);
			}
		}else if(payment.sysIOFlg=="1"){//系统内
			$("#BankList_"+i).hide();
			$("#BankBranchList_"+i).hide();
			$("#RecordType_"+i).hide();
			$("#ReceiveCityName_"+i).hide();
			$("#InputRecordType_"+i).hide();
		}
	}
	//设置备注
	if(payment.postScript!=null&&payment.postScript!=""){
		$("#payNote_"+i).val(payment.postScript);
		//$("#payNote").attr("disabled","disabled");
	}
}

function makeOption(id,value,html,isSelected){
	var $option = $("<option>");
	value&&$option.attr("value", value);
	id&&$option.attr("id", value);
	html&&$option.html(html);
	isSelected&&$option.attr("selected",true);;
	$option.append('</option>');
	return $option;
}

/************************************转账支付 begin****************************************/
/**
 * 合并付款
 */
function mergePay(obj){
	var params=getPayParam();
	if(typeof params =="undefined"){
		return;
	}
	var  purinvoiceNoMuster=$("#choosePurinvoiceNo").html();
	var purinvoiceNos=purinvoiceNoMuster.split(",")
	if(purinvoiceNos.length<1){
		alert("请选择发票");
		return;
	}
//    for(var key in paymentNos){
//    	params.paymentNo=paymentNos[key];
    var result = execjava("upPaymentBean.doTransferPay", params, 'json');
//    	if(!result || result.status != "000"){
//    		alert("转账失败！");
//    	}
//    }
//	alert(JSON.stringify(params));
}

/**
 * 支付  支付指令提交接口
 */
function transferPay(obj){
	
	//防止重复多次点击，2秒钟之内不能重复调用
	if(resubmit == true){
		resubmit = false;
		window.setTimeout(function(){
			resubmit = true;
		},2000);
	}else{
		return;
	}
	
	var params={};
	var payparams=[];
	//var payparams1=[];
	var payparams1=[];
	for(var i=0;i<payCount;i++){
		var index='index'+i;
		var param=getPayParam(i);
		payparams.push(param);	
//		if(falgForNull.index=='1'){
//			payparams1.push(param);
//		}
		
		if(isdispaly.index=='1'){
			payparams1.push(param);
		}
	}
	//params.payParamsArray=payparams;
//	var result = execjava("factoringBean.transfer", params, 'json', factoringservice);
	if(typeof payparams =="undefined"){
		return;
	}
//	console.log(JSON.stringify(params));
//	return;
	
//	if(!$.isEmptyObject(payparams1)){
//		var result = execjava("upPaymentBean.updateRecAccNoInfo", payparams1, 'json');
//		if(!result || result.retCode != "200"){
//			alert("更新账号信息失败！");
//		}
//	}
	
	if(!$.isEmptyObject(payparams1)){
		var result = execjava("upPaymentBean.insertRecAccNoInfo", payparams1, 'json');
		if(!result || result.retCode != "200"){
			alert("插入账号信息失败！");
		}
	}
	var result = execjava("upPaymentBean.doTransferPay", payparams, 'json');
	if(!result || result.retCode != "200"){
		if(result.retCode == "500"){
			//重复点击的情况
			alert("当前操作频率过快，请稍后重试！");
		}else{
			alert(result.retmsg);
		}		
		return;
	}
	
//	 0-未付款 1-待确认  2-已付款  3-付款失败
	if(result&&result.paymentStatus){
		if(result.paymentStatus=="2"){
			alert("付款成功");
		}else{
			alert(result.retmsg);
		}
	}
	obj.disabled = true;
	obj.onclick = null;
	obj.style.cursor = "text";
	obj.className = "btn btn-disabled";
}
/**
 * 支付1 应付账款付款接口
 */
function shouldPay(obj){
	var params=getPayParam();
	if(typeof params =="undefined"){
		return;
	}
	// 调用保理服务后台
	var result = execjava("upPaymentBean.doPay", params, 'json');
	if(!result){
		alert("转账失败！");
		return;
	}
	obj.disabled = true;
	obj.onclick = null;
	obj.style.cursor = "text";
	obj.className = "btn btn-disabled"
}

function getPayParam(i){
	var customerId = $("#supplierNameSelect_"+i).val();
	if(!customerId){
		alert("请选择供应商");
		return;
	}
	var payType = $("input:radio[name='payType_"+i+"']:checked").val(),// 转账处理方式
		payAccName = $("#payAccountName_"+i+" option:selected").text(),// 本方账号名称
		payAccNo = $("#payAccountNo_"+i).val(),//本方账号
		recAccName = $("#recAccName_"+i+" option:selected").text(),// 对方账号名称
		
		sysIOFlag = $("input:radio[name='sysIOFlg_"+i+"']:checked").val(),//系统内外标记
		isPub = $("input:radio[name='isPub_"+i+"']:checked").val(),// 对公对私标记
		branchBankNo = "",//银行编号
		inputBankNam = "",// 手动录入的银行名称
		payAmt = $("#payAmount_"+i).val(),//付款金额
		note = $("#payNote_"+i).val();//备注
	if($("#inputrecAccNo_"+i).css("display")=='none'){
		var recAccNo = $("#recAccNo_"+i).val();// 对方账号
	}else{
		var recAccNo=$("#inputrecAccNo_"+i).val();
	}
	var params = {};
	// 判断分公司
	if(isHasBranchCompany){
		var companyId = $("#companyInfoSelect_"+i).val();		
		var companyName = $("#companyInfoSelect_"+i+" option:selected").text();
		if(!companyId){
			params.companyId = getCustId();
			params.companyName = currentCompanyName;
		}else{
			params.companyId = companyId;
			params.companyName = companyName;
		}
		
	}else{
		params.companyId = getCustId();
		params.companyName = currentCompanyName;	
	}
	// 记账处理方式
	if(payType == ""){
		alert("请选择转账处理方式");
		return;
	}
	if(payAccName == ""){
		alert("请输入本方账号名称");
		return;
	}
	if(payAccNo == ""){
		alert("请输入本方账号");
		return;
	}
	if(recAccName == ""){
		alert("请输入对方账号名称");
		return;
	}
	if(recAccNo == ""){
		alert("请输入对方账号");
		return;
	}
	
	/**
	 * 判断系统内外标记：
	 * 如果是系统外，则需要判断是否选择或输入相关的行号和行名
	 */	
	if(sysIOFlag === "2"){
		// 获取录入方式
		var recordType = $("input:radio[name='recordType_"+i+"']:checked").val();
		var recCityName = $("#recCityName_"+i).val();
		if(recCityName == ""){
			alert("请输入收款方所在城市名称！");
			return;
		}
		params.recCityName = recCityName;
		if(recordType === "0"){
			branchBankNo = $("#branchBankNoSelect_"+i).val();
			if(!branchBankNo){
				alert("请选择收款人账户所属银行！");
				return;
			}
			params.recBankNo = branchBankNo;
			params.recBankName = $("#branchBankNoSelect_"+i+" option:selected").text();
		}else{
			inputBankNam = $("#inputBankName_"+i).val();
			if(inputBankNam == "" || inputBankNam.trim() == ""){
				alert("请输入收款人账户所属银行！");
				return;
			}
			branchBankNo = $("#branchBankNoSelect_"+i).val();
			if(branchBankNo)
			params.recBankNo = branchBankNo;
			params.recBankName = inputBankNam;
		}
	}
	/**
	 * 判断金额输入问题
	 */
	var reg = /^\d+(\.\d{0,2})?$/
	if(!reg.test(payAmt)){
		alert("付款金额输入有误，请输入数字！");
		$("#payAmount_"+i).focus().select();
		return;
	}
	/**
	 * 填充数据
	 */
	params.payerId = currentCustomerId;
	params.payerName = currentUserName;
	params.payAccName = payAccName;
	params.payAccNo = payAccNo;
	params.reciverId = customerId;
	params.reciverName = $("#supplierNameSelect_"+i+" option:selected").text();
	params.recAccName = recAccName;
	params.recAccNo = recAccNo;
	params.sysIOFlag = sysIOFlag;
	params.paymentNo = S3Params.getData("paymentId").split(",")[i];
	params.payAmt = payAmt;
	params.isPub = isPub;
	params.payType = payType;
	params.currType = $("input:radio[name='currType_"+i+"']:checked").val();
	params.postScript = note;
	
//	console.info(params);
	return params;
}
//-----------------合并付款 begin-------
function choosePurinvoice(){
	searchPurinvoiceInfoList(1);
	showBg("choosePurinvoiceWindow");
}
function choosePurinvoiceAffirm(){
	var checkedPurinvoice=checkedObj.getData();
	if(checkedPurinvoice.length === 0){
 		alert("请至少选择一条发票！");
 		return;
 	}
	var tempNo=$.map(checkedPurinvoice,function(n,t){
	    return n.split("_")[0];
	}); 
	$("#choosePurinvoiceNo").html(tempNo.toString());
	var tempPayAmt=$.map(checkedPurinvoice,function(n,t){
		return n.split("_")[1].replace(/,/g,"");
	}); 
	var total=0;
	for(var key in tempPayAmt){
		total=accAdd(total,tempPayAmt[key]);
	}
	$("#payAmount").val(total);
	closeAddWin('choosePurinvoiceWindow');
}

/**
 * 付款单查询列表
 * 
 * @param page 页码
 * @param paymentStatus 付款单状态
 */
function searchPurinvoiceInfoList(page, invoiceStatus, factringStatus){
	var limit=5;
	if(!page){
		page = 1;
	}
	var params = Utils.form2json("#keySearchForm",false);
	params.page = page;
	params.limit = limit;
	/**
	 * queryType，查询类型，根据当前用户角色判断并赋值
	 * 0-供应商查询，查询登录用户的发票，对应的角色为供应商，即角色ID为：11
	 * 1-核心企业查询，查询所有符合条件发票，对应的角色为供应商，即角色ID为：12
	 */
	params.queryType = 1;
	// 页面视图  0发票视图
	params.viewType = 0;
	// 融资状态
	params.factoringStatus = factringStatus;
	// 发票状态
	params.purchaseStatus = invoiceStatus;
	var result = execjava("factoringBean.purchaseListQuery", params, 'json', factoringservice);
	if( !result || result.retCode != "200"){
		var uri = getContextPath("~main/errorInfo.php");
			uri += "?retmsg=" + encodeURIComponent("发票数据获取异常！");
			uri += "&retpage=" + getContextPath("~main/main.php");
		window.location.href = uri;
		return;
	}
	var total = parseInt(result.total,10);
	var pageTotal = parseInt((total + limit - 1) /limit);// 总页数
	// 分页
	$("#choosePurinvoicePage").pager({
		pagecount : pageTotal,
		pagenumber : page,
		buttonClickCallback : function(pageclickednumber) {
			searchPurinvoiceInfoList(pageclickednumber,invoiceStatus);
		}
	});
	var nimabi=result.purchaseList;
	//渲染表格
	var html = template.render('mergePurinvoiceTpl',{
		limit : limit,
		purchaseList : result.purchaseList,
		checkedPurchase :checkedObj.getData()
	});
	$("#choosePurinvoiceDom").html(html);
}

//--------------合并付款 end------


/**
 * 获取付款单及供应商相关数据
 * 
 * @returns	result对象，包含下列数据：</br>
 * 			result.retCode  返回码，200-查询成功  999-查询失败</br>
 * 			result.retMsg   返回信息</br>
 * 			result.paymentList  查询的付款单列表
 */
function getPaymentDetail(paymentNo){
	var params = {
		"equalsPaymentNo" : paymentNo,
		"queryType":1
	}
	var result = execjava("upPaymentBean.paymentDetailListQuery", params, 'json');
//	if(result.paymentList[0].recAccName==null || result.paymentList[0].recAccName==""){
//		alert("付款单中没有收款人账户名，无法进行付款！");
//		return;
//	}
	var reciverId=result.paymentList[0].reciverId;
	var reciverName=result.paymentList[0].reciverName;
	var companyId=result.paymentList[0].companyId;
	var companyName=result.paymentList[0].companyName;
	//处理名称为空的问题
	//reciverId不为空并且reciverName为空的情况下成立
	if(reciverId&&!reciverName){
		var date1 = execjava("upPaymentBean.getCustomerNameByCustomerId", {'customerId':reciverId}, 'json');
		result.paymentList[0].reciverName=date1.userName;
	}
	//isHasBranchCompany的值为true，并且companyId不为空，companyName为空时成立
	if(isHasBranchCompany&&companyId&&!companyName){
		var date2 = execjava("upPaymentBean.getCompanyNameByCompanyId", {'companyId':companyId}, 'json');
		result.paymentList[0].companyName=date2.companyName;
	}
	return result;
}

/****************************************支付功能************************************/

/**
 *  支付时，相应的事件及页面加载
 *  @param tplId:对应的模板id
 */
function renderPayData(tplId, result,paymnetNo,i){
	if(typeof result != "undefined"){
		result.payAmt = EToString(result.payAmt);
	}
	$("#newPaymenDom1").append(template.render(tplId,{
		result : result,
		paymnetNo:paymnetNo,
		i:i
		})		
	);
	
	//给手动输入收款账号的input框添加监听事件
	$('#inputrecAccNo_'+i).bind('input propertychange',function(){
		//$("#recAccNo_"+i).find
		//$("select[id='recAccNo_'"+i+"] option:selected").removeAttr("");
		$("#recAccNo_"+i).find('option:eq(0)').attr('selected','selected');
		autoReceivingInfo($(this).val(),i,'propertychange');
	});
	/**
	 * 系统内外单击事件
	 */
	//var sysIOFlgi="sysIOFlg_"+i;
	$("input[name='sysIOFlg_"+i+"']").bind("click", function(){
		if(this.value === "1"){
			$("#BankList_"+i).hide();
			$("#BankBranchList_"+i).hide();
			$("#RecordType_"+i).hide();
			$("#ReceiveCityName_"+i).hide();
			$("#InputRecordType_"+i).hide();
		}else{
			$("#BankList_"+i).show();
			$("#BankBranchList_"+i).show();
			$("#RecordType_"+i).show();
			$("#ReceiveCityName_"+i).show();
			$("#InputRecordType_"+i).hide();
			$("input:radio[name='recordType_"+i+"']").eq('0').prop("checked", true);
			getBankBrankList(i);
		}
	});
	/**
	 * 录入方式点击事件
	 */
	$("input[name='recordType_"+i+"']").bind("click", function(){
		if(this.value === "1"){
			$("#BankList_"+i).hide();
			$("#BankBranchList_"+i).hide();
			$("#InputRecordType_"+i).show();
		}else{
			$("#BankList_"+i).show();
			$("#BankBranchList_"+i).show();
			$("#InputRecordType_"+i).hide();
			$("#inputBankName_"+i).val("");//银行名称
			$("#branchBankNoSelect_"+i).html("");
			getBankBrankList(i);
		}
	});
}

/**
 * 获取分公司数据
 */
function getBranchCompany(data,i){
	var result = execjava("companyInfoBean.getBranchCompanyInfo",null,'json');
	if(!result || result.status != '000'){
		alert("分公司信息获取失败");
		return;
	}
	var branchCompany = result.branchCompany;
	var companyId = data;
	
	var $select = $("#companyInfoSelect_"+i);
	$select.append("<option value=''>请选择分公司</option>");
	for(var i = 0,len=branchCompany.length; i<len; i++){
		var $option = $("<option>");
		$option.attr("value", branchCompany[i].companyId);
		$option.html(branchCompany[i].companyName);
		if(companyId == branchCompany[i].companyId){
			$option.attr("selected",true);
		}
		$option.append('</option>');
		$select.append($option);
	}
}


function makeOption(id,value,html,isSelected){
	var $option = $("<option>");
	value&&$option.attr("value", value);
	id&&$option.attr("id", value);
	html&&$option.html(html);
	isSelected&&$option.attr("selected",true);;
	$option.append('</option>');
	return $option;
}

/**
 * 获取所有的供应商信息
 */
function getCustomerInfo(i,data){
	$("#supplierNameSelect_"+i).html('');
	var params = getParams(i,data);
	/**
	 * result：
	 * retCode  返回码，200-支付成功  999-支付失败
	 * retMsg   返回信息
	 * recAccNoList  查询返回的收款账户信息列表，List<AccountEntity>
	 */
	var result = execjava("factoringBean.recAccInfoQuery", params, 'json', factoringservice);
	if(!result || result.retCode != '200'){
		alert("供应商信息获取失败");
		return;
	}
	var customerList = result.recAccNoList;
	renderCustomerData(customerList, data,i);
}

/**
 * 渲染数据
 * 
 * @param customerList 数据集合
 * @param data	选择的供应商
 */
function renderCustomerData(customerList, data,i){
	if(customerList == null){
		return;
	}
	var $select = $("#supplierNameSelect_"+i);
	$("#supplierNameSelect_"+i).html('');
	$select.append("<option value=''>请选择供应商</option>");
	/**
	 * 这里查询的数据的时根据分公司查询到跟该分公司关联的所有收款账号，一个供应商可能存在多个收款账户的问题，所有这里要去除重复的数据
	 * 存储对应的供应商编号（customerId），用于去除重复的数据:
	 */
	var removeRepeat = [];
	for(var i = 0,len=customerList.length; i<len; i++){
		var $option = $("<option>");
		if(customerList[i].hasOwnProperty("customerId")){
			if(removeRepeat.indexOf(customerList[i].customerId) > -1){
				continue;
			}
			removeRepeat.push(customerList[i].customerId);
			$option.attr("value", customerList[i].customerId);
			if(data == customerList[i].customerId){
				$option.attr("selected", true);
			}
			$option.html(customerList[i].customerName);
		}else{
			if(removeRepeat.indexOf(customerList[i].reciverId) > -1){
				continue;
			}
			removeRepeat.push(customerList[i].reciverId);
			$option.attr("value", customerList[i].reciverId);
			if(data == customerList[i].reciverId){
				$option.attr("selected", true);
			}
			$option.html(customerList[i].reciverName);
		}
		$option.append('</option>');
		$select.append($option);
	}
	removeRepeat=[];
}
///**
// * 切换供应商时，相应的收款账号（即页面上的对方账号）将进行变化；
// * @param obj
// */
//function showRecAcc(obj){
//	$("#recAccNo").html('');
//	$("#recAccName").html('');
//	var value = obj.value;
//	if(value == ""){
//		return;
//	}
//	getRecAccInfo(value);
//}
/**
 * 获取参数,如果没有的话，则取默认的值为:ultimate
 * @returns {___anonymous4174_4205}
 */
function getParams(i){
	var companyId = "";
	if(isHasBranchCompany){
		companyId = $("#companyInfoSelect_"+i).val();
	}else{
		companyId = getCustId();
	}
	var params = {};
	if(companyId == null || companyId == ""){
		params.flag = false;
		return params;
	}
	params.companyId = companyId;
	params.flag = true;
	return params;
}

/**
 * 获取付款单账号信息
 */
function getPayerAccInfo(i,data){
	var params = getParams(i);
	var result = execjava("factoringBean.payAccInfoQuery", params, 'json', factoringservice);
	var $selectName = $("#payAccountName_"+i);
	$selectName.attr("disabled", true);
	var $selectNo = $("#payAccountNo_"+i);
	 $("#payAccountNo_"+i).html('');
	 $("#payAccountName_"+i).html('');
	var payList = result.payAccNoList;
	// 同时往两个 select 中填充数据
	for(var i=0,len=payList.length;i<len;i++){
		var optionsNo = $("<option>");
		var optionsName = $("<option>");
		if(data == payList[i].accNo){
			optionsNo.attr("selected", true);
			optionsName.attr("selected", true);
			$selectNo.attr("disabled", true);//使下拉类表不可用
		}
		optionsNo.attr("value",payList[i].accNo);
		optionsNo.html(payList[i].accNo);
		optionsName.attr("value", payList[i].accNo);
		optionsName.html(payList[i].accName);
		
		optionsNo.append("</option");
		$selectNo.append(optionsNo);
		optionsName.append("</option");
		$selectName.append(optionsName);
	}
}
/**
 * 修改账号时，同步修改对应的账户名
 * @param obj
 * @param value
 */
function changeAccName(obj, value, id,i){
	$("#" + id+"_"+i + " option[value='" + value +"']").attr("selected", true);
	if(id!="payAccountName")
    autoReceivingInfo(value,i,'propertychange');
}

/**
 * 调用后台获取数据
 * @param customerId
 * @return	result：<br/>
 * 			result.retCode  返回码，200-支付成功  999-支付失败<br/>
 *			result.retMsg   返回信息<br/>
 * 			result.recAccNoList  查询返回的收款账户信息列表，AccountEntity
 */
function getRecAccInfo(customerId,recAccName,i){
	if(!customerId){
		alert("请选择供应商");
		return;
	}
	var params = getParams(i);
	params.customerId = customerId;
	params.recAccName = recAccName;
	
	var result = execjava("factoringBean.recAccInfoQuery", params, 'json', factoringservice);
	return result;
}

/**
 * 渲染收款账户数据
 * @param customerId 对应的供应商编号
 */
function renderRecAccInfo(result, recAccNo,recAccName,j){
	    var index='index'+j;
		var $selectNo = $("#recAccNo_"+j);
		var $selectName = $("#recAccName_"+j);
		$("#recAccNo_"+j).html('');
		$("#recAccName_"+j).html('');
		$selectName.attr("disabled", true);
		var payeeList = result.recAccNoList;
		getAccinFo=payeeList;
		if(payeeList.length <= 0){
			//alert("对应的 “" + $("#supplierNameSelect option:selected").text() + "”供应商没有收款账号！");
//			$("#supplierNameSelect").val('');
			var optionsName1 = $("<option>");
			optionsName1.attr("value",'');
			optionsName1.html(recAccName);
			optionsName1.append("</option");
			$selectName.append(optionsName1);
			flagForInsert.index='1';
			alert("没有查到收款账户名下面的账号，请手动输入！");
			var   recAccNo1=$("#inputrecAccNo_"+j).val();
			autoReceivingInfo(recAccNo1,j);
			return;
		}
		
		falgForNull.index='1';
		//$("#inputrecAccNo_"+j).hide();
		// 同时往两个 select 中填充数据
		var option1=$("<option>");
		option1.attr("value",'');
		option1.html("请选择收款账号！");
		option1.append("</option");
		$selectNo.append(option1);
		for(var i=0,len=payeeList.length;i<len;i++){
			var optionsNo = $("<option>");
			var optionsName = $("<option>");
			if(payeeList[i].hasOwnProperty("customerId")){
				if(recAccNo == payeeList[i].accNo){
					optionsNo.attr("selected",true);
					optionsName.attr("selected",true);
					$selectNo.attr("disabled", true);//使下拉类表不可用
				}
				optionsNo.attr("value",payeeList[i].accNo);
				optionsNo.html(payeeList[i].accNo);		
				optionsName.attr("value", payeeList[i].accNo);
				optionsName.html(recAccName);
			}else{
				if(recAccNo == payeeList[i].recAccNo){
					optionsNo.attr("selected",true);
					optionsName.attr("selected",true);
					$selectNo.attr("disabled", true);//使下拉类表不可用
				}
				optionsNo.attr("value",payeeList[i].recAccNo);
				optionsNo.html(payeeList[i].recAccNo);		
				optionsName.attr("value", payeeList[i].recAccNo);
				optionsName.html(recAccName);
			}
			
			optionsNo.append("</option");
			$selectNo.append(optionsNo);
			optionsName.append("</option");
			$selectName.append(optionsName);
		}
		//$('#inputrecAccNo_'+j).val("1111");
		autoReceivingInfo(payeeList[0].accNo,j);
	
}

/**
 * 获取关联的发票信息
 * @param page
 */
function getRelatedPurchase(page){
	// 获取选择的数据
//	var purchase = checkedObj.getData();
//	var params = {
//		"page" : page,
//		"limit" : limit,
//		"type" : type
//	}
//	var result = execjava("factoringBean.paymentRelatedPurchaseQuery", params, 'json', factoringservice);
//	var checkedCount = 0;
//	var dataList = result.purchaseList;
//	var total = parseInt(result.total, 10);
//	var pageTotal = parseInt((total + limit - 1) / limit);
//	
//	for(var i = 0 , len = dataList.length; i < len; i++){
//		if(purchase.indexOf(dataList[i].purchaseNo) > -1){
//			checkedCount++;
//		}
//	}
//	var html = template.render("newPaymentDetailTpl", {
//		dataList : dataList,
//		purchaseNos : purchase,
//		checkedCount : checkedCount,
//		limit : limit
//	});
//	var html = template.render("newPaymentDetailTpl", {
//	});
//	$("#newPaymenDom").html(html);
	
//	$("#pager").pager({
//		pagecount : pageTotal,
//		pagenumber : page,
//		buttonClickCallback : function(pageclickednumber) {
//			getRelatedPurchase(pageclickednumber, status);
//		}
//	});
}

/**
 * 获取监管账户
 */
function getSupervisionAccount(customerId){
	var params = getParams();
	params.customerId=customerId;
	var result = execjava("upPaymentBean.doGetSupervisionAccount", params, 'json');
	var $selectNo = $("#recAccNo");
	var $selectName = $("#recAccName");
	$("#recAccNo").html('');
	$("#recAccName").html('');
	$selectName.attr("disabled", true);
	$selectNo.attr("disabled", true);//使下拉类表不可用
	var supervisionAccount=result.dataList;
	if(supervisionAccount.length <= 0){
		alert("对应的 “" + $("#supplierNameSelect option:selected").text() + "”供应商没有监管账号！");
		$("#recAccNo").html('');
		$("#recAccName").html('');
		return;
	}
	// 同时往两个 select 中填充数据
	var optionsNo = $("<option>");
	var optionsName = $("<option>");
	optionsNo.attr("selected",true);
	optionsName.attr("selected",true);
	optionsNo.attr("value",supervisionAccount[1].superviseNo);
	optionsNo.html(supervisionAccount[1].superviseNo);	
	optionsName.attr("value", supervisionAccount[1].superviseNo);
	optionsName.html(supervisionAccount[1].superviseName);
	optionsNo.append("</option");
	$selectNo.append(optionsNo);
	optionsName.append("</option");
	$selectName.append(optionsName);
}

/**
 * 获取银行列表信息
 * @param bankNo
 */
function getBankBrankList(i,bankNo){
	var branchName = $("#inputBranchName").val();
	var params = {
		"page" : 1,
		"limit" : 0,
		"bankNo" : bankNo,
		"bankName" : ""
	}
	var result = execjava("factoringBean.bankQuery", params, 'json', factoringservice);
	if(!result){
		alert("银行列表信息获取失败！");
		return;
	}
	var bankList = result.bankList;
	if(!bankList || bankList.length == 0){
		return;
	}
	//填充select下拉列表
	var $select = $("#bankNoSelect_"+i);
	$select.html("");
	$select.append($("<option value=''></option>").html("-----请选择-----"));
	for(var i = 0, len = bankList.length; i < len; i++){
		var $option = $("<option>");
		$option.attr("value", bankList[i].bankNo);
		$option.html(bankList[i].bankName);
		$option.append("</option>");
		$select.append($option);
	}
}

/**
 * 根据银行编号及关键字查询银行网点的信息
 */
function queryBankBranch(i){
	$("#branchBankNoSelect_"+i).html("");
	var bankNo = $("#bankNoSelect_"+i).val();
	if(bankNo == null || bankNo == ""){
		alert("请选择所属银行！");
		return;
	}
	var keyWord = $("#branchKeyWord_"+i).val();
	if(keyWord == "" || keyWord.trim() == ""){
		alert("请输入银行网点关键字！");
		return;
	}
	var params = {
		"page" : 1,
		"limit" : 0,
		"bankNo" : bankNo,
		"branchName" : keyWord
	}
	var result = execjava("factoringBean.bankBranchQuery", params, 'json', factoringservice);
	var branchList = result.bankBranchList;
	if(!branchList || branchList.length == 0){
		return;
	}
	//填充select下拉列表
	var $select = $("#branchBankNoSelect_"+i);
	$select.html("");
	$select.append($("<option value=''></option>").html("-----请选择-----"));
	for(var i = 0, len = branchList.length; i < len; i++){
		var $option = $("<option>");
		$option.attr("value", branchList[i].branchNo);
		$option.html(branchList[i].branchName);
		$option.append("</option>");
		$select.append($option);
	}
}

/**********************************无付款单转账支付**************************************/
/**
 * 
 */
function selectBranchCompany(){
	$('#supplierNameSelect').html('');
	$('#payAccountNo').html('');
	$('#payAccountName').html('');
	$("#recAccNo").html('');
	$("#recAccName").html('');
	if($("#commonAccNo").attr("checked")){
		renderCustomerData(getCommonAcc($("#commonAccNo")[0]));
	}else{
		//获取供应商
		getCustomerInfo();
		// 获取付款账户信息
		getPayerAccInfo();
	}
}
/**
 * 更改收款账户时相应的更改供应商信息
 */
function changePayAccNo(){
	if($("#commonAccNo").attr("checked")){
		var customer = getCommonAcc($("#commonAccNo")[0]);
		renderCustomerData(customer);
	}
}

/**
 * 更改供应商时相应的更改收款账号
 */
function changeCustomer(value){
	renderRecAccInfo(getRecAccInfo(value));
}

/**
 * 常用联系人信息
 * @param obj
 */
function checkCommonContact(obj){
	if(obj.checked){
		renderCustomerData(getCommonAcc(obj));
	}else{
		selectBranchCompany();
	}
}

/**
 * 获取常用账号信息
 * @param obj
 * @returns commonAcc;
 */
function getCommonAcc(obj){
	var params = getParams();
	var payAccountNo = $("#payAccountNo").val();
	var payAccountName = $("#payAccountName option:selected").text();
	var reciverId = $("#supplierNameSelect").val();
	if(!params.flag || payAccountNo == "" || payAccountNo == null){
		alert("请选择分公司或本方账号信息！");
		obj.checked = false;
		return null;
	}
	params.payAccNo = payAccountNo;
	params.payAccName = payAccountName;
	if(reciverId != "" && reciverId != null){
		params.reciverId = reciverId;
	}
	/**
	 * retCode  返回码，200-支付成功  999-支付失败
	 * retMsg   返回信息
	 * commonAccNoList  返回的收款账户信息列表，类型为List<CommonAccountEntity>
	 */
	var result = execjava("factoringBean.commonRecAccInfoQuery", params, 'json', factoringservice);
	var commonAcc = result.commonAccNoList;
	if(commonAcc.length == 0){
		alert("当前选择的账户信息不存在常用对方账户！");
		obj.checked = false;
		return null;
	}
	$("#recAccNo").html('');
	$("#recAccName").html('');
	return commonAcc;
}



/*************************************添加账号**************************************************/


/**
 * 获取所有的经销商
 */
function getAllCustomer(customerId){
	var result = execjava("userInfoBean.getCustomerInfo",null,'json');
	if(!result){
		alert("供应商信息获取失败");
		return;
	}
	var customerList = result.customerList;
	var $select = $("#addrec_recCustomer");
	$select.html('');
	$select.append("<option value=''>请选择经销商</option>");
	for(var i = 0,len=customerList.length; i<len; i++){
		var $option = $("<option>");
		if(customerId == customerList[i].customerId){
			$option.attr("selected", true);
		}
		$option.attr("value", customerList[i].customerId);
		$option.html(customerList[i].userName);
		$option.append('</option>');
		$select.append($option);
	}
}

/**
 * 打开添加账号弹窗
 * @param id 弹窗ID编号
 */
function openAddWin(id){
	var companyId = $("#companyInfoSelect").val();
	var companyName = $("#companyInfoSelect option:selected").text();
	if(isHasBranchCompany){
		if(companyId == ""){
			alert("请先选择分公司！");
			return;
		}
	}else{
		companyId = getCustId();
		companyName = currentCompanyName;
	}
	$("#addDom").html(template.render("addTpl",{}));
	$("#addpay_companyName").val(companyName);
	$("#addpay_companyId").val(companyId);
	
	$("#addrec_companyName").val(companyName);
	$("#addrec_companyId").val(companyId);
	getAllCustomer($("#supplierNameSelect").val());
	showBg(id);
}

/**
 * 关闭弹窗
 * @param id
 */
function closeAddWin(id, flag){
	closeBg(id);
	if(flag === 1){
		var companyId = $("#addpay_companyId").val();
		if(isHasBranchCompany){
			getBranchCompany(companyId);
		}
		var payAccParam = Utils.form2json("#payAccForm",false);
		var recAccParam = Utils.form2json("#recAccForm",false);
		
		var selectCutomer = $("#addrec_recCustomer").val();
		
		if($("#commonAccNo").attr("checked")){
//			renderCustomerData(getCommonAcc($("#commonAccNo")[0]), selectCutomer);
			$("#commonAccNo").attr("checked", false);
		}
		getPayerAccInfo(payAccParam.accNo);
		getCustomerInfo(selectCutomer);
		renderRecAccInfo(getRecAccInfo(selectCutomer), recAccNo);
	}
}

/**
 * 提交添加
 */
function addAccount(){
	var payAccParam = Utils.form2json("#payAccForm",false);
	var recAccParam = Utils.form2json("#recAccForm",false);
	recAccParam.customerName = $("#addrec_recCustomer option:selected").text();
	if(typeof recAccParam.customerId == "undefined"){
		recAccParam.customerId = $("#addrec_recCustomer").val();
	}
	for(var key in payAccParam){
		if(payAccParam.hasOwnProperty(key)){
			var value = payAccParam[key];
			if(value == "" || value == null || value.trim() == ""){
				alert("请确认是否存在空值！");
				$("input[name='" + key + "']")[0].focus();
				return;
			}
		}
	}
	for(var key in recAccParam){
		if(recAccParam.hasOwnProperty(key)){
			var value = recAccParam[key];
			if(value == ""){
				alert("请确认是否存在空值！");
				if(key != "customerId"){
					$("input[name='" + key + "']")[1].focus();
				}
				return;
			}
		}
	}
	
	var payResult = execjava("factoringBean.accInfoDBAdd", payAccParam, 'json', factoringservice);
	var recResult = execjava("factoringBean.accInfoDBAdd", recAccParam, 'json', factoringservice);
	if (payResult.retCode != "200" || payResult.retCode!= "200") {
		alert("账号添加失败！");
		return;
	}
	//添加成功关闭弹窗
	closeAddWin('addWindow', 1);
}

//---------------------------------付款账号 选择补全信息------------begin--
function autoReceivingInfo(receNo,i,propertychange){
	
	$("input[name=sysIOFlg_"+i+"][type='radio'][value=2]").removeAttr("disabled");
	$("input[name=sysIOFlg_"+i+"][type='radio'][value=1]").removeAttr("disabled");
	
	$('#inputrecAccNo_'+i).val(receNo);
	var customerId = $("#supplierNameSelect_"+i).val();
	var params = getParams(i);
	params.customerId = customerId;
	if(propertychange!=null && propertychange!=""){
		params.eqrecAccNo=receNo;
	}else{
		params.recAccNo=receNo;
	}
	var result = execjava("factoringBean.recAccInfoQuery", params, 'json', factoringservice);
	var recAccNoInfo=result.recAccNoList[0];
	
	//系统内外(由于账号表中sysIOFlg字段的值为空，所以下面的条件是进不去的)
	if(recAccNoInfo&&recAccNoInfo.hasOwnProperty("sysIOFlg")&&recAccNoInfo.sysIOFlg!=null&&recAccNoInfo.sysIOFlg!=""){
		$("input[name=sysIOFlg_"+i+"][type='radio'][value=2]").attr("disabled","disabled");
		$("input[name=sysIOFlg_"+i+"][type='radio'][value=1]").attr("disabled","disabled");
		//系统外
		if(recAccNoInfo.sysIOFlg=="2"){
			$("input[name=sysIOFlg_"+i+"][type='radio'][value= '2']").attr("checked","checked");
			$("#ReceiveCityName_"+i).show();
			$("#recCityName_"+i).val(recAccNoInfo.recCityName?recAccNoInfo.recCityName:"");
			//手工输入
			$("#RecordType_"+i).show();
			$("#InputRecordType_"+i).show();
			$("input[name=recordType_"+i+"][type='radio'][value='1']").attr("checked","checked");
			//银行名称
			if(recAccNoInfo.recBankName!=null&&recAccNoInfo.recBankName!=""){
				$("#inputBankName_"+i).val(recAccNoInfo.recBankName);//银行名称
				$("#branchBankNoSelect_"+i).append(makeOption("ii3",recAccNoInfo.recBankNo,"",true));//银行账号
			}
			return;
		}
	}
	$("input[name=sysIOFlg_"+i+"][type='radio'][value= '1']").attr("checked","checked");
	$("#BankList_"+i).hide();
	$("#BankBranchList_"+i).hide();
	$("#RecordType_"+i).hide();
	$("#ReceiveCityName_"+i).hide();
	$("#InputRecordType_"+i).hide();
}
//---------------------------------付款账号 选择补全信息------------end--

