template.openTag = "<%";
template.closeTag = "%>";
/**
 * 前台功能权限配置
 */
var paymentFunctions={"11":"lookUp","12":"payOff","5":"payOff"};
/**
 * 是否有父付款单
 */
var isParentPaymet=false;

var hasUpdatepaymentStatus=false;

//上游保理服务
var factoringservice = "factoringservice";
/**
 * 付款单状态
 */
var paymentStatus = {
	"0" : "未付款",
	"1" : "待确认",
	"2" : "已付款",
	"3" : "付款失败"
};

/**
 * 转账状态
 */
var transferStatus_ = {
	"0":"提交成功,等待银行处理",
	"1":"授权成功, 等待银行处理",
	"2":"等待授权",
	"3":"等待二次授权",
	"4":"等待银行答复",
	"5":"主机返回待处理",
	"6":"被银行拒绝",
	"7":"处理成功",
	"8":"指令被拒绝授权",
	"9":"银行正在处理",
	"10":"预约指令",
	"11":"预约取消",
	"86":"等待电话核实",
	"95":"待核查",
	"98":"区域中心通讯可疑"
};
//简化转化状态
var transferStatus = {
		"2,3":"待授权",
		"0,1,4,5,9,10,11,86,95,98":"处理中",
		"8,6":"失败",
		"7":"处理成功",
		getTransferStatusValue:getTransferStatusValue
};
var payType = {
	1 : "加急",
	2 : "普通"
}
// 每页数据量
var limit = syPageLimit;
//查询方法
var search=null;

//存放所有的付款的信息
var paymentList=null;
//存放所有的付款单对应的付款指令信息
var payCommandListParm=new Array();
function pageInitialize(){
	//var roleId = $("#currentRoleId").val();
	//if(roleId=='12') //核心企业业务员
	//	if(way=="1"){
			//$("#mergerButton").show();//显示合并付款
	//	}
	// 搜索条件DOM渲染
	showPaymentSearchType();
	search=isParentPaymet?searchPaymentParentInfoList:searchPaymentInfoList;
	//isParentPaymet?searchPaymentParentInfoList():searchPaymentInfoList(1);
	search(1);
}

function searchPaymentParentInfoList(page, status, choosedTransferStatus){
	var params = Utils.form2json("#keySearchForm",false);
	if(!page){
		page = 1;
	}
	var params = Utils.form2json("#keySearchForm",false);
	// 判断开始时间与结束时间
	var start_date = $('#start_date').val();
	var end_date = $('#end_date').val();
	if(!Utils.doubleMargin(start_date, end_date)){
		return;
	}
	if(params.startAmount&&params.endAmount){//校验金额
		if(parseInt(params.startAmount)>parseInt(params.endAmount)){
			alert("付款金额区间(例如1-2)，要前小后大");
			clean();
			return;
		}
	}
	params.status = status;
	params.transferStatus = choosedTransferStatus;
	/**
	 * queryType，查询类型，根据当前用户角色判断并赋值
	 * 0-供应商查询，查询登录用户的发票，对应的角色为供应商，
	 * 1-核心企业查询，查询所有符合条件发票，对应的角色为业务员
	 */
	var queryType;
	var role=getUserPaymentFunction();
	if (role === "payOff"){
		queryType = 1;
	}else if(role === "lookUp"){
		queryType = 0;
	}
	params.queryType=queryType;
	var result = execjava("factoringBean.paymentListQuery", params, 'json', factoringservice);
	var total = parseInt(result.total,10);
	var pageTotal = parseInt((total + limit - 1) / limit);// 总页数
//	alert(JSON.stringify(result));
	var paymentList = result.paymentList;
//	// 分页
	$("#pager").pager({
		pagecount : pageTotal,
		pagenumber : page,
		buttonClickCallback : function(pageclickednumber) {
			searchPaymentParentInfoList(pageclickednumber, status);
		}
	});
	for(var i=0;i<paymentList.length;i++){
		paymentList[i].amount = EToString(paymentList[i].payAmt);
		paymentList[i].payAmt = addCommafy(paymentList[i].payAmt);
	}
	var html = template.render('paymentListEnsembleTpl',{
		paymentList : paymentList,
		paymentStatus : paymentStatus,
		transferStatus : transferStatus,
		status : status,
		choosedTransferStatus : choosedTransferStatus
	});
	$("#mypayment_table").html(html);
	//paymentListEnsembleTpl
}


/**
 * 发货单显示页面，付款单关联订单时点击减号触发方法，隐藏关联订单
 * 
 */
function jianordernone(paymentNo,columnNum){
	document.getElementById("showrelatepaymentorder"+paymentNo).style.display='none';
	document.getElementById("jia"+paymentNo).style.display='';
	document.getElementById("jian"+paymentNo).style.display='none';
//	if(columnNum%2==0)
//	{
//		document.getElementById("ordertable"+num).style.background='#fff';
//	}
//	else
//	{
//		document.getElementById("ordertable"+num).style.background='#f9f9f9';
//	}
	
	$("#bottom").css("display","none");
	$("#bottom").css("display","block");

}

/**
 * 付款单显示页面，付款单关联付款单详情单时点击加号触发方法，显示关联的付款单详情单
 * 
 */
function jiaordershow(paymentNo,customerId){

	document.getElementById("jia"+paymentNo).style.display='none';
	document.getElementById("jian"+paymentNo).style.display='';
	if(!$("#showrelatepaymentorder"+paymentNo).html()==""||!$("#showrelatepaymentorder"+paymentNo).html()==null){
		showrelatepaymentorderTabel(paymentNo);
	}else{
		document.getElementById("paymentorder"+paymentNo).style.display='';
		document.getElementById("paymentorder"+paymentNo).style.background='#f8f4ec';
	}
		
	$("#bottom").css("display","none");
	$("#bottom").css("display","block");

}




function showrelatepaymentorderTabel(paymentNo){
	
		
	$("#showrelatepaymentorder"+paymentNo).css("display","");
	//document.getElementById("ordertable"+num).style.background='#f8f4ec';
}



function showRelatedOrderTabel(num,no){
	var params = {};
	params.page = 1;
	params.limit = limit;
	params.parentNo = no;
	/**
	 * queryType，查询类型，根据当前用户角色判断并赋值
	 * 0-供应商查询，查询登录用户的发票，对应的角色为供应商，
	 * 1-核心企业查询，查询所有符合条件发票，对应的角色为业务员
	 */
	var queryType;
	var role=getUserPaymentFunction();
	if (role === "payOff"){
		queryType = 1;
	}else if(role === "lookUp"){
		queryType = 0;
	}
	params.queryType=queryType;
	// 调用保理服务后台
	var result = execjava("upPaymentBean.paymentDetailListQuery", params, 'json');
	if(!result || result.retCode != "200"){
		alert("付款单查询数据异常！");
		return;
	}
	var paymentList = result.paymentList;
	var paymentNoMuster="";
	for(var key in paymentList){
		paymentNoMuster+=paymentList[key].paymentNo+",";
	}
	var relatedPurchaseQuery;
	//查询付款单对应的发票状态
	if(paymentNoMuster)
	     relatedPurchaseQuery = execjava("upPaymentBean.doGetPurchaseByPayment", {'paymentNoMuster':paymentNoMuster}, 'json');
	var relatedPurchases
	if(relatedPurchaseQuery)
		relatedPurchases=relatedPurchaseQuery.dataList;
	for(var i=0;i<paymentList.length;i++){
		paymentList[i].amount = EToString(paymentList[i].payAmt);
		paymentList[i].payAmt = addCommafy(paymentList[i].payAmt);
		paymentList[i].isUpload=getRelatedUpLoad(paymentList[i].paymentNo,relatedPurchases);
		paymentList[i].payTime=paymentList[i].payTime?new Date(paymentList[i].payTime.DatefastTime).toLocaleDateString().replace(/\//g,"-"):"";

	}
	var html = template.render('relatedOrder_tpl',{
		paymentList : paymentList,
		paymentStatus : paymentStatus,
		transferStatus : transferStatus,
		status : status,
		way:way,
		num:num,
		role:role
	});
	$("#showrelatedorder"+num).html(html);		
}


/**************************************付款单页面查询方式************************************/
/**
 * 根据不同角色显示查询条件
 */
function showPaymentSearchType(){
	var searchHtml = template.render('paymentSearchTypeTpl_' + getUserPaymentFunction(), {});
	$("#paymentSearchDom").html(searchHtml);
}


/**************************************付款单列表*****************************************/
/**
 * 清空搜索条件
 */
function clean(){
	Utils.clearValue("keySearchForm");
	searchPaymentInfoList(1);
}

//function test11(){
//	alert(arguments.callee);
//}

/**
 * 付款单查询列表
 * 
 * @param page 页码
 * @param paymentStatus 付款单状态
 * @param transferStatus 付款单转账状态
 * @param status 选中的付款单状态
 * @param  choosedTransferStatus 选中的付款单转账状态
 */
function searchPaymentInfoList(page, status, choosedTransferStatus){
//$.typicalPager({'total':'10'});
	//return ;
	if(!page){
		page = 1;
	}
	// 判断开始时间与结束时间
	var start_date = $('#start_date').val();
	var end_date = $('#end_date').val();
	if(!Utils.doubleMargin(start_date, end_date)){
		$('#start_date').val("");
		$('#end_date').val("");
		return;
	}
	var params = Utils.form2json("#keySearchForm",false);
	if(params.startAmount&&params.endAmount){//校验金额
		if(parseInt(params.startAmount)>parseInt(params.endAmount)){
			alert("付款金额区间(例如1-2)，要前小后大");
			$("#startPayAmount").val("");
			$("#endPayAmount").val("");			
			//clean();
			return;
		}
	}
	params.page = page;
	params.limit = limit;
	params.status = status;
	params.transferStatus = choosedTransferStatus;
	/**
	 * queryType，查询类型，根据当前用户角色判断并赋值
	 * 0-供应商查询，查询登录用户的发票，对应的角色为供应商，
	 * 1-核心企业查询，查询所有符合条件发票，对应的角色为业务员
	 */
	var queryType;
	var role=getUserPaymentFunction();
	if (role === "payOff"){
		queryType = 1;
	}else if(role === "lookUp"){
		queryType = 0;
	}
	params.queryType=queryType;
	params.startTime = start_date;
	params.endTime = end_date;
	// 调用保理服务后台，获取付款单数据
	var result = execjava("upPaymentBean.paymentDetailListQuery", params, 'json');
	if(!result || result.retCode != "200"){
		alert("付款单查询数据异常！");
		return;
	}
	paymentList = result.paymentList;
	
	var paymentNoMuster="";
	for(var key in paymentList){
		paymentNoMuster+=paymentList[key].paymentNo+",";
	}
	var relatedPurchaseQuery;
	//查询付款单对应的发票状态
	if(paymentNoMuster)
	     relatedPurchaseQuery = execjava("upPaymentBean.doGetPurchaseByPayment", {'paymentNoMuster':paymentNoMuster}, 'json');
	var relatedPurchases
	if(relatedPurchaseQuery)
		relatedPurchases=relatedPurchaseQuery.dataList;
	var total = parseInt(result.total,10);
	var pageTotal = parseInt((total + limit - 1) / limit);// 总页数
//	// 分页
	$("#pager").pager({
		pagecount : pageTotal,
		pagenumber : page,
		buttonClickCallback : function(pageclickednumber) {
			searchPaymentInfoList(pageclickednumber, status,choosedTransferStatus);
		}
	});
	for(var i=0;i<paymentList.length;i++){
		if (paymentList[i].payAmt != undefined) {
			paymentList[i].amount = EToString(paymentList[i].payAmt);
			paymentList[i].payAmt = (paymentList[i].payAmt);
		}
		//
		paymentList[i].isUpload=getRelatedUpLoad(paymentList[i].paymentNo,relatedPurchases);
//		paymentList[i].payTime=paymentList[i].payTime?new Date(paymentList[i].payTime.DatefastTime).toLocaleDateString().replace(/\//g,"-"):"";
		//paymentList[i].status = parseInt(paymentList[i].status);
		
		
		var reciverId=paymentList[i].reciverId;
		var reciverName=paymentList[i].reciverName;
		var companyId=paymentList[i].companyId;
		var companyName=paymentList[i].companyName;
		if(reciverId&&!reciverName){
			var date1 = execjava("upPaymentBean.getCustomerNameByCustomerId", {'customerId':reciverId}, 'json');
			paymentList[i].reciverName=date1.userName;
		}
		/*if(companyId&&!companyName){
			var date2 = execjava("upPaymentBean.getCompanyNameByCompanyId", {'companyId':companyId}, 'json');
			paymentList[i].companyName=date2.companyName;
		}*/
	}
	
	
		//需要将指令表信息更新到付款单主表的List
		var updatePaymentList = new Array();
		for(var key=0;key<paymentList.length;key++){
			var updatePayment = new Map();
			var paymentNoCurrent=paymentList[key].paymentNo;			
			updatePayment.paymentNo = paymentNoCurrent;
			//查找该笔付款单关联付款指令信息。
			var params= {
					"paymentNo":paymentNoCurrent
			};
			var ary = execjava("upPaymentBean.getPayCommandList", params, 'json');
			var payCommandList=ary.payCommand;
			payCommandListParm[key]=payCommandList;
			for(var i=0;i<payCommandList.length;i++){
				payCommandList[i].status = parseInt(payCommandList[i].status);
				payCommandList[i].transferStatus = parseInt(payCommandList[i].transferStatus);
			}	
			var paymentStatusOne = paymentList[key].status;
			if(paymentStatusOne == "2" || paymentStatusOne == "3" || paymentStatusOne == "4"){
				//console.info(paymentList[key].paymentNo+"付款单已是最终状态，不进行更新!");
				//付款单已是最终状态，不进行更新。（付款单最终状态包括：2-已付款  3-付款失败  4-作废）
				continue;
			}
			if(payCommandList.length>0){
				//var len=payCommandList.length;
				//var payTimeLast=payCommandList[len-1];
				//$("#paymentStatus_"+key).html(paymentStatus[payCommandList[0].status]);
				//$("#transferStatus_"+key).html(transferStatus.getTransferStatusValue(payCommandList[0].transferStatus));
				updatePayment.status=parseInt(payCommandList[0].status);
				updatePayment.transferStatus=parseInt(payCommandList[0].transferStatus);
				updatePayment.transNo=payCommandList[0].transNo;
				updatePayment.payTime=payCommandList[0].payTime;
				updatePayment.postScript=payCommandList[0].postScript;
				updatePayment.reciverName=payCommandList[0].reciverName;
				updatePayment.companyName=payCommandList[0].companyName;
			}
			
			
			updatePaymentList.push(updatePayment);
			
//		var relatePaymentOrderTableHtml = template.render('relatedPaymentOrder_tpl', {
//			payCommandList:payCommandList,
//		   	paymentNo:paymentNoCurrent,
//		   	paymentStatus:paymentStatus,
//		   	transferStatus:transferStatus
//		}); 
//		$("#showrelatepaymentorder"+paymentNoCurrent).html(relatePaymentOrderTableHtml);
		}
		
		
		var paymentlistparams={
				"paymentList":updatePaymentList	
		};
		var ary1=execjava("upPaymentBean.updatePaymentStatus", paymentlistparams, 'json');
		if(!ary1 || ary1.retCode != "200"){
			alert("更新付款单状态异常！");
			return;
		}
		hasUpdatepaymentStatus=true;
	
		
//preview		
//	var html = template.render('paymentListTpl_'+role,{
//		paymentList : paymentList,
//		paymentStatus : paymentStatus,
//		transferStatus : transferStatus,
//		status : status,
//		choosedTransferStatus : choosedTransferStatus,
//		way:way
//	});
//	$("#mypayment_table").html(html);
	
	var thisArray;//适配字段
	var thisCol;//列属性
	var prefix;//展示前缀
	var statusIndex;//状态索引
	var checkBoxIndex;//
	var transferStatusIndex;//转账状态索引
	if(role == "payOff"){
		thisArray = colArray1;
		prefix = "付款单";
		thisCol = upPaymentpayOff_col;
	}else{
		thisArray = colArray;
		prefix = "收款单";
		thisCol = upPaymentlookUp_col;
	}
	for(var i = 0;i<thisArray.length;i++){
		if(thisArray[i][1] == "status"){
			statusIndex = i;
		}
		if(thisArray[i][1] == "transferStatus"){
			transferStatusIndex = i;
		}
		if(thisArray[i][1] == "checkBox"){
			checkBoxIndex = i;
		}
	}
	var tableConfig = {  		
			paging:false,//分页
	  		processing:true,//处理数据显示
	  		searching:false,//搜索框
	   	    ordering:true,//排序
	  		autoWidth:true,//宽度自适应
	  		info:false,//是否显示页脚
	  		scrollX:true,
	  		scrollY:getScrollY(paymentList),
	  		order:[],//插件BUG，必须重写默认值，否则第一列会出现图标
	  		columnDefs:[{orderable:false,targets:[checkBoxIndex,statusIndex,transferStatusIndex]}]
	  	};

	var invoiceSelectConfig = {  		
			name:"invoiceStatus",
			ocfnText:"searchPaymentInfoList(1,this.value, $(&quot;#chooseTransferStatus&quot;).val());",
			id:"choosePaymentStatus",
			defName:prefix+"状态",
			display:paymentStatus
	};
	var transferStatusSelectConfig = {  		
			name:"financeStatus",
			ocfnText:"searchPaymentInfoList(1,$(&quot;#choosePaymentStatus&quot;).val(),this.value);",
			id:"chooseTransferStatus",
			defName:prefix+"转账状态",
			display:transferStatus
	};
	
	headerCallbackFunction = function(thead,data,start,end,display){
		$(thead).addClass("DTth");
		$("#"+invoiceSelectConfig.id+" option[value='"+status+"']").attr("selected","selected");
		$("#"+transferStatusSelectConfig.id+" option[value='"+choosedTransferStatus+"']").attr("selected","selected");
	};
	
	thisCol.status.title = getSelectHtml(invoiceSelectConfig);
	thisCol.transferStatus.title = getSelectHtml(transferStatusSelectConfig);
	
  	var oTable = $("#mypayment_table").renderDatatables(thisArray,thisCol,paymentList,tableConfig);

}
/**
 * 如果关联一张发票并且已将上传到总行 返回是否上传到总行
 * 如果关联多张发票或者不关联发票 返回null
 * 
 */
function getRelatedUpLoad(paymentNo,relatedPurchases){
	var num=0;
	var retIsUpload="";
	if(relatedPurchases){
		for(var i=0;i<relatedPurchases.length;i++){
			if(relatedPurchases[i].a_paymentNo==paymentNo){
				num++;
				retIsUpload=relatedPurchases[i].isUpload;
			}
		}
	}
	if(num==1){
		return retIsUpload
	}
	return null;
}

/**
 * 跳转到相应的页面：<br/>
 * flag === 0  ==>	跳转到有付款单支付页面<br/>
 * flag === 1  ==>	跳转到付款单详情页面<br/>
 * flag === 2  ==>	跳转到无付款单转账支付页面<br/>
 * 
 * @param id	付款单号，如果是无付款单，该值为空字符串
 * @param flag	跳转标记，值为：0,1,2
 * @param url	对应页面的target地址
 * @param isUpload 是否是上传到总行 0-未上传，1-已经上传 如果是无付款单，该值为未定义
 */
function jumpTo(id, flag, url,isUpload){
	$("#paymentId").val(id);
	$("#showFlag").val(flag);//表示点击的按钮类型
	$("#isUpload").val(isUpload);
	$("#way").val(way);//全局变量付款模式
	
	var idArray=new Array();
	 idArray=id.split(',');
	for(var index=0;index<idArray.length;index++){
		
		var params = {
				"equalsPaymentNo" :idArray[index],
				"queryType":1
		}
		var result = execjava("upPaymentBean.paymentDetailListQuery", params, 'json');
		if(result.total == 0 ){
			alert("没有找到付款人信息！");
			return;
		}else if(url == "upPay" &&(result.paymentList[0].recAccName==null || result.paymentList[0].recAccName=="")){
			alert("付款单中没有收款人账户名，无法进行付款！");
			return;
		}
	}
	var form = document.getElementById("paymentDetailForm");	
	if(flag == 1){
		if(url == 'dibetNoteDetail'){
			if(dibetNoUrl != "" && typeof(dibetNoUrl) != "undefined"){
				if(dibetNoType == '0'){//0---内部链接
					form.action = getRealPath() + dibetNoUrl;
				}else{//1---外部链接
					form.action = dibetNoUrl;
				}
			}else{
				form.action = getRealPath()+"~main/share/frame.php?target="+url;
			}			
		}else if(url == 'uppaymentDetail'){
			if(paymentNoUrl != "" && typeof(paymentNoUrl) != "undefined" ){
				if(paymentNoType == '0'){//0---内部链接
					form.action = getRealPath() + paymentNoUrl;
				}else{//1---外部链接
					form.action = paymentNoUrl;
				}		
			}else{
				form.action = getRealPath()+"~main/share/frame.php?target="+url;
			}
		}
		
	}else{
		form.action = getRealPath()+"~main/share/frame.php?target="+url;
	}
	
	form.submit();
}

/**
 * 获取权限
 */
function getUserPaymentFunction(){
	var roleId = $("#currentRoleId").val();
	 var i=$.map(paymentFunctions,function(value,key){
	    var roles=key.split(",");
	    if(roles.indexOf(roleId)>-1){
	    	return value;
	    }
     });
	 if(i.length<1){
		 alert("没有任何权限使用此功能");
		 return;
	 }
	 return i[0];
}

//获取简化转化状态
function getTransferStatusValue(subKey){
	if(!subKey){
		return undefined
	}
	var subKey1=subKey.toString();
	for(var key in transferStatus){
		var keys=key.split(",");
		 if(keys.indexOf(subKey1)>-1){
		    	return transferStatus[keys];
		 }
	}
}


function checkAll(){

//  	var checkIdArr = $("input[name='checkOne']");
//  	var checkIdArr1=$("input[name='checkAll']");
//  	var totalMoney = 0;
//  	var totalNum = 0;
//  	var lastTrObj = $("#myCartList");
//  	if(checkIdArr1[0].checked){
//  		for(var i=0;i<checkIdArr.length;i++){
//  			if(checkIdArr[i].disabled==false && checkIdArr[i].checked==false){
//				checkIdArr[i].checked=true;
//  	  		}
//  			var proValue = $("#quanty" + i).val();
//			var price =  delCommafy($("#quanty" + i).parent().prev().text().substr(1));		
//			var cartCost = parseFloat(price) * parseFloat(proValue);
//			totalNum += parseFloat(proValue);
//			totalMoney += cartCost;
//		}
//  		lastTrObj.find(".countTotal").text(totalNum);
//  		lastTrObj.find(".totalMoney").text("￥" + addCommafy(totalMoney.toFixed(2)));
//  	}else{
//  		for(var i=0;i<checkIdArr.length;i++){
//  			if(checkIdArr[i].disabled==false && checkIdArr[i].checked==true){
//				checkIdArr[i].checked=false;
//  			}
//		}
//  		lastTrObj.find(".countTotal").text(0);
//  		lastTrObj.find(".totalMoney").text("￥" + addCommafy(0));
//  	}

	var checkIdArr = $("input[name='checkOne']");
	var checkIdArr1=$("input[name='checkAll']");
	var totalMoney=0;
	var totalNum=0;
	if(checkIdArr1[0].checked){
		for(var i=0;i<checkIdArr.length;i++){
			if(checkIdArr[i].disabled==false && checkIdArr[i].checked==false){
				checkIdArr[i].checked=true;
				totalNum +=1;
				var proValue=$("payAmt_"+i).val();
			    totalMoney +=parseFloat(proValue);
			}
		}
	}
		else{
  		for(var i=0;i<checkIdArr.length;i++){
			if(checkIdArr[i].disabled==false && checkIdArr[i].checked==true){
			checkIdArr[i].checked=false;
			}
			totalMoney=0;
			totalNum=0;
  		  }
	}
}


function multiPayment(){
	//var checkIdArr = $("input[name='checkOne']:checked");
//	var selectFeatureFlag = checkFeatureSelected(checkIdArr);
//	if(checkIdArr.length == 0){
//        alert("您还未选择任何付款单！");
//		return;
//	}
//	if(!selectFeatureFlag){
//		return;
//	}
	var checkedPayment = checkedObj.getData();
	if(checkedPayment.length === 0){
 		alert("请至少选择一条付款单数据！");
 		return;
 	}
	var paymentNoArray=checkedPayment.toString();
	jumpTo(paymentNoArray,0, "upPay",'0');
}



function  checkFeatureSelected(checkNodes){
	var flag=true;
	$.each(checkNodes,function(index,item){
		//alert($(item));
		var rid=$(item).parent().parent().find("td");
		var content=$(rid[9]).find("a").html();
		if(content=='支付' || content=='贷款'){
		}else{
			alert("第" + (index+1)+"种付款单不能进行付款操作！");
			flag = false;
			return;
		}
	});
	return flag;
}


function savePaymentNo(checkNodes){
	var paymentNoArray1="";
	$.each(checkNodes,function(index,item){
		var rid=$(item).parent().parent().find("td");
		var paymentNo=$(rid[2]).html().trim();
		//alert(paymentNo);
		paymentNoArray1+=paymentNo+',';
	});
	var paymentNoArray1=paymentNoArray1.slice(0,paymentNoArray1.lastIndexOf(','));
	return paymentNoArray1;
}


function financeWin(id,i){
	//var index="index"+i;
	var relatePaymentDetailTableHtml = template.render('relatedPaymentOrder_tpl', {
	payCommandList:payCommandListParm[i],
   	paymentNo:paymentList[i].paymentNo,
//   	paymentStatus:paymentStatus,
   	transferStatus:transferStatus
	}); 
	
	$("#paymentDetailListDom").html(relatePaymentDetailTableHtml);
	showBg(id);
}

