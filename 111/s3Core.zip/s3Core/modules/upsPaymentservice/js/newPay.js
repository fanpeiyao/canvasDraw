template.openTag = "<%";
template.closeTag = "%>";
//上游保理服务
var factoringservice = "factoringservice";
$(document).ready(function(){
	initPage();
});
/**
 * 无付款单转账
 */
function initPage(){
	// 无付款单转账支付页面
	$("#newPaymenDom").html(template.render("newpayTpl"));
	event();
	if(isHasBranchCompany){
		$("#companyInfoLi").css("display","block");//显示分公司
		getBranchCompany($("#companyInfoSelect"));
	}else{
		$("#companyInfoLi").css("display","none");//隐藏分公司
		getPayerAccInfo();//显示付款账户
		getCustomerInfo();
	}
}
function event(){
	/**
	 * 系统内外单击事件
	 */
	$("input[name='sysIOFlg']").bind("click", function(){
		if(this.value === "1"){
			$("#BankList").hide();
			$("#BankBranchList").hide();
			$("#RecordType").hide();
			$("#ReceiveCityName").hide();
			$("#InputRecordType").hide();
		}else{
			$("#BankList").show();
			$("#BankBranchList").show();
			$("#RecordType").show();
			$("#ReceiveCityName").show();
			$("#InputRecordType").hide();
			$("input:radio[name='recordType']").eq('0').prop("checked", true);
			getBankBrankList();
		}
	});
	/**
	 * 录入方式点击事件
	 */
	$("input[name='recordType']").bind("click", function(){
		if(this.value === "1"){
			$("#BankList").hide();
			$("#BankBranchList").hide();
			$("#InputRecordType").show();
		}else{
			$("#BankList").show();
			$("#BankBranchList").show();
			$("#InputRecordType").hide();
			$("#inputBankName").val("");//银行名称
			$("#branchBankNoSelect").html("");
			getBankBrankList();
		}
	});
}
/**
 * 支付  支付指令提交接口
 */
function transferPay(obj){
	var params=getPayParam();
	if(typeof params =="undefined"){
		return;
	}
	var result = execjava("upPaymentBean.doTransferPayNew", params, 'json');
	if(!result || result.retCode != "200"){
		alert("转账失败！");
		return;
	}else{
		alert("转账成功！");
	}
	obj.disabled = true;
	obj.onclick = null;
	obj.style.cursor = "text";
	obj.className = "btn btn-disabled"
}
function getPayParam(){
	var customerId = $("#supplierNameSelect").val();
	if(!customerId){
		alert("请选择供应商");
		return;
	}
	var payType = $("input:radio[name='payType']:checked").val(),// 转账处理方式
		payAccName = $("#payAccountName option:selected").text(),// 本方账号名称
		payAccNo = $("#payAccountNo").val(),//本方账号
		recAccName = $("#recAccName option:selected").text(),// 对方账号名称
		recAccNo = $("#recAccNo").val(),// 对方账号
		sysIOFlag = $("input:radio[name='sysIOFlg']:checked").val(),//系统内外标记
		isPub = $("input:radio[name='isPub']:checked").val(),// 对公对私标记
		bankNo = "",// 银行编号
		branchBankNo = "",//银行名称
		inputBankNam = "",// 手动录入的银行名称
		payAmt = $("#payAmount").val(),//付款金额
		note = $("#payNote").val();//备注
	var params = {};
	// 判断分公司
	if(isHasBranchCompany){
		var companyId = $("#companyInfoSelect").val();
		if(!companyId){
			alert("请选择分公司");
			return;
		}
		var companyName = $("#companyInfoSelect option:selected").text();
		params.companyId = companyId;
		params.companyName = companyName;
	}else{
		params.companyId ="";;
		params.companyName = currentCompanyName;
		
	}
	// 记账处理方式
	if(payType == ""){
		alert("请选择转账处理方式");
		return;
	}
	if(payAccName == ""){
		alert("请输入本方账号名称");
		return;
	}
	if(payAccNo == ""){
		alert("请输入本方账号");
		return;
	}
	if(recAccName == ""){
		alert("请输入对方账号名称");
		return;
	}
	if(recAccNo == ""){
		alert("请输入对方账号");
		return;
	}
	
	/**
	 * 判断系统内外标记：
	 * 如果是系统外，则需要判断是否选择或输入相关的行号和行名
	 */	
	if(sysIOFlag === "2"){
		// 获取录入方式
		var recordType = $("input:radio[name='recordType']:checked").val();
		var recCityName = $("#recCityName").val();
		if(recCityName == ""){
			alert("请输入收款方所在城市名称！");
			return;
		}
		params.recCityName = recCityName;
		if(recordType === "0"){
			bankNo = $("#bankNoSelect").val();
			branchBankNo = $("#branchBankNoSelect").val();
			if((bankNo == "" || branchBankNo == "")){
				alert("请选择收款人账户所属银行！");
				return;
			}
			params.recBankNo = branchBankNo;
			params.recBankName = $("#branchBankNoSelect option:selected").text();
		}else{
			inputBankNam = $("#inputBankName").val();
			if(inputBankNam == "" || inputBankNam.trim() == ""){
				alert("请输入收款人账户所属银行！");
				return;
			}
			branchBankNo = $("#branchBankNoSelect").val();
			if(branchBankNo)
			params.recBankNo = branchBankNo;
			params.recBankName = inputBankNam;
		}
	}
	/**
	 * 判断金额输入问题
	 */
	var reg = /^\d+(\.\d{0,2})?$/
	if(!reg.test(payAmt)){
		alert("付款金额输入有误，请输入数字！");
		$("#payAmount").focus().select();
		return;
	}
	/**
	 * 填充数据
	 */
	params.payerId = currentCustomerId;
	params.payerName = currentUserName;
	params.payAccName = payAccName;
	params.payAccNo = payAccNo;
	params.reciverId = customerId;
	params.reciverName = $("#supplierNameSelect option:selected").text();
	params.recAccName = recAccName;
	params.recAccNo = recAccNo;
	params.sysIOFlag = sysIOFlag;
	params.payAmt = payAmt;
	params.isPub = isPub;
	params.payType = payType;
	params.currType = $("input:radio[name='currType']:checked").val();
	params.postScript = note;
	
//	console.info(params);
	return params;
}

/**
 * 获取付款单账号信息
 */
function getPayerAccInfo(){
	var params = getParams();
	var result = execjava("upPaymentBean.payAccInfoQuery", params, 'json');
	var $selectName = $("#payAccountName");
	$selectName.attr("disabled", true);
	var $selectNo = $("#payAccountNo");
	 $("#payAccountNo").html('');
	 $("#payAccountName").html('');
	var payList = result.accNoList;
	// 同时往两个 select 中填充数据
	for(var i=0,len=payList.length;i<len;i++){
		var optionsNo = $("<option>");
		var optionsName = $("<option>");
		optionsNo.attr("value",payList[i].accNo);
		optionsNo.html(payList[i].accNo);
		optionsName.attr("value", payList[i].accNo);
		optionsName.html(payList[i].accName);
		optionsNo.append("</option");
		$selectNo.append(optionsNo);
		optionsName.append("</option");
		$selectName.append(optionsName);
	}
}
/**
 * 渲染收款账户数据
 * @param customerId 对应的供应商编号
 */
function renderRecAccInfo(result){
	var $selectNo = $("#recAccNo");
	var $selectName = $("#recAccName");
	$("#recAccNo").html('');
	$("#recAccName").html('');
	$selectName.attr("disabled", true);
	var payeeList;
	if(result&&result.hasOwnProperty("recAccNoList"))
		payeeList = result.recAccNoList;
	if(!payeeList&&payeeList.length <= 0){
		alert("对应的 “" + $("#supplierNameSelect option:selected").text() + "”供应商没有收款账号！");
		$("#recAccNo").html('');
		$("#recAccName").html('');
		return;
	}
	// 同时往两个 select 中填充数据
	for(var i=0,len=payeeList.length;i<len;i++){
		var optionsNo = $("<option>");
		var optionsName = $("<option>");
		if(payeeList[i].hasOwnProperty("customerId")){
			optionsNo.attr("value",payeeList[i].accNo);
			optionsNo.html(payeeList[i].accNo);		
			optionsName.attr("value", payeeList[i].accNo);
			optionsName.html(payeeList[i].accName);
		}else{
			optionsNo.attr("value",payeeList[i].recAccNo);
			optionsNo.html(payeeList[i].recAccNo);		
			optionsName.attr("value", payeeList[i].recAccNo);
			optionsName.html(payeeList[i].recAccName);
		}
		optionsNo.append("</option");
		$selectNo.append(optionsNo);
		optionsName.append("</option");
		$selectName.append(optionsName);
	}
	autoReceivingInfo(payeeList[0].accNo);
}

/**
 * 获取分公司数据
 */
function getBranchCompany($select){
	var result = execjava("companyInfoBean.getBranchCompanyInfo",null,'json');
	if(!result || result.status != '000'){
		alert("分公司信息获取失败");
		return;
	}
	var branchCompany = result.branchCompany;
	$select.append("<option value=''>请选择分公司</option>");
	for(var i = 0,len=branchCompany.length; i<len; i++){
		var $option = $("<option>");
		$option.attr("value", branchCompany[i].companyId);
		$option.html(branchCompany[i].companyName);
		$option.append('</option>');
		$select.append($option);
	}
}
/**
 * 获取所有的供应商信息
 */
function getCustomerInfo(){
	var params = {};
	if(isHasBranchCompany){
		params.companyId = $("#companyInfoSelect").val();
	}else{
		//params.companyId = getCustId();
		params.companyId = "";
	}
	var result = execjava("factoringBean.recAccInfoQuery", params, 'json', factoringservice);
	if(!result || result.retCode != '200'){
		alert("供应商信息获取失败");
		return;
	}
	var customerList = result.recAccNoList;
	renderCustomerData(customerList);
}

/**
 * 渲染数据
 * 
 * @param customerList 数据集合
 * @param data	选择的供应商
 */
function renderCustomerData(customerList){
	if(customerList == null){
		return;
	}
	var $select = $("#supplierNameSelect");
	$select.html('');
	$select.append("<option value=''>请选择供应商</option>");
	/**
	 * 这里查询的数据的时根据分公司查询到跟该分公司关联的所有收款账号，一个供应商可能存在多个收款账户的问题，所有这里要去除重复的数据
	 * 存储对应的供应商编号（customerId），用于去除重复的数据:
	 */
	var removeRepeat = [];
	for(var i = 0,len=customerList.length; i<len; i++){
		var $option = $("<option>");
		if(customerList[i].hasOwnProperty("customerId")){
			if(removeRepeat.indexOf(customerList[i].customerId) > -1){
				continue;
			}
			removeRepeat.push(customerList[i].customerId);
			$option.attr("value", customerList[i].customerId);
			$option.html(customerList[i].customerName);
		}else{
			if(removeRepeat.indexOf(customerList[i].reciverId) > -1){
				continue;
			}
			removeRepeat.push(customerList[i].reciverId);
			$option.attr("value", customerList[i].reciverId);
			$option.html(customerList[i].reciverName);
		}
		$option.append('</option>');
		$select.append($option);
	}
}

/**
 * 
 */
function selectBranchCompany(){
	$('#supplierNameSelect').html('');
	$('#payAccountNo').html('');
	$('#payAccountName').html('');
	$("#recAccNo").html('');
	$("#recAccName").html('');
	if($("#commonAccNo").attr("checked")){
		renderCustomerData(getCommonAcc($("#commonAccNo")[0]));
	}else{
		//获取供应商
		getCustomerInfo();
		// 获取付款账户信息
		getPayerAccInfo();
	}
}
/**
 * 更改收款账户时相应的更改供应商信息
 */
function changePayAccNo(){
	if($("#commonAccNo").attr("checked")){
		var customer = getCommonAcc($("#commonAccNo")[0]);
		renderCustomerData(customer);
	}
}

/**
 * 修改账号时，同步修改对应的账户名
 * @param obj
 * @param value
 */
function changeAccName(obj, value, id){
	$("#" + id + " option[value='" + value +"']").attr("selected", true);
	autoReceivingInfo(value);
}

/**
 * 更改供应商时相应的更改收款账号
 */
function changeCustomer(value){
		renderRecAccInfo(getRecAccInfo(value));
}

/**
 * 调用后台获取数据
 * @param customerId
 * @return	result：<br/>
 * 			result.retCode  返回码，200-支付成功  999-支付失败<br/>
 *			result.retMsg   返回信息<br/>
 * 			result.recAccNoList  查询返回的收款账户信息列表，AccountEntity
 */
function getRecAccInfo(customerId){
	if(!customerId){
		alert("请选择供应商");
		return;
	}
	var params = getParams();
	params.customerId = customerId;
	
	var result = execjava("factoringBean.recAccInfoQuery", params, 'json', factoringservice);
	return result;
}

/**
 * 获取常用账号信息
 * @param obj
 * @returns commonAcc;
 */
function getCommonAcc(obj){
	var params = getParams();
	var payAccountNo = $("#payAccountNo").val();
	var payAccountName = $("#payAccountName option:selected").text();
	var reciverId = $("#supplierNameSelect").val();
	if(!params.flag || payAccountNo == "" || payAccountNo == null){
		alert("请选择分公司或本方账号信息！");
		obj.checked = false;
		return null;
	}
	params.payAccNo = payAccountNo;
	params.payAccName = payAccountName;
	if(reciverId != "" && reciverId != null){
		params.reciverId = reciverId;
	}
	/**
	 * retCode  返回码，200-支付成功  999-支付失败
	 * retMsg   返回信息
	 * commonAccNoList  返回的收款账户信息列表，类型为List<CommonAccountEntity>
	 */
	var result = execjava("factoringBean.commonRecAccInfoQuery", params, 'json', factoringservice);
	var commonAcc = result.commonAccNoList;
	if(commonAcc.length == 0){
		alert("当前选择的账户信息不存在常用对方账户！");
		obj.checked = false;
		return null;
	}
	$("#recAccNo").html('');
	$("#recAccName").html('');
	return commonAcc;
}

function getParams(){
	var companyId = "";
	if(isHasBranchCompany){
		companyId = $("#companyInfoSelect").val();
	}else{
		companyId ="";
	}
	var params = {};
//	if(companyId == null || companyId == ""){
//		params.flag = false;
//		return params;
//	}
	params.companyId = companyId;
	params.flag = true;
	return params;
}
/**
 * 获取银行列表信息
 * @param bankNo
 */
function getBankBrankList(bankNo){
	var branchName = $("#inputBranchName").val();
	var params = {
		"page" : 1,
		"limit" : 0,
		"bankNo" : bankNo,
		"bankName" : ""
	}
	var result = execjava("upPaymentBean.bankQuery", params, 'json');
	if(!result){
		alert("银行列表信息获取失败！");
		return;
	}
	var bankList = result.bankList;
	if(!bankList || bankList.length == 0){
		return;
	}
	//填充select下拉列表
	var $select = $("#bankNoSelect");
	$select.html("");
	$select.append($("<option value=''></option>").html("-----请选择-----"));
	for(var i = 0, len = bankList.length; i < len; i++){
		var $option = $("<option>");
		$option.attr("value", bankList[i].bankNo);
		$option.html(bankList[i].bankName);
		$option.append("</option>");
		$select.append($option);
	}
}
/**
 * 根据银行编号及关键字查询银行网点的信息
 */
function queryBankBranch(){
	$("#branchBankNoSelect").html("");
	var bankNo = $("#bankNoSelect").val();
	if(bankNo == null || bankNo == ""){
		alert("请选择所属银行！");
		return;
	}
	var keyWord = $("#branchKeyWord").val();
	if(keyWord == "" || keyWord.trim() == ""){
		alert("请输入银行网点关键字！");
		return;
	}
	var params = {
		"page" : 1,
		"limit" : 0,
		"bankNo" : bankNo,
		"branchName" : keyWord
	}
	var result = execjava("upPaymentBean.bankBranchQuery", params, 'json');
	var branchList = result.bankBranchList;
	if(!branchList || branchList.length == 0){
		return;
	}
	//填充select下拉列表
	var $select = $("#branchBankNoSelect");
	$select.html("");
	$select.append($("<option value=''></option>").html("-----请选择-----"));
	for(var i = 0, len = branchList.length; i < len; i++){
		var $option = $("<option>");
		$option.attr("value", branchList[i].branchNo);
		$option.html(branchList[i].branchName);
		$option.append("</option>");
		$select.append($option);
	}
}

//-------------------------------------------添加账号-------------begin
//打开添加付款账户对话框
function openAddPayAccWin(id){
	//加载dom
	$("#addPayAccDom").html(template.render("addPayAccTpl",{}));
	if(isHasBranchCompany){
		getBranchCompany($("#addPayAccCompanyInfo"));
	}else{
		$select=$("#addPayAccCompanyInfo");
		option=makeOption(null,getCustId(),currentCompanyName,true);
		$select.append(option);
	}
	showBg(id);
}
//保存付款账户
function addPayAccAccount(){
	var payAccParam = Utils.form2json("#payAccForm",false);
	payAccParam.companyId=$("#addPayAccCompanyInfo").val();
	payAccParam.companyName=$("#addPayAccCompanyInfo option:selected").text();
	for(var key in payAccParam){
		if(payAccParam.hasOwnProperty(key)){
			var value = payAccParam[key];
			if(value == "" || value == null || value.trim() == ""){
				alert("请确认是否存在空值！");
				$("input[name='" + key + "']")[0].focus();
				return;
			}
		}
	}
	var payResult = execjava("factoringBean.accInfoDBAdd", payAccParam, 'json', factoringservice);
	if (payResult.retCode != "200") {
		alert("账号添加失败！");
		return;
	}
	//页面刷新付款账号列表
	getPayerAccInfo();//显示付款账户
	closeBg("addPayAccWindow");
}
//打开添加收款账户对话框
function openAddRecAccWin(id){
	$("#addRecAccDom").html(template.render("addRecAccTpl",{}));
	if(isHasBranchCompany){
		getBranchCompany($("#addRecAccCompanyInfo"));
		$("#addRecAccCompanyInfo").attr("disabled", false);//使下拉类表可用
	}else{
		$select=$("#addRecAccCompanyInfo");
		option=makeOption(null,getCustId(),currentCompanyName,true);
		$select.append(option);
		getAllCustomer($("#addrec_recCustomer"));//加载所有供应商
		$("#addrec_recCustomer").attr("disabled", false);//使下拉类表可用
	}
	showBg(id);
}
//添加收款账户切换分公司事件
function addRecAccCompanyInfoEvent(doc){
	if(!doc.value) {
		$("#addrec_recCustomer").html('');
		$("#addrec_recCustomer").attr("disabled", true);//使下拉类表不可用
		return;
	}
	getAllCustomer($("#addrec_recCustomer"));
	$("#addrec_recCustomer").find("option").each(function(){//删除不需要的不对等的供应商
		if(doc.value!=$(this).attr("companyId"))
		    $(this).remove();
	});
	$("#addrec_recCustomer").attr("disabled", false);//使下拉类表可用
}
//保存收款账户
function addRecAccAccount(){
	var recAccParam = Utils.form2json("#recAccForm",false);
	recAccParam.companyId=$("#addRecAccCompanyInfo").val();
	recAccParam.companyName=$("#addRecAccCompanyInfo option:selected").text();
	recAccParam.customerId=$("#addrec_recCustomer").val();
	recAccParam.customerName=$("#addrec_recCustomer option:selected").text();
	for(var key in recAccParam){
		if(recAccParam.hasOwnProperty(key)){
			var value = recAccParam[key];
			if(value == ""){
				alert("请确认是否存在空值！");
//				if(key != "customerId"){
//					alert(key);
//					$("input[name='" + key + "']")[1].focus();
//				}
				return;
			}
		}
	}
	var recResult = execjava("factoringBean.accInfoDBAdd", recAccParam, 'json', factoringservice);
	if (recResult.retCode != "200") {
		alert("账号添加失败！");
		return;
	}
	initPage();
	closeBg("addRecAccWindow");
}

/**
 * 获取所有的经销商
 */
function getAllCustomer($select){
	var result = execjava("userInfoBean.getCustomerInfo",null,'json');
	if(!result){
		alert("供应商信息获取失败");
		return;
	}
	var customerList = result.customerList;
	$select.html('');
	for(var i = 0,len=customerList.length; i<len; i++){
		var $option = $("<option>");
		$option.attr("value", customerList[i].customerId);
		$option.html(customerList[i].userName);
		$option.attr("companyId",customerList[i].companyId);
		$option.append('</option>');
		$select.append($option);
	}
}

function makeOption(id,value,html,isSelected){
	var $option = $("<option>");
	value&&$option.attr("value", value);
	id&&$option.attr("id", value);
	html&&$option.html(html);
	isSelected&&$option.attr("selected",true);;
	$option.append('</option>');
	return $option;
}
//-------------------------------------------添加账号-------------end

//---------------------------------付款账号 选择补全信息------------begin--
function autoReceivingInfo(receNo){
	var customerId = $("#supplierNameSelect").val();
	var params = getParams();
	params.customerId = customerId;
	params.recAccNo=receNo;
	var result = execjava("factoringBean.recAccInfoQuery", params, 'json', factoringservice);
	var recAccNoInfo=result.recAccNoList[0];
	//系统内外
	if(recAccNoInfo&&recAccNoInfo.hasOwnProperty("sysIOFlg")&&recAccNoInfo.sysIOFlg!=null&&recAccNoInfo.sysIOFlg!=""){
		//系统外
		if(recAccNoInfo.sysIOFlg=="2"){
			$("input[name=sysIOFlg][type='radio'][value= '2']").attr("checked","checked");
			$("#ReceiveCityName").show();
			$("#recCityName").val(recAccNoInfo.recCityName?recAccNoInfo.recCityName:"");
			//手工输入
			$("#RecordType").show();
			$("#InputRecordType").show();
			$("input[name=recordType][type='radio'][value='1']").attr("checked","checked");
			//银行名称
			if(recAccNoInfo.recBankName){
				$("#inputBankName").val(recAccNoInfo.recBankName);//银行名称
				$("#branchBankNoSelect").append(makeOption("ii3",recAccNoInfo.recBankNo,"",true));//银行账号
			}
			return;
		}
	}
	$("input[name=sysIOFlg][type='radio'][value= '1']").attr("checked","checked");
	$("#BankList").hide();
	$("#BankBranchList").hide();
	$("#RecordType").hide();
	$("#ReceiveCityName").hide();
	$("#InputRecordType").hide();
}
//---------------------------------付款账号 选择补全信息------------end--



