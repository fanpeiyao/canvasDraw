template.openTag = "<%";
template.closeTag = "%>";
//上游保理服务
var factoringservice = "factoringservice";
/**
 * 数据渲染
 */
function renderData(){
	var result = getPaymentDetail();
	// 付款单详情页面
	renderDetailInfo(result);
	$("#addAccDom").css("display", "none");
	/**
	 * 判断是否显示分公司：isHasBranchCompany 【该变量定义在： "~main/config/data.js"】
	 * true：表示存在
	 * false：表示没有分公司，只有一个核心企业
	 */
	if(isHasBranchCompany){
		$("#companyInfoLi").css("display","block");
	}else{
		$("#companyInfoLi").css("display","none");
	}
}
/**
 * 获取付款单及供应商相关数据
 * 
 * @returns	result对象，包含下列数据：</br>
 * 			result.retCode  返回码，200-查询成功  999-查询失败</br>
 * 			result.retMsg   返回信息</br>
 * 			result.paymentList  查询的付款单列表
 */
function getPaymentDetail(){
	var paymentNo = S3Params.getData("paymentId");
	var params = {
		"equalsPaymentNo" : paymentNo,
		"queryType":1
	}
	var result = execjava("upPaymentBean.paymentDetail", params, 'json');
	return result;
}

/*********************************付款单详情**************************************************/
/**
 * 渲染付款单详情数据
 * @param result 付款单数据
 */
function renderDetailInfo(result){
	var payment = result.paymentList;
	var html = template.render("paymentDetailTpl",{
		payment : payment
	});
	$("#newPaymenDom").html(html);
	/**
	 * 根据系统内外标识判断是否显示相应的行名行号相关信息
	 */
	if(payment.sysIOFlg == "2"){
		$("#BankList").show();//收款人账户所属银行
		//$("#BankBranchList").show();
		$("#RecordType").show();   //这一个与下面一个在手动输入与级联查询中均会有所显示
		$("#ReceiveCityName").show();
		if($("input:radio[name='recordType']:checked").val() == "1"){
			$("#BankList").hide();//收款人账户所属银行
			//$("#BankBranchList").hide();
			$("#InputRecordType").show();
		}
	}
}