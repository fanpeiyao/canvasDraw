<div class="clear">
    <div class="cent-border clear" >
    	<div class="bg_td bb_tb pad10 h25 f7" id="paymentDetailDom">
    		<p class="fl_l f14">
			</p>
    		<!--  <p class="fl_r f14" id="addAccDom">
				<span class="f1 fw lin_h25">
					<a href="javascript:;" onclick="openAddRecAccWin('addRecAccWindow')">添加收款账号</a>
				</span>
				<span class="f1 fw lin_h25">
					<a href="javascript:;" onclick="openAddPayAccWin('addPayAccWindow')">添加付款账号</a>
				</span>
			</p>-->
		</div>
    	<div id='newPaymenDom'>
		</div>
	</div>
</div>
<div id="fullbg" class="pop_shadow"></div>
<!-- 添加收款账号 -->
<div class="pop_window_box" id="addRecAccWindow" style="width:500px;">
	<div class="pop_window_title">
		<i></i>添加收款账号
		<span><a href="javascript:closeBg('addRecAccWindow')">×</a></span>
	</div>
	<div class="clifycont" id="contentBody">
      	<div id="addRecAccDom"></div>
    </div>		  
   	<p class="tex_c">
	     <a href="javascript:addRecAccAccount();" class="btn btn-next skin_btn_light">添加</a>
	     <a href="javascript:closeBg('addRecAccWindow')" class="btn btn-close">关闭</a>
	</p>   
</div>
<!-- 添加付款账号 -->
<div class="pop_window_box" id="addPayAccWindow" style="width:500px;">
	<div class="pop_window_title">
		<i></i>添加付款账号
		<span><a href="javascript:closeBg('addPayAccWindow')">×</a></span>
	</div>
	<div class="clifycont" id="contentBody">
      	<div id="addPayAccDom"></div>
    </div>		  
   	<p class="tex_c">
	     <a href="javascript:addPayAccAccount();" class="btn btn-next skin_btn_light">添加</a>
	     <a href="javascript:closeBg('addPayAccWindow')" class="btn btn-close">关闭</a>
	</p>   
</div>
<?php 
	include_once 'jstpl/newPay_tpl.php';
?>
<script src="<?php echo $root_path ?>~main/js/Utils.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>common/js/number.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo $root_path ?>modules/upsPaymentservice/js/newPay.js"></script>
<script type="text/javascript">
var currentCustomerId = "<?php echo $userId?>";
var currentUserName = "<?php echo $userName?>";
var currentCompanyName = "<?php echo $salecompanyName?>";
</script>