<div class="clear">
    <div class="cent-border clear" >
    	<div class="bg_td bb_tb pad10 h25 f7" id="paymentDetailDom">
    		<p class="fl_l f14">
				<span class="fw lin_h25">
					付款单号：<font class="f4 fw"><?php echo $_POST['paymentId']?></font>
				</span>
			</p>
    		<!-- <p class="fl_r f14" id="addAccDom">
				<span class="f1 fw lin_h25">
					<a href="javascript:;" onclick="openAddWin('addWindow')">添加账号</a>
				</span>
			</p> -->
		</div>
    	<div id='newPaymenDom'>
    		<div id="newPaymenDom1">
    		</div>
    		<div class="fl_r mar_b10 mar_r30">
		<!-- 点击支付，如果支付成功，而用户刷新了页面，则此时支付功能不可用 -->
			<input type="button" value="支付" class="btn btn-next skin_btn_light" id="payButton"/>
			</div>
		</div>
	</div>
</div>
<div class="clear"></div>
<!-- 添加账号 -->
<div id="fullbg" class="pop_shadow"></div>
<div class="pop_window_box" id="addWindow" style="width:500px;">
	<div class="pop_window_title">
		<i></i>添加账号
		<span><a href="javascript:closeAddWin('addWindow')">×</a></span>
	</div>
	<div class="clifycont" id="contentBody">
		<div class="mar_b10 mar_l10" id="branchCompanyDom"></div>
      	<div id="addDom"></div>
     	<p class="page" id="financePage">
     	</p>
    </div>		  
   	<p class="tex_c">
	     <a href="javascript:addAccount();" class="btn btn-next skin_btn_light">添加</a>
	     <a href="javascript:closeAddWin('addWindow')" class="btn btn-close">关闭</a>
	</p>   
</div>
<!-- 选择付款单 对话框 -->
<div id="fullbg" class="pop_shadow"></div>
<div class="pop_window_box" id="choosePurinvoiceWindow" style="width:500px;">
	<div class="pop_window_title">
		<i></i>选择发票
		<span><a href="javascript:closeAddWin('choosePurinvoiceWindow')">×</a></span>
	</div>
	<div class="clifycont">
      	<div id="choosePurinvoiceDom"></div>
     	<p class="page" id="choosePurinvoicePage">
     	</p>
    </div>		  
   	<p class="tex_c">
	     <a href="javascript:choosePurinvoiceAffirm();" class="btn btn-next skin_btn_light">确定</a>
	     <a href="javascript:closeAddWin('choosePurinvoiceWindow')" class="btn btn-close">关闭</a>
	</p>   
</div>
<?php 
	include_once 'jstpl/pay_tpl.php';
?>
<script src="<?php echo $root_path ?>~main/js/Utils.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>common/js/number.js" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo $root_path ?>modules/upsPaymentservice/js/pay.js"></script>
<script type="text/javascript">
	var currentCustomerId = "<?php echo $userId?>";
	var currentUserName = "<?php echo $userName?>";
	var currentCompanyName = "<?php echo $salecompanyName?>";
	$(document).ready(function(){
		renderData1();
	});
</script>
