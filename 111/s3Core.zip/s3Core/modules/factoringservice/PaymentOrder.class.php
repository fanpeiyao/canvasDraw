<?php
class PaymentOrder{
	
	
	/**
	 *跳转我的贷款
	 *
	 */
	public static function selectMyFinancing($type){
		$params= array(
			"type"=>$type				
		);
		$payInfo = execjava('myFinancingBean.doMyFinancing', $params, 'php','factoringservice');
		
		if($payInfo["resCode"]!="200"){
			$retmsg = $payInfo["resMsg"];
			$failUrl = "../../~main/errorInfo.php?retmsg=".$retmsg;
			echo "<script language='javascript'>";
			echo " location.href = '$failUrl'";
			echo "</script>";
			return ;
		}
		
		$myFinancingurl = $payInfo["myFinancingurl"];
				$version = $payInfo["version"];
						$merid = $payInfo["merid"];
						$trancode = $payInfo["trancode"];
						$charset = $payInfo["charset"];
						$signature = $payInfo["signature"];
						$reqdata = $payInfo["b64reqdata"];
	
						echo "<form  id='payform' name='payform' action='$myFinancingurl' method='post'>";
						echo "<input type=hidden id='version'  name='version' value='$version'>";
						echo "<input type=hidden id='charset'  name='charset' value='$charset'>";
						echo "<input type=hidden id='merid'  name='merid' value='$merid'>";
						echo "<input type=hidden id='signature'  name='signature' value='$signature'>";
						echo "<input type=hidden id='trancode'  name='trancode' value='$trancode'>";
						echo "<input type=hidden id='reqdata'  name='reqdata' value='$reqdata'>";
			echo "<input style='display: none' type='submit' value='Submit'/>";
			 echo "</form>";
			echo "<script language='javascript'>";
			echo " document.getElementById('payform').submit();";
						echo "</script>";
				return ;
		}

		
}

?>