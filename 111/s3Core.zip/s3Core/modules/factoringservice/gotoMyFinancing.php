<!DOCTYPE html>
<html>
<head></head>
<body>

<?php 
//ini_set("include_path",".;D:\\dev2\\tomcat7.0.55\\webapps\\ultimate");

	$type = $_REQUEST['type'];	
	require_once '~main/ctx.php';    	
	require_once 'PaymentOrder.class.php';
	$payInfo=PaymentOrder::selectMyFinancing($type);
?>
</body>
</html>
