<!--right start-->
<div class="right">
	<div class="cent-border">
		<div class="title-side">请选择筛选条件:</div>
		
		<div class="condit">
			<span>客户编号/名称：<input id="customerId" type="text" class="input-text" />
			</span> <span>申请时间：<input id="start_date" type="text"
				class="input-text w100 input1_data"
				onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });" />
				-<input id="end_date" type="text"
				class="input-text w100 input1_data"
				onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });" />
				<a href="javascript:;" class="btn_small skin_btn_light"
				onclick="searchByKey();">搜索</a> <a href="javascript:;"
				class="btn_small skin_btn_dark" onclick="clean();">重置</a>
			</span>
		</div>
		
		<div class="condit">

			<p id="statusSearch">
				状 态： <font><a href="javascript:;" statusId="0"
					onclick="statusSearch(0);" class="search-current">全部</a> </font> <font><a
					href="javascript:;" statusId="1" onclick="statusSearch(1);">待激活</a>
				</font> <font><a href="javascript:;" statusId="2"
					onclick="statusSearch(2);">已激活</a> </font> <font><a
					href="javascript:;" statusId="3" onclick="statusSearch(3);">已禁用</a>
				</font>
			</p>
		</div>

		<div class="mar10">
			<div id='customerVerifyListTpl' class="mar_t20"></div>
			<p class="page" id="pager"></p>
		</div>
		
	</div>
</div>
<!--right end-->
<?php include_once 'tpl/customerVerifyList_tpl.php';?>
<script src="<?php echo $root_path ?>modules/unionService/js/customerVerifyList.js" type="text/javascript"></script>