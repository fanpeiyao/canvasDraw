<!--修改密码开始--> 
<div class="cent-border">
	<div class="title-side border-top skin-border"><i class="iconfont icon-xiugaimima skin-color"></i> 修改密码</div>

	<div class="mar_t20">
		<!--输入框-->
		<div class="modifybox">
			<div>
				<p>原始密码：<input type="password" id="oldpwd" class="input1 w200" onblur="check('oldpwd');"/> <font class="f1">*</font></p>
				<p>新的密码：<input type="password" id="newpwd" class="input1 w200"  onblur="check('newpwd');"/> <font class="f1">*</font></p>
				<p>确认密码：<input type="password" id="confirmPwd" class="input1 w200" onblur="check('confirmPwd');"/> <font class="f1">*</font></p>
			</div>
			<!--错误提示-->
			<div id="errorTip" class="error hidden">
				<i class="icon-error"></i><font id="loginres">您输入的密码不正确</font>
			</div>
		</div>
		<!--按钮-->
		<div class="pad20 tex_c"><a href="javascript:;" class="btn_small skin_btn_light" id="savePass">确认</a></div>
		<!--温馨提示-->	
		<div class="tips">
			<p class="mar_t15">请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。</p>
			<p>为了保护您账号的安全,请不要将密码设置为其他网站(如:其它游戏、邮箱、聊天工具等)相同的密码。</p>
			<p>建议您每隔一段时间修改您的密码，以防密码泄漏。</p>
		</div>
	</div>
</div>

<script src="<?php echo $root_path ?>modules/unionService/js/rsaoath.min.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/modifyPwd_form.js" type="text/javascript"></script>
<!--right end-->
