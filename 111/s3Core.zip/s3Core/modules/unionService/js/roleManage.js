var count=10;//分页
var oldId;//当前被选中的roleId
var roleList;//角色列表
$(document).ready(function() {
	template.openTag = "<%";
	template.closeTag = "%>";
	
	getRoleList(1);
	var triggers = $(".modalInput").overlay({
	    mask: {
        	color: '#ebecff',
        	loadSpeed: 1,
        	opacity: 0.8
        },
        fixed: false,
        closeOnClick: false
    });
});

function search(pageNum){
	var roleNameVague = $("#roleNameSearch").val();
	roleNameVague = roleNameVague.trim();
	var roleListTmp = [];
	var num = 0;
	var pageTotal = 0;
	if (roleList != null && roleList.length > 0 && roleNameVague != null && roleNameVague != ""){
		for (var i = 0; i < roleList.length; i++){
			if (roleList[i].RoleEntityname.indexOf(roleNameVague) != -1){
				roleListTmp[num++]=roleList[i];
			}
		}
		
		pageTotal = parseInt((parseInt(num)+parseInt(count-1))/count);// 总页数
		//分页
	    $("#pager").pager({ 
	      pagecount: pageTotal, 
	      pagenumber: pageNum, 
	      buttonClickCallback: function(pageclickednumber){search(pageclickednumber);} 
	    });
	    
	   //模板渲染
	    var roleTpl = template.render('roleList', {
	    			roleList:roleListTmp,
	    		    pagenumber: pageNum,  //第几页
	    			limit:count,          //每页显示数
	    			num:num               //总记录数
			     }); 
	    $("#roleTpl").html(roleTpl);
	    $("#roleNameSearch").val(roleNameVague);
	} else if (roleNameVague == null || roleNameVague == ""){
		getRoleList(1);
	}	
}

function clearForm(){
	$("#roleNameSearch").val("");
}

function getRoleList(pageNum){
	var params={
			"page":pageNum,
			"limit":count
	};
	var ary = execjava('unionRoleBean.getRoleList', params, 'json',"usermanage");
	if(ary.status!="000"){
        alert(ary.retmsg);
        return;
    }
	roleList = ary.roleList;//获取的全部roleList
    var num = ary.count;//总记录数
	var pageTotal = parseInt((parseInt(num)+parseInt(count-1))/count);// 总页数
    //分页
    $("#pager").pager({ 
      pagecount: pageTotal, 
      pagenumber: pageNum, 
      buttonClickCallback: function(pageclickednumber){getRoleList(pageclickednumber);} 
    });
    
   //模板渲染
    var roleTpl = template.render('roleList', {
    			roleList:ary.roleList,
    		    pagenumber: pageNum,  //第几页
    			limit:count,          //每页显示数
    			num:num               //总记录数
		     }); 
    $("#roleTpl").html(roleTpl);
}

/*++++++++++++++++++++++++++++++弹出框 start++++++++++++++++++++++++++++++*/
function addDiag(){
	var roleInfoHtml = template.render('roleInfoManager', {	
		isUpdate : false	//增加
	});  
    $("#roleInfoHtml").html(roleInfoHtml);
	$("#role_trigger").click();
	$("#roleInfo").css("top", (($(window).height() / 2) - ($("#roleInfo").outerHeight() / 2))>0?($(document).scrollTop()+($(window).height() / 2) - ($("#roleInfo").outerHeight() / 2)):0);
}

function updateDiag(roleId, roleName, enable){
	oldId = roleId;
	var roleInfoHtml = template.render('roleInfoManager', {
		roleId:roleId, 
		roleName:roleName,
		isUpdate : true	//修改
	}); 	
    $("#roleInfoHtml").html(roleInfoHtml);
    $("#enableRole").val(enable);
	$("#role_trigger").click();
	$("#roleInfo").css("top", (($(window).height() / 2) - ($("#roleInfo").outerHeight() / 2))>0?($(document).scrollTop()+($(window).height() / 2) - ($("#roleInfo").outerHeight() / 2)):0);
}

function viewUsers(pageNum, roleId, roleName){
	var parm={roleId:roleId,roleName:roleName,pageNum:pageNum,limit:count};
	var userInfo = execjava("unionRoleBean.queryUserInfo",parm,'json',"usermanage");
	var num = userInfo.userList.length;//总记录数
	var pageTotal = parseInt((parseInt(num)+parseInt(count-1))/count);// 总页数

	var roleInfoHtml = template.render('viewUsers', {
		roleId:roleId, 
		roleName:roleName,
		userInfo:userInfo,
		pagenumber: pageNum,  //第几页
		limit:count,          //每页显示数
		num:num               //总记录数
	}); 	
	
	$("#roleInfoHtml2").html(roleInfoHtml);
	document.getElementById("title").innerHTML = "角色" + roleName + "下的用户";
	//分页
    $("#userpager").pager({ 
      pagecount: pageTotal, 
      pagenumber: pageNum, 
      buttonClickCallback: function(pageclickednumber){viewUsers(pageclickednumber,roleId,roleName);} 
    });
	$("#role_trigger2").click();
	$("#roleInfo2").css("top", (($(window).height() / 2) - ($("#roleInfo2").outerHeight() / 2))>0?($(document).scrollTop()+($(window).height() / 2) - ($("#roleInfo2").outerHeight() / 2)):0);	
}

//查询角色下方法
function functionSetup(roleId, roleName){
	var parm={roleId:roleId,roleName:roleName};
	//当前用户function
	var UserFunctions=execjava("unionRoleBean.queryFunctionInfo",parm,'json',"usermanage");
	//所有用户function
	var allUserFunctions=execjava("unionFunctionBean.queryFunction",parm,'json',"usermanage");
	var roleInfoHtml = template.render('allocateFunctions', {
		roleId:roleId, 
		roleName:roleName,
		isUpdate : true	//修改
	}); 	
    $("#roleInfoHtml3").html(roleInfoHtml);
    document.getElementById("title").innerHTML = roleName + "权限分配";
	$("#role_trigger3").click();
	$("#roleInfo3").css("top", (($(window).height() / 2) - ($("#roleInfo3").outerHeight() / 2))>0?($(document).scrollTop()+($(window).height() / 2) - ($("#roleInfo3").outerHeight() / 2)):0);
	
	var idArrays=new Array();
	//现有方法
	var oldf=UserFunctions.nowfunctions;
	for(var k=0;k<oldf.length;k++){//组装
		idArrays[k]=oldf[k].id;
	}
	for(var k=0;k<allUserFunctions.functionList.length;k++)
	{		
		for(var j=0;j<idArrays.length;j++){
			if(idArrays[j]==allUserFunctions.functionList[k].id)
			{
				allUserFunctions.functionList[k].checked=true;
			}
		}       
	}
	//如果现有方法在总方法里有，去除
	var setting = {
			view: {
				selectedMulti: false
			},
			check: {
				enable: true
			},
			data: {
				simpleData: {
					enable: true
				}
			},
			callback: {
				onCheck: onCheck
			}
		};

		var clearFlag = false;
		function onCheck(e, treeId, treeNode) {
			if (clearFlag) {
				clearCheckedOldNodes();
			}
		}
		function clearCheckedOldNodes() {
			var zTree = $.fn.zTree.getZTreeObj("functionTree"),
			nodes = zTree.getChangeCheckedNodes();
			for (var i=0, l=nodes.length; i<l; i++) {
				nodes[i].checkedOld = nodes[i].checked;
			}
		}
		$.fn.zTree.init($("#functionTree"), setting, allUserFunctions.functionList);
		$("#roleFunctions").attr("roleId",roleId);
}

function closeDiag(){
	$("#role_popupclose").click();
}

function closeDiag2(){
	$("#role_popupclose2").click();
}

function closeDiag3(){
	$("#role_popupclose3").click();
}
/*++++++++++++++++++++++++++++++弹出框 end++++++++++++++++++++++++++++++*/

function addRole(){
	var roleId = $("#roleID").val();
	var roleName =$("#roleName").val();
	
//	if(roleId==""){
//		$("#errTip").show();
//		$("#errMsg").html("请输入角色ID");
//		return ;
//	}
	if(roleName==""){
		$("#errTip").show();
		$("#errMsg").html("请输入角色名称");
		return ;
	}

	var params={
			roleId:roleId,
			roleName:roleName			
	}
	var ary = execjava('unionRoleBean.addRole', params, 'json',"usermanage");
	if(ary.status=="000"){
		alert(ary.retmsg);
		location.reload();
	}else{
        $("#errTip").show();
		$("#errMsg").html(ary.retmsg);
        return;
    }	
}

function updateRole(){
	var roleId = $("#roleID").val();
	var roleName =$("#roleName").val();
	var enable = $("#enableRole").val();
	
	if(roleId==""){
		$("#errTip").show();
		$("#errMsg").html("请输入角色ID");
		return ;
	}
	if(roleName==""){
		$("#errTip").show();
		$("#errMsg").html("请输入角色名称");
		return ;
	}
	
	var params={
			newId:roleId,
			oldId:oldId,
			roleName:roleName,
			enable:enable
	}
	var ary = execjava('unionRoleBean.updateRole', params, 'json',"usermanage");
	if(ary.status=="000"){
		alert(ary.retmsg);
		location.reload();
	}else{
		$("#errTip").show();
		$("#errMsg").html(ary.retmsg);
        return;
    }
}

function deleteRole(roleId){
	var r=confirm("是否确认删除？");
	if(!r){
		return;
	}
	var params={
			roleId:roleId
	}
	var ary = execjava('unionRoleBean.deleteRole', params, 'json',"usermanage");
	if(ary.status=="000"){
		alert(ary.retmsg);
		location.reload();
	}else{
        alert(ary.retmsg);
        return;
    }
}

function saveRoleFunctons(){//保存权限与功能关联关系
	var roleId=$("#roleFunctions").attr("roleId");	
	var zTree = $.fn.zTree.getZTreeObj("functionTree");
	var addList=new Array();
	var delList=new Array();
	var changedList=zTree.getChangeCheckedNodes();
	for (var k=0;k<changedList.length;k++)
	{
		if(changedList[k].checked){
			addList[addList.length]=changedList[k].id;
			}
		if(changedList[k].checked==false){
			delList[delList.length]=changedList[k].id;
			}
	}
	var addFunctionIds=addList+"";
	var delFunctionIds=delList+"";
	var param={"roleId":roleId,
			"addFunctionIds":addFunctionIds,
			"delFunctionIds":delFunctionIds
			};
	
	var ary=execjava("unionRoleBean.updateRoleFunction",param,'json',"usermanage");
	if(ary.status=="000"){
		alert(ary.retmsg);
		location.reload();
	}else{
		$("#errTip").show();
		$("#errMsg").html(ary.retmsg);
        return;
    }	
}

function searchClick(pageNum){//特定角色下的用户查找
	var roleId    = $("#roleID").val();
	var roleName  = $("#roleName").val();
	var userName  = $.trim($("#nameSearch").val());
	var loginName = $.trim($("#loginNameSearch").val());
	var mobilePhone = $.trim($("#mobileSearch").val());
	var customId    = $.trim($("#dearNoSearch").val());	
	
	var param = {roleId:roleId,userName:userName,loginName:loginName,mobilePhone:mobilePhone,customId:customId};
	
	var userInfo = execjava("unionUserBean.getUserList",param,'json',"usermanage");
	if(userInfo.status!="000"){
		alert(userInfo.retmsg);
		return;
	}
	
	var num = userInfo.userList.length;//总记录数
	var pageTotal = parseInt((parseInt(num)+parseInt(count-1))/count);// 总页数

	var roleInfoHtml = template.render('viewUsers', {
		roleId:roleId, 
		roleName:roleName,
		userInfo:userInfo,
		pagenumber: pageNum,  //第几页
		limit:count,          //每页显示数
		num:num               //总记录数
	}); 	
	
	$("#roleInfoHtml2").html(roleInfoHtml);
	document.getElementById("title").innerHTML = "角色" + roleName + "下的用户";
	$("#nameSearch").val(userName);
	$("#loginNameSearch").val(loginName);
	$("#mobileSearch").val(mobilePhone);
	$("#dearNoSearch").val(customId);
	
	//分页
    $("#userpager").pager({ 
      pagecount: pageTotal, 
      pagenumber: pageNum, 
      buttonClickCallback: function(pageclickednumber){searchClick(pageclickednumber);} 
    });
}

function clearSearch(){
   $("#nameSearch").val("");
   $("#loginNameSearch").val("");
   $("#mobileSearch").val("");
   $("#dearNoSearch").val("");
}

function propelling(){
	$.ajax(path + "~main/share/creatRoleFun.php");
	window.location.href = window.location.href;
}