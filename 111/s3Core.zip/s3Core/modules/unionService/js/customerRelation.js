var operatorList = null;
var userservice = 'usermanage';
var userList = null;
var relationList = null;

var roleName = { "1":"经销商","2":"业务员","4":"内勤","3":"管理员","5":"财务","6":"仓库管理员","7":"经销商采购","8":"经销商财务","9":"总经理","11":"供应商","12":"上游业务员"};
var errinfo = {
		"40001":"系统错误",
		"40002":"参数错误",
		"40041":"修改用户对应关系失败",
		"40042":"该用户未注册，无法绑定",
		"40043":"获取用户列表失败",
		"40051":"编辑用户对应公司失败",
		"40052":"解除公司关系失败，至少绑定一家公司",
		"40053":"解除公司信息失败",
		"40054":"绑定用户公司关系失败"
};

$(document).ready(function() {
	//用于弹出框展示
	var triggers = $(".modalInput").overlay({
		// some mask tweaks suitable for modal dialogs
	    mask: {
	      color: '#ebecff',
	      loadSpeed: 1,
	      opacity: 0.8
	    },
	    fixed: false,
	    closeOnClick: false
	});
	loadAllRoles();
	document.getElementById("roleSelector").options[1].selected=true;
	//页面初始化载入数据
	loadData(1);
});




/**
 * 页面初始化，载入数据
 */
function loadData(pageNum,searcheKey){
	var params = {
		"page":pageNum
	};
	var searchKey = $("#searchId").val();
	var roleId = $("#accountRoleId").val();
	var type = $("#roleSelector").val();
	searchKey = $.trim(searchKey);
	roleId = $.trim(roleId);
	
	if(searchKey!=null && searchKey != undefined && searchKey != ""){
		params.searchKey = searchKey;
	}
	if(roleId!=null && roleId != undefined && roleId != ""){
		params.roleId = roleId;
	}
	if(type!=null && type != undefined && type != ""){
		params.type = type;
	}
	var result=execjava("userRelateBean.getLocalUserList",params,"json");
	operatorList = result.userList;
	 
	var num = result.count;//总记录数
	var pageTotal = parseInt((parseInt(num)+parseInt(8-1))/8);// 总页数
	  //分页
	    $("#pager").pager({ 
	      pagecount: pageTotal, 
	      pagenumber: pageNum, 
	      buttonClickCallback: function(pageclickednumber){loadData(pageclickednumber);} 
	    });
	//加载数据
 	var orderProductList = template.render('customerRelationTemp', {
 		userList: operatorList
 	 });	
 	$("#customerList").html(orderProductList);	
 	
}

/**
 * 展开弹出框
 * @param divId
 * @param i
 */
function openMask(divId,i){
	if(!divId){
		return;
	}
	
	current = operatorList[i];
	
	if(divId =="customer"){
		var type = $("#roleSelector").val();
		if(type==null || type == undefined || type == ""){
			alert("请选择角色后再进行绑定客户！");
			return false;
		}
		getUserList(1);
	}
	
	if(divId =="operator"){
		getCompanyList();
	}

	$("#"+ divId +"Add").click();
	$("#" + divId + "Overlay").css("display","block");
	$("#" + divId + "Overlay").css("position","fixed");
	$("#exposeMask").css("display","block");
	$('#fullbg').show();
}

/**
 * 切换选择角色信息
 */
function changeRole(obj){
	var index = obj.selectedIndex;
	//$("#roleSelector").get(0).selectedIndex=index;
	getUserList(1);
}

/**
 * 弹出框列出用户列表
 * @param pageNumber
 */
function getUserList(pageNum){
	
	//获取查询参数
	var userId = current.UserEntityid;
	var searchKey = $("#secCustomerKey").val() == "请输入客户编号或客户名称"? "":$("#secCustomerKey").val();
	var type = $("#roleSelector").val();
	var param = { "belongTo":userId,"searchKey":searchKey.trim(),"type":type};
	
	
	//查询该用户的对应关系
	var result = execjava("userRelateBean.getUserRelation",param,"json");
	if(result.retCode != "200"){
		alert(errinfo[result.retCode]);
	}
	var relation = result.relation;
	relationList = relation;
	//加载数据
 	var userlisthtml = template.render('bindFormTemp', {
 		user:current,
 		roleName:roleName,
 		relation: relation
 	 });	
 	$("#bindForm").html(userlisthtml);
 	
 	
	var params = {"page":pageNum,"searchKey":searchKey.trim(),"belongTo":userId};
	var result2=execjava("userRelateBean.getUnbindList",params,"json");
	if(result2.retCode != "200"){
		alert(errinfo[result2.retCode]);
	}
	userList = result2.userList;
	// 展示数据
	var num = result2.count;//总记录数
	var pageTotal = parseInt((parseInt(num)+parseInt(8-1))/8);// 总页数
	 //分页
	$("#userPager").pager({ 
	      pagecount: pageTotal, 
	      pagenumber: pageNum, 
	      buttonClickCallback: function(pageclickednumber){getUserList(pageclickednumber);} 
	 });
	
	//加载数据
 	var userlisthtml = template.render('customerFormTemp', {
 		userList: userList
 	 });	
 	$("#customerForm").html(userlisthtml);
}
function loadAllRoles(){
	var result = execjava("userRelateBean.getRoleList", {},'json');
		if(!result ||!result['roles'] || !result['roles'].length){
			return;
		}
		var roles = result['roles'];
		var html = "<option value=''>所有角色</option>";
		for(var i=0;i<roles.length;i++){			
			html += '<option  value="'+ roles[i].RoleEntityid +'"　 >'+roles[i].RoleEntityname+'</option>';
		}
		jQuery("#roleSelector").html(html);
		
}

function getCompanyList(pageNumber){
	
	//获取查询参数
	var userId = current.UserEntityid;
	var customerId = current.UserEntitycustomId;
	var param = {userId:userId,customerId:customerId};
	var result = execjava("userRelateBean.getUserCompany",param,"json");
	if(result.retCode != "200"){
		alert(errinfo[result.retCode]);
		
	}
	
	bindcompanyList= result.companies;
	//渲染展示
	var bindcompanyhtml = template.render("bindCompanyList",{bindcompanyList:bindcompanyList});
	$("#bindCompanyForm").html(bindcompanyhtml);
	
	//获取公司
	var params = {userId:userId,customerId:customerId};
	var result2=execjava("userRelateBean.getCompanyList",params,"json");
	if(result2.retCode != "200"){
		alert(errinfo[result2.retCode]);
	}
	showcompanyList = result2.companies;
	// 展示数据
	var companyhtml = template.render("companyList",{companyList:showcompanyList});
	$("#companyForm").html(companyhtml);
	
}

/**
 * 解除绑定  flag=0 删除
 * @param obj
 */
function relationUnbind(obj){
	var i = obj.getAttribute("id");
	var userId = current.UserEntityid;
	var customerId = current.UserEntitycustomId;
	var relation = relationList[i];
	
	
	//查询数据库
	var params = {
			userId:relation.userId,
			flag:0,
			belongTo:userId,
			belongCustomerId:customerId,
			type:relation.type
	};
	var result=execjava("userRelateBean.editUserRelation",params,"json");
	if(result.retCode !="200"){
		alert(errinfo[result.retCode]);
	}
	//重载页面
	getUserList(1);
}

/**
 * 绑定  flag=2 插入
 */
function relationBind(obj){
	var i = obj.getAttribute("id");
	var userId = current.UserEntityid;
	var customerId = current.UserEntitycustomId;
	var user = userList[i];
	
 	var roleId = $("#roleSelector").val();
 	
 	if(roleId == ''){
 		alert("请先选择角色，再进行绑定操作！");
 		return false;
 	}
	//查询数据库
	var params = {
			userId:user.UserEntityid,
			customerId:user.UserEntitycustomId,
			type:roleId+"",
			flag:2,
			belongTo:userId,
			belongCustomerId:customerId
	};
	var result=execjava("userRelateBean.editUserRelation",params,"json");
	if(result.retCode !="200"){
		alert(errinfo[result.retCode]);
	}
	getUserList(1);
}

/**
 * 解绑公司 flag = 0
 * @param obj
 */
function companyUnbind(obj){
	var i = obj.getAttribute("id");
	var params = {
			userId:current.UserEntityid,
			customerId:current.UserEntitycustomId,
			companyId:bindcompanyList[i].SaleCompanyEntityid,
			companyName:bindcompanyList[i].SaleCompanyEntitysalecompanyName,
			flag:"0"
	};
	var result=execjava("userRelateBean.editUserCompany",params,"json");
	if(result.retCode !="200"){
		alert(errinfo[result.retCode]);
	}
	getCompanyList();
}
/**
 * 绑定公司  flag =2
 * @param obj
 */
function companyBind(obj){
	var i = obj.getAttribute("id");
	var userId = current.UserEntityid;
	var company = showcompanyList[i];
	var params = {
			userId:current.UserEntityid,
			customerId:current.UserEntitycustomId,
			companyId:company.SaleCompanyEntityid,
			companyName:company.SaleCompanyEntitysalecompanyName,
			flag:"2"
	};
	var result=execjava("userRelateBean.editUserCompany",params,"json");
	if(result.retCode !="200"){
		alert(errinfo[result.retCode]);
	}
	getCompanyList();
}



/**
 * 关闭弹出框
 * @param divId
 */
function checkRestore(divId){
	if(!divId){
		return;
	}
	clearCustomerForm();
	$("#" + divId +"Overlay").css("display","none");
	$("#exposeMask").css("display","none");
	$('#fullbg').hide();
}

/**
 * 
 */
function keyFocus(){
	var key = $("#secCustomerKey").val();
	if(key == "请输入客户编号或客户名称"){
		$("#secCustomerKey").val("");
		$("#secCustomerKey").removeClass("f11");
	}
}
function keyBlur(){
	var key = $("#secCustomerKey").val();
	if(key == ""){
		$("#secCustomerKey").val("请输入客户编号或客户名称");
		 $("#secCustomerKey").addClass("f11");
	}
}
/**
 * 重置页面搜索框
 */
function clearForm(){
	$("#searchId").val('');
	$("#accountRoleId").val(''); 
	loadData(1);
}

function clearOperatorForm(){
	
	$("#sapId").val('');
	$("#searchRoleId").val(''); 
}
function clearCustomerForm(){
	$("#secCustomerKey").val('');
	$("#secCustomerKey").blur();
}