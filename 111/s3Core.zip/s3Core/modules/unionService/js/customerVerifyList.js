/** 用户审核js */
var searchtype;
var searchstatus;
var errinfo={
		"40001":"系统错误",
		"40002":"错误的参数",
		"40003":"appid错误或不存在",
		"40004":"获取密钥失败",
		"40005":"appid、token校验错误",
		"40007":"获取手机验证码失败",
		"40008":"手机验证码校验失败",
		"40009":"手机号码与系统不一致",
		"40011":"非法的用户",
		"40012":"注册失败",
		"40013":"用户名或密码错误",
		"40014":"用户已存在",
		"40015":"修改密码失败",
		"40016":"重置密码失败",
		"40017":"用户未激活",
		"40018":"获取审核列表失败",
		"40019":"审核用户失败",
		"40020":"获取用户信息失败",
		"40021":"修改用户信息失败",
		"40022":"获取地址信息失败",
		"40023":"修改地址信息失败",
		"40033":"获取用户角色失败",
		"40034":"修改用户角色失败",
		"40041":"修改用户对应关系失败",
		"40042":"该用户未注册，无法绑定",
		"40043":"获取用户列表失败",
		"40076":"只有管理员才能进行该操作"
	};
// 模板标签
template.openTag = "<%";
template.closeTag = "%>";
var userservice = "usermanage";
var verifyType = null;

jQuery(document).ready(function() {

	f_getCustomerVerifyList(1);

});
/**
 * 清空搜索框
 */
function clean(){
	$("#customerId").val('');
	$("#start_date").val('');
	$("#end_date").val('');
};
/**
 * 根据日期，用户编号进行搜索
 */
function searchByKey() {   
	var start = $("#start_date").val();
	var end = $("#end_date").val();
	start = start.substring(0, 4) + start.substring(5, 7)
			+ start.substring(8, 10);
	end = end.substring(0, 4) + end.substring(5, 7) + end.substring(8, 10);
	if (start > end && start != "" && end != "") {
		alert("开始时间大于结束时间！");
		return;
	}
	f_getCustomerVerifyList(1);
};
/**
 * 根据用户类型进行搜索
 * @param type
 */
function typeSearch(type)
{
	if(type == 0){searchtype = null;}
	else{searchtype = type-1;}
	$("#typeSearch [typeId]").removeClass();
	$("#typeSearch [typeId = "+type+"]").addClass("search-current");
	f_getCustomerVerifyList(1);
}

/**
 * 根据审核状态进行搜索
 */
function statusSearch(status)
{
	if(status == 0){searchstatus = null;}
	else{searchstatus = status-1;}
	$("#statusSearch [statusId]").removeClass();
	$("#statusSearch [statusId = "+status+"]").addClass("search-current");
	f_getCustomerVerifyList(1);
}
/**
 * 查询客户列表
 * 
 * @param pageNum
 *            当前页码
 */
function f_getCustomerVerifyList(pageNum) {
	 var count = 8;//每页显示的记录数
	 var customerId = $("#customerId").val();
	 customerId = $.trim(customerId);
	 var params = {
			  "limit":count,
		      "page":pageNum,
    		  "searchValue":customerId,
    		  "startTime":$("#start_date").val(),
    		  "endTime":$("#end_date").val(),
    		  "status":searchstatus
    }; 
	var ary = execjava('userAuthenBean.getUserSensor', params, 'json',userservice);
	if (!ary || ary.retCode != "200") {
		alert(errinfo[ary.retCode]);
		return;
	}
	verifyType = ary.verifyType;
    //搜索到的所有记录
    var num = ary.count;
    //总页数
	var pageTotal = parseInt((parseInt(num)+parseInt(count-1))/count);//总页数   
    
	$("#pager").pager({ 
      pagecount: pageTotal, 
      pagenumber: pageNum, 
      buttonClickCallback: function(pageclickednumber){f_getCustomerVerifyList(pageclickednumber,status);
      } 
    });		

	// 模板渲染
	var customerVerifyListHtml = template.render('customerVerifyTemp', {
		customerVerifyList : ary.customerVerifyList
	});

	$("#customerVerifyListTpl").html(customerVerifyListHtml);
	
}

function editCustomerId(ele){
	if(verifyType == '1'){
		var inputs = $(ele).find("input");
		if(inputs.length > 0){
			var value = inputs.eq(0).val();
			$(ele).html(value);
		}else{
			$("#customerVerifyListTpl").find("tr").each(function(){
				
				var inp = $(this).find("td:first").find("input");
				if(inp.length > 0){
					var value = inp.eq(0).val();
					$(this).find("td:first").html(value);
				}
			});
			
			var content = $(ele).html();
			content = $.trim(content);
			$(ele).html('<input type="text" value="' + content + '" />');
			$(ele).find("input").focus();
		}
	}
}




function verifyCustomer(unionId,elem,status){
	if(!unionId || !elem)
		return ;
	var params = {};
	var msg = '';
	if(status =='1')
		msg = "确认激活此客户信息?";
	else
		msg = "确认禁用此客户信息?";
	if(!confirm(msg)){
		return;
	}
	if(verifyType == '1' && status == "1"){
		var customerId = null;
		
		var inp = $(elem).parent().parent().find("td:first").find("input");
		if(inp.length > 0){
			customerId = inp.eq(0).val();
		}else{
			customerId = $(elem).parent().parent().find("td:first").html();
		}
		customerId = $.trim(customerId);
		
		if(customerId == null || customerId == ''){
			alert('请填写客户编号！');
			editCustomerId($(elem).parent().parent().find("td:first"));
			return;
		}
		params.customerId = customerId;
	}
	
	params.unionId = unionId;
	params.status = status;
	
	
	//激活当前用户
	var ary = execjava('userAuthenBean.userSensor', params, 'json',userservice);
	if (ary == null || ary == "") {
		alert("操作用户失败！");
		return;
	}
	
	if(ary.retCode != '200'){
		alert(errinfo[ary.retCode]);
	}else{
		alert("操作成功！");
		f_getCustomerVerifyList(1);
	}
	
}
