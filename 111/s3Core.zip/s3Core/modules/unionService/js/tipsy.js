/**
 * 验证错误提示消息方法，需要jquery支持 
 * @param {Object} ele
 * @param {Object} msg
 * @param {Object}config 配置信息
 * 					gravity：错误提示框位置，共三位数：
 * 							前两位数表示提示框位置：
 * 								nn-提示框位于上方中间；ne-提示框位于上方最右边；nw-提示框位于上方最左边；
 * 								ss-提示框位于下方中间；se-提示框位于下方最右边；sw-提示框位于下方最左边；
 * 								ww-提示框位于左方中间；wn-提示框位于左方最顶部；ws-提示框位于左方最底部；
 * 								ee-提示框位于右方中间；en-提示框位于右方最顶部；es-提示框位于右方最底部；
 * 							第三位数表示提示框箭头位置：
 * 								第一位为n和s时：l-箭头位于提示框左边；c-箭头位于提示框中间；r-箭头位于提示框右边；
 * 								第一位为w和e时：t-箭头位于提示框顶部；c-箭头位于提示框中间；b-箭头位于提示框底部；
 */
var showPrompt = function(ele, msg,config){

	var defaults = {
		delayIn: 0,
		delayOut: 0,
		fade: false,
		fallback: '',
		gravity: 'eec',
		html: false,
		live: false,
		offset: 0,
		opacity: 0.8,
		title: 'title',
		trigger: 'hover'
	};

	var options = $.extend({}, defaults, config);
	
	function fixTitle($ele) {
		if ($ele.attr('title') || typeof($ele.attr('original-title')) != 'string') {
			$ele.attr('original-title', $ele.attr('title') || '').removeAttr('title');
		}
	}
	
	function Tipsy(element, options) {
		this.$element = $(element);
		this.options = options;
		this.enabled = true;
		fixTitle(this.$element);
	}
	
	Tipsy.prototype = {
		show: function(msg) {
			var title = msg;
			if (title && this.enabled) {
				var $tip = this.tip();
				
				$tip.find('.tipsy-inner')[this.options.html ? 'html' : 'text'](title);
				$tip[0].className = 'tipsy'; // reset classname in case of dynamic gravity
				$tip.remove().css({top: 0, left: 0, visibility: 'hidden', display: 'block'}).appendTo(document.body);
				$($tip[0]).bind("click",function(){
					$(this).hide();
				});
				
				var pos = $.extend({}, this.$element.offset(), {
					width: this.$element[0].offsetWidth,
					height: this.$element[0].offsetHeight
				});
				
				var actualWidth = $tip[0].offsetWidth, actualHeight = $tip[0].offsetHeight;
				var gravity = (typeof this.options.gravity == 'function') ? this.options.gravity.call(this.$element[0]) : this.options.gravity;
				if(!gravity){
					gravity = "sel";
				}
				gravity = gravity.toLowerCase();
				var tp;
				
				switch (gravity.charAt(0)) {
					case 'n':
	                    tp = {top: pos.top - actualHeight - this.options.offset, left: pos.left + pos.width/2 - actualWidth / 2 };
	                    break;
                    case 's':
                        tp = {top: pos.top + pos.height + this.options.offset, left: pos.left + pos.width/2 - actualWidth / 2};
                        break;
                    case 'w':
                        tp = {top: pos.top + pos.height/2  - actualHeight / 2, left: pos.left - actualWidth - this.options.offset};
                        break;
                    case 'e':
                        tp = {top: pos.top + pos.height/2  - actualHeight / 2, left: pos.left + pos.width + this.options.offset+7};
                        break;
                    default:
                    	tp = {top: pos.top + pos.height + this.options.offset, left: pos.left + pos.width - actualWidth / 2};
                    	break;
                }
				
				if (gravity.length >1 && gravity.charAt(0) != gravity.charAt(1)) {
					switch (gravity.charAt(1)) {
						case 'n':
		                    tp.top = pos.top + pos.height/2 - actualHeight + 10;
		                    break;
	                    case 's':
	                    	tp.top = pos.top + pos.height/2 + this.options.offset-10;
	                    	break;
	                    case 'w':
	                    	tp.left = pos.left - 15;
	                    	break;
	                    case 'e':
	                    	tp.left = pos.left + pos.width - actualWidth/2 + 15;
	                    	break;
	                }
				}
				if (gravity.length >2) {
					$tip.find(".tipsy-arrow").addClass("tipsy-arrow-" +gravity.charAt(0) + gravity.charAt(2))
				}
				
				$tip.css(tp).addClass('tipsy-' + gravity);
				
				if (this.options.fade) {
					$tip.stop().css({opacity: 0, display: 'block', visibility: 'visible',position:'absolute'}).animate({opacity: this.options.opacity});
				} else {
					$tip.css({visibility: 'visible', opacity: this.options.opacity,position:'absolute'});
				}
			}
		},
		
		hide: function() {
			if (this.options.fade) {
				this.tip().stop().fadeOut(function() { $(this).remove(); });
			} else {
				this.tip().remove();
			}
		},
		
		getTitle: function() {
			var title, $e = this.$element, o = this.options;
			fixTitle($e);
			if (typeof o.title == 'string') {
				title = $e.attr(o.title == 'title' ? 'original-title' : o.title);
			} else if (typeof o.title == 'function') {
				title = o.title.call($e[0]);
			}
			title = ('' + title).replace(/(^\s*|\s*$)/, "");
			return title || o.fallback;
		},
		
		tip: function() {
			if (!this.$tip) {
				this.$tip = $('<div class="tipsy" id="' + ele.attr('verifyNum') + '"></div>').html('<div class="tipsy-arrow"></div><div class="tipsy-inner"/></div>');
			}
			return this.$tip;
		},
		
		validate: function() {
			if (!this.$element[0].parentNode) {
				this.hide();
				this.$element = null;
				this.options = null;
			}
		},
		enable: function() { this.enabled = true; },
		disable: function() { this.enabled = false; },
		toggleEnabled: function() { this.enabled = !this.enabled; },
		setMsg:function(msg){
			this.tip().find('.tipsy-inner').text(msg);
		},
		getMsg:function(){
			return this.tip().find('.tipsy-inner').text();
		}
	};
	
	var elementOptions = function(ele, options) {
		return $.metadata ? $.extend({}, options, $(ele).metadata()) : options;
	};
	
	var tipsy = $.data(ele, 'tipsy');
	if (!tipsy) {
		tipsy = new Tipsy(ele, elementOptions(ele, options));
		$.data(ele, 'tipsy', tipsy);
	}
	tipsy.show(msg);
	return tipsy;
};