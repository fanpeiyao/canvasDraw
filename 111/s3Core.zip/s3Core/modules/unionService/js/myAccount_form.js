$(function(){
	var userservice = "usermanage";
	var userobj = S3Config.getConfig("s3_user");
	var customerId = userobj.UserEntitycustomId;
	var customerName = userobj.UserEntityuserName;
	var loginName = userobj.UserEntityloginName;
	var mobile = userobj.UserEntitymobilephone;
	var unionId = userobj.UserEntityunionId;
	var userrole = S3Config.getConfig("s3_currentRole");
	var myAccount = true;
	var errinfo={
			"40001":"系统错误",
			"40002":"错误的参数",
			"40003":"appid错误或不存在",
			"40004":"获取密钥失败",
			"40005":"appid、token校验错误",
			"40007":"获取手机验证码失败",
			"40008":"手机验证码校验失败",
			"40009":"手机号码与系统不一致",
			"40011":"非法的用户",
			"40012":"注册失败",
			"40013":"用户名或密码错误",
			"40014":"用户已存在",
			"40015":"修改密码失败",
			"40016":"重置密码失败",
			"40017":"用户未激活",
			"40018":"获取审核列表失败",
			"40019":"审核用户失败",
			"40020":"获取用户信息失败",
			"40021":"修改用户信息失败",
			"40022":"获取地址信息失败",
			"40023":"修改地址信息失败",
			"40033":"获取用户角色失败",
			"40034":"修改用户角色失败",
			"40041":"修改用户对应关系失败",
			"40042":"该用户未注册，无法绑定",
			"40043":"获取用户列表失败",
			"40071":"两次密码不一致",
			"40072":"密码至少包含大写字母，小写字母，数字和符号中的3种,长度至少为8位",
			"40073":"原密码错误",
			"40074":"没有修改成功",
			"40075":"重置密码失败",
			"40076":"只有管理员才能进行该操作",
			"40077":"校验不通过",
			"40061":"存在多个用户，需要配置应用号"
		};
	
	
	
	
	
	function getCompanyList(){
		 var result=execjava("userInfoBean.getCompanyList",{},"json",userservice);
	        if(!result || !result.retCode){
	            var companyList = [];
	            renderTpl(companyList);
	            return;
	        }
	        //检查是否取得校验字段
	        var retCode = result.retCode;
	        //检查校验结果
	        var msg = "";
	        if(retCode=="200"){//经销商用户非首次登录，
	        	var companyList = result.companyList;
	        	renderTpl(companyList);
	        }
	}
	
	function renderTpl(list){
		var companyList = list || [];
		var companyListHtml = template.render('companyList', {
			companyList : companyList
		});
		$("#companyListTpl").html(companyListHtml);
	}
	
	function editAccount(){
		var btnVal = jQuery("#editBtn").html();
		if(btnVal == '编辑'){
			/************添加表单校验**********************/
			$.validator.stopValidate();
			/************添加表单校验结束**********************/
			var loginName = jQuery("#loginName").html();
			var mobile = jQuery("#customerMobile").html();
			var userName = jQuery("#userName").html();
			jQuery("#loginName").html("<input type='text' value='" + loginName + "'maxLength='11' required rules='notnull length username'/>");
			jQuery("#customerMobile").html("<input type='text' id='customerByMobile' onchange='getValidateCodeByMobile()' value='" + mobile + "' minLength='11' maxLength='11' rules='notnull mobile'/>");
			jQuery("#mobileValicode").html("<input type='text' id='mobileByValicode' minLength='11' maxLength='11' rules=''/>");
			jQuery("#userName").html("<input type='text' value='" + userName + "' minLength='2' maxLength='50' rules='notnull'/>");
			jQuery("#editBtn").html("保存");
		/************添加表单校验**********************/
		$.validator.startValidate();
		/************添加表单校验结束**********************/
		}else{
			if($("#validatecode").css('display')!='none'){
				if($("#mobileByValicode").val()=='' || $("#mobileByValicode").val()==null){
					alert('验证码不能为空');
					return;
				}
			}
			
			if( !$.validator.verifyAll() ){
				return;
			}
			
			var cId = customerId;
			if(!cId) cId = jQuery("#customerId").html();
			if(!cId) return; 
			var type = 0;
			if(myAccount)
				type = 1;
			var loginName = jQuery("#loginName input").val();
			var mobile = jQuery("#customerMobile input").val();
			var userName = jQuery("#userName input").val();
			var code=jQuery("#mobileByValicode").val();
			var params = {};
			params = {
				unionId:unionId,
				loginName:loginName,
				mobile:mobile,
				customerId:cId,
				userName:userName,
				code:code,
				type:type
			};
			var result = execjava("userInfoNewBean.editUserInfo", params,'json',userservice);
			if(!result || !result.retCode){
				return;
			}
			if(result.retCode == '200'){
				alert("修改成功！");
				location.reload();
			}else{
				alert(errinfo[result.retCode] || result.retMsg);
			}
		}
	}
	


	$("#customerId").html(customerId);
	$("#loginName").html(loginName);
	$("#userName").html(customerName);
	$("#customerMobile").html(mobile);
	if(userrole === "1"){
		$("#customerDetail").show();
		getCompanyList();
	}
	$("#editBtn").bind("click",editAccount);

});