var userservice = "usermanage";

var errinfo={
		"40001":"系统错误",
		"40002":"错误的参数",
		"40003":"appid错误或不存在",
		"40004":"获取密钥失败",
		"40007":"获取手机验证码失败",
		"40008":"手机验证码校验失败",
		"40009":"手机号码与系统不一致",
		"40010":"原密码错误",	
		"40071":"两次密码不一致",
		"40072":"请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。",
		"40073":"原密码错误",
		"40074":"没有修改成功",
		"40075":"重置密码失败",
		"40061":"存在多个用户，需要配置应用号"
	};

jQuery(document).ready(function(){
	
	
    /*如果是首次登录,原始密码不用填写
    if(S3Config.getConfig("s3_firstLoginCheck") == 'true'){
        jQuery("#oldpwd").parent().css("display","none").attr("readOnly","readOnly");
    }
    */
});

	function closeWin(){
		clearForm();
		hideError();
		$("#modifyPwdOverlay").css("display","none");
		$("#fullbg").css("display","none");
	}
	function showError(msg){
		$("#errorTips").removeClass("hidden");
		$("#loginresult").html(msg);
	}
	function hideError(){
		$("#errorTips").addClass("hidden");
	}
	function clearForm(){
		$("#oldpwd").val("");
		$("#newpwd").val("");
		$("#confirmPwd").val("");
		$("#mobile").val("");
		$("#validateCode").val("");
	}
	//检测密码复杂度
	function checkPassComplexity(password){
		if(password.length<8 || password.length>16){
			return false;
         }
		var ls = 0;
		if(password.match("(.*)[a-z]+(.*)")){
				ls++;
		}
		if(password.match("(.*)[A-Z]+(.*)")){
			ls++;
		}
		if(password.match("(.*)[0-9]+(.*)")){
				ls++;
		}				
		if(password.match("(.*)[^a-zA-Z0-9]+(.*)")){
				ls++;
		}			
		if(ls >= 2){
				return true;
		}
		return false;
	}
	function check(name){
		var value = jQuery("#"+name).val();
		
		if(name == 'confirmPwd'){
			var newpwd = jQuery("#newpwd").val();
			if(!value){
				showError("确认密码不能为空！");
				return false;
			}
			if(newpwd != value){
				showError("两次输入密码不一致！");
				return false;
			}
		}else if(name == 'newpwd'){
			if(!value){
				showError("新密码不能为空！");
	            return false;
			}else{
				if(!checkPassComplexity(value)){
					showError("请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。");
		            return false;
	/*			if(value.length<8||value.length>16){
					showError("新密码长度应在8-16个字符之间！");
		            return false; */ 
				}else{
					hideError();
				}
			}
		}else if(name == 'confirmPwd'){
			if(!value){
				showError("原始密码不能为空！");
		        return false;  
			}
		}
		else if(name == 'mobile'){
			if(!value){
				showError("手机号码不能为空！");
		        return false;  
			}
		}
		else if(name == 'validateCode'){
			if(!value){
				showError("验证码不能为空！");
		        return false;  
			}
		}
	}
    function checkPwdInfo() {
        var oldpwd = jQuery("#oldpwd").val();
        var newpwd = jQuery("#newpwd").val();
        var confirmPwd = jQuery("#confirmPwd").val();
        var mobile = jQuery("#mobile").val();
        var validateCode = jQuery("#validateCode").val();
        
		if(!oldpwd){
			showError("原始密码不能为空！");
	        return false;  
		}
		if(!newpwd){
			showError("新密码不能为空！");
            return false;
		}else{
			if(!checkPassComplexity(newpwd)){
				showError("请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。");
	            return false;
/*			if(newpwd.length<8||newpwd.length>16){
				showError("新密码长度应在8-16个字符之间！");
	            return false; */ 
			}else{
				hideError();
			}
		}
		if(!confirmPwd){
			showError("确认密码不能为空！");
			return false;
		}
		if(jQuery.trim(newpwd) != jQuery.trim(confirmPwd)){
			showError("两次输入密码不一致！");
			return false;
		}
		if(!mobile){
			showError("手机号码不能为空！");
			return false;
		}
		if(!validateCode){
			showError("验证码不能为空！");
			return false;
		}
	return true;
    
    }

    jQuery("#savePass").click(function(){
        if(!checkPwdInfo()){
        	return;
        }
        var oldpwd = jQuery("#oldpwd").val();
        var newpwd = jQuery("#newpwd").val();
        var confirmpwd = jQuery("#confirmPwd").val();
        var mobile = jQuery("#mobile").val();
        var validateCode = jQuery("#validateCode").val();
        if(!oldpwd || !newpwd || !confirmPwd || !mobile || !validateCode) return;
        
        var param = {};
        var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
        if(result.retCode != "200"){
        	alert("获取公钥失败");
        	return;
        }
        
        //rsa加密
        var rsakey = new RSAKey();
		rsakey.setPublic(result.modulus,result.exponent);
		var oldpwd = rsakey.encrypt(oldpwd);
		var newpwd = rsakey.encrypt(newpwd);
		var confirmpwd = rsakey.encrypt(confirmpwd);
		
        var params = {
        	oldPassword:oldpwd.toString(16),
        	newPassword:newpwd.toString(16),
        	confirmpassword:confirmpwd.toString(16),
        	mobile:mobile,
        	validateCode:validateCode
        };
        var msg = "";
        var ret = execjava("userAuthenBean.editUserInfoByFirstLogin",params, "json",userservice);
        if(!ret || !ret.retCode){
        	alert("系统异常！");
        	return;
        }
       	if (ret.retCode == "200") {
           hideError();
           alert("修改用户信息成功!");
           window.location = getRealPath() + "~main/main.php";
        } else{
        	alert(errinfo[ret.retCode] || ret.retMsg);
        }
    });   

	/**
	 * 向已输入的手机号码发送短信,如果需要对其他的输入框校验也可以写在这里
	 * eq.如果是根据登陆名到统一认证那获取手机号码的 ,可以判断登陆名是否为空,这里在的mobile改为loginName
	 */
	function getValidateCode(){
		var mobile = $("#mobile").val().trim();
		if(mobile == ''){
			showError("手机号码不能为空！");
			return false;
		}else if(!/^(86)?1[3-8]\d{9}$/.test(mobile)){			
			showError("请填写正确的手机号码！");
			return false;
		}
		btn = $("#getCheckCode");
		var params = {
			mobile:mobile
		};
		execjava("userAuthenBean.getValidateCode",params,"json",'usermanage',true,codeCallback);
		hideError();
	}
	
	/**
	 * 短信发送成功调用方法 
	 */
	var codeCallback = function(result){
		result = eval("("+result+")");
		if(!result || !result.retCode){
		     alert("系统出错，请联系管理员!");
		     return;
		}
		if(result.retCode == '200'){
		     /*alert("系统已向您在本网登记的手机号码（"+  result.mobile +"）发送验证码,请及时检验！");*/
		     btn.removeAttr("onclick");
		     var time = 60;
			var hander = setInterval(function(){
				if(time <= 0){
					btn.html("获取验证码");
					btn.attr("onclick","getValidateCode(this);");
					window.clearInterval(hander);
				} else {
					btn.html(""+(time--)+"s后重试");
				}
			},1000);
		}else{
			if(result.retField)
		     	alert(result.retField + result.retMsg);
		    else
		    	alert(result.retMsg);
		}
		
		
	};
