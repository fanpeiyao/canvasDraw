/** 地址管理js */

// 模板标签
template.openTag = "<%";
template.closeTag = "%>";
var v1 = "address";
var dataMap = null;
var userservice = "usermanage";

jQuery(document).ready(function() {
	
	getAddressList(1);//加载地址列表
	loadAddressForm();//加载地址信息表单
	
	/************添加表单校验**********************/
	$.validator.startValidate();
	/************添加表单校验结束**********************/
	
	
});

var bindingFunction = function(event){
	$(".addrSettingbtn").hide();
	var ele = event.currentTarget;
	var id = $(ele).find("td:last-child").find("*").attr("id");
	var type = event.type;
	if(type == 'mouseover'){
		if(id)
			$("#"+id).show();
	}
	else{
		if(id)
			$("#"+id).hide();
	}
};

//加载二级经销商到选择框
function loadSecCustomer(){
	
}
function init(){
	dataMap =  {};
	for(var i =0;i<addrForm.length;i++){
		dataMap[addrForm[i].fieldName] = addrForm[i];
	}
}

function loadAddressForm(){
	if(!addrForm) return;
	var html = "";
	var functionList = [];
	for(var i=0;i < addrForm.length;i ++ ){
		var temp = addrForm[i];
		if(!temp.formName || temp.formName != v1) continue;
		if(temp.type == 'select'){
			html += '<p><font>' + temp.displayName + ':</font>'
				 + '<span>'
				 + '<select name="'+ temp.fieldName +'" id="' + temp.fieldName + '" value="' 
				 + temp.defaultValue + '"' ;
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.childSelect)
				html += ' childSelect = "'+ temp.childSelect +'"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
			if(temp.userMsg)
				html += ' userMsg="' + temp.userMsg + '" ';	
			if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';
			
			html += '><option selected="selected" value="">请选择</option></select><i>'
				+ (temp.require?'*':'') +'</i>';
			if(temp.tipInfo)
				html += '<label>' + temp.tipInfo + '</label>';		 
			
			html += '</span></p>';
			functionList.push(temp);
			
		}else{
			if(temp.type == 'hidden'){
				html += '<p><font></font><span>';
			}else{
				html += '<p><font>' + temp.displayName + ':</font>'
			      + '<span>';
			}
			
			html += '<input name="'+ temp.fieldName +'" id="' + temp.fieldName + '" type="' + temp.type 
			      + '" value="' + temp.defaultValue + '" ';
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
			if(temp.userMsg)
				html += ' userMsg="' + temp.userMsg + '" ';	
			if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';
			 html += ' />';
			 
			 if(temp.type == 'hidden'){
				 html += '</span></p>';
			 }else{
				 html += '<i>'+ (temp.require?'*':'') +'</i>';
				 if(temp.tipInfo)
						html += '<label>' + temp.tipInfo + '</label>';		 
				 html += '</span></p>';
			 }
		}
		
	}
	$("#addressInfo").html(html);
	for(var i = 0;i < functionList.length;i ++ ){
		var t = functionList[i];
		//如果控件类型为选择框类型
		var fun = addressFn[t.loadFunction];
		if(typeof fun == 'function') fun.call(this,t);
		if(t.type == 'select'){
			var fun = addressFn[t.changeFunction];
			if(typeof fun == 'function') $("#"+t.fieldName).bind('change',fun);
		}
	}
	
}


var addressList = null;
var limit = 8;
/**
 * 查询地址信息
 * 
 * @param pageNum
 *            当前页码
 */

function getAddressList(pageNum) {
	/************关闭表单校验提示框**********************/
	$.validator.closeMsg();
	/************关闭表单校验提示框**********************/
	var params = {
		page:pageNum,
		limit:limit
		
	};
	var userId = jQuery("#choosedUserId").val();
	params.userId = userId;
	var ary = execjava('addressBean.getAddressInfo', params, 'json');
	if (ary == null || ary == "") {
		alert("地址获取失败");
		return;
	}
	addressList = ary.addressList;
	
	//var count = 5;
	var num = ary.count;//总记录数
	var pageTotal = parseInt((parseInt(num)+parseInt(limit-1))/limit);// 总页数
	// 模板渲染
	var addressListHtml = template.render('addressList', {
		addressList : ary.addressList
	});

	$("#addressTpl").html(addressListHtml);
	/**绑定事件**/
	$("#addrTbody tr").bind('mouseover',bindingFunction);
	$(".addrSettingbtn").hide();
	//分页
	$("#addressPager").pager({ 
	   pagecount: pageTotal, 
	   pagenumber: pageNum, 
	   buttonClickCallback: function(pageclickednumber){getAddressList(pageclickednumber);} 
	});
}


function setAreaById(_parentSelected,_areaTypeStr,_areaSelId) {
	if(!_parentSelected) return;
	var params = {
		parentId :_parentSelected
	};
	var list = execjava("addressBean.getAreaList",params, "json");
	ret = list.areaList;
	document.getElementById(_areaSelId).options.length=0;
	document.getElementById(_areaSelId).options.add(new Option("请选择",""));
	for(var i = 0 ;i <ret.length;i++){		
		document.getElementById(_areaSelId).options.add(new Option(ret[i].areaName,ret[i].areaId));
	}
	$("#"+_areaSelId).change();
}




// form提交
$("#addrSaveBtn").click(function() {
	//校验所有输入框是否通过
	if( !$.validator.verifyAll() ){
		return;
	}
	var params = getParams();
	params.userId = jQuery("#choosedUserId").val();
	var result = execjava("addressBean.editAddressInfo",params, "json");
	if(!result){
		alert("系统异常！请联系管理员！");
		return;
	}
	if(result.retCode == '200'){
		alert("操作成功！");
		cancelFun();
		getAddressList(1);
		
	}else{
		alert(result.retCode);
	}
	
});
function getParams(){
	if(!dataMap)
		init();
	var params = {};
	$("#addrForm").find("input,select").each(function(){
		var id = $(this).attr("id");
		if(id){
			params[id] = $.trim($(this).val());
			var item = dataMap[id];
			if(item.optionName && item.name){
				params[name] = $(this).find("option:selected").text();
			}
		}
	});
	$("#addrForm").find("input[type='checkbox'],input[type='radio']").each(function(){
		var id = $(this).attr("id");
		var checked = $(this).prop("checked");
		if(id){
			if(checked)
				params[id] = "1";
			else
				params[id] = "0";
		}
	});
	return params;
}
//取消或重置
$("#cancelBtn").click(function() {
	cancelFun();
});

//修改时取消按钮事件
function cancelFun(){
	/************关闭表单校验提示框**********************/
	$.validator.closeMsg();
	/************关闭表单校验提示框**********************/
	jQuery("#addressInfo select").val('');
	jQuery("#addressInfo input").val('');
	jQuery("#addressInfo input[type=checkbox],#addressInfo input[type=radio]").removeAttr("checked").val("0");
	jQuery("#operatSpan").text("添加地址");
	jQuery("#cancelBtn").text("重置");
	jQuery("#addrId").val("");
}

// 设置修改信息
function setFormForUpdate(row) {
	
	if(row == null || row == undefined || addressList == null){
		return;
	}
	var currentAddress = addressList[row];
	if(!dataMap)
		init();
	for(var key in dataMap){
		var value = currentAddress[key] || "";
		if(dataMap[key]['type'] == 'select'){
			//如果是选择框，设值，触发change事件
			jQuery("#"+key).val(value);
			if(dataMap[key]['changeFunction']){
				//如果change事件有值
				jQuery("#"+key).change();
			}
		}else if(dataMap[key]['type'] == 'checkbox' || dataMap[key]['type'] == 'radio'){
			//如果是复选框，设值，将复选框选中
			if(value){
				jQuery("#"+key).val(value);
				jQuery("#"+key).attr("checked",true);
			}else{
				jQuery("#"+key).removeAttr("checked");
				jQuery("#"+key).val("0");
			}
			
		}else {
			jQuery("#"+key).val(value);
		}
		
	}

}
// 删除地址信息
function delAddress(_addrId) {
	if (confirm("确认删除此地址吗?")) {
		var params = {
			addrId : _addrId
		};
		execjava("addressBean.deleteAddress", params,"json");
		cancelFun();
	}
	getAddressList(1);
	$("#addrTbody tr").bind('mouseover',bindingFunction);
	$(".addrSettingbtn").hide();
}

//改变默认地址
function changeShipCurrent(_addrId) {
	var params = {
		addrId : _addrId
	};
	var userId = jQuery("#choosedUserId").val();
	params.userId = userId;
	execjava("addressBean.setDefaultAddr", params,"json");
	getAddressList(1);
	$("#addrTbody tr").bind('mouseover',bindingFunction);
	$(".addrSettingbtn").hide();
}




