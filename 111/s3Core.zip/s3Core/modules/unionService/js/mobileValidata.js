var extForm1={
		getValidateCode:{
		tagName:'a',
		href:'javascript:;',
		id:"getCheckCode",
		'class':'btn input-regist-btn',
		onclick:'getValidateCode();',
		html:'获取验证码',
		customFn:"checkPhone"
		}
	}

/**
 * 设置同一行多个标签 
 */
var setExtItem = function(key){
	if(!extForm1 || !extForm1[key]) return;
	var extTag = extForm1[key];
	var html = "<"+extTag['tagName'] +' ';
	var closeHtml = "</"+extTag['tagName'] +'>';
	for(k in extTag){
		if(k!='tagName'&&k!='html'){
			html += k +'="'+extTag[k]+'"';
		}
	}
	html += ">";
	if(extTag['html'])
		html += extTag['html'];
	html += closeHtml;
	return html;
};
/**
 * 手机号码发生改变时所调用的方法，会保存页面加载时的手机号码，然后后面的手机号码会与这个号码进行比对
 */
function getValidateCodeByMobile(){
	var userobj = S3Config.getConfig("s3_user");
	var mobilebefore = userobj.UserEntitymobilephone;
	var mobilephone = $("#customerByMobile").val();
	var checkcodehtml="";
	if(mobilephone==mobilebefore){
		$("#validatecode").hide();
		$("#mobileByValicode").attr("value","");
		return;
	}
	if(mobilephone == ''){
		$("#customerByMobile").blur();
		$("#validatecode").hide();
		return;
	}else if(!/^(86)?1[3-8]\d{9}$/.test(mobilephone)){
		alert("请填写正确的手机号码！");
		$("#validatecode").hide();
		return;
	}
	$("#validatecode").show();
	
	console.log($("#getCheckCode").length);
	if($("#getCheckCode").length==0){
		checkcodehtml = setExtItem('getValidateCode');
		jQuery("#mobileByValicode").after(checkcodehtml);
	}
}

/**
 * 向已输入的手机号码发送短信,如果需要对其他的输入框校验也可以写在这里
 * eq.如果是根据登陆名到统一认证那获取手机号码的 ,可以判断登陆名是否为空,这里在的mobile改为loginName
 */
function getValidateCode(){
	var mobile = $("#customerByMobile").val();
	btn = $("#getCheckCode");
	var params = {
		mobile:mobile
	};
	execjava("userAuthenBean.getValidateCode",params,"json",'usermanage',true,codeCallback);	
}
/**
 * 短信发送成功调用方法 
 */
var codeCallback = function(result){
	result = eval("("+result+")");
	if(!result || !result.retCode){
	     alert("系统出错，请联系管理员!");
	     return;
	}
	if(result.retCode == '200'){
	     alert("系统已向您在本网登记的手机号码（"+  result.mobile +"）发送验证码,请及时检验！");
	     btn.removeAttr("onclick");
	     var time = 60;
		var hander = setInterval(function(){
			if(time <= 0){
				btn.html("获取验证码");
				btn.attr("onclick","getValidateCode(this);");
				window.clearInterval(hander);
			} else {
				btn.html(""+(time--)+"s后重试");
			}
		},1000);
	}else{
		if(result.retField)
	     	alert(result.retField + result.retMsg);
	    else
	    	alert(result.retMsg);
	}
};