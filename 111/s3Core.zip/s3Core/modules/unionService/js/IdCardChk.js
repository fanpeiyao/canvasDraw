var chkIDCard = function(sid){
	var vcity={
			11:'北京',12:'天津',13:'河北',14:'山西',15:'内蒙古',
			21:'辽宁',22:'吉林',23:'黑龙江 ',
			31:'上海',32:'江苏',33:'浙江',34:'安徽',35:'福建',36:'江西',37:'山东',
			41:'河南',42:'湖北 ',43:'湖南',44:'广东',45:'广西',46:'海南',
			50:'重庆',51:'四川',52:'贵州',53:'云南',54:'西藏 ',
			61:'陕西',62:'甘肃',63:'青海',64:'宁夏',65:'新疆',
			71:'台湾',
			81:'香港',82:'澳门',91:'国外 '
		};
	
	var arrInt = new Array(7,9,10,5,8,4,2,1,6,3,7,9,10,5,8,4,2);
	var arrCh  = new Array('1','0','X','9','8','7','6','5','4','3','2');
	
	var checkCard = function(sid){
		if(sid){
			sid = sid.toUpperCase();
			
			if(isIdCard(sid) === false){
				return false;
			}
			
			if(checkProvince(sid) === false){
				return false;
			}
			
			if(checkBirthday(sid) === false){
				return false;
			}
			
			if(checkParity(sid) === false){
				return false;
			}
		}
		return true;
	};
	//校验长度，类型是否符合规范
	isIdCard = function(sid){
		var reg = /(^\d{15}$)|(^\d{17}(\d|X)$)/;
		if(reg.test(sid) === false){
			return false;
		}
		return true;
	};
	//取前两位校验省份
	checkProvince = function(sid){
		var province = sid.substr(0,2);
		if(!vcity[province]){
			return false;
		}
		return true;
	};
	//校验生日
	checkBirthday = function(sid){
		var len = sid.length;
		if(len == '15'){
			var re_fifteen = /^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/;
			var data = sid.match(re_fifteen);
			var year = data[2];
			var month = data[3];
			var day = data[4];
			var birthday = new Date('19'+year+'/'+month+'/'+day);
			return verifyBirthday('19'+year,month,day,birthday);
		}
		
		if(len == '18'){
			var re_eighteen = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/;
			var data = sid.match(re_eighteen);
			var year = data[2];
			var month = data[3];
			var day = data[4];
			var birthday = new Date(year+'/'+month+'/'+day);
			return verifyBirthday(year,month,day,birthday);
		}
		return false;
	};
	//校验日期合法
	verifyBirthday = function(year,month,day,birthday){
		var now = new Date();
		var now_year = now.getFullYear();
		
		if(birthday.getFullYear() == year 
				&& (birthday.getMonth()+1) == month
				&& (birthday.getDate() == day)){
			//vat time = now_year - year;
			//if(time >= 3 && time <= 100){
				return true;
			//}
			//return false;
		}
		return false;
	};
	//校验位检测
	checkParity = function(sid){
		sid = upgrade(sid);//15升18
		var len = sid.length;
		if(len == 18){
			var temp = 0,i,valnum;
			for(i=0; i<17; i++){
				temp += sid.substr(i,1)*arrInt[i];
			}
			valnum = arrCh[temp % 11];
			if(valnum == sid.substr(17,1)){
				return true;
			}
			return false;
		}
		return false;
	};
	
	//15位升18位
	upgrade = function(sid){
		if(sid.length == '15'){
			var temp = 0,i;
			sid = sid.substr(0,6)+'19'+sid.substr(6,sid.length-6);
			
			for(i=0; i<17; i++){
				temp += sid.substr(i,1)*arrInt[i];
			}
			sid += arrCh[temp % 11];
		}
		return sid;
	};
	return checkCard(sid);
}