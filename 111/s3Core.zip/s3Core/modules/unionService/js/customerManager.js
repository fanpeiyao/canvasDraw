var userList = null;
var valueType = null;
var customerId = null;
var customerName = null;
var userId = null;
var operatorId = null;
var merchantId = S3params.getData("userId");
var operatorConfig = {
	operatorList : null,
	type : null,
	current:null
};
var customerConfig = {
	customerList : null,
	type : null,
	current:null
};
var userservice = "usermanage";
$(document).ready(function() {
	//用于弹出框展示
	var triggers = $(".modalInput").overlay({
		// some mask tweaks suitable for modal dialogs
	    mask: {
	      color: '#ebecff',
	      loadSpeed: 1,
	      opacity: 0.8
	    },
	    fixed: false,
	    closeOnClick: false
	});
	
		loadCustomer();
	
		

	loadRegisterForm('company');
	/************添加表单校验**********************/
	$.validator.startValidate();
	/************添加表单校验结束**********************/
	jQuery("#editBtn").bind("click",editAccount);
});

function editAccount(){
	var btnVal = jQuery("#editBtn").html();
	if(btnVal == '编辑'){
		if(!canModify){
			var mobile = jQuery("#customerInfo td[name=mobile]").html();
			var email = jQuery("#customerInfo td[name=email]").html();
			
			
			jQuery("#customerInfo td[name=mobile]").html("<input type='text' value='" + mobile + "' minLength='11' maxLength='11' rules='mobile'/>");
			jQuery("#customerInfo td[name=email]").html("<input type='text' value='" + email + "' rules='email'/>");
		
		}else{
			var names = canModify.split("\|");
			for(var i=0;i<names.length;i++){
				var temp = jQuery("#customerInfo td[name="+names[i] +"]").html();
				var rules = "";
				if(names[i] == 'mobile'){
					rules = " minLength='11' maxLength='11' rules='mobile'";
				}else if(names[i] == 'email'){
					rules = " rules='email'";
				}else{
					rules = " rules='notnull'";
				}
				jQuery("#customerInfo td[name="+names[i] +"]").html("<input type='text' value='" + temp + "' " + rules +"/>");
			}
		}
		
	jQuery("#editBtn").html("保存");
	/************添加表单校验**********************/
	$.validator.startValidate();
	/************添加表单校验结束**********************/
	}else{
		var form = jQuery("#customerInfo");
		if( !$.validator.verifyAll(form) ){
			return;
		}
		var params = {};
		if(!canModify){
			var mobile = jQuery("#customerInfo td[name=mobile] input").val();
			var email = jQuery("#customerInfo td[name=email] input").val();
			
			params = {
				mobile:mobile,
				email:email,
				userId:merchantId,
				type:0
			};
		}else{
			params = {
				userId:merchantId,
				type:0
			};
			var names = canModify.split("\|");
			for(var i=0;i<names.length;i++){
				var value = jQuery("#customerInfo td[name=" + names[i] + "] input").val();
				params[names[i]] = value;
			}
		}
		
		var result = execjava("userInfoBean.updateAccountInfo", params,'json',userservice);
		if(!result || !result.retCode){
			return;
		}
		if(result.retCode == '200')
			location.reload();
		else
			alert(result.retMsg || "修改账户信息出错！");
	}
}
var canModify = null;
function loadCustomer(){
	//加载当前客户的信息
	if(merchantId == null || merchantId == undefined){
		return;
	}
	//加载所有部门信息
	var params = {
		page:1,
		userId:merchantId
	};
	var ret=execjava('userInfoBean.myCustomerInfo', params, 'json',userservice);
	
	if(!ret || !ret.customerList || !ret.count){
		return;
	}
	canModify  = ret.canModify;
	setCustomer(ret.customerList[0]);
}
function setCustomer(customer){
	if(!customer){
		return;
	}
	userId = merchantId;
	customerId = customer.customerId;
	customerName = customer.customerName;
	operatorId = customer.operatorId;
	$("#customerInfo td[name=userName]").html(customerName);
	$("#customerInfo td[name=mobile]").html(customer.mobile);
	$("#customerInfo td[name=email]").html(customer.email);
	$("#customerInfo td[name=loginName]").html(customer.loginName);
	
}





function checkFormValue(){
	var result = true;
	$("#customerForm").find("input").each(function(){
		if($(this).attr("name")!="id" && $(this).val() == ''){
			var title = $(this).attr("errorTitle");
			
			showError(title+"不能为空!");
			result = false;
			return false;
		}
	});
	return result;
}



function clearForm(divId){
	$("#searchId").val('');
	$("#searchName").val('');
}


/************生成客户FORM******************/
var fieldMapName = {};
//获取表单元素,格式
function loadRegisterForm(v1){
	/************添加表单校验**********************/
	$.validator.stopValidate();
	/************添加表单校验结束**********************/
	clearForm(v1);
	if(!registerForm) return;
	var html = '<input name="id" type="hidden" />';
	var functionList = [];
	for(var i=0;i < registerForm.length;i ++ ){
		var temp = registerForm[i];
		if(!temp.formName || temp.formName != v1) continue;
		fieldMapName[temp.fieldName] = temp.displayName;
		if(temp.type == 'select'){
			html += '<p><font>' + temp.displayName + ':</font><span>'+
			'<select name="'+ temp.fieldName +'" id="' + temp.fieldName + '" value="' 
			+ temp.defaultValue + '" class="'+ temp.conClass +'" ' ;
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
			if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			 
			html += '></select></span><b>'+ (temp.require?'*':'') +'</b></p>';
			functionList.push(temp);
			
		}else if(temp.type == 'hidden'){
			html += '<p><font></font><span>'+
			'<input name="'+ temp.fieldName +'" id="' + temp.fieldName + '" type="hidden" value="' 
			+ temp.defaultValue + '" class="'+ temp.conClass +'" ';
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
				if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			html +=' />'
			+'</span><b></b></p>';
		}else {
			html += '<p><font>' + temp.displayName + ':</font><span>'+
			'<input name="'+ temp.fieldName +'" id="' + temp.fieldName + '" type="' + temp.type + 
			'" value="' + temp.defaultValue + '" class="'+ temp.conClass +'"';
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
				if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			 html += ' />'
			+'</span><b>'+ (temp.require?'*':'') +'</b></p>';
		}
		
	}
	$("#customerForm").html(html);
	for(var i = 0;i < functionList.length;i ++ ){
		var t = functionList[i];
			//如果控件类型为选择框类型
		var fun = registerList[t.loadFunction];
		if(typeof fun == 'function') fun.call(this,t);
		if(t.type == 'select'){
			var fun = registerList[t.changeFunction];
			if(typeof fun == 'function') $("#"+t.fieldName).bind('change',fun);
		}
	}
	
}
function clearForm(){
	$("#customerForm").html('');
}