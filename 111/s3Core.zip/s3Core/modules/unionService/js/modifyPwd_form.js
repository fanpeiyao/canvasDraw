var userservice = "usermanage";
//var ctx = S3Config.getConfig("s3_root");
//var firstLogin = S3Config.getConfig("s3_firstLoginCheck");
//var user = S3Config.getConfig("s3_user");
//var loginName = S3Config.getConfig("s3_user").UserEntityloginName;

var errinfo={
		"40001":"系统错误",
		"40002":"错误的参数",
		"40003":"appid错误或不存在",
		"40004":"获取密钥失败",
		"40007":"获取手机验证码失败",
		"40008":"手机验证码校验失败",
		"40009":"手机号码与系统不一致",
		"40010":"原密码错误",	
		"40071":"两次密码不一致",
		"40072":"请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。",
		"40073":"原密码错误",
		"40074":"没有修改成功",
		"40075":"重置密码失败",
		"40061":"存在多个用户，需要配置应用号"
	};

jQuery(document).ready(function(){
	
	
    /*如果是首次登录,原始密码不用填写*/
    if(S3Config.getConfig("s3_firstLoginCheck") == 'true'){
        jQuery("#oldpwd").parent().css("display","none").attr("readOnly","readOnly");
    }
});

	function showError(msg){
		$("#errorTip").removeClass("hidden");
		$("#loginres").html(msg);
	}
	function hideError(){
		$("#errorTip").addClass("hidden");
	}
	function check(name){
		var value = jQuery("#"+name).val().trim();
		
		if(name == 'confirmPwd'){
			var newpwd = jQuery("#newpwd").val();
			if(!value){
				showError("确认密码不能为空！");
				return false;
			}
			if(jQuery.trim(newpwd) != jQuery.trim(value)){
				showError("两次输入密码不一致！");
				return false;
			}
		}else if(name == 'newpwd'){
			if(!value){
				showError("新密码不能为空！");
	            return false;
			}else{
				if(value.length<8||value.length>16){
					showError("新密码长度应在8-16个字符之间！");
		            return false;  
				}else{
					hideError();
				}
			}
		}else{
			if(!value){
				showError("原始密码不能为空！");
		        return false;  
			}
		}
	}
    function checkPwdInfo() {
        var oldpwd = jQuery("#oldpwd").val();
        var newpwd = jQuery("#newpwd").val();
        var confirmPwd = jQuery("#confirmPwd").val();
        
		if(!oldpwd){
			showError("原始密码不能为空！");
	        return false;  
		}
		if(!newpwd){
			showError("新密码不能为空！");
            return false;
		}else{
			if(newpwd.length<8||newpwd.length>16){
				showError("新密码长度应在8-16个字符之间！");
	            return false;  
			}else{
				hideError();
			}
		}
		if(!confirmPwd){
			showError("确认密码不能为空！");
			return false;
		}
		if(jQuery.trim(newpwd) != jQuery.trim(confirmPwd)){
			showError("两次输入密码不一致！");
			return false;
		}
	return true;
    
    }

    jQuery("#savePass").click(function(){
        if(!checkPwdInfo()){
        	return;
        }
        var oldpwd = jQuery("#oldpwd").val();
        var newpwd = jQuery("#newpwd").val();
        var confirmPwd = jQuery("#confirmPwd").val();
        if(!oldpwd || !newpwd || !confirmPwd) return;
        
        var param = {};
        var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
        if(result.retCode != "200"){
        	alert("获取公钥失败");
        	return;
        }
        
        //rsa加密
        var rsakey = new RSAKey();
		rsakey.setPublic(result.modulus,result.exponent);
		var oldpwd = rsakey.encrypt(oldpwd);
		var newpwd = rsakey.encrypt(newpwd);
		var repeatpwd = rsakey.encrypt(confirmPwd);
		
        param.loginName = S3Config.getConfig("s3_user").UserEntityloginName;
        var params = {
        	oldPassword:oldpwd.toString(16),
        	newPassword:newpwd.toString(16),
        	repeatPassword:repeatpwd.toString(16)
        };
        var msg = "";
        var ret = execjava("userAuthenBean.changePassword",params, "json",userservice);
        if(!ret || !ret.retCode){
        	alert("系统异常！");
        	return;
        }
       	if (ret.retCode == "200") {
           hideError();
           alert("修改密码成功!");
           window.location = getRealPath() + "~main/share/frame.php?target=myAccount";
        } else{
        	alert(errinfo[ret.retCode] || ret.retMsg);
        }
    });   

