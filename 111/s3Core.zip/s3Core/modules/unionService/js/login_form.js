var userservice = "usermanage";
var resubmit = true;
var errinfo={
		"40005":"验证码校验失败",
		"40007":"获取手机验证码失败",
		"40008":"手机验证码校验失败",
		"40009":"手机号码与系统不一致",
		"40011":"非法的用户",
		"40012":"注册失败",
		"40013":"用户名或密码错误",
		"40014":"用户已存在",
		"40015":"修改密码失败",
		"40016":"重置密码失败",
		"40017":"用户未激活",
		"40018":"获取审核列表失败",
		"40019":"审核用户失败",		
		"40061":"存在多个用户，需要配置应用号",
		"40062":"密码错误超过规定次数，请在30分钟之后进行操作",
		"40063":"当前注册通道为封闭状态，不能进行注册，请联系管理员",
		"40013":"用户名或密码错误"
	};

/** 登录模块 */
$(function(){
    var ctx = getRealPath();//S3Config.getConfig("s3_root");
    

    function CookieSupport(){
    };
    CookieSupport.setNativeCookie=function(name, value)
    {
        var argv = CookieSupport.setNativeCookie.arguments;
        var argc = CookieSupport.setNativeCookie.arguments.length;
        var expires = (argc>2) ? argv[2] : null;
        //alert(expires);
        if(expires != null && typeof expires == 'number'){
            expires = new Date(expires);
        }else{
        	var date=new Date();
        	date.setTime(date.getTime()+3600*1000*24*7);
        }
        var path = (argc > 3) ? argv[3] : null;
        var domain = (argc > 4) ? argv[4] : null;
        var secure = (argc > 5) ? argv[5] : false;

        document.cookie = name + "=" + value+
            ((expires == null) ? ("; expires=" + date.toGMTString()) : ("; expires=" + expires.toGMTString())) +
            ((path == null) ? "" : ("; path=" + path)) +
            ((domain == null) ? "" : ("; domain=" + domain)) +
            ((secure == true) ? "; secure" : "");
    };

    CookieSupport.removeNativeCookie=function(name)
    {
        var expdate = new Date();
        expdate.setTime(expdate.getTime() - (86400 * 1000 * 1));
        CookieSupport.setNativeCookie(name, "", expdate);
    };

    CookieSupport.getcookieval=function(offset)
    {
        var endstr = document.cookie.indexOf (";", offset);
        try{
        	 if (endstr == -1)
            endstr = document.cookie.length;
        }catch(e){
        	
        }
       
        return document.cookie.substring(offset, endstr);
    };

    CookieSupport.getNativeCookie=function(name)
    {
        var arg = name + "=";
        var alen = arg.length;
        var clen = document.cookie.length;
        var i = 0;
        while (i < clen) {
            var j = i + alen;
            if (document.cookie.substring(i, j) == arg)
                return CookieSupport.getcookieval (j);
            i = document.cookie.indexOf(" ", i) + 1;
            if (i == 0) break;
        }
        return null;
    };

    /**
     * 加载cookie信息到登录页面。
     */
    function loadCookieInfo(){
        var remberLoginName = jQuery("#rememberUserName");
        if (remberLoginName.length > 0) {
            var cookieName = CookieSupport.getNativeCookie("yname");
            if (cookieName) {
                jQuery("#username").val(decodeURI(decodeURI(cookieName)));
                $("#username").removeClass("f11");
                jQuery(remberLoginName).attr("checked", true);
            }
            var roleName = CookieSupport.getNativeCookie("company");
            if(roleName){
                roleName = decodeURI(decodeURI(roleName));
                $("#sub").text(roleName);
            }
        }
        var  validCode = CookieSupport.getNativeCookie("validCode");
        if(validCode){
        	document.getElementById("validCode").style.display = '';
    		colorConvert();
        }
    }

    loadCookieInfo();


    
/*    $("#username").focus(function(){
    	 var username = $(this).val();
    	 $(this).removeClass("f11");
    	 if(username=='请输入用户名'){
    	 	$(this).val('');
    	 	
    	 }
    	});

	$("#username").blur(function(){
	 var username = $(this).val();
	 if(username==''){
	 	$(this).val('请输入用户名');
	 	$(this).addClass("f11");
	 }
	});


	$("#validate").focus(function(){
	 var username = $(this).val();
	 $(this).removeClass("f11");
	 if(username=='输入验证码'){
		 $(this).val('');

	 }
	});

	$("#validate").blur(function(){
	 var username = $(this).val();
	 if(username==''){
	 	$(this).val('输入验证码');
	 	$(this).addClass("f11");
	 }
	});
*/

    $(".foucus").focus(function(){
    	$(this).addClass("skin-boxShadow");
    });
    $(".foucus").blur(function(){
    	$(this).removeClass("skin-boxShadow");
    });
    
    $("#username").keydown(function(event){
        if(event.keyCode == 13){
            login();
        }
    });
    $("#username").blur(function(){
        if($(this).val() == ""){
            $("#errorTip").removeClass("hidden");
            $("#loginres").html('用户名不能为空！');
           

        }else{
            $("#errorTip").addClass("hidden");
        }
    });



    $("#password").blur(function(){

        if($(this).val()==""){
            $("#errorTip").removeClass("hidden");
            $("#loginres").html("密码不能为空！");
        }else{
            $("#errorTip").addClass("hidden");

        }
    });
    $("#password").keydown(function(event){
        if(event.keyCode == 13){
            login();
        }
    });
    
     $("#validate").blur(function(){
			checkCode();
    });
    $("#validate").keydown(function(event){
        if(event.keyCode == 13){
            login();
        }
    });
    
    $("#loginbtn").click(function(){
    	login();
        //return false必须添加，否则无法进行跳转。
        //只能在触发事件的function中添加return false，如果加在login()中也没有用。
        //解释：loginbtn是a标签的id，在执行完click操作之后，如果返回ture，那么会去执行href的内容
        //return false;
    });
	function checkCode(){
		var ret = false;
		var code_num = $("#validate").val();
		
		if(code_num == ""){
            $("#errorTip").removeClass("hidden");
            $("#loginres").html("验证码不能为空！");
            
        }else{
            $("#errorTip").addClass("hidden");
            $.ajax({
            	url:"chk_code.php?act=num",
            	async:false,
            	type:"post",
            	data:{code:code_num},
            	success:function(msg){
            		if(msg==1){
            		ret = true;
            	}else{
            		$("#errorTip").removeClass("hidden");
		            $("#loginres").html("验证码错误，请输入正确的验证码");
            	}
            	}
            });
        }
        return ret;
	}
	
	//检测密码复杂度
	function checkPassComplexity(password){
		if(password.length<8 || password.length>16){
			return false;
         }
		var ls = 0;
		if(password.match("(.*)[a-zA-Z]+(.*)")){
				ls++;
		}
		if(password.match("(.*)[0-9]+(.*)")){
				ls++;
		}						
		if(password.match("(.*)[^a-zA-Z0-9]+(.*)")){
				ls++;
		}			
		if(ls >= 2){
				return true;
		}
		return false;
	}
	
    function login(){
    	
    	$("#validate").unbind("blur");
    	
    	//防止重复多次点击，1秒钟之内不能重复调用
    	if(resubmit == true){
    		resubmit = false;
    		window.setTimeout(function(){
    			resubmit = true;
    		},1000);
    	}else{
    		return;
    	}
    	
        var loginName = $("#username").val();
	    var password = $("#password").val();
	    //var code_num = $("#validate").val();
        if(!jQuery.trim(loginName)|| jQuery.trim(loginName)=="请输入用户名") {
            $("#errorTip").removeClass("hidden");
            $("#loginres").html("用户名不能为空！");

            $("#username").focus();
            return;
        }
        if(!jQuery.trim(password) ) {
           $("#errorTip").removeClass("hidden");
            $("#loginres").html("密码不能为空！");

            $("#password").focus();
            return;
        }
        /*
        if(code_num == "" || code_num == "输入验证码"){
            $("#errorTip").removeClass("hidden");
            $("#loginres").html("验证码不能为空！");
            return;
        }
        */
        if(document.getElementById("validCode").style.display != 'none'){
        	var code_num = $("#validate").val();
        	if(code_num == "" || code_num == "输入验证码"){
                $("#errorTip").removeClass("hidden");
                $("#loginres").html("验证码不能为空！");
                return;
            }
        }
        
        var param = {};
        var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
        if(result.retCode != "200"){
        	$("#errorTip").removeClass("hidden");
            $("#loginres").html('系统错误');
            //$("#validate").next().attr("src","captcha.php?'+Math.random();");
            $("#validateImg").click();
            return;
        }
        
        //rsa加密
        var rsakey = new RSAKey();
		rsakey.setPublic(result.modulus,result.exponent);
		var pwd = rsakey.encrypt(password);
        param.loginName = loginName;
        param.password = pwd.toString(16);
        param.platform = "0";	//pc login
        //有验证码的情况下调用userLoginNew校验验证码，
        //没有验证码的情况下调用userLoginNewFirst，如果有错误登录记录就显示验证码，然后调用userLoginNew校验验证码
        if(document.getElementById("validCode").style.display != 'none'){
            param.code = code_num;
            result=execjava("userAuthenBean.userLoginNew",param,"json",userservice);
            }else{
            	param.code = '';//不展示验证码的时候code默认为空
            	result=execjava("userAuthenBean.userLoginNewFirst",param,"json",userservice);
            	if(result.retCode == '900'){//该用户有密码错误次数记录，禁止调用该接口，需填写图片验证码
               	 /*//param.code = code_num;
                   if(document.getElementById("validCode").style.display != 'none'){
                       param.code = code_num;
                       }else{
                       	param.code = '';//不展示验证码的时候code默认为空
                       }
                   result=execjava("userAuthenBean.userLoginNew",param,"json",userservice);
                   if(!result || !result.retCode){
                       $("#errorTip").removeClass("hidden");
                       $("#loginres").html('系统错误');
           			$("#validate").next().attr("src","captcha.php?'+Math.random();");
                       return;
                   }*/
	        		document.getElementById("validCode").style.display = '';
	        		colorConvert();
	        		try{CookieSupport.setNativeCookie("validCode", "validCode");}catch(e){}
	        		$("#errorTip").removeClass("hidden");
	                $("#loginres").html("请输入验证码!");
	                //$("#validate").next().find("img").attr("src","captcha.php?'+Math.random();");
	                $("#validateImg").click();
	                return;           	  
               }  
            }      
        
        
        //检查是否取得校验字段
        var retCode = result.retCode;
        var active = result.isActive;
        
        //检查校验结果
        var msg = "";
        if(retCode=="200"){//经销商用户非首次登录，并用户校验成功。
        	if(active == '0'){
        		alert("用户未激活，请联系企业激活！");
        		return;
        	}
            var forwardSearch=location.search;
            var refPage=document.referrer;

            if(refPage.indexOf(location.hostname)==-1)
                refPage=null;
            if(refPage){
                forwardSearch += (forwardSearch.indexOf( '?' ) >= 0 ? '&' : '?' ) + "referrer="+encodeURIComponent(refPage);
            }
            //登记信息到cookie中
            try{

                if (document.getElementById("rememberUserName").checked) {
                    CookieSupport.setNativeCookie("yname", 	encodeURI(encodeURI(jQuery("#username").val())));
                    CookieSupport.setNativeCookie("saveStatus", 	1);
                } else {
                    CookieSupport.removeNativeCookie("yname");
                    CookieSupport.removeNativeCookie("saveStatus");
                }


            }catch(e){}
            var ary  = execjava("userInfoBean.setLoginSession",{},"json");
            var existComp = ary.existComp;
            if(!ary || !ary.retCode) {
            	$("#errorTip").removeClass("hidden");
            	$("#loginres").html("设置用户session出错!");
            	return;
            }
            if(ary.retCode !='200'){
            	$("#errorTip").removeClass("hidden");
            	$("#loginres").html(ary.retMsg);
            	
            }
            var flag = result.flag;
           var isFirstLogin = result.isFirstLogin;
           var onlineCount = result.onlineCount;
           if(isFirstLogin == "true"){
		       	alert("此次登录为首次登录，为了您的账号安全，请修改您的账号密码及手机号信息！");
		       	$("#modifyPwdOverlay").css("display","block");
		       	$("#fullbg").css("display","block");
	       	}else{	       		
	       		if(existComp =="0"){	       			
	       			alert("您目前还没有绑定分公司，可能会影响某些功能的使用，请联系管理员进行分公司绑定！");	       			
	       		}
	       		if(onlineCount > 1){       			
	       			alert("此账户已在其他设备上登录，请谨慎操作！");
	       			
	       		}
	       		window.location = ctx + "~main/main.php";
	       	}
       
           
           
           
        /*    if(!checkPassComplexity(password)){
            	alert("密码过于简单，为了您的账号安全，请修改您的账号密码！");          	
            	$("#modifyPwdOverlay").css("display","block");
            	$("#fullbg").css("display","block");
            }else 
            	if(isFirstLogin == "true"){
            	alert("此次登录为首次登陆，为了您的账号安全，请修改您的账号密码！");
            	$("#modifyPwdOverlay").css("display","block");
            	$("#fullbg").css("display","block");
            	}else{
            		if(existComp =="0"){
            			alert("您目前还没有绑定分公司，可能会影响某些功能的使用，请联系管理员进行分公司绑定！");
            		}
            	//var order = "quickOrder";
                window.location = ctx + "~main/main.php";
            }*/
        }else {
        	if(result.retCode != "200"){
        		document.getElementById("validCode").style.display = '';
        		colorConvert();
        		try{CookieSupport.setNativeCookie("validCode", "validCode");}catch(e){}
        	}
            $("#errorTip").removeClass("hidden");
            $("#loginres").html(result.retMsg);
            //$("#validate").next().find("img").attr("src","captcha.php?'+Math.random();");
            $("#validateImg").click();

        }
    };
    
    

});
