var searchtype;
var searchstatus;
// 模板标签
template.openTag = "<%";
template.closeTag = "%>";
var userservice = "usermanage";
var accountList = [];
var roleMap = {};
var errinfo={
		"40001":"系统错误",
		"40002":"错误的参数",
		"40003":"appid错误或不存在",
		"40004":"获取密钥失败",
		"40005":"token校验失败",
		"40007":"获取手机验证码失败",
		"40008":"手机验证码校验失败",
		"40009":"手机号码与系统不一致",
		"40011":"非法的用户",
		"40012":"注册失败",
		"40013":"用户名或密码错误",
		"40014":"用户已存在",
		"40015":"修改密码失败",
		"40016":"重置密码失败",
		"40017":"用户未激活",
		"40018":"获取审核列表失败",
		"40019":"审核用户失败",
		"40061":"存在多个用户，需要配置应用号",
		"40076":"您没有权限进行该操作"
	};

$(document).ready(function() {
	//用于弹出框展示
	var triggers = $(".modalInput").overlay({
		// some mask tweaks suitable for modal dialogs
	    mask: {
	      color: '#ebecff',
	      loadSpeed: 1,
	      opacity: 0.8
	    },
	    fixed: false,
	    closeOnClick: false
	});
	/************添加表单校验**********************/
	$.validator.startValidate();
	/************添加表单校验结束**********************/
	getUserList(1);
});
var openType='';
/**
 * 关闭弹出框
 * @param divId
 */
function checkRestore(divId){
	if(!divId){
		return;
	}
	clearForm();
	$("#addOverlay").css("display","none");
	$("#exposeMask").css("display","none");
	$.validator.closeMsg();
	getUserList(1);
}
function disableAccount(i){
	operAccount(i,"0");
}
function enableAccount(i){
	operAccount(i,"1");
}
function operAccount(i,status){
	if(i!=null){
		current = accountList[i];
	}
	var unionId = current.unionId;
	var params = {};
	var msg = "确认"+(status=="1"?"启用":"停用")+"此客户信息?";
	if(!confirm(msg)){
		return;
	}
	params.unionId = unionId;
	params.status = status;
	//激活当前用户
	var ary = execjava('userAuthenBean.userSensor', params, 'json',userservice);
	if (ary == null || ary == "") {
		alert("操作用户失败！");
		return;
	}
	if(ary.retCode != '200'){
		alert(errinfo[ary.retCode] || ary.retMsg);
	}else{
		alert("操作成功！");
		getUserList(1);
	}	
}
var current = null;
/**
 * 展开弹出框
 * @param divId
 * @param i
 */
function openMask(divId,i){
	if(!divId){
		return;
	}
	if(divId=='add')
		$("#oper").html("增加");
	else
		$("#oper").html("编辑");
	openType = divId;
	if(i!=null){
		current = accountList[i];
		var par = {
			unionId :current.unionId
		};
		var res = execjava("userRoleBean.getUserRole",par,'json',userservice);
		if(res&&res['roles']){
			current.roles = res['roles'];
		}
		$("#password,#repeatPassword").parent().parent().hide();
		$("#password,#repeatPassword").removeAttr("rules");
		setForm();
	} else{
		current = null;
		$("#password,#repeatPassword").attr("rules","notnull  length");
		$("#password,#repeatPassword").parent().parent().show();
	}
	
	$("#addOperator").click();
	$("#addOverlay").css("display","block");
	$("#exposeMask").css("display","block");
}
function setForm(){
	$.validator.closeMsg();
	if(!current|| openType=='add') {
		$("#accountForm").find("input").val('');
		$("#status").removeAttr("checked");
		$("#rolelist input").removeAttr("checked");
		return;
	}
	for(var key in current){
		$("#accountForm #"+key).val(current[key]);
	}	
	if(current['status'] == '1') $("#status").attr("checked",true);
	else $("#status").removeAttr("checked");
	if(current.roles){
		for(var i=0;i<current.roles.length;i++){
			$("#rolelist input[value="+current.roles[i].RoleEntityid+"]").attr("checked",true);
		}
	}else{
		$("#rolelist input").removeAttr("checked");
	}
	
}
/**
 * 校验重复密码 
 */
function checkRepass(){
	var passVal = $("#password").val();
	var repassVal = $("#repeatPassword").val();
	
	if(!passVal || !repassVal || passVal==repassVal ){
		return true;
	}else{
		return '两次密码不一致，请重新输入！';
	}
}
/**
 * 清空表单数据 
 */
function clearForm(){
	$("#accountForm").find("input").each(function(){
		var type = $(this).attr("type");
		if(type == 'text' || type == 'password')
			$(this).val("");
		else
			$(this).removeAttr("checked");
	});
}

/*********获取参数*************/
function getParams(){
	var params = {};
	//遍历input
	$("#accountForm input").each(function(a,b){
		var name=$(b).attr("name");
		var val=$(b).val();
		params[name] = val;
	});
	//var checked = $("#accountForm input[type=checkbox]").attr("checked");
	var checked = $("#accountForm input[type=checkbox]")[0].checked;
	if(checked)
		params.status = 1;
	else
		params.status = 0;
	params.accountType = "1";
	return params;
}
/**
 * 清空搜索框
 */
function clean(){
	$("#customerId").val('');
	$("#start_date").val('');
	$("#end_date").val('');
};
/**
 * 根据日期，用户编号进行搜索
 */
function searchByKey() {   
	var start = $("#start_date").val();
	var end = $("#end_date").val();
	start = start.substring(0, 4) + start.substring(5, 7)
			+ start.substring(8, 10);
	end = end.substring(0, 4) + end.substring(5, 7) + end.substring(8, 10);
	if (start > end && start != "" && end != "") {
		alert("开始时间大于结束时间！");
		return;
	}
	getUserList(1);
};
/**
 * 根据用户类型进行搜索
 * @param type
 */
function typeSearch(type)
{
	if(type == 0){searchtype = null;}
	else{searchtype = type-1;}
	$("#typeSearch [typeId]").removeClass();
	$("#typeSearch [typeId = "+type+"]").addClass("search-current");
	getUserList(1);
}

/**
 * 根据审核状态进行搜索
 */
function statusSearch(status)
{
	if(status == 0){searchstatus = null;}
	else{searchstatus = status-1;}
	$("#statusSearch [statusId]").removeClass();
	$("#statusSearch [statusId = "+status+"]").addClass("search-current");
	getUserList(1);
}
/**
 * 查询客户列表
 * 
 * @param pageNum
 *            当前页码
 */
function getUserList(pageNum) {
	 var count = 8;//每页显示的记录数
	 var customerId = $("#customerId").val();
	 customerId = $.trim(customerId);
	 var params = {
			  "limit":count,
		      "page":pageNum,
    		  "searchValue":customerId,
    		  "startTime":$("#start_date").val(),
    		  "endTime":$("#end_date").val(),
    		  "status":searchstatus,
    		  "customerId":acctid
    }; 
	var ary = execjava('userSecBean.getSubUserRoleList', params, 'json',userservice);
	if (!ary || ary.retCode != "200") {
		alert(errinfo[ary.retCode] || ary.retMsg);
		return;
	}
	verifyType = ary.verifyType;
    //搜索到的所有记录
    var num = ary.count;
    //总页数
	var pageTotal = parseInt((parseInt(num)+parseInt(count-1))/count);//总页数   
    
	$("#pager").pager({ 
      pagecount: pageTotal, 
      pagenumber: pageNum, 
      buttonClickCallback: function(pageclickednumber){getUserList(pageclickednumber,status);
      } 
    });		
	accountList = ary.customerVerifyList;

	// 模板渲染
	var customerVerifyListHtml = template.render('accountListTemp', {
		accountList : accountList,
		roleMap:roleMap
	});

	$("#accountListTpl").html(customerVerifyListHtml);
	
}
function showError(msg){
	$("#errTip").removeClass("hidden");
	$("#errorTip").html(msg);
}
function hideError(){
	$("#errTip").addClass("hidden");
	$("#errorTip").html('');
}

function saveOrUpdateAccount(){
	if( !$.validator.verifyAll() ){
		return;
	}
	var params = getParams();
	var role = '';
	var checked = 0;
	
	$("#rolelist").find("input").each(function(index){
		if($(this).attr("checked")=='true'){
			role += ","+$(this).val();
			checked += 1;
		}else if(this.checked){
			role += ","+$(this).val();
			checked += 1;
		}
	});
	if(!checked){
		showError("请至少选择一个角色！");
		return false;
	}
	hideError();
	params.rolee=role.substring(1);
	params.flag = "2";
	if(current){
		params.unionId = current.unionId;
		params.flag = "1";
	}
	if(params.password){
		var param = {};
        var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
        if(result.retCode != "200"){
            showError(errinfo["40001"]);
            return;
        }
        
        //rsa加密
        var rsakey = new RSAKey();
		rsakey.setPublic(result.modulus,result.exponent);
		var pwd = rsakey.encrypt(params.password);
        params.password = pwd.toString(16);
        params.repeatPassword = pwd.toString(16);
	}
	
	params.target = "other";
	params.customerId = acctid;
	var ret=execjava('userSecBean.editUserInfo', params, 'json',userservice);
	if(!ret || !ret.retCode){
		alert("系统异常！");
		return;
	}
	if(ret.retCode == "200"){
		if(current)
			alert("修改成功！");
		else
			alert("增加成功！");
		getUserList(1);
		clearForm('edit');
		checkRestore('add');
	}else{
		alert(errinfo[ret.retCode] || ret.retMsg || "系统错误！请联系管理员！");
	}
}

