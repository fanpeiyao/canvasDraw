/** 注册用户信息校验 */
var userservice = "usermanage";
var errinfo={
		"40001":"系统错误",
		"40002":"错误的参数",
		"40003":"appid错误或不存在",
		"40004":"获取密钥失败",
		"40005":"appid、token校验错误",
		"40007":"获取手机验证码失败",
		"40008":"手机验证码校验失败",
		"40009":"手机号码与系统不一致",
		"40011":"非法的用户",
		"40012":"注册失败",
		"40013":"用户名或密码错误",
		"40014":"用户已存在",
		"40015":"修改密码失败",
		"40016":"重置密码失败",
		"40017":"用户未激活",
		"40018":"获取审核列表失败",
		"40019":"审核用户失败",
		"40071":"两次密码不一致",
		"40072":"密码至少包含大写字母，小写字母，数字和符号中的3种,长度至少为8位",
		"40073":"原密码错误",
		"40074":"没有修改成功",
		"40075":"重置密码失败",
		"40061":"存在多个用户，需要配置应用号",
		"40062":"密码错误超过规定次数，请在30分钟之后进行操作",
		"40063":"当前注册通道为封闭状态，不能进行注册，请联系管理员"
	};

$(document).ready(function() {

	$(".title-tab").find('li').find('a').bind('click',function(){
		$(this).parentsUntil('div').find('a').removeClass('current-tab');
		$(this).addClass('current-tab');
		v1 = $(this).attr('params');
		loadRegisterForm(v1);
		/************添加表单校验**********************/
		$.validator.startValidate({tipPosition:'nel'});
		/************添加表单校验结束**********************/
	});
	
	
	loadRegisterForm(v1);
	//$("input[type=password]").attr("style","width:150px\\9;#width:150px");
	/************添加表单校验**********************/
	$.validator.startValidate({tipPosition:'nel'});
	/************添加表单校验结束**********************/
});
var fieldMapName = {};
var copyMap = [];
//获取表单元素,格式
function loadRegisterForm(v1){
	/************添加表单校验**********************/
	$.validator.stopValidate();
	/************添加表单校验结束**********************/
	clearForm(v1);
	if(!registerForm) return;
	var html = "";
	var functionList = [];
	for(var i=0;i < registerForm.length;i ++ ){
		var temp = registerForm[i];
		if(!temp.formName || temp.formName != v1) continue;
		fieldMapName[temp.fieldName] = temp.displayName;
		if(temp.copyTo){
			copyMap.push({
				name:temp.fieldName,
				copyTo:temp.copyTo
			});
		}
		if(temp.type == 'select'){
			html += '<p><font>' + temp.displayName + ':</font><span>'+
			'<select name="'+ temp.fieldName +'" id="' + temp.fieldName + '" value="' 
			+ temp.defaultValue + '" class="'+ temp.conClass +'" ' ;
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
			if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			 
			html += '></select></span><b>'+ (temp.require?'*':'') +'</b>';
			if(temp.extItem){
				var items = temp.extItem.split('|');
				for(var m=0;m<items.length;m++){
					html += setExtItem(items[m]);
				}
			}
			html += '</p>';
			functionList.push(temp);
			
		}else if(temp.type == 'hidden'){
			html += '<p><font></font><span>'+
			'<input name="'+ temp.fieldName +'" id="' + temp.fieldName + '" type="hidden" value="' 
			+ temp.defaultValue + '" class="'+ temp.conClass +'" ';
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
				if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			html +=' />'
			+'</span><b></b>';
			if(temp.extItem){
				var items = temp.extItem.split('|');
				for(var m=0;m<items.length;m++){
					html += setExtItem(items[m]);
				}
			}
			html += '</p>';
		}else {
			html += '<p><font>' + temp.displayName + ':</font><span>'+
			'<input name="'+ temp.fieldName +'" id="' + temp.fieldName + '" type="' + temp.type + 
			'" value="' + temp.defaultValue + '" class="'+ temp.conClass +'"';
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
				if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			 html += ' />'
			+'</span><b>'+ (temp.require?'*':'') +'</b>';
			if(temp.extItem){
				var items = temp.extItem.split('|');
				for(var m=0;m<items.length;m++){
					html += setExtItem(items[m]);
				}
			}
			html += '</p>';
		}
		
	}
	$("#regInfo").html(html);
	for(var i = 0;i < functionList.length;i ++ ){
		var t = functionList[i];
			//如果控件类型为选择框类型
		var fun = registerList[t.loadFunction];
		if(typeof fun == 'function') fun.call(this,t);
		if(t.type == 'select'){
			var fun = registerList[t.changeFunction];
			if(typeof fun == 'function') $("#"+t.fieldName).bind('change',fun);
		}
	}
	
}

/**
 * 设置同一行多个标签 
 */
var setExtItem = function(key){
	if(!extForm || !extForm[key]) return;
	var extTag = extForm[key];
	var html = "<"+extTag['tagName'] +' ';
	var closeHtml = "</"+extTag['tagName'] +'>';
	for(k in extTag){
		if(k!='tagName'&&k!='html'){
			html += k +'="'+extTag[k]+'"';
		}
	}
	html += ">";
	if(extTag['html'])
		html += extTag['html'];
	html += closeHtml;
	return html;
};
/**
 *注册页面会调用的方法 
 */
var registerList = {
	
	changeArea:function(){
		var id = $(this).attr("id");
		for(var i=0;i < registerForm.length;i ++ ){
			var temp = registerForm[i];
			if(temp.fieldName == id){
				$("#"+temp.relationTo).val($(this).find('option:selected').html());
				break;
			}
		}
	},
	loadArea:function(item){
		var ary = execjava(item.url, item.params,'json');
		if(ary==null|| ary == "" ){
			alert("加载失败");
			return ;
		}
		if(ary[item.returnList] ){
			var html = "";
			for(var i = 0 ;i < ary[item.returnList].length;i ++){
				var area = ary[item.returnList][i];
				html += "<option value='"+area[item.fieldName]+"'>"+area[item.relationTo] + "</option>";
			}
			$("#"+item.fieldName).html(html);
			if(ary[item.returnList].length > 0)
				$("#"+item.relationTo).val(ary[item.returnList][0][item.relationTo]);
		}
	}
};
function clearForm(v1){
	$("#regInfo").html('');
}


function getParams(){
	var params = {};
	var re = /,/g;  
	if(copyMap && copyMap.length >0){
		for(var i=0;i<copyMap.length;i++){
			var item = copyMap[i];
			var name = item.name;
			var copyTo = item.copyTo;
			copyTo = copyTo.replace(re,',#');
			jQuery("#regInfo #"+copyTo).val(jQuery("#regInfo #"+name).val());
		}
	}
	//遍历input
	$("input").each(function(a,b){
		var name=$(b).attr("name");
		var val=$(b).val();
		var type=$(b).attr("type");
		if(type=="password"){
			params[name] = val;
		}else{
			params[name] = val;
 		}
	});
	//遍历select
	$("select").each(function(){
		var name=$(this).attr("name");
		var val=$(this).val();
		params[name] = val;

	});
	if(v1 == 'company')
		params.accountType = "1";
	else
		params.accountType = "0";
	return params;
}
//提交表单信息
function registerUser(){
	if( !$.validator.verifyAll() ){
		return;
	}
	var param = {};
    var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
    if(result.retCode != "200"){
    	 alert(errinfo[ret.retCode] || ret.retMsg);
         return;
    }
    
	var params = getParams();
    
	//rsa加密
    var rsakey = new RSAKey();
	rsakey.setPublic(result.modulus,result.exponent);
	var pwd = rsakey.encrypt(params.password);
    params.password = pwd.toString(16);
	var repwd = rsakey.encrypt(params.repeatPassword);
    params.repeatPassword = repwd.toString(16);
	
	params.target = "register";
	var ret = execjava("userAuthenBean.userRegister", params, "json",userservice);
	if(ret==false){
		alert("系统异常，请联系管理员！");
		return ;
	}
	if(ret.retCode !="200"){
			alert(ret.retMsg || errinfo[ret.retCode]);
	}else{
		alert("注册成功!");
		window.location.href = getContextPath("~main/login.php");
	}
}

