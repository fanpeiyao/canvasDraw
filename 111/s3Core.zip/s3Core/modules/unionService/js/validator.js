$.validator = $.validator || {};
/* 校验控件合法性
 * _defaults参数：
 * 		prekey:"rules", 预定义校验规则
 * 		prekey_sep:" ", 预定义校验规则分隔符
 * 		customkey:"userDefined", 自定义校验规则
 * 		customkey_sep:" ", 自定义校验规则分隔符
 * 		customFnKey:"customFn",//customFn-自定义校验函数
 *		customArgsKey:"customArgs",//customFn-自定义校验函数参数,调用自定义校验函数时，参数以数组形式传入
 *		customArgsKey_sep:" ",//customFn-自定义校验函数参数分隔符
 * 		tipPosition:"nw" 错误提示框位置，共三位数：
 * 					前两位数表示提示框位置：
 * 						nn-提示框位于上方中间；ne-提示框位于上方最右边；nw-提示框位于上方最左边；
 * 						ss-提示框位于下方中间；se-提示框位于下方最右边；sw-提示框位于下方最左边；
 * 						ww-提示框位于左方中间；wn-提示框位于左方最顶部；ws-提示框位于左方最底部；
 * 						ee-提示框位于右方中间；en-提示框位于右方最顶部；es-提示框位于右方最底部；
 * 					第三位数表示提示框箭头位置：
 * 						第一位为n和s时：l-箭头位于提示框左边；c-箭头位于提示框中间；r-箭头位于提示框右边；
 * 						第一位为w和e时：t-箭头位于提示框顶部；c-箭头位于提示框中间；b-箭头位于提示框底部；
 */
(function(){
	
	$.extend($.validator,{
		version: "1.0.0-beta.1",
		_defaults:{
			prekey:"rules",//rules-预定义校验规则;
			prekey_sep:" ",//rules-预定义校验规则分隔符
			customkey:"userDefined",//userDefined-自定义校验规则
			customkey_sep:" ",//userDefined-自定义校验规则分隔符
			customkey_msg:"userMsg",//自定义校验规则错误信息字段
			customFnKey:"customFn",//customFn-自定义校验函数
			customArgsKey:"customArgs",//customFn-自定义校验函数参数
			customArgsKey_sep:" ",//customFn-自定义校验函数参数分隔符
			tipPosition:"EEC"//提示信息显示位置
		},
		_settings:{
			prekey:"rules",//rules-预定义校验规则;
			prekey_sep:" ",//rules-预定义校验规则分隔符
			customkey:"userDefined",//userDefined-自定义校验规则
			customkey_sep:" ",//userDefined-自定义校验规则分隔符
			customkey_msg:"userMsg",//自定义校验规则错误信息字段
			customFnKey:"customFn",//customFn-自定义校验函数
			customArgsKey:"customArgs",//customFn-自定义校验函数参数
			customArgsKey_sep:" ",//customFn-自定义校验函数参数分隔符
			tipPosition:"EEC"//提示信息显示位置
		},
		RULEKEYS:{
			NOTNULL:"notnull",//非空
			LENGTH:"length",//长度校验
			NUMBER:"number",//数字校验
			POSITIVE:"positive",//非负数校验（含0）
			INTEGER:"integer",//非负整数校验（含0）
			EMAIL:"email",//邮箱校验
			MOBILE:"mobile",//手机号码校验
			FIXEDLINE:"fixedline",//固话校验
			TEL:"tel",//手机及固话校验
			IDCARD:"idcard",//身份证校验
			POSTCODE:"postcode",//邮政编码
			ILLEGALCHAR:"illegalchar",//非法字符是否含有 <>&/'|
			LETTER:"letter",//26个英文字母  
			UPPERLETTER:"upperletter",//26个大写英文字母  
			LOWERLETTER:"lowerletter",//26个小写英文字母
			NUMLETTER:"numletter",//数字、字母
			NUMLETTERLINE:"numletterline",//数字、字母和下划线
			PASSWORD:"password",//密码
			CHINESECHAR:"chinesechar",//汉字
			USERNAME:"username"//登录名，只能包含汉字、字母、数字和下划线
		},
		errmsgs:{
			NOTNULL:"不能为空！",//非空
			NUMBER:"请输入数字！",//数字校验
			POSITIVE:"请输入大于0的数字！",//非负数校验（含0）
			INTEGER:"请输入正整数！",//非负整数校验（含0）
			EMAIL:"请填写正确的邮箱格式！",//邮箱校验
			MOBILE:"请填写正确的手机号码！",//手机号码校验
			FIXEDLINE:"请填写正确的电话号码！",//固话校验
			TEL:"请填写正确的手机/电话号码！",//手机及固话校验
			IDCARD:"请填写正确的身份证号码！",//身份证校验
			POSTCODE:"请填写正确的邮政编码！",//邮政编码
			ILLEGALCHAR:"不能输入以下特殊字符“<>&/\'|\\”",//非法字符是否含有 <>&/'|
			LETTER:"请输入英文字母！",//26个英文字母  
			UPPERLETTER:"请输入大写英文字母！",//26个大写英文字母  
			LOWERLETTER:"请输入小写英文字母！",//26个小写英文字母
			NUMLETTER:"请输入字母和数字！",//数字、字母
			NUMLETTERLINE:"请输入字母、数字和下划线！",//数字、字母和下划线
			PASSWORD:"请以字母开头、长度在8-18位，至少包含大写字母，小写字母，数字和符号中的3种！",//密码
			CHINESECHAR:"请输入中文！",//汉字
			MINLENGTH:"最小长度不能小于",
			MAXLENGTH:"最大长度不能大于",
			ERRFORMAT:"输入的格式不正确！",
			USERNAME:"请输入汉字、字母、数字、小数点和下划线！"//登录名，只能包含汉字、字母、数字和下划线
		},
		_patterns:{
			NUMBER:"^[0-9]*$",//数字校验
			POSITIVE:"^\\d+(\\.\\d+)?$",//非负数校验（含0）
			INTEGER:"^\\d+$",//非负整数校验（含0）
			EMAIL:"^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$",//邮箱校验
			MOBILE:"^(86)?1[3-8]\\d{9}$",//手机号码校验
			FIXEDLINE:"^((\\(010|02[0-9]|0[3-9][0-9]{2}\\))|(010|02[0-9]|0[3-9][0-9]{2}-)|(010|02[0-9]|0[3-9][0-9]{2}))?\\d{7,8}(-\\d{1,4})?$",//固话校验
			TEL:"^(010|02[0-9]|0[3-9][0-9]{2}-)?\\d{7,8}$|^(010|02[0-9]|0[0-9][0-9]{2}\\d{7,8})$|^\\d{7,8}$|^1\\d{10}$",//手机及固话校验
			POSTCODE:"^\\d{6}$",//邮政编码
			ILLEGALCHAR:"^[^<>&/|'\\\\]+$",//非法字符是否含有 <>&/'|\
			LETTER:"^[A-Za-z]+$",//26个英文字母
			UPPERLETTER:"^[A-Z]+$",//26个大写英文字母  
			LOWERLETTER:"^[a-z]+$",//26个小写英文字母
			NUMLETTER:"^[A-Za-z0-9]+$",//数字、字母
			NUMLETTERLINE:"^\\w+$",//数字、字母和下划线
			//PASSWORD:"^[A-Za-z]\\w{7,17}$",//密码，以字母开头、长度在8-18位，只能包含字母、数字和下划线
			PASSWORD:"^[a-z](?=.*?\\w)(?=.*?[0-9])(?=.*?[A-Z]){8,18}|^[A-Z](?=.*?\\w)(?=.*?[0-9]){8,18}",//密码，以字母开头、长度在8-18位，只能包含字母、数字和下划线
			CHINESECHAR:"^[\u4e00-\u9fa5]*$",//汉字
			USERNAME:"^[\\u4e00-\\u9fa5\\w.]*$"//登录名，只能包含汉字、字母、数字、小数点和下划线
		},
		_verifyKeys:[],
		_verifyArray:{},//校验结果保存对象
		_setConfig:function(config){
			this._settings = $.extend({},this._defaults,config);
		},
		startValidate: function(config) {
			this._setConfig(config);
			this._verifyKeys = [this._settings.prekey,
					            this._settings.customkey,
					            this._settings.customFnKey];
	        
			for(var i=0;i<this._verifyKeys.length;i++){
				//获取含有关键字属性对象
				$("["+this._verifyKeys[i]+"]:not(:disabled)").each(function(i){
					//获取校验对象的标签名，只校验input和select
					var ele = $(this);
					if(ele.is("input") || ele.is("select")){
						//利用随机数产生校验编号,绑定校验事件
						var num = ele.attr("verifyNum");
						if(!num){
							num = i+getRandom(6);
							ele.attr("verifyNum",num);
							ele.bind("blur",function(){$.validator.verify($(this));});
						}
					}
				});
			}
		},
		stopValidate:function(){
			for(var i=0;i<this._verifyKeys.length;i++){
				//获取含有关键字属性对象
				$("["+this._verifyKeys[i]+"]:not(:disabled)").each(function(i){
					//获取校验对象的标签名，只校验input和select
					var ele = $(this);
					if(ele.is("input") || ele.is("select")){
						$.validator.unVerify(ele);
					}
				});
			}
		},
		verify:function(ele){
			if(!ele) return;
			//获取对象配置的预定义校验规则
			var preRules = ele.attr(this._settings.prekey);
			preRules = preRules?$.trim(preRules):"";
			//获取对象配置的自定义校验规则
			var customRules = ele.attr(this._settings.customkey);
			customRules = customRules?$.trim(customRules):"";
			//获取对象配置的自定义校验函数
			var customFn = ele.attr(this._settings.customFnKey);
			customFn = customFn?$.trim(customFn):"";
			
			var num = ele.attr("verifyNum");
			
			//初始化为通过
			this._verifyArray[num] = true;
			//预定义校验规则
			if(preRules!=""){
				var preRuleArr = preRules.split(this._settings.prekey_sep);
				for(var i=0;i<preRuleArr.length;i++){
					this._verifyArray[num] = this.preValidate(preRuleArr[i].toLowerCase(),ele);
					if(!this._verifyArray[num])	break;
				}
			}
			//预定义校验通过或无预定义校验，开始自定义正则校验
			if(this._verifyArray[num] && customRules!=""){
				var customRuleArr = customRules.split(this._settings.customkey_sep);
				for(var i=0;i<customRuleArr.length;i++){
					this._verifyArray[num] = this.customValidate(customRuleArr[i],ele);
					if(!this._verifyArray[num]) break;
				}
			}
			//预定义、自定义正则校验通过或无预定义、自定义正则校验，开始自定义函数校验
			if(this._verifyArray[num] && customFn!=""){
				//获取对象配置的自定义校验函数
				var customArgs = ele.attr(this._settings.customArgsKey);
				var msg = true;
				if(customArgs){
					customArgs = $.trim(customArgs).split(this._settings.customArgsKey_sep);
					if(typeof window[customFn] === "function"){
						msg = window[customFn](customArgs);
					}
				}else{
					if(typeof window[customFn] === "function"){
						msg = window[customFn]();
					}
				}
				
				this._verifyArray[num] = (msg==true?true:false);
				//设置提示错误信息框
				this.showMsg(ele,msg,this._verifyArray[num]);
			}
			return this._verifyArray[num];
		},
		unVerify:function(ele){
			if(!ele) return;
			var preRules = ele.attr(this._settings.prekey)?$.trim(ele.attr(this._settings.prekey)):"";//获取对象配置的预定义校验规则
			var customRules = ele.attr(this._settings.customkey)?$.trim(ele.attr(this._settings.customkey)):"";//获取对象配置的自定义校验规则
			//利用随机数产生校验编号
			var num = ele.attr("verifyNum");
			if(num){
				ele.removeAttr("verifyNum");//删除校验属性
				ele.unbind("blur",function(){$.validator.verify($(this));});//移除绑定事件
			}
			delete this._verifyArray[num];//删除校验结果
			//移除错误信息框
			var tip = $("#"+ num);
			if(tip.length>0) tip.remove();
		},
		/* 校验所有配有校验规则的可编辑input和select
		 * param：form 指定某一需要校验的form表单jquery对象，
		 * 		  若为空，则校验所有需要校验的对象。
		 * return：boolean 所有需要校验的对象是否都通过： true-全部通过，否-存在不通过
		 */
		verifyAll:function(form){
			var eles;
			var isCorrect = true;
			
			for(var i=0;i<this._verifyKeys.length;i++){
				if(!form){
					//获取含有关键字属性对象
					eles = $("["+this._verifyKeys[i]+"]:not(:disabled)");
				}else{
					//获取含有关键字属性对象
					var tag = form[0].tagName.toLowerCase();
					var id = form.attr("id");
					var name = form.attr("name");
					var selector = tag;
					if(id)
						selector += "[id='" + id + "']";
					if(name)
						selector += "[name='" + name + "']";
					eles = $(selector+" ["+this._verifyKeys[i]+"]:not(:disabled)");
				}
				eles.each(function(i){
					//获取校验对象的标签名，只校验input和select
					var ele = $(this);
					if((ele.is("input") || ele.is("select")) && !$.validator.verify(ele)){
						isCorrect=false;
					}
				});
			}
			return isCorrect;
		},
		preValidate:function (preRule,ele){
			var value = $.trim(ele.val());
			var msg = "";
			var reg;
			var isCorrect = true;
			
			switch(preRule){
				case this.RULEKEYS.NOTNULL :
					if(!value || value == ""){
						msg = msg + this.errmsgs.NOTNULL;
						isCorrect = false;
					}
					break;
				case this.RULEKEYS.LENGTH :
					var b = true;
					var minlen = ele.attr("minLength");
					var maxlen = ele.attr("maxLength");
					if(!value || (!minlen && !maxlen)) 
						return true;
					if(minlen && value.length < minlen){
						msg = msg || this.errmsgs.MINLENGTH + minlen + '!';
						isCorrect = false;
					}
					if(maxlen && value.length > maxlen){
						msg = msg || this.errmsgs.MAXLENGTH + maxlen + '!';
						isCorrect = false;
					}
					break;
				case this.RULEKEYS.IDCARD :
					if(chkIDCard(value) == false){
						msg = msg + this.errmsgs.IDCARD;
						isCorrect = false;
					}
					break;
				default:
					if(value){
						for(var key in this.RULEKEYS){
							if(preRule == this.RULEKEYS[key]){
								reg = new RegExp(this._patterns[key]);
								
								if( !reg.test(value) ){
									msg = msg + this.errmsgs[key];
									isCorrect = false;
								}
								break;
							}
						}
					}
			}
			//设置提示错误信息框
			this.showMsg(ele,msg,isCorrect);
			
			return isCorrect;	
		},
		customValidate:function(pattern,ele){
			var value = $.trim(ele.val());
			var msg = ele.attr(this._settings.customkey_msg);
			var reg;
			var isCorrect = true;
			try{
				reg = new RegExp(pattern);
				if( value && !reg.test(value) ){
					if(!msg){
						msg = this.errmsgs.ERRFORMAT;
					}
					isCorrect = false;
				}
			}catch(e){
				isCorrect = false;
			}
			
			//设置提示错误信息框
			this.showMsg(ele,msg,isCorrect);
			
			return isCorrect;	
		},
		showMsg:function(ele,msg,isCorrect){
			//设置提示错误信息框
			var verifyNum = ele.attr('verifyNum');
			var tip = $("#"+ verifyNum);
			
			if(tip.length > 0) tip.remove();
			if(!isCorrect) {
				showPrompt(ele, msg,{gravity:this._settings.tipPosition});
			}
		},
		closeMsg:function(obj){
			if(!obj){
				$("div.tipsy").each(function(i){
					$(this).remove();
				});
			}else{
				$(obj).find("[verifynum]").each(function(i){
					var ele = $(this);
					var tip = $("#"+ele.attr("verifynum"));
					if((ele.is("input") || ele.is("select")) && tip.length > 0){
						tip.remove();
					}
				});
			}
		}
	});
	
	/*
	 * 生产指定位数的随机数.
	 * 参数为生成随机数的位数.
	 */
	var getRandom = function(n){
		n = n || 1;
		var rnd = '';
		for(var i = 0; i < n; i++) rnd += Math.floor(Math.random() * 10);
		return rnd - 0;
	};
	
})();