var operatorList = null;
var type = null;
var userservice = 'usermanage';
var errinfo={
		"40001":"系统错误",
		"40002":"错误的参数",
		"40003":"appid错误或不存在",
		"40004":"获取密钥失败",
		"40005":"appid、token校验错误",
		"40007":"获取手机验证码失败",
		"40008":"手机验证码校验失败",
		"40009":"手机号码与系统不一致",
		"40011":"非法的用户",
		"40012":"注册失败",
		"40013":"用户名或密码错误",
		"40014":"用户已存在",
		"40015":"修改密码失败",
		"40016":"重置密码失败",
		"40017":"用户未激活",
		"40018":"获取审核列表失败",
		"40019":"审核用户失败",
		"40020":"获取用户信息失败",
		"40021":"修改用户信息失败",
		"40022":"获取地址信息失败",
		"40023":"修改地址信息失败",
		"40033":"获取用户角色失败",
		"40034":"修改用户角色失败",
		"40041":"修改用户对应关系失败",
		"40042":"该用户未注册，无法绑定",
		"40043":"获取用户列表失败",
		"40071":"两次密码不一致",
		"40072":"请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。",
		"40073":"原密码错误",
		"40074":"没有修改成功",
		"40075":"重置密码失败",
		"40076":"只有管理员才能进行该操作",
		"40077":"校验不通过",
		"40061":"存在多个用户，需要配置应用号"
	};
$(document).ready(function() {
	//用于弹出框展示
	var triggers = $(".modalInput").overlay({
		// some mask tweaks suitable for modal dialogs
	    mask: {
	      color: '#ebecff',
	      loadSpeed: 1,
	      opacity: 0.8
	    },
	    fixed: false,
	    closeOnClick: false
	});
	loadAllRoles();
	loadData(1);
	loadRegisterForm(v1);
	/************添加表单校验**********************/
	$.validator.startValidate();
	/************添加表单校验结束**********************/
});

var roleMap = {};
var copyMap = [];

function loadAllRoles(){
	var result = execjava("userManageBean.getMainRoleList", {},'json');
		if(!result ||!result['roles'] || !result['roles'].length){
			return;
		}
		var html = "";
		var roles = result['roles'];
		for(var i=0;i<roles.length;){
			roleMap[roles[i].RoleEntityid] = roles[i].RoleEntityname;
			html += '<p class="pl2 post">';
			html += '<span class="span2"><input name="" type="checkbox" value="'+ roles[i].RoleEntityid +'"　class="bord0" />'+roles[i].RoleEntityname+'</span>';
			if(i+1<roles.length){
				roleMap[roles[i+1].RoleEntityid] = roles[i+1].RoleEntityname;
				html += '<span class="span2"><input name="" type="checkbox" value="'+ roles[i+1].RoleEntityid +'"　class="bord0" />'+roles[i+1].RoleEntityname+'</span>';
			}
			if(i+2<roles.length){
				roleMap[roles[i+2].RoleEntityid] = roles[i+2].RoleEntityname;
				html += '<span class="span2"><input name="" type="checkbox" value="'+ roles[i+2].RoleEntityid +'"　class="bord0" />'+roles[i+2].RoleEntityname+'</span>';
			}
			html += '</p>';
			i+=3;
		}
		jQuery("#rolelist").html(html);
}
var current = null;
var count = 10;
var userPageNum = 1;

function openMask(divId,i){
	//$("#confirmbtn").unbind();
	if(!divId){
		return;
	}
	hideError();
	type = divId;
	if(divId=='add'){
		current = null;
		$("#oper").html('增加');
		$("#confirmbtn").attr("onClick","addOperator()");
		//$("#confirmbtn").bind("click",function(){addOperator()});
	}else{
		$("#oper").html('编辑');
		$("#confirmbtn").attr("onClick","editOperator()");
		//$("#confirmbtn").bind("click",function(){editOperator()});
	}
	if(i!=null){
		current = operatorList[i];
	}
	setEditForm(current,divId);
	$("#addOperator").click();

	$("#addOverlay").css({"display":"block","position":"fixed","top":"21%","left":"28%","z-index":"99999"});
	$("#customerOverlay").css({"display":"block","position":"fixed","top":"21%","left":"28%"});
	$("#exposeMask").css("display","block");
	$('#fullbg').show();
}

function openResetMask(i){
	$("#resetErrTip").addClass("hidden");
	$("#resetErrorTip").html('');
	if(i!=null){
		current = operatorList[i];
	}
	$("#resetOverlay").find("input").val('');
	$("#resetOperator").click();
	$('#fullbg').show();
	$("#resetOverlay").css({"display":"block","position":"fixed","top":"21%","left":"28%"});
	$("#exposeMask").css("display","block");
}

function checkPwd(){
	var password = $("#resetOverlay").find("input").val();
	password = $.trim(password);
	
	if(!password){
		$("#resetErrTip").removeClass("hidden");
		$("#resetErrorTip").html('密码不能为空！');
		return;
	}else{
		if(password.length >=8 && password.length <=16){
			$("#resetErrTip").addClass("hidden");
			$("#resetErrTip").html('');
		}else{
			$("#resetErrTip").removeClass("hidden");
			$("#resetErrorTip").html('请输入8-16位的密码！');
			return;
		}
	}
}

function resetPwd(){
	if(!current)return;
	var password = $("#resetOverlay").find("input").val();
	password = $.trim(password);
	
	var params = {
		loginName:current.loginName
	};
	var ret=execjava("userManageBean.resetPassword",params,"json");
	if(!ret || !ret.retCode){
		alert("系统异常！");
		$("#fullbg").hide();
		return;
	}
	if(ret.retCode == "200"){
		alert("重置密码成功！该用户的密码重置为"+ret.password);
		clearResetForm();
	}else{
		alert(errinfo[ret.retCode] || ret.retMsg);
		$("#fullbg").hide();
	}
	
}

function deleteUser(i){
	if(i!=null){
		current = operatorList[i];
	}
	var unionId = current.unionId;
	var params = {};
	var msg = "确认删除此客户信息?";
	if(!confirm(msg)){
		return;
	}
	params.unionId = unionId;
	params.status = "2";
	//激活当前用户
	var ary = execjava('userAuthenBean.userSensor', params, 'json',userservice);
	if (ary == null || ary == "") {
		alert("操作用户失败！");
		return;
	}
	if(ary.retCode != '200'){
		alert(errinfo[ary.retCode]  || ary.retMsg);
	}else{
		alert("操作成功！");
		loadData(1);
	}	
}

function checkRestore(divId){
	if(!divId){
		return;
	}
	type=divId;
	$("#"+divId+"Overlay").css("display","none");
	$("#exposeMask").css("display","none");
	$('#fullbg').hide();
	$.validator.closeMsg();
	loadData(userPageNum);
}
function setEditForm(current,divId){

	$("#rolelist input").removeAttr("checked");
		loadRegisterForm(v1);
				/************添加表单校验**********************/
				$.validator.startValidate();
				/************添加表单校验结束**********************/
			if(divId=='add'){
				
			}else{
				jQuery("#customerForm input,select").attr("disabled",false);
				//首先给所有输入框设值，然后将所有的软件框　选择框都设为不可用，最后将可修改的框移除不可用属性
				for(var key in current){
					jQuery("#customerForm [name=" + key + "]").val(current[key]);
				}
			}
	if(divId=='edit'){
		var roles = current.roles;
		for(var j = 0;j<roles.length;j++){
			$("#rolelist input[value="+roles[j].RoleEntityid+"]").attr('checked',true);
		}
		
	}
	if(divId == 'add'){
		jQuery("#customerForm").find("input").removeAttr("disabled");
	}else{
		jQuery("#customerForm #password,#repeatPassword").parent().parent().remove();
		//jQuery("#customerForm").find("input:last").attr("disabled",true);
	}
	
	
	
}

function loadData(pageNum){
	 
	var searchId = $("#searchId").val();
	searchId = $.trim(searchId);
	userPageNum = pageNum;
 	var params = {
		"pageNum":pageNum,
		"limit":10
	};
	
	if(searchId!=null && searchId != undefined && searchId != ""){
		params.searchKey = searchId;
	}
	var result=execjava("userManageBean.getUserList",params,"json");
	if(result.retCode != '200'){
		alert(errinfo[result.retCode]);
	}
	
	var list = [];
	for(var i = 0;i < result.userList.length;i ++){
		 var user = result.userList[i];

		 var item = {};
		 item.unionId = user.UserEntityid;
		 item.customerId = user.UserEntitycustomId;
		 item.userName = user.UserEntityuserName;
		 item.loginName = user.UserEntityloginName;
		 item.mobile = user.UserEntitymobilephone;
		 item.roles = user.UserEntityroles;
		 item.email = user.UserEntityemail;
		 list.push(item);
	}

	operatorList = list;
	var num = result.count;//总记录数
	var pageTotal = parseInt((parseInt(num)+parseInt(count-1))/count);// 总页数
	$("#pager").pager({ 
	      pagecount: pageTotal, 
	      pagenumber: pageNum, 
	      buttonClickCallback: function(pageclickednumber){userPageNum = pageclickednumber;loadData(pageclickednumber);} 
	    });
	//加载数据
 	var salesManagerList = template.render('salesManagerTemp', {
 		userList: result.userList
 	 });	
 	$("#salesList").html(salesManagerList);	
}
function showError(msg){
	$("#errTip").removeClass("hidden");
	$("#errorTip").html(msg);
}
function hideError(){
	$("#errTip").addClass("hidden");
	$("#errorTip").html('');
}


/*********获取参数*************/
function getParams(){
	var params = {};
	var re = /,/g;  
	if(copyMap && copyMap.length >0){
		for(var i=0;i<copyMap.length;i++){
			var item = copyMap[i];
			var name = item.name;
			var copyTo = item.copyTo;
			copyTo = copyTo.replace(re,',#');
			jQuery("#customerForm #"+copyTo).val(jQuery("#customerForm #"+name).val());
		}
	}
	//遍历input
	$("input").each(function(a,b){
		var name=$(b).attr("name");
		var val=$(b).val();
		var type=$(b).attr("type");
		if(type=="password"){
			params[name] = val;
		}else{
			params[name] = val;
 		}
	});
	//遍历select
	$("select").each(function(){
		var name=$(this).attr("name");
		var val=$(this).val();
		params[name] = val;

	});
	if(v1 == 'company')
		params.accountType = "1";
	else
		params.accountType = "0";
	return params;
}
//检测密码复杂度
function checkPassComplexity(password){
	if(password.length<8 || password.length>16){
		return false;
     }
	var ls = 0;
	if(password.match("(.*)[a-z]+(.*)")){
			ls++;
	}
	if(password.match("(.*)[A-Z]+(.*)")){
		ls++;
	}
	if(password.match("(.*)[0-9]+(.*)")){
			ls++;
	}				
	if(password.match("(.*)[^a-zA-Z0-9]+(.*)")){
			ls++;
	}			
	if(ls >= 2){
			return true;
	}
	return false;
}
function addOperator(){
	if( !$.validator.verifyAll() ){
		return;
	}
	var params = getParams();

	if(!checkPassComplexity(params.password)){
		showError("请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。");
	}
	var role = '';
	var checked = 0;
	
	$("#rolelist").find("input").each(function(index){
		if($(this).attr("checked")=='true'){
			role += ","+$(this).val();
			checked += 1;
		}else if(this.checked){
			role += ","+$(this).val();
			checked += 1;
		}
		
	});
	if(!checked){
		showError("请至少选择一个角色！");
		return false;
	}

	hideError();
	params.rolee=role.substring(1);
	params.flag = "2";
	if(current){
		params.unionId = current.unionId;
		params.flag = "1";
	}
	/*if(params.password){
		var param = {};
        var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
        if(result.retCode != "200"){
        	$("#errorTip").removeClass("hidden");
            $("#loginres").html(errinfo["40001"]);
            return;
        }
           
	}*/
	

	var ret=execjava('userManageBean.addUser', params, 'json');
	if(!ret || !ret.retCode){
		alert("系统异常！");
		return;
	}
	if(ret.retCode == "200"){
		alert("增加成功！");
		checkRestore('add');
	}else{
		alert(errinfo[ret.retCode] || ret.retMsg);
	}
}

function editOperator(){	
	if( !$.validator.verifyAll() ){
		return;
	}
	var params = getParams();
	var role = '';
	var checked = 0;
	
	$("#rolelist").find("input").each(function(index){
		if($(this).attr("checked")=='true'){
			role += ","+$(this).val();
			checked += 1;
		}else if(this.checked){
			role += ","+$(this).val();
			checked += 1;
		}
		
	});
	if(!checked){
		showError("请至少选择一个角色！");
		return false;
	}

	hideError();
	params.rolee=role.substring(1);
	params.flag = "2";
	if(current){
		params.unionId = current.unionId;
		params.flag = "1";
	}
	/*if(params.password){
		var param = {};
        var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
        if(result.retCode != "200"){
        	$("#errorTip").removeClass("hidden");
            $("#loginres").html(errinfo["40001"]);
            return;
        }
           
	}*/
	

	var ret=execjava('userManageBean.editUser', params, 'json');
	if(!ret || !ret.retCode){
		alert("系统异常！");
		return;
	}
	if(ret.retCode == "200"){
		alert("修改成功！");
		checkRestore('add');
		location.reload();
	}else{
		alert(errinfo[ret.retCode] || ret.retMsg);
	}
}

function clearForm(divId){
	jQuery("#customerForm input,#customerForm select").val('');
	
	$("#rolelist [type=checkbox]").each(function(){
		$(this).attr('checked',false);
	});
	
	if(current){
		jQuery("#customerForm input,#customerForm select").each(function(){
			jQuery(this).val(current[jQuery(this).attr("id")]);
		});
	}
	if(current){
		var roles = current.roles;
		$("#rolelist [type=checkbox]").each(function(){
			$(this).attr('checked',false);
		});
		for(var j = 0;j<roles.length;j++){
			$("#rolelist input[value="+roles[j].RoleEntityid+"]").attr('checked',true);
		}
		
	}
}
function clearResetForm(){
//	if(i!=null){
//		current = operatorList[i];
//	}
	$("#resetOperator").click();
	$("#resetOverlay").css("display","none");
	$("#exposeMask").css("display","none");
	$("#fullbg").hide();
}
function clean(){
	$("#searchId").val('');
	loadData(1);
}
/*
function deleleOperator(index){
	if(Number(index) < 0){
		return;
	}
	if(!confirm("请确认是否删除该用户？")){
		return;
	}
	var oper = operatorList[index];
	if(!oper)
		return;
	var params = {
		id : oper.userId
	};
	var ret=execjava('userInfoBean.deleteOperator', params, 'json');

	if(!ret || !ret.retCode){
		return ;
	}
	if(ret.retCode == '200'){
		alert("删除成功！");
		checkRestore('edit');
	}else{
		alert(ret.retMsg);
	}
}*/

function getValidateCodeByMobile(){
	var mobile = $("#mobile").val();
	if(mobile == ''){
		$("#mobile").blur();
		return;
	}else if(!/^(86)?1[3-8]\d{9}$/.test(mobile)){
		alert("请填写正确的手机号码！");
		return;
	}
	html = '<p><font>手机验证码：</font><span><input name="'+ 'validateCode' +'" id="'+'validateCode'+ '" type="'+'text'+ 
	'" value="' + '' + '" class="'+ 'input-regist-check' +'"';
		html += ' rules="' + 'notnull' + '"';
		html += ' userDefined="' + '' + '" ';	
	 html += ' />'
	+'</span><b>'+ '*'+'</b>';
	html += setExtItem('getValidateCode');
	html+='</p>';
	 $("#customerId").parent().parent().after(html);
	btn = $("#getCheckCode");
//	var params = {
//		mobile:mobile
//	};
//	execjava("userAuthenBean.getValidateCode",params,"json",'usermanage',true,codeCallback);	
}


/**
 * 设置同一行多个标签 
 */
var setExtItem = function(key){
	if(!extForm1 || !extForm1[key]) return;
	var extTag = extForm1[key];
	var html = "<"+extTag['tagName'] +' ';
	var closeHtml = "</"+extTag['tagName'] +'>';
	for(k in extTag){
		if(k!='tagName'&&k!='html'){
			html += k +'="'+extTag[k]+'"';
		}
	}
	html += ">";
	if(extTag['html'])
		html += extTag['html'];
	html += closeHtml;
	return html;
};

function getRegisterForm(){
	for(var i=0;i<registerForm.length;i++){
		if(registerForm[i].formName == v1 && registerForm[i].fieldName == 'validateCode'){
			registerForm.splice(i,1);
			break;
		}
	}
}

/************生成客户FORM******************/
var fieldMapName = {};
var saveOrUpdateCols = [];
//获取表单元素,格式
function loadRegisterForm(v1){
	/************添加表单校验**********************/
	$.validator.stopValidate();
	/************添加表单校验结束**********************/
	clearForm(v1);
	getRegisterForm();
	if(!registerForm) return;
	var html = '<input name="id" type="hidden" />';
	var functionList = [];
	for(var i=0;i < registerForm.length;i ++ ){
		var temp = registerForm[i];
		if(!temp.formName || temp.formName != v1) continue;
		fieldMapName[temp.fieldName] = temp.displayName;
		saveOrUpdateCols.push(temp.fieldName);
		if(temp.type == 'select'){
			html += '<p><font>' + temp.displayName + '：</font><span>'+
			'<select name="'+ temp.fieldName +'" id="' + temp.fieldName + '" value="' 
			+ temp.defaultValue + '" class="'+ temp.conClass +'" ' ;
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
			if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			 
			html += '></select></span><b>'+ (temp.require?'*':'') +'</b></p>';
			functionList.push(temp);
			
		}else if(temp.type == 'hidden'){
			html += '<p><font></font><span>'+
			'<input name="'+ temp.fieldName +'" id="' + temp.fieldName + '" type="hidden" value="' 
			+ temp.defaultValue + '" class="'+ temp.conClass +'" ';
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
				if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			html +=' />'
			+'</span><b></b></p>';
		}else {
			html += '<p><font>' + temp.displayName + '：</font><span>'+
			'<input name="'+ temp.fieldName +'" id="' + temp.fieldName + '" type="' + temp.type + 
			'" value="' + temp.defaultValue + '" class="'+ temp.conClass +'"';
			if(temp.rules)
				html += ' rules="' + temp.rules + '"';
			if(temp.relationTo)
				html += ' relationTo="' + temp.relationTo + '"';
			if(temp.minLength)
				html += ' minLength="' + temp.minLength + '"';
			if(temp.maxLength)
				html += ' maxLength="' + temp.maxLength + '"';
			if(temp.onchange)
				html += ' onchange="' + temp.onchange + '"';
			if(temp.userDefined)
				html += ' userDefined="' + temp.userDefined + '" ';	
				if(temp.customFn)
				html += ' customFn="' + temp.customFn + '" ';	
			if(temp.customArgs)
				html += ' customArgs="' + temp.customArgs + '" ';	
			 html += ' />'
			+'</span><b>'+ (temp.require?'*':'') +'</b></p>';
		}
		
	}
	$("#customerForm").html(html);
	for(var i = 0;i < functionList.length;i ++ ){
		var t = functionList[i];
			//如果控件类型为选择框类型
		var fun = registerList[t.loadFunction];
		if(typeof fun == 'function') fun.call(this,t);
		if(t.type == 'select'){
			var fun = registerList[t.changeFunction];
			if(typeof fun == 'function') $("#"+t.fieldName).bind('change',fun);
		}
	}
	
}

//推送菜单
function propelling(){
	$.ajax({
      url: path + "~main/share/creatRoleFun.php",
      async: false,
      cache: false,
      success:function(result){
      	alert(result);
      }
    });
	window.location.href = window.location.href;
}
function stopAccount(i){
	if(!confirm("确认停用该帐户？")) return;
	if(i==null ||i ==undefined) return;
	current = operatorList[i];
	var params = {
		unionId:current.unionId
	};
	var result=execjava("userInfoBean.setAccountStatus",params,"json");
	if(!result || !result.retCode){
		alert("停用帐户失败");
		return;
	}
	if(result.retCode == '200'){
		alert("操作成功");
		loadData(1);
	}else{
		alert(result.retMsg);
	}
}