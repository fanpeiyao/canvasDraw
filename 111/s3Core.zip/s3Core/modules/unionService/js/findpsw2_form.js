$(function(){
	var userservice = "usermanage";
	
	 var params = null;
	 

});
var loginName = S3Config.getConfig("s3_userName");
var errinfo={
		"40001":"系统错误",
		"40002":"错误的参数",
		"40016":"重置密码失败",
		"40061":"存在多个用户，需要配置应用号",
		"40009":"输入的手机号码与系统的不一致！",
		"40071":"两次密码不一致",
		"40072":"密码至少包含大写字母，小写字母，数字和符号中的3种",
		"40073":"原密码错误",
		"40074":"没有修改成功",
		"40075":"重置密码失败",
		"40061":"存在多个用户，需要配置应用号"
	};


function findpsw2(){
	var userservice = "usermanage";
    var password = $("#password").val();
    var repeatPassword = $("#repeatPassword").val();
    
    if(!password){
    	alert("密码不能为空！");
    	return;
    }
    if(!repeatPassword){
    	alert("重复密码不能为空！");
    	return;
    }
    if(password != repeatPassword){
    	alert("两次密码不一致！");
    	return;
    }
    var p = $("input").map(function(){
        return $(this).attr('id')+':"'+$(this).val()+'"';
    }).get().join(",");
    p = "{"+p+"}";
    
    
    params = eval("("+p+")");
//    params['newPassword'] = params['password'];
//    params['repeatPassword'] = params['repeatPassword'];
    $("p").removeAttr("display");
    
    //加密
    var param = {};
    var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
    if(result.retCode != "200"){
    	 alert(errinfo[result.retCode]);
         return;
    }
    //rsa加密
    var rsakey = new RSAKey();
	rsakey.setPublic(result.modulus,result.exponent);
	var newpwd = rsakey.encrypt( params['password']);
	params['newPassword'] = newpwd.toString(16);
	var repeatpwd = rsakey.encrypt( params['repeatPassword']);
	params['repeatPassword'] = repeatpwd.toString(16);
    params.loginName = loginName;
    
    var result=execjava("userAuthenBean.findPassword",params,"json",userservice);
        if(!result || result.retCode!="200"){
           	alert(errinfo[result.retCode]);
            return;
        }
        alert("重置密码成功！请重新登陆系统！");
       	window.location.href = getContextPath("~main/login.php");
}