jQuery(document).ready(function(){
	$("#userName").focus(function(){
		 var username = $(this).val();
		 $(this).removeClass("f11");
		 if(username=='输入账号'){
		 	$(this).val('');
		 	
		 }
	});

	$("#userName").blur(function(){
		 var username = $(this).val();
		 if(username.trim()==''){
		 	$(this).val('输入账号');
		 	$(this).addClass("f11");
		 }
	});


	$("#mobile").focus(function(){
		 var mobile = $(this).val();
		 $(this).removeClass("f11");
		 if(mobile=='输入手机号码'){
		 	$(this).val('');
		 	
		 }
	});

	$("#mobile").blur(function(){
		 var mobile = $(this).val();
		 if(mobile.trim()==''){
		 	$(this).val('输入手机号码');
		 	$(this).addClass("f11");
		 }else if(!/^(86)?1[3-8]\d{9}$/.test(mobile)){
				alert("请填写正确的手机号码！");
				return;
		}
	});

	$("#validate").focus(function(){
		 var username = $(this).val();
			$(this).removeClass("f11");
		 if(username=='输入验证码'){
		 	$(this).val('');
		 
		 }
	});

	$("#validate").blur(function(){
		 var username = $(this).val();
		 if(username.trim()==''){
		 	$(this).val('输入验证码');
		 	$(this).addClass("f11");
		 }
	});

	$("#validateCode").focus(function(){
		 var username = $(this).val();
		 $(this).removeClass("f11");
		 if(username=='输入验证码'){
			 $(this).val('');
			
		 }
	});

	$("#validateCode").blur(function(){
		var username = $(this).val();
		if(username.trim()==''){
			$(this).val('输入验证码');
			$(this).addClass("f11");
		}
	});
	
	//jQuery("#nextstep").bind("click",nextstep);
});
var errinfo = {		
	"40001":"系统错误",
	"40002":"错误的参数",
	"40007":"手机号码与系统不一致",
	"40009":"输入的手机号码与系统的不一致！",
	"40011":"非法的用户",
	"40016":"重置密码失败",
	"40071":"两次密码不一致",
	"40072":"请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。",
	"40073":"原密码错误",
	"40074":"没有修改成功",
	"40075":"重置密码失败",
	"40076":"只有管理员才能进行该操作",
	"40077":"验证不通过",
	"40061":"存在多个用户，需要配置应用号"	
};

var userservice = "usermanage";
var btn = null;
function sendMobileCode(ele){
		btn = $(ele);
	  
		var userName = jQuery("#userName").val();
		if(jQuery.trim(userName) == "" || jQuery.trim(userName) == "输入账号" ){
			alert("用户名不能为空！");
			return;
		}
		var  mobile = "";
		if(mobileValidate){
			mobile = jQuery("#mobile").val();
			if(jQuery.trim(mobile) == "" || jQuery.trim(mobile) == "输入手机号码" ){
				alert("手机号码不能为空！");
				return;
			}
		}
		
		var params = {
			loginName:userName,
			mobile:mobile
		};
		execjava("userAuthenBean.sendValidateCodeNew",params,"json",userservice,true,codeCallback);
	}
	var codeCallback = function(result){
			result = eval("("+result+")");
		    if(!result || !result.retCode){
	           	alert("系统出错，请联系管理员!");
	            return;
	        }
	        if(result.retCode == '200'){
	        	alert("系统已向您在本网登记的手机号码（"+  result.mobile +"）发送验证码,请及时检验！");
	        	btn.removeAttr("onclick");
	        	 var time = 60;
			    var hander = setInterval(function(){
			        if(time <= 0){
			            btn.html("获取验证码");
			            btn.attr("onclick","sendMobileCode(this);");
			
			            window.clearInterval(hander);
			        } else {
			
			            btn.html(""+(time--)+"s");
			
			        }
			    },1000);
	        }else{
	        	alert(result.retMsg);
	        }
	        
		   
	 };
	function checkNotNull(id){
		var value = jQuery("#"+id).val();
		if(value == null || value == undefined || value == ''){
			return false;
		}
		return true;
	}
	function findpsw(){
		var userName  = jQuery("#userName").val();
		var mobile = jQuery("#mobile").val();
		var validateCode = jQuery("#validateCode").val();
		var newPassword = jQuery("#password").val();
		var repeatPassword =jQuery("#repeatPassword").val(); 
		var code_num = $("#validate").val();
		if(userName == '输入账号'){
			jQuery("#userName").val('');
		}
		if(!checkNotNull("userName")){
			alert("用户名不能为空！");
			return;
		}
		if(jQuery.trim(mobile) == "" || jQuery.trim(mobile) == "输入手机号码" ){
			alert("手机号码不能为空！");
			return;
		}
		if(!checkNotNull("password")){
			alert("新密码不能为空！");
			return;
		}
		if(!checkNotNull("repeatPassword")){
			alert("确认密码不能为空！");
			return;
		}
		if(!checkNotNull("validate")){
			alert("验证码不能为空！");
			return;
		}
		/*if(!checkCode()) {
            $("#validate").focus();
            return;
        }*/
		if(validateCode == null || validateCode == undefined || validateCode == '' || validateCode == '输入验证码'){
			alert("手机验证码不能为空！");
			return;
		}
		if(newPassword != repeatPassword){
			alert("新密码与确认密码不同！");
			return;
		}
		
		var params = {
			loginName:userName,
			mobile:mobile,
			code:code_num,
			validateCode:validateCode
		};
		
        	//window.location.href = getContextPath("~main/module/account/findPwd2.php?loginName="+userName);
            
            //加密
            var param = {};
            var result=execjava("userAuthenBean.getPublicKey",param,"json",userservice);
            if(result.retCode != "200"){
            	 alert(errinfo[result.retCode]);
                 return;
            }
            //rsa加密
            var rsakey = new RSAKey();
        	rsakey.setPublic(result.modulus,result.exponent);
        	var newpwd = rsakey.encrypt(newPassword);
        	params['newPassword'] = newpwd.toString(16);
        	
            params.loginName = userName;
            
            var result=execjava("userAuthenBean.findPasswordNew",params,"json",userservice);
                if(!result || result.retCode!="200"){
                   	alert(errinfo[result.retCode] || result.retMsg);
                   	//$("#validate").attr("src","../../captcha.php?'+Math.random();");
                   	//$("#validate").next().attr("src","../../captcha.php?'+Math.random();");
                   	$("#validateImg").click();
                    return;
                }
                alert("重置密码成功！请重新登录系统！");
               	window.location.href = getRealPath()+"~main/login.php";
        
	}
	
/*	function checkCode(){
		var ret = false;
		var code_num = $("#validate").val();
		
		if(code_num == "" || code_num == "输入验证码"){
           	alert("验证码不能为空！");
        }else{
            
            $.ajax({
            	url:getContextPath("~main/chk_code.php?act=num"),
            	async:false,
            	type:"post",
            	data:{code:code_num},
            	success:function(msg){
            		if(msg==1){
	            		ret = true;
	            	}else{
	            		alert("验证码错误！");
	            		
	            	}
            	}
            });
        }
        return ret;
	}*/
