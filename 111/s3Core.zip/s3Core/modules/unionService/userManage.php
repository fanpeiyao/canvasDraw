<!--right start-->
<div class="right skin-border">
	<div class="cent-border">
		<div class="title-side">
			<i class="iconfont icon-sousuo skin-color"></i>
			请选择筛选条件:
		</div>
		<div class="condit">
			<div class="inpSearch">
				<span style="width:31%" class="choice_list">客户编号/名称：</span>
				<input style="width:64%" id="searchId" type="text" class="inputData" />
			</div>
			<!-- <span>所属部门：<input id="searchDepart" type="text" class="input-text" /></span>   -->
			<div class="positionBtn3">
				<a href="javascript:;" class="btn_small skin_btn_light"onclick="loadData(1);">搜索</a> 
				<a href="javascript:;"class="btn_small skin_btn_dark" onclick="clean();">重置</a>
			</div>
		</div>
		<div class="title-inner">
			<span><i class="iconfont icon-zhangdan skin-color" style="top:1px;left:-2px;"></i>用户管理</span>
			<font class="fl_r mar_b20 cursor">
				<span>
					<i class="iconfont icon-plus-circle skin-color" style="top:1px;left:15px;"></i>
					<a href="javascript:;"onclick="openMask('add');" class="titleinnera">增加客户</a>
				</span>
				<!-- 
				<span>
					<i class="iconfont icon-sync" style="top:1px;left:15px;"></i>
					<a href="javascript:propelling();" class="titleinnera">同步菜单</a> 
				</span>
				 -->
			</font>
		</div>

		<div id="salesList"></div>
		<p class="page" id=pager>
			<img src="../imgs/page.jpg" width="395"
				height="34" />
		</p>
	</div>
</div>
<!--right end-->

<!--popup start-->
<div class="popup" id="addOverlay" style="display: none;z-index:99999;">
	<div class="pop-title">
		<font><i class="icon-pop"></i><span id="oper">增加</span>客户</font>
		<div style="display: none">
			<a class="modalInput" rel="#addOverlay" id="addOperator"
				href="javascript:void(0);"></a> <a class="close" rel="#addOverlay"
				href="javascript:void(0);" id="popupclose"></a>
		</div>
		<a href="javascript:;" rel="#addOverlay" onclick="checkRestore('add')"><img
			src="../imgs/close.jpg" width="16"
			height="16" /> </a>
	</div>
	<div class="pop-cent2 f12 h255">
		<div id="customerForm"></div>

		<p class=" mar_t30 post pl">
			<span class="pad_l20">角色选择：</span>
		</p>
		<div id="rolelist" class="top50">
		</div>
		<!-- 错误提示 -->
		<div class="f1">
			<p id="errTip" class="pop-err hidden">
				<span> <img src="../imgs/pic-error.jpg"
					width="16" height="16" class="ver_a"> <font class="f1">Error!</font>
					<font id="errorTip"></font>
				</span>
			</p>
		</div>
	</div>

	<div class="pop-up">
		<p>
			<a  class="btn_small skin_btn_light" id="confirmbtn" >确
				定</a> <a href="javascript:;" onclick="clearForm('edit');"
				class="btn_small skin_btn_dark">重置</a>
		</p>
	</div>
</div>
<!--popup end-->

<!--popup start-->
<div class="popup" id="resetOverlay" style="z-index:99999;display: none;">
	<div class="pop-title">
		<font><i class="icon-pop"></i>重置密码</font>
		<div style="display: none">
			<a class="modalInput" rel="#resetOverlay" id="resetOperator"
				href="javascript:void(0);"></a> <a class="close" rel="#resetOverlay"
				href="javascript:void(0);" id="popupclose"></a>
		</div>
		<a href="javascript:;" rel="#resetOverlay"
			onclick="checkRestore('reset')"><img src="../imgs/close.jpg"
			width="16" height="16" /> </a>
	</div>
	<div class="pop-cent2 f12 h255">


		<p class=" mar_t30 post pl">
			<span class="pad_l20">确认需要重置该客户密码？</span>
		</p>
		<!-- 错误提示 -->
		<div class="f1">
			<p id="resetErrTip" class="pop-err hidden">
				<span> <img src="../imgs/pic-error.jpg"
					width="16" height="16" class="ver_a"> <font id="resetErrorTip"></font>
				</span>
			</p>
		</div>
	</div>

	<div class="pop-up">
		<p>
			<a href="javascript:;" class="btn_small skin_btn_light" onclick="resetPwd();">确 定</a>
			<a href="javascript:;" onclick="clearResetForm();"
				class="btn_small skin_btn_dark">取消</a>
		</p>
	</div>
</div>

<!--popup end-->
<div class="mar_t20"></div>

<div id="fullbg" class="pop_shadow" style="z-index:9999;display: none;"></div>
<?php  include_once 'tpl/salesManagerList_tpl.php';
?>

<script src="<?php echo $root_path ?>modules/unionService/js/IdCardChk.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/tipsy.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/validator.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/rsaoath.min.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/salesManagerList.js"></script>