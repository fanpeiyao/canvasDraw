<div class="mar_t20 mar_b20">
		<table class="table1 auto" width="70%">
			  <tr>
			    <td width="30%" class="tex_r pad_r25 f5">客户编号：</td>
			    <td width="50%" class="tex_l pad_l25" ><span id="customerId"></span><span class="f1 f12">(客户在公司编号，不可修改 )</span></td>
			  </tr>
		     <tr>
			    <td class="tex_r pad_r25 f5">登录名：</td>
			    <td class="tex_l pad_l25" id ="loginName"></td>
			  </tr>
			  		      <tr>
			    <td class="tex_r pad_r25 f5">客户名称：</td>
			    <td class="tex_l pad_l25" id="userName"></td>
			  </tr>
		      <tr>
			    <td class="tex_r pad_r25 f5">联系手机：</td>
			    <td class="tex_l pad_l25" id="customerMobile"></td>
			  </tr>
			  <tr style="display:none;" id="validatecode">
			    <td class="tex_r pad_r25 f5">手机验证码：</td>
			    <td class="tex_l pad_l25" id="mobileValicode" style="position:relative;"></td>
			  </tr>
			  <tr>
			    <td class="tex_c pad10" colspan="2">
			    	<a href="javascript:;" class="btn_small skin_btn_light" id="editBtn">编辑</a>
			    </td>
			  </tr>
		</table>


</div>
<!--内容2-->
<div id="customerDetail" style="display:none;">
<!-- 屏蔽二级经销商信息
	<div class="title-inner mar_t20"><i class="icon-list"></i>二级经销商信息</div>
	<div class="mar_t20" id="userbindedTpl"></div>
 -->
	<div class="title-inner mar_t20"><i class="icon-list"></i>经销商对应公司信息</div>
	<div class="mar_t20 mar_b20" id="companyListTpl"></div>
</div>
<?php include_once 'modules/unionService/tpl/companyList_tpl.php';?>

<script src="<?php echo $root_path ?>modules/unionService/js/tipsy.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/IdCardChk.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/validator.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/myAccount_form.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/mobileValidata.js" type="text/javascript"></script>
