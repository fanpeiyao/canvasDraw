<div id="fullbg" class="pop_shadow" style="display:none;"></div>
<div class="mp-box fn-show-lg-only" id="modifyPwdOverlay" style="display:none;z-index:99999999;margin-left:-340px;  left:50%;width:680px;top:26%;height:525px;" >
	
	<a href="javascript:;" rel="#modifyPwdOverlay" onclick="closeWin()"><img
		src="./imgs/close.jpg" style="float:right;margin-top:-10px;" /> </a>


		
	<p class="hint-title">
		<i style="font-size:20px;top:2px;" class="iconfont icon-xiangqing skin-color"></i>
		首次登录请先绑定你的手机号码并修改密码
	</p>
	<div class="pc-input-boxnew">
		
		<div class="firstLogin">
			<span class="f12">原始密码：</span>
			<input placeholder="输入你的原始密码" type="password" id="oldpwd"class="input1 w200" onblur="check('oldpwd');" /> 
			<font style="color:#C7000A;" class="f1">*</font>
		</div>
		<div class="firstLogin">
			<span class="f12">新的密码：</span>
			<input placeholder="输入你的新密码" type="password" id="newpwd"class="input1 w200" onblur="check('newpwd');" /> 
			<font style="color:#C7000A;" class="f1">*</font>
		</div>
		<div class="firstLogin">
			<span class="f12">确认密码：</span>
			<input placeholder="重新输入你的新密码" type="password" id="confirmPwd"class="input1 w200" onblur="check('confirmPwd');" /> 
			<font style="color:#C7000A;" class="f1">*</font>
		</div>
		<div class="firstLogin" class="phone">
			<span class="f12">手机号码：</span>
			<input placeholder="输入你的手机号" id="mobile"class="input1 w200"  onblur="check('mobile');" maxlength="11"/>
			<a id="getCheckCode" class="getCheckCode"  onclick="getValidateCode(this);">获取验证码</a>
			<font style="color:#C7000A;" class="f1">*</font>
		</div>
		<div class="firstLogin">
			<span class="f12">验证码&nbsp;&nbsp;&nbsp;</span>：
			<input placeholder="输入验证码" id="validateCode" class="input1 w200"  onblur="check('validateCode');"/> 
			<font style="color:#C7000A;" class="f1">*</font>
		</div>
	</div>


	<div id="errorTips" class="error hidden">
		<i class="icon-error"></i><font id="loginresult">您输入的密码不正确</font>
	</div>

	<div class="tex_c">
		<a href="javascript:;" class="pc-tk-btn-new skin_btn_light" id="savePass">确认</a>
	</div>
	
	<div class="loginTip">
		<p class="loginTip_title">温馨提示</p>
		<p class="loginTip_txt">请将密码设置为8(含)位以上,必须包含数字、大写字母、小写字母、特殊字符这四种类型中的两种。</p>
		<p class="loginTip_txt">为了保护您的账户安全请不要将密码设置为其他网站相同的密码。</p>
		<p class="loginTip_txt">建议您每隔一段时间修改您的密码，以防密码泄露。</p>
	</div> 
</div>
<script>
	export default{ 
		props: {
			root_path: {
				type: String, 
			}
		},
		created(){
		     console.log(this.root_path)
		},
	}
</script>