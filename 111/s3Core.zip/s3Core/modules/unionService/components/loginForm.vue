<template>
	<div>
		<div class="login_name skin-border skin-color">用户登录</div> 
		<div class="login_middle">
			<div class="inpp inp_name">
				<span class="inp_title">用户名:</span>
				<input id="username" type="text" placeholder=""  value="" class="f11 inp foucus" />
				<em><i class="iconfont icon-yonghuming skin-color"></i></em>
			</div>
			
			<div class="inpp inp_password">
				<span class="inp_title">密码:</span>
				<input id="password" type="password" placeholder="" value=""class="inp foucus" />
				<em><i style="font-size:19px;" class="iconfont icon-mima skin-color"></i></em>
			</div>
			
			<div id="validCode" style="display: none;">
				<span class="inp_title">验证码:</span>
				<input type="text" class="yzminput f11 foucus validate" id="validate" placeholder="" value="" />
				<span class="login_yz"> 
					<a href="#" class="d-code2"> 
						<img src="captcha.php" title="点击刷新" id="validateImg" onclick="this.src='captcha.php?'+Math.random();" />
					</a>
				</span>
			</div>
		
			<span class="rememberUserName"> 
				<input id="rememberUserName" name="input" type="checkbox"class="fl_l w15" />
				<font class="mari">记住用户名</font> 
				<font><a class="forget skin-color" href="module/account/findPwd.php">忘记密码?</a> </font>
			</span>
			
			<div class="martop f12 f3">
				<span id="errorTip" class="hidden"> <i class="iconfont icon-cha" style="color:#C7000A;left:0px;top:2px;"></i> <font class="pad_l5"
					id="loginres">您输入的密码不正确</font>
				</span>
			</div>
			
			<a href="#" id="loginbtn" class="btn-login skin-back">登 录</a>
		</div> 
	</div>

</template>

