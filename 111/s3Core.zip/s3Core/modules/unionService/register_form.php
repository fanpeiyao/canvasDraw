<script src="<?php echo $root_path ?>modules/unionService/js/IdCardChk.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/tipsy.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/validator.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/jsbn.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/prng4.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/rng.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/rsa.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/register2.js" type="text/javascript"></script>

	<!--企业注册-->
    <h3>注册信息</h3>
    <div id="regInfo">
    </div>
    <!--错误提示-->
    <div class="regist-tip hidden">错误提示信息</div>
    <div><a href="javascript:;" class="btn btn-regist" onclick="registerUser();">立即注册</a></div>
          
<!--register end-->


