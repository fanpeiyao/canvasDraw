<div class="right skin-border">
	<div class="cent-border">
		<div class="title-side">地址管理</div>  
		<div id="addressTpl"></div><!-- 地址列表tpl -->
	
		<!--添加新地址-->
		<div id="addrForm" class="clear">
			<p class="title-inside">添加地址（<font class="skin-color">*</font>必填）</p>
			<div>
				<div class="cont-address" id="addressInfo"></div><!--地址表单-->
				<p class="pop-up">
					<a href="javascript:;" id="addrSaveBtn" class="btn btn-next skin_btn_light mar_r10">保存</a>
					<a href="javascript:;" id="cancelBtn" class="btn btn-next skin_btn_dark">重置</a>
				</p>
			</div>
		</div>
	</div>
</div>
<?php include_once 'modules/unionService/tpl/addressList_tpl.php';?>

<script src="<?php echo $root_path ?>modules/unionService/js/IdCardChk.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/tipsy.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/validator.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/address_form.js" type="text/javascript"></script>
