<!--找回密码-->
<p>
	<font>用户名：</font> <span> <input name="" type="text" value="输入账号"
		maxlength="100" id="userName" class="input-regist f11" />
	</span><b>*</b>
</p>
<p id="mobileValidate">
	<font>手机号码：</font> <span> <input name="" type="text" value="输入手机号码"
		maxlength="11" id="mobile" class="input-regist f11" />
	</span><b>*</b>
</p>
<p>
	<font>验证码：</font>
	<span>
	<input type="text" value="输入验证码" maxlength="100" id="validate" class="input-validate  f11"nullmsg="请输入验证码！"> 
<!-- 	<img src="../../captcha.php" title="点击刷新"style="margin-right:5px;height: 23px; width: 80px"onclick="this.src='../../captcha.php?'+Math.random();"class="yzm-img2" /> -->
	<img src="../../captcha.php"  title="点击刷新"  id="validateImg"   style="margin-right:5px;height: 23px; width: 80px"onclick="this.src='../../captcha.php?'+Math.random();" class="yzm-img2" />
	</span>
	<b>*</b>
</p>
<p>
	<font>手机验证码：</font><span> <input name="" type="text" value="输入验证码"
		maxlength="100" id="validateCode" class="input-validate  f11">
	</span> <span class="validate-pic"><a href="javascript:;"
		onclick="sendMobileCode(this);">获取验证码</a> </span><b>*</b>
</p>
<p>
		<font>请输入密码：</font><span> <input type="password" class="input-regist"
			id="password" autocomplete="off"  />
		</span><b>*</b>
</p>
<p>
		<font>请再次输入密码：</font><span> <input type="password" maxlength="100"
			id="repeatPassword" class="input-regist" autocomplete="off" />
		</span><b>*</b>
</p>

<!--错误提示-->
<div class="regist-tip hidden clear" id="errorTip">错误提示信息</div>
<div>
	<a href="javascript:;" class="btn btn-regist skin-back" onclick="findpsw();">提交</a>
	
</div>



<script src="<?php echo $root_path ?>modules/unionService/js/rsaoath.min.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/findPwd_form.js" type="text/javascript"></script>
                
  
