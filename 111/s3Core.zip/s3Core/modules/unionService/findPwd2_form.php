
<!--找回密码-->
<div>
	<p>
		<font>请输入密码：</font><span> <input type="password" class="input-regist"
			id="password" autocomplete="off" />
		</span><b>*</b>
	</p>
	<p>
		<font>请再次输入密码：</font><span> <input type="password" maxlength="100"
			id="repeatPassword" class="input-regist" autocomplete="off" />
		</span><b>*</b>
	</p>
</div>

<div class="regist-tip hidden" id="errorTip">错误提示信息</div>
<div>
	<a href="javascript:;" class="btn btn-regist" onclick="findpsw2();">提交</a>
</div>

<script src="<?php echo $root_path ?>modules/unionService/js/rsaoath.min.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/findpsw2_form.js" type="text/javascript"></script>
                
 