<!--right start-->
<div class="right skin-border">
	<div class="cent-border">
		<div class="title-side">
			<i class="iconfont icon-sousuo skin-color"></i>
			请选择筛选条件:
		</div>
		<div class="condit2">

			<div class="inpSearch">
				<span style="width:31%;" class="choice_list">客户编号/名称:</span>
				<input id="searchId" type="text" class="inputData" />
			</div>
			
			<div class="inpSearch" style="width:160px;">
				<span class="choice_list"  style="min-width:60px;">角色:</span> 
				<select style="width:74%;" id="roleSelector"onchange="loadData(1);" class="inputData"></select>
			</div>
			
			<div class="positionBtn3">
				<a href="javascript:;" class="btn_small skin_btn_light" onclick="loadData(1);">搜索</a> 
		 		<a href="javascript:;" class="btn_small skin_btn_dark" onclick="clearForm();">重置</a>
			</div>	
				
		</div>
		<div class="title-inner clear">
			<span><i style="top:1px; left:-2px;" class="iconfont icon-btn_pljj skin-color"></i>用户关系</span>
		</div>

		<div id="customerList"></div>
		<p class="page" id=pager></p>
	</div>
</div>
<!--right end-->
<div class="popup" id="operatorOverlay" style="display: none;left:28%;top:21%; z-index:99999">
	<div class="pop-title">
		<font>用户所属公司绑定列表</font>
		<div style="display: none">
			<a class="modalInput" rel="#operatorOverlay" id="operatorAdd"
				href="javascript:void(0);"></a> <a class="close"
				rel="#operatorOverlay" href="javascript:void(0);" id="popupclose"></a>
		</div>
		<a href="javascript:;" rel="#operatorOverlay"
			onclick="checkRestore('operator')"><img
			src="../imgs/close.jpg" width="16"
			height="16" /> </a>
	</div>


	<div class="of p10">
		<div class="mar10" id="bindCompanyForm"></div>
	</div>


	<div class="of p10">
		<div class="mar10" id="companyForm"></div>
	</div>

	<div class="pop-up clear">
		<p>
			<!--  <a href="javascript:;" onclick="saveOrUpdateSec();" class="btn_small skin_btn_light">确 定</a> -->
			<a href="javascript:;" onclick="checkRestore('operator');"
				class="btn_small skin_btn_dark">返 回</a>
		</p>
	</div>
</div>


<!--popup start-->
<div class="popup" id="customerOverlay" style="display: none;left:28%;top:21%;z-index:99999" >
	<div class="pop-title">
		<font>用户绑定关系列表</font>
		<div style="display: none">
			<a class="modalInput" rel="#customerOverlay" id="customerAdd"
				href="javascript:void(0);"></a> <a class="close"
				rel="#customerOverlay" href="javascript:void(0);"></a>
		</div>
		<a href="javascript:;" rel="#customerOverlay"
			onclick="checkRestore('customer')"><img
			src="../imgs/close.jpg" width="16"
			height="16" /> </a>
	</div>
	<div class="of p10">
		<div id="bindForm"></div>
	</div>
	<div class="condit5">
		<!-- <span>角色:</span> <select id="roleSelector"
			onchange="changeRole(this);">
			<option value="1">经销商</option>
			<option value="2">业务员</option>
			<option value="3">管理员</option>
			<option value="4">内勤</option>
		</select> --> 
		<span>关键字：<input id="secCustomerKey" type="text"
			class="input-text f11" style="width: 150px;" value="请输入客户编号或客户名称"
			onfocus="keyFocus();" onblur="keyBlur();" />
		</span> <a href="javascript:;" onclick="getUserList(1);"
			class="btn_small skin_btn_light">搜索</a> <a href="javascript:;"
			onclick="clearCustomerForm();" class="btn_small skin_btn_dark">重置</a></span>
	</div>
	<div class="of p10">

		<div id="customerForm"></div>
		<p class="page" id="userPager">
			<img src="../imgs/page.jpg" width="395"
				height="34" />
		</p>
	</div>

	<div class="pop-up clear">
		<p>
			<!--  <a href="javascript:;" onclick="saveOrUpdateSec();" class="btn_small skin_btn_light">确 定</a> -->
			<a href="javascript:;" onclick="checkRestore('customer');"
				class="btn_small skin_btn_dark">返 回</a>
		</p>
	</div>
</div>
<!-- 编辑的表单 -->
<div class="mar_t20"></div>
<div id="fullbg" class="pop_shadow" style="z-index:9999;display: none;"></div>
<?php  
	include_once 'tpl/customerRelationList_tpl.php';
?>
<script src="<?php echo $root_path ?>modules/unionService/js/customerRelation.js"></script>