<script src="<?php echo $root_path ?>p/js/jquery-val/jquery.validate.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>p/js/validateStrLength.js" 	type="text/javascript"></script>
<script type="text/javascript">
<!--
	//显示新增角色页面
	function showInfo(){
		 $( "#roleAddDiv" ).dialog({
				autoOpen: false,
				title:"添加角色",
				//show: "blind",
				height: 'auto',
				width:300,
				draggable:false,
	 			resizable:false,
				modal: true,
				buttons: {
					"保存": function() {
						saveRoleInfo()
						},
					"关闭": function() {
						 $("#roleAddDiv input").val("");
						$( "#roleAddDiv" ).dialog( "destroy" );
						}
				},				
				close:function(){
					 $("#roleAddDiv input").val("");
					$("#roleAddDiv").dialog( "destroy" );
				}
			});
		  $( "#roleAddDiv" ).dialog( "open" );
		  clearUpdateTips();
	}

	function saveRoleInfo(){
			var addRoleId=$("#addRoleId").val();
			if(addRoleId==""){
	               updateTips("请填写角色ID",$("#addRoleId"));
	                return false;
					}
			var roleName=$("#roleName").val();
			if(roleName==""){
               updateTips("请填写角色名称",$("#roleName"));
                return false;
				}
			//setp 1:开始发交易
			var retMap=execjava("b2bRoleBean.addSingleRole",{id:addRoleId,name:roleName,businessKey:$("#businessKey").val()},'json');
			//2 :取得交易结果是否成功判断
			var retCode=retMap.status;
			if(retCode=='000'){
					$( "#roleAddDiv" ).dialog( "destroy" );
					$('#roleAddDiv input').val('');//清空内容
					alert("新增角色成功");
					queryRoles();//refresh
				}else{
					$( "#roleAddDiv" ).dialog( "destroy" );
					$('#roleAddDiv input').val('');
					alert(retMap.RetMsg);		
					queryRoles();
				}			
		}
	
//-->
</script>

        <div   id="roleAddDiv" style="display:none;"  >
        <p class="validateTips " style='text-align:center;color: red;'></p>
                   <form >
                    	<fieldset >
                    		<p><label  for="addRoleId">角色ID:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
							<input id="addRoleId" name="addRoleId" maxlength="20" value="" class="text ui-widget-content ui-corner-all opreate allFields" /></p>
							
							<p><label  for="roleName">角色名称： </label>
							<input id="roleName" name="roleName" maxlength="20" value="" class="text ui-widget-content ui-corner-all opreate allFields" /></p>

							<p><label  for="businessKey">业务代码： </label>
							<input id="businessKey" name="businessKey" maxlength="20" value="" class="text ui-widget-content ui-corner-all opreate allFields" /></p>
						</fieldset>
                    </form>                    
        </div>
        
         <div  id="roleEdit"  style="display:none;"  >
         <p class="validateTips " style='text-align:center;color: red;'></p>
                   <form >
                        <input id='roleId' value="" style="display: none;">
                   <fieldset >
                   			<p><label  for="roleName">角色ID:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </label>
							<input id="lastRoleId" name="lastRoleId" maxlength="20" value="" class="text ui-widget-content ui-corner-all opreate allFields" /></p>
							<p><label  for="label_rowName">角色名称： </label>
							<input id="editRoleName" name="editRoleName" maxlength="20" value="" class="text ui-widget-content ui-corner-all opreate allFields" /></p>

							<p><label  for="editBusinessKey">业务代码： </label>
							<input id="editBusinessKey" name="editBusinessKey" maxlength="20" value="" class="text ui-widget-content ui-corner-all opreate allFields" /></p>

							<p><label  for="enableRole">角色状态： </label>
							<select id="enableRole">
								<option value="1">启用</option>
								<option value="0">禁用</option>
							</select>							 
					</fieldset>              
                    </form>
        </div>