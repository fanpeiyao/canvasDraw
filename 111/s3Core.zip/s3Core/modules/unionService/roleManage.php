<!-- <//?php require_once 'modules/activitiService/roleInfo.php'; ?> -->

<link href="<?php echo $root_path ?>modules/unionService/css/zTreeStyle/zTreeStyle.css" rel="stylesheet" type="text/css" media="all" />
<script src="<?php echo $root_path ?>modules/unionService/js/jsTree/jquery.ztree.all-3.5.min.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/jsTree/jquery.ztree.core-3.5.min.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/jsTree/jquery.ztree.excheck-3.5.min.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/jsTree/jquery.ztree.exhide-3.5.min.js" type="text/javascript"></script>
<!--角色管理页面--> 
<div class="right">
<div class="cent-border">
<div class="title-role">请选择筛选条件:</div>  
	<div class="contditrole"><span>角色名称: <input name="" type="text" class="input-data-text" id="roleNameSearch"/> <a href="javascript:search('1')" class="btn_small skin_btn_light">搜索</a> <a href="javascript:clearForm();" class="btn_small skin_btn_dark" onclick="" >重置</a></span></div>
	<div class="title-inner"><span><i class="icon-list"></i>角色列表</span><font class="fl_r  mar_b20 cursor"><a href="javascript:propelling();" class="titleinnera">推送菜单</a><a href="javascript:addDiag();" class="titleinnera1">新增角色</a></font></div>
	<!--内容1-->
		<div class="mar10">
      	<div id="roleTpl" class="mar_t20"></div>
        </div>
        <p class="page" id=pager>
        <img src="<?php echo $root_path?>~main/imgs/page.jpg" width="395" height="34" />
        </p>
</div>
</div>

<!--middle popup1 start-->
<div id="roleInfo" class="popup" style="display: none;">
	<div style="display: none">
		<a class="modalInput" rel="#roleInfo" id="role_trigger" href="javascript:void(0);"></a> 
		<a class="close" rel="#roleInfo" href="javascript:void(0);" id="role_popupclose"><img src="<?php echo $root_path?>~main/imgs/close.jpg" width="16" height="16" /></a>
	</div>
    <div id="roleInfoHtml"></div>
</div>
<!--popup1 end-->

<!--wide popup2 start-->
<div id="roleInfo2" class="popup2" style="display: none;">
	<div style="display: none">
		<a class="modalInput" rel="#roleInfo2" id="role_trigger2" href="javascript:void(0);"></a> 
		<a class="close" rel="#roleInfo2" href="javascript:void(0);" id="role_popupclose2"><img src="<?php echo $root_path?>~main/imgs/close.jpg" width="16" height="16" /></a>
	</div>
    <div id="roleInfoHtml2"></div>
</div>
<!--popup2 end-->

<!--narrow popup3 start-->
<div id="roleInfo3" class="popup3" style="display: none;">
	<div style="display: none">
		<a class="modalInput" rel="#roleInfo3" id="role_trigger3" href="javascript:void(0);"></a> 
		<a class="close" rel="#roleInfo3" href="javascript:void(0);" id="role_popupclose3"><img src="<?php echo $root_path?>~main/imgs/close.jpg" width="16" height="16" /></a>
	</div>
    <div id="roleInfoHtml3"></div>
</div>
<!--popup3 end-->

<?php include_once 'tpl/roleList_tpl.php';?>
<script src="<?php echo $root_path ?>modules/unionService/js/roleManage.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>~main/js/jquery.bgiframe.pack.js" type="text/javascript"></script>
