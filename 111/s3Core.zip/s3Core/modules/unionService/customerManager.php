<div class="right">
	<div class="cent-border">
		<!--内容区 start-->
		<div class="title-side">客户信息</div>
		<div class="pad20">
			<div class="detail-border" id="customerInfo">
				<table class="table1 auto" width="70%">
					<tbody>
						<tr>
							<td width="30%" class="tex_r pad_r25 f5">客户名称：</td>
							<td width="50%" class="tex_l pad_l25" name="userName"></td>
						</tr>
						<tr>
							<td class="tex_r pad_r25 f5">客户账号：</td>
							<td class="tex_l pad_l25" name="loginName"></td>
						</tr>
						<tr>
							<td class="tex_r pad_r25 f5">手机号码：</td>
							<td class="tex_l pad_l25" name="mobile"></td>
						</tr>
						<tr>
							<td class="tex_r pad_r25 f5">邮箱：</td>
							<td class="tex_l pad_l25" name="email"></td>
						</tr>
						<tr>
							<td class="tex_c pad10" colspan="2"><a href="javascript:;"
								class="btn_small skin_btn_light" id="editBtn">编辑</a>
							</td>
						</tr>
					</tbody>
				</table>

			</div>


		</div>

		<!--内容区 end-->
	</div>
</div>
<!--detail start-->
<?php  
include_once 'tpl/customerManager_tpl.php';
?>
<!--detail end-->
<script src="<?php echo $root_path ?>modules/unionService/js/tipsy.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/IdCardChk.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/validator.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>~main/js/jquery.bgiframe.pack.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>~main/js/registerData.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/customerManager.js" type="text/javascript"></script>
