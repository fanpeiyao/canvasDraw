<?php 

$userId = $user->UserEntityid;
$customId = $user->UserEntitycustomId;

//print_r($companies);
?>
<script >
	var acctid = '<?php echo $customId;?>';
</script>
<?php include_once 'modules/unionService/tpl/accountList_tpl.php';?>
<!--right start-->
<script src="<?php echo $root_path ?>modules/unionService/js/tipsy.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/IdCardChk.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/validator.js"></script>
<script src="<?php echo $root_path ?>~main/js/jquery.bgiframe.pack.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/jsbn.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/prng4.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/rng.js"></script>
<script src="<?php echo $root_path ?>modules/unionService/js/rsa.js"></script>

<script
	src="<?php echo $root_path ?>modules/unionService/js/subAccountManage.js"></script>
<div class="right">
	<div class="cent-border">
		<div class="title-side-1">
			子账户管理<a href="javascript:openMask('add');">新增账户</a>
		</div>
		<div class="title-side">请选择筛选条件:</div>
		<div class="condit">
			<span>客户名称：<input id="customerId" type="text" class="input-text" />
			</span> <span>申请时间：<input id="start_date" type="text"
				class="input-text w100 input1_data"
				onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });" />
				-<input id="end_date" type="text"
				class="input-text w100 input1_data"
				onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });" />
				<a href="javascript:;" class="btn_small skin_btn_light"
				onclick="searchByKey();">搜索</a> <a href="javascript:;"
				class="btn_small skin_btn_dark" onclick="clean();">重置</a>
			</span>
		</div>
		<div class="condit">

			<p id="statusSearch">
				状 态： <font><a href="javascript:;" statusId="0"
					onclick="statusSearch(0);" class="search-current">全部</a> </font> <font><a
					href="javascript:;" statusId="1" onclick="statusSearch(1);">已停用</a>
				</font> <font><a href="javascript:;" statusId="2"
					onclick="statusSearch(2);">已启用</a> </font>
			</p>
		</div>

		<div class="mar10" id="accountListTpl"></div>
		<p class="page" id=pager>
			<img src="<?php echo $root_path?>~main/imgs/page.jpg" width="395"
				height="34" />
		</p>
	</div>
</div>

<!--right end-->
<!--popup start-->
<div class="popup" id="addOverlay" style="display: none;">
	<div class="pop-title">
		<font><i class="icon-pop"></i><span id="oper">增加</span>账户</font>
		<div style="display: none">
			<a class="modalInput" rel="#addOverlay" id="addOperator"
				href="javascript:void(0);"></a> <a class="close" rel="#addOverlay"
				href="javascript:void(0);" id="popupclose"></a>
		</div>
		<a href="javascript:;" rel="#addOverlay" onclick="checkRestore('add')"><img
			src="<?php echo $root_path ?>~main/imgs/close.jpg" width="16"
			height="16" /> </a>
	</div>
	<div class="pop-cent2 f12 h255" id="accountForm">
		<div>
			<p>
				<font>登录名：</font> <span> <input name="loginName" id="loginName"
					type="text" value="" class="input-regist"
					rules="notnull length username" minlength="4" maxlength="64">
				</span> <b>*</b>
			</p>
			<p>
				<font>密&nbsp;&nbsp;码：</font> <span><input name="password"
					id="password" type="password" value="" class="input-regist"
					rules="notnull  length" minlength="8" maxlength="16"> </span> <b>*</b>
			</p>
			<p>
				<font>重复密码：</font> <span><input name="repeatPassword"
					id="repeatPassword" type="password" value="" class="input-regist"
					rules="notnull" relationto="password" minlength="8" maxlength="16"
					customfn="checkRepass"> </span> <b>*</b>
			</p>
			<p>
				<font>账户名称：</font> <span><input name="userName" id="userName"
					type="text" value="" class="input-regist" rules="notnull length"
					maxlength="128"> </span> <b>*</b>
			</p>
			<p>
				<font>手机号码：</font> <span><input name="mobile" id="mobile"
					type="text" value="" class="input-regist" rules="notnull mobile"
					maxlength="11"> </span> <b>*</b>
			</p>
			<p>
				<font>是否启用：</font> <span><input id="status" type="checkbox" value="">
				</span>
			</p>
		</div>

		<p class=" mar_t30 post pl">
			<span class="pad_l20">角色选择：</span>
		</p>
		<div id="rolelist" class="top50">
			<p class="pl2 post">
				<?php if($id == "1"){

					$retMap = execjava('userRoleBean.getSubRoleList', null, "php",'usermanage');
					if($retMap!=null&&$retMap['roles']!=null){
		
	        		$subRoles=$retMap['roles'];
	        		$html = '';
	        		for($i=0;$i<count($subRoles);){
						$html = $html.'<span class="span2"><input name="role" type="radio" value="'.$subRoles[$i]->RoleEntityid.'"　class="bord0" />'.$subRoles[$i]->RoleEntityname.'</span>';
						if($i+1<count($subRoles)){
							$html = $html.'<span class="span2"><input name="role" type="radio" value="'.$subRoles[$i+1]->RoleEntityid.'"　class="bord0" />'.$subRoles[$i+1]->RoleEntityname.'</span>';
						}
						$i+=2;
	        		}
	        		echo $html;
        		}
				}
				?>
			</p>

		</div>
		<!-- 错误提示 -->
		<div class="f1">
			<p id="errTip" class="pop-err hidden">
				<span> <img src="<?php echo $root_path ?>~main/imgs/pic-error.jpg"
					width="16" height="16" class="ver_a"> <font class="f1">Error!</font>
					<font id="errorTip"></font>
				</span>
			</p>
		</div>
	</div>

	<div class="pop-up">
		<p>
			<a href="javascript:;" class="btn_small skin_btn_light"
				onclick="saveOrUpdateAccount();">确 定</a> <a href="javascript:;"
				onclick="setForm();" class="btn_small skin_btn_dark">重置</a>
		</p>
	</div>
</div>
<!--popup end-->
