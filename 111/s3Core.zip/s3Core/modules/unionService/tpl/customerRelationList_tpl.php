<!-- 用户关系维护 -->
<script id="customerRelationTemp" type="text/html">
       <div>
        	<table width="100%">
              <tr class="border-tr">
                <th width="10%" class="fn">客户编号</th>
                <th width="30%" class="fn">客户名称</th>
                <th width="30%" class="fn">操作</th>
              </tr>
			<% if(userList == null || userList.length < 1){%>
			<tr class="bg_tr1 f5 fw">
                <td colspan="3">无查询结果！</td>
			</tr>
			<% }else{%>
			<% for (var i=0; i<userList.length; i++){
				var customer=userList[i];
			%>
              <tr <% if(i%2==1){%>class="bg_tr1 bb_tb"<%}%>>
                <td><%=customer.UserEntitycustomId%></td>
                <td><%=customer.UserEntityuserName%></td>
                <td>
					<a href="javascript:;" style="width:60px;" onclick="openMask('customer',<%=i%>);" class="btn_small skin_btn_light">绑定客户</a>
					<a href="javascript:;" style="width:60px;" onclick="openMask('operator',<%=i%>);" class="btn_small skin_btn_light">绑定公司</a>
				</td>
              </tr>
			<%}
			}%>
            </table>
        </div>
</script>

<script id="customerFormTemp" type="text/html">
   <div class="mar10">
        	<table width="100%">
              <tr class="border-tr">
                <th width="20%" class="fn">客户编号</th>
                <th width="40%" class="fn">客户名称</th>
				<th width="20%" class="fn">操作</th>
              </tr>
			<% if(userList == null || userList.length < 1){%>
			<tr class="bg_tr1 f5 fw">
                <td colspan="3">无查询结果！</td>
			</tr>
			<% }else{


			for (var i=0; i<userList.length; i++){
				var customer=userList[i];
			%>
              <tr <% if(i%2==1){%>  class="bg_tr1 bb_tb"  <%}%>  >
                <td><%=customer.UserEntitycustomId%></td>
                <td><%=customer.UserEntityuserName%></td>
               	<td>
					<a href="javascript:;" class="btn_small skin_btn_light" id = "<%=i%>" onclick="relationBind(this)">绑定</a>
				</td>
              </tr>
			<%}

			}%>
            </table>
    </div>
</script>

<script id ="bindFormTemp" type = "text/html">	
<div class="mar10">
	<h2>已绑定</h2>
	<table width="100%">
      <tr class="border-tr">
        <th width="20%" class="fn">客户编号</th>
        <th width="40%" class="fn">客户名称</th>
        <!--<th width="15%" class="fn">角色</th>-->
		<th width="20%" class="fn">操作</th>
      </tr>
	<% if(relation == null || relation.length < 1){%>
	<tr class="bg_tr1 f5 fw">
        <td colspan="3">未绑定任何客户！</td>
	</tr>
	<% }else{
	for (var i=0; i<relation.length; i++){
		var customer=relation[i];
	%>
      <tr <% if(i%2==1){%>  class="bg_tr1 bb_tb"  <%}%>  >
        <td><%=customer.customerId%></td>
        <td><%=customer.userName%></td>
        <!--<td><%=roleName[customer.type]%>-->
		</td>
       	<td>
			<a href="javascript:;" class="btn_small skin_btn_light" id = "<%=i%>" onclick="relationUnbind(this)">解除</a>
</td>
      </tr>
	<%}

	}%>
    </table>

</div>
</script>


<!-- 业务员列表 -->
<script id="bindCompanyList" type="text/html">
<div class="mar10">
    <table width="100%">
        <tr class="border-tr">
    				<th width="20%" class="fn">公司编号</th>
    				<th width="40%" class="fn">公司名称</th>
					<th width="20%" class="fn">操作</th>
        </tr>
			<% if(bindcompanyList == null || bindcompanyList.length < 1){%>
			<tr>
                <td colspan="3">无查询结果！</td>
			</tr>
			<% }else{%>
			<% for (var i=0; i<bindcompanyList.length; i++){
				var company=bindcompanyList[i];
			%>
              <tr <% if(i%2=='1'){%> class='border-tr' <%}%>>
              <tr <% if(i%2==1){%> class="bg_tr1"<%}%>>
                <td width="31%"><%=company.SaleCompanyEntityid%></td>
                <td width="31%"><%=company.SaleCompanyEntitysalecompanyName%></td>
				<td>
				<a href="javascript:;" class="btn_small skin_btn_light" id = "<%=i%>" onclick="companyUnbind(this)">解除</a>
				</td>
              </tr>
			<%}
			}%>
            </table>
</div>
</script>

<script id ="companyList" type = "text/html">
<div class="mar10">
<table width="100%">
<tr class="border-tr">
			<th width="20%" class="fn">公司编号</th>
			<th width="40%" class="fn">公司名称</th>
			<th width="20%" class="fn">操作</th>
</tr>
	<% if(companyList  == null || companyList .length < 1){%>
	<tr>
        <td colspan="3">无查询结果！</td>
	</tr>
	<% }else{%>
	<% for (var i=0; i<companyList .length; i++){
		var company=companyList [i];
	%>
      <tr <% if(i%2=='1'){%> class='border-tr' <%}%>>
      <tr <% if(i%2==1){%> class="bg_tr1"<%}%>>
        <td width="31%"><%=company.SaleCompanyEntityid%></td>
        <td width="31%"><%=company.SaleCompanyEntitysalecompanyName%></td>
		<td>
		<a href="javascript:;" class="btn_small skin_btn_light" id = "<%=i%>" onclick="companyBind(this)">绑定</a>
		</td>
      </tr>
	<%}
	}%>
    </table>
</div>
</script>