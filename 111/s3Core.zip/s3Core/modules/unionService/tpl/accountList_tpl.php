<!-- 新增用户列表 -->
<script id="accountListTemp" type="text/html">
<table class="table1 auto" width="95%">
    <tr class="border-tr">
       <th width="5%">序号</th>
	   <th>登录名</th>
       <th>账户名</th>
       <th>创建时间</th>
       <th>账户状态</th>
       <th>操作</th>
    </tr>
<% if(accountList && accountList.length!=0){
	for(var i=0;i<accountList.length;i++){
		var account = accountList[i];
%>
    <% if(i%2==0){%>
	<tr>
	<% }else{%>
	<tr class="bg_tr1 bb_tb">
	<%}%>
       <td><%=i+1%></td>
	   <td><%=account.loginName%></td>
       <td><%=account.userName%></td>
       <td class="f3"><%=account.createTime%></td>

       <td><% if(account.status == '1'){%>已启用<% }else{%>已停用<%}%></td>
       <td>
	<% if(account.status != 1){%>
		<a href="javascript:enableAccount(<%=i%>);" class="btn_small skin_btn_light">启用
		</a> 
	<%}else{%>
		<a href="javascript:disableAccount(<%=i%>);" class="btn_small skin_btn_dark">停用
		</a> 
	<%}%>
		<a href="javascript:openMask('edit',<%=i%>);" class="btn_small skin_btn_light">编辑</a></td>
    </tr>
	<%}%>
<% }else { %>
	<tr> <td colspan="6">无数据</td></tr>
<%  }%>
</table>
</script>