<!-- 终端客户列表 -->
<script id="customerManagerList" type="text/html">


		
      <table width="100%">
            <tr class="border-tr">
               		<th>用户名</th>
                    <th>用户编号</th>
                    <th>客户名称</th>
                    <th>手机号码</th>
                    <th>电子邮箱</th>
					<th>操作</th>
            </tr>
			<% if(customerList == null || customerList.length < 1){%>
			<tr>
                <td colspan="6">无查询结果！</td>
			</tr>
			<% }else{%>
			<% for (var i=0; i<customerList.length; i++){
				var customer=customerList[i];
			%>
              <tr <% if(i%2==1){%> class="bg_tr1 bb_tb"<%}%>>
				<td><%=customer.loginName%></td>
                <td><%=customer.customerId%></td>
                <td><%=customer.userName%></td>
                <td><%=customer.mobile%></td>
				<td><%=customer.email%></td>
                <td>
					<a href="javascript:;" onclick="openMask('edit','customer',<%=i%>);"  class="btn_small skin_btn_light">编辑</a> 
					<%if(isEdit==1){%><a href="javascript:;" onclick="deleteCustomer(<%=i%>);" class="btn-del">删除</a><%}%>
				</td>
              </tr>
			<%}
			}%>
            </table>


           <p class="page" id="customerPager"></p>         
</script>
<!-- 业务员列表 -->
<script id="operatorManagerList" type="text/html">
        	<table width="100%">
              <tr class="border-tr">
               		<th width="5%">&nbsp;</th>
    				<th width="10%">客户编号</th>
    				<th width="20%">姓名</th>
    				<th width="25%">手机号码</th>
              </tr>
			<% if(operatorList == null || operatorList.length < 1){%>
			<tr>
                <td colspan="4">无查询结果！</td>
			</tr>
			<% }else{%>
			<% for (var i=0; i<operatorList.length; i++){
				var operator=operatorList[i];
			%>
              <tr <% if(i%2==1){%> class="bg_tr1 bb_tb"<%}%>>
				<td>
				<input type="radio" name="RadioGroup1" value="<%=i%>" <% if(operatorId == operator.customerId){%>checked="true"<%}%>/></td>
                <td><%=operator.customerId%></td>
                <td><%=operator.customerName%></td>
                <td><%=operator.mobile%></td>
                
              </tr>
			<%}
			}%>
            </table>
</script>