<!-- 快速下单时，商品查询条件模板 -->
<script id="salesManagerTemp" type="text/html">
      <div>
        	<table width="100%" style="position:relative;top:-19px;">
              <tr class="border-tr">
                <th width="8%">客户编号</th>
                <th width="20%">客户姓名</th>
				<th width = "20%">联系方式</th>
                <th width="15%">操作</th>
              </tr>

			<% if(userList == null || userList.length < 1){%>

				<tr class="bg_tr1 f5 fw">
               	 	<td colspan="4">无查询结果！</td>
				</tr>	

			<% }else{%>


			<% for (var i=0; i<userList.length; i++){
				var user=userList[i];
			%>


              <tr <% if(i%2==1){%>class="bg_tr1 bb_tb"<%}%>>

                <td><%=user.UserEntitycustomId%></td>
                <td><%=user.UserEntityuserName%></td>
				<td><% if(user.UserEntitymobilephone!=null &&user.UserEntitymobilephone!="")%><%=user.UserEntitymobilephone%></td>

                <td><a href="javascript:;" onclick="openMask('edit',<%=i%>);" class="btn_small skin_btn_light">编辑</a> 
					<a href="javascript:;" onclick="openResetMask(<%=i%>);" class="btn_small skin_btn_light">重置密码</a>
				</td>
              </tr>
			<%}%>
			<%}%>
            </table>
        </div>
</script>