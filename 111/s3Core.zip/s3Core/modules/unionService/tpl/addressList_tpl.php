<!-- 地址列表模板 -->
<script id="addressList" type="text/html">
<div>
<table id="table1" class="table2" width="100%">
	<thead>
		<tr id="tableHead">
			<th>联系人</th>
			<th>联系方式</th>
			<th width="30%">收货地址</th>
			<th width="16%">默认发票地址</th>
			<th width="18%">操作</th>
			<th width="10%"></th>
		</tr>
	</thead>
<tbody id="addrTbody">
<% if(addressList.length!=0){%>
	 <% for (var i=0; i<addressList.length; i++) {%>
		<% if(i%2==0){%>
			<tr>
		<% }else{%>
			<tr class="bg_tr1 bb_tb">
		<%}%>
		<td><%=addressList[i].firstName%></td>
		<td lastphone="<%=(addressList[i].mobile || addressList[i].telephone)%>"> 
			<% if(addressList[i].mobile){ %> 
				<%=addressList[i].mobile%> 
			<%} else {%> 
				<%=addressList[i].telephone%>
			<%}%>
		</td>
		<td>
			<%=addressList[i].address%>
			<!--<%=addressList[i].provName%>
			<%=addressList[i].cityName%>
			<%=addressList[i].cityAreaName%>
			<%=addressList[i].address%>-->
		</td>
		<td>
			<%if(addressList[i].isBillCurrent == 1){%>
				是
			<%}else{%>
				否
			<%}%>
			
		</td>
		<td class="tex_l pad_l20">
				<!--<a href="javascript:;"   onclick="setFormForUpdate('<%=i%>')" class="btn_small skin_btn_light">修改</a>-->
 				&nbsp;&nbsp;<%if(addressList[i].isCurrent != 1){%>
				<a href="javascript:;"   id="delBtn<%=addressList[i].addrId%>"  onclick="delAddress('<%=addressList[i].addrId%>')"  class="btn_small skin_btn_dark">删除</a>
			<%}%>
		</td>
		<td>
			<%if(addressList[i].isCurrent=="1"){%>
				<span class = "addrDefault">默认地址</span>
			<%}else{%>
				<a href ="javascript:;" class = "addrSettingbtn" id ="addr<%=addressList[i].addrId%>" onclick="changeShipCurrent('<%=addressList[i].addrId %>')">设为默认</a>	
			<%}%>
		</td>

	</tr>
   <%}
  }else{	
%>
	<tr><td colspan="6" class="bg_td f1">无地址数据</td></tr>
<%}%>
</tbody>
</table>
<p class="page" id="addressPager"></p>
</div>
</script>
