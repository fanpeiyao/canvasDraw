<script id="companyList" type="text/html">

<table class="table1" width="95%">
	<thead>
		<tr>
			<th>公司编号</th>
			<th width="40%">公司名称</th>  
			<th>账户余额</th> 
		</tr>
	</thead>

<tbody>
<% if(companyList.length!=0){%>
	 <% for (var i=0; i<companyList.length; i++) {%>
		<% if(i%2==0){%>
			<tr>
		<% }else{%>
			<tr class="bg_tr1 bb_tb">
		<%}%>
		<td class="f7"><%=companyList[i].companyId%></td>
		<td class="f7"><%=companyList[i].companyName%></td>
  		<td class="f1 fw">￥<%=companyList[i].balance%></td>
		
	</tr>
   <%}
  }else{	
%>
	<tr><td colspan="3" class="f1 bg_td">无分公司信息</td></tr>
<%}%>
</tbody>
</table>

</script>

<script id="bindedList" type="text/html">

<table class="table1" width="95%">
	<thead>
		<tr>
			<th>二级经销商编号</th>
			<th width="40%">二级经销商名称</th>  
		</tr>
	</thead>
<tbody>
<% if(customerList.length!=0){%>
	 <% for (var i=0; i<customerList.length; i++) {%>
		<% if(i%2==0){%>
			<tr>
		<% }else{%>
			<tr class="bg_tr1 bb_tb">
		<%}%>
		<td class="f7"><%=customerList[i].customerId%></td>
		<td class="f7"><%=customerList[i].userName%></td>
	</tr>
   <%}
  }else{	
%>
	<tr><td colspan="2" class="f1 bg_td">无二级经销商数据</td></tr>
<%}%>
</tbody>
</table>

</script>







