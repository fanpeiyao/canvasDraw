<!-- 客户审核列表模板 -->
<script id="customerVerifyTemp" type="text/html">
<table width="100%">
        <tr class="border-tr">
            <th width="17%">客户编号</th>
			<th width="25%">客户名称</th>
            <th width="19%">申请时间</th>
            <th width="13%">状态</th>
            <th width="14%">操作</th>
        </tr>
<% if(customerVerifyList.length!=0){
	var statusMap = {};
	statusMap['0'] = '待激活';
	statusMap['1'] = '已激活';
	statusMap['2'] = '已禁用';
%>
   <% for (var i=0; i<customerVerifyList.length; i++) {
		var cust = customerVerifyList[i];
   %>
	<tr <% if(i%2 == 1 ) {%> class="bg_tr1 bb_tb"<%}%>>
  		<td>
			<%=cust.customerId%></td>
		<td><%=cust.userName%></td>
		<td><%=cust.createTime%></td>
		<td><% if("0"==cust.status || !cust.status){%>待激活<%}else{%><%=statusMap[cust.status]%><%}%></td>
		<td>
		<%if("0"==cust.status  || !cust.status){%>
			<a href="javascript:;" onclick="verifyCustomer('<%=cust.unionId%>',this,'1')" class="btn_small skin_btn_light">激活</a>
		<%}
		if("1"==cust.status){%>
			<a href="javascript:;" onclick="verifyCustomer('<%=cust.unionId%>',this,'2')" class="btn_small skin_btn_dark">禁用</a>
		<%}
		if("2"==cust.status){%>
			<a href="javascript:;" onclick="verifyCustomer('<%=cust.unionId%>',this,'1')" class="btn_small skin_btn_light">启用</a>
		<%}%>
		</td>	
	</tr>
   <%}
 }else{	%>
	<tr class="bg_tr1 fw f5">
		<td colspan="5">无查询结果！</td>
	</tr>
<%}%>
</table>


</script>
