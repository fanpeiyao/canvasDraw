<!-- 省份、市区、地区模板 -->
<script type="text/html" id="seleProvince">
	<span class="w120 display-in tex_r">地区：</span>
	<span class="display-in tex_l">
		<select class="h25  ver_a" errormsg="请选择区域" redId='newAddrForm#selectCity' id="selectProvince" name="form_province_id">
			<option selected="selected" value="">请选择省份</option>
			<% if (provinces!=null && provinces.length >0) {
				   for(var i = 0 ;i <provinces.length; i++) {%>
						<option value="<%=provinces[i].areaId%>"><%=provinces[i].areaName%></option>
				<% }
			}%>		
		</select><label>省</label>
		<select class="h25 ver_a" redId='newAddrForm#selectDistrict' isnull="0" id="selectCity" name="form_city_id">
			<option value="">请选择城市</option>
		</select><label> 市</label> <font class="f1">*</font>
		
		
	</span>
</script>