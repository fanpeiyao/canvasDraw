<!-- 省份、市区、地区模板 -->
<script type="text/html" id="selProvince">
	
	<p class=" pad_l20 f14 mar_t20 " >
		经销商名称：<input type="text" id="customerName" name="customerName" class=" h22  mar_r10 ver_a"/> 
		<a class="btn4 search mar_r10" href="#" onclick="searchDealer(1)">搜索</a> 
		<a href="#" class="btn2 clear" onclick="clean();">清空</a>
	</p>
	<div id="dealerTpl" class="mar_t20"></div>
	
	<!-- 分页 -->
	<p class="fl_r pad10 mar_r20" id="dealerPager"></p>
</script>

<script type="text/html" id="dealerTable">

<table width="100%" id="tableDealer">
	   <tr class="border-tr" id="tableHead">
	     <td width="10%"></td>
	     <td>经销商编号</td>
	     <td width="57%">经销商名称</td>
	   </tr>
  	   <% if(dealerList.length==0){%>
       <tr class="bg_tr1 f5 fw">
         <td colspan="3" align="center">无查询结果！</td>
       </tr>
	  <%}%>
  	   <% if(dealerList.length>0){
		  for(var i = 0 ;i <dealerList.length; i++) {%>
             <tr class="bg_tr1 bb_tb">
                <td  class="blue2"><input id="radio<%=i%>" type="radio" name="client" class="border0" />
					<input type="hidden" value = "<%=dealerList[i].operatorId%>"/></td>
                <td><%=dealerList[i].customerId%></td>
                <td><%=dealerList[i].customerName%></td>
             </tr>
		   <%}%>
	  <%}%>
</table>
</script>