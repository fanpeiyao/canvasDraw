<script id="roleList" type="text/html">
        	<table width="100%">
              <tr class="border-tr">
				<th width="25%">角色名称</th>
				<th width="15%">角色状态</th>
				<!--<th width="15%">业务代码</th>-->
                <th>操作</th>
              </tr>
<% if(roleList==null||roleList.length==0){%>
     <tr class="bg_tr1 f5 fw">
        <td colspan="5" align="center">无查询结果！</td>
     </tr>
  	<%}else{%>
			<% for(var i=(pagenumber - 1)*limit;((i < num) && (i <pagenumber*limit));i++){%>
              <tr <%if(i%2==1){%>class="bg_tr1 bb_tb"<%}%>>
				<td><%=roleList[i].RoleEntityname%></td>
				<% if (roleList[i].RoleEntityenable == 1){%>
					<td>启用</td>
				<%} else if(roleList[i].RoleEntityenable == 0){%>
					<td>禁用</td>
				<% }%>
	        <td>
				<a href="javascript:viewUsers('1','<%=roleList[i].RoleEntityid%>','<%=roleList[i].RoleEntityname%>')" class="btn_small skin_btn_light">查看人员</a>
				<a href="javascript:functionSetup('<%=roleList[i].RoleEntityid%>','<%=roleList[i].RoleEntityname%>')" class="btn_small skin_btn_light">分配权限</a>
				<a href="javascript:updateDiag('<%=roleList[i].RoleEntityid%>','<%=roleList[i].RoleEntityname%>','<%=roleList[i].RoleEntityenable%>')" class="btn_small skin_btn_light">编辑</a>
				<a href="javascript:deleteRole('<%=roleList[i].RoleEntityid%>')" class="btn_small skin_btn_light">删除</a>
				</td>               
			<%}%>
<%}%>
</tr>
</table>
</script>

<script id="roleInfoManager" type="text/html">
<div class="pop-title" >
    <font><i class="icon-pop"></i><%if(isUpdate){%>角色修改<%}else{%>添加角色<%}%></font>
        <a href="javascript:closeDiag();"><img src="<?php echo $root_path?>~main/imgs/close.jpg" width="16" height="16" /></a>
    </div>
    <div class="pop-cent pad-l90">
		<%if(isUpdate){%>
        	<p><font class="w60">角色ID：</font><span>
				<input name="" type="text" id="roleID" value="<%=roleId%>" disabled="disabled" onkeyup="this.value=this.value.replace(/\D/g,'');"/>
			</span></p>
        	<p><font class="w60">角色名称：</font><span>
				<input name="" type="text" id="roleName" value="<%=roleName%>"/></span>
			<b>*</b></p>	
			<p><font class="w60">角色状态：</font><span>
				<select id="enableRole" >
					<option value="1">启用</option>
					<option value="0">禁用</option>
				</select>
				</span><b>*</b></p>
		<%}else{%>		
        	<!--<p><font class="w60">角色ID：</font><span>-->
				<input name="" type="hidden" id="roleID" onkeyup="this.value=this.value.replace(/\D/g,'');"/>
			<!--</span><b>*</b></p>-->
        	<p><font class="w60">角色名称：</font><span>
				<input name="" type="text" id="roleName"/></span>
			<b>*</b></p>	
		<%}%>
    </div>
	<!-- 错误提示 -->
	<div class="f1">
					<p id="errTip" class="pop-err display">
						<span> <img src="<?php echo $root_path ?>~main/imgs/pic-error.jpg" width="16" height="16" class="ver_a"> <font class="f1">Error!</font>
							<font id="errMsg"></font>
						</span>
					</p>
	</div>

    <div class="pop-up">
		<p>
			<%if(isUpdate){%>
				<a href="javascript:updateRole();" class="btn_small skin_btn_light">确 定</a>
			<%}else{%>
				<a href="javascript:addRole();" class="btn_small skin_btn_light">确 定</a>
			<%}%>
			<a href="javascript:closeDiag();" class="btn btn-close">取 消</a></p>
    </div>	
</script>

<script id="allocateFunctions" type="text/html">
<!-- 权限分配页面 -->
<div id="roleFunctions" class="bg_concent" >
	<div class="pop-title" >
   		<font><div id = "title">权限分配</div></font>
        <a href="javascript:closeDiag3();"><img src="<?php echo $root_path?>~main/imgs/close.jpg" width="16" height="16" /></a>
    </div>
	<div class="tree left ztreeright" >
		<ul id="functionTree" class="ztree ztreeleft"></ul>
	</div>
</div>
<!-- 错误提示 -->
<div class="f1">
	<p id="errTip" class="tex_c mar_t20 display">
		<span> <img src="<?php echo $root_path ?>~main/imgs/pic-error.jpg" width="16" height="16" class="ver_a" /> <font class="f1">Error!</font>
			<font id="errMsg"></font>
		</span>
	</p>
</div>
<div class="pop-up1 mar_t10">
	<p><a href="javascript:saveRoleFunctons();" class="mar_t10 btn_small skin_btn_light">保 存</a>
	<a href="javascript:closeDiag3();" class="btn_small skin_btn_dark">取 消</a></p>
</div>	
</script>

<script id="viewUsers" type="text/html">
<div id="roleUsers">
<div class="pop-title">
   		<font><div id = "title">用户3以下的人员</div></font>
		<input name="" type="hidden" id="roleID" value="<%=roleId%>" />
		<input name="" type="hidden" id="roleName" value="<%=roleName%>" />
        <a href="javascript:closeDiag2();"><img src="<?php echo $root_path?>~main/imgs/close.jpg" width="16" height="16" /></a>
</div>
	<div class="of p10">
		<div>
		<input type="hidden" id="roleOpen" />
			<div class="condit">
        		<div>
					<span>登录名：<input id="loginNameSearch" type="text" class="input-text"></span>
     			   	<span>手机号：<input id="mobileSearch" type="text" class="input-text"></span>
				</div>
				<div class="pad_t10">
				   	<span>用户名：<input id="nameSearch" type="text" class="input-text"></span>
				   	<span>编<font class="hidden">空</font>号：<input id="dearNoSearch" type="text" class="input-text"></span>
				   	<a class="btn btn-search_min"  value="1" href="#" onclick="searchClick('1')">搜索</a>
            	   	<a onclick="clearSearch()" class="btn_small skin_btn_dark" href="#">清空</a>
				</div>
			</div>
			
			<div class="title-inner"><span><i class="icon-list"></i>用户信息列表</span></div>
			<div id="roleUsersTable" class="pay-l of">
		    <table width="98%">
				<tr class="border-tr">
                <th class="fn">编号</th>
                <th class="fn">用户名</th>
                <th class="fn">登录名</th>
				<th class="fn">手机号码</th>
                <th class="fn">角色</th>
             	</tr>
				<% if(userInfo.userList == null || num < 1){%>
				<tr class="bg_tr1 f5 fw">
                	<td colspan="5">无查询结果！</td>
				</tr>
				<% }else{%>
				<% for(var i=(pagenumber - 1)*limit;((i < num) && (i <pagenumber*limit));i++){
					var user=userInfo.userList[i];
				%>
          	    <tr <% if(i%2==1){%>class="bg_tr1 bb_tb"<%}%>>
            	    <td><%=user.customId%></td>
                	<td><%=user.userName%></td>
                	<td><%=user.loginName%></td>
					<td><%=user.mobilephone%></td>   
					<td><%=user.roleName%></td>         	   
        	      </tr>
				<%}%>
				<%}%>
			</table>
             </div>
			<p class="page" id="userpager">
      			<img src="<?php echo $root_path?>~main/imgs/page.jpg" width="395" height="34" />
        	</p>
			<div class="end"></div>
		</div>
	</div>
<div class="pop-up">
	<a href="javascript:closeDiag2();" class="btn btn-close">关 闭</a></p>
</div>	
</div>

</script>
