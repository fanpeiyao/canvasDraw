<?php 
require_once 'tpl/newPaymentOrder_tpl.php';
require_once 'paymentConfirm.php';
require_once 'tpl/showModel.php';
?>

<script src="<?php echo $root_path ?>modules/paymentservice/js/paymentConfig.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/paymentservice/js/newPayment.js" type="text/javascript"></script>
	
<body>

<div class="pay-wrapper">
		<div class="pay-main">		
			<p class="pay-newpay_title"><font>新建付款单</font></p>
			<input type="hidden" id="cbSelected" name="cbSelected" value="" />
			<input type="hidden" id="seller_id" name="seller_id" value="" /> 
			<input type="hidden" id="combinePage" name="combinePage" value="" />
			<input type="hidden" id="form_orderStatusChk" name="form_orderStatusChk" value="" />
			<input type="hidden" id="fromOrder" name="fromOrder" value="" />
			<!--内容区begin-->
			<div class="pay-newpay_cont">					  
				<!--内容区1-->
			    <div class="pay_cont" id="shownewpaymentInfo"></div>
                <div class="pay_cont" id="hasrzinfo"></div>
				<!--内容区2(隐藏模块用class="display")-->								
				<div id="newpaymentorder_table"></div>	
				<div id="pager" class="pay-page"></div>
                <p class="clear"></p>			    				
			    <!-- 备注付款模块 -->
                <div class="pay-new_bottom">
				        <!--内容区3-->
				        <div class="pay-new_remark">
						    <span>备注：</span>
						    <textarea name="notes" id="notes" value="备注请勿超过50字" cols="50"
							    rows="5"
							    onpropertychange="if(value.length>50) value=value.substr(0,50);"
							    oninput="if(value.length>50) value=value.substr(0,50);"
							    onfocus="clearText('notes', 'ErrTip','50');"
							    onblur="validateRMKLength('notes', 'ErrTip','50');">备注请勿超过50字</textarea>
						    <div style="display: none; margin-left: 62px;" class="Error" id="ErrTip"></div>
				       </div>
				</div>
				<!--内容区4,付款金额显示-->
				<div class="pay-new_amount" id="showmoney_table"></div>
				<p class="clear"></p>			    
			</div>
			<!--内容区end-->
			</br>
			<!-- 跳转下一步区域 -->
			<div class="pay-new_next"><a class="pay-btn_next" href="javascript:void(0);" onclick="paymentconfirm()">下一步</a></div>
			<p class="clear"></p>
			</div>
			<script type="text/javaScript">
				$("#seller_id").val(seller_id);			 	
				$("#customerDebt").html(convertToMoney(customerDebt));
				$("#fromOrder").val(fromOrder); 								
			</script>
			
		</div>
	</div>
</body>
</html>
