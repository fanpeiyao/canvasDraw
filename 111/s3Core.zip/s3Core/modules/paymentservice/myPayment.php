<!--加载引用--> 
<?php   
	require_once 'tpl/paymentList_tpl.php';
	require_once 'paymentSum.php';
?>
<script src="<?php echo $root_path ?>modules/paymentservice/js/paymentConfig.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/paymentservice/js/myPayment.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>common/js/number.js" type="text/javascript"></script>
<!--  <script src="<?php echo $root_path ?>modules/paymentservice/js/relatedOrdertbl.js" type="text/javascript"></script> -->

<!--我的订单开始-->
<div class="payment-border">
		<div class="payment-side"> 请选择筛选条件:</div> 
<div class="pay-rightcontent">

	<!--搜索模块-->
	<div class="pay-search_bg" id="mypaymentSearch"></div>
	
	<!--付款单列表-->
	<!--标题栏-->
	<p class="payment-inner">
		<span><i class="iconfont icon-zhangdan skin-color" style="margin-right:3px;"></i>我的付款单</span>
		<font>
			<a href="javascript:void(0);" onclick='newpayment(this)' rootpath='<?php echo $realpath ?>' ><i class="iconfont icon-xinjian" style="position:relative;top:1px;left:-5px;"></i>新建付款单</a>
		</font>
	</p>	
	<!--付款单table栏-->
	<div id="mypayment_table" ></div><!-- 付款单展示模块 -->
	<div id="pager" class="pay-page"></div><!-- 页码显示模块 -->	
	<div class="clear"></div>
</div>	
</div>
<div class="popupsty pop_window_box" id="easyPayResult" style="display: none;"></div>
<!--我的订单结束--> 