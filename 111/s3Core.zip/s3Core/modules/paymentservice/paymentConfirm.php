<div  id="paymentConfirm" class="pay-popup" style="display:none;">
 
 	 <!--标题-->
     <p class="pay-popup_title"><span>付款单确认</span><a onclick="closeBg('paymentConfirm')">× </a></p>
           
  	 <div class="pay-popup_content" id="paymentConfirmTableWidth">
  	 <!--内容区--> 
        	<p class="pay-popup_ye" id="paymentconfirmdebt">余额： <span class="pay-tab_money" id="customerDebt"></span></p>
		    <div>
		            <div id="selectedtable"></div>
					<p class="pay-popup_remark">
		            	<span >备注：</span>
		            	<textarea id="notes1" disabled></textarea>
		            </p>
		            <div class="pay-popup_amount">	
		                <p id="paymentconfirmshow"><span id="ThisTimeShow1Span"></span><font id="amount1span"></font>&nbsp元</p>	
		                <p><span id="ThisTimeMoney1Span"></span><font id="ThisTimeMoney1"></font >&nbsp元</p>
		            </div>
		    </div>
		    <div class="pay-popup_line"></div>
	</div>
	
    <!--按钮-->
    <p class="pay-btn">
        <a href="javascript:void(0);" onclick="setPaymentOrder();" class="pay-btn_next">确 定</a> 
        <a href="javascript:void(0);" class="pay-btn_back" onclick="closeBg('paymentConfirm')">返 回</a>
    </p>
    
</div>
<div id="fullbg"></div>

