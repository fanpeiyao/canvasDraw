/**
 * 付款单显示页面，付款单关联订单时点击加号触发方法，显示关联订单
 * @author zjfh-raojc
 * @returns 点击加号显示付款单关联订单
 */
function jiahaoshow(num){

	document.getElementById("jiahao"+num).style.display='none';
	document.getElementById("jianhao"+num).style.display='';
	document.getElementById("mainOrder"+num).style.background='#f9fbe1';
	if($("#showrelatedorder"+num).html()==""||$("#showrelatedorder"+num).html()==null){
		createRelatedOrderTabel(num);
	}else{
		document.getElementById("ordertable"+num).style.display='';
		document.getElementById("ordertable"+num).style.background='#f8f4ec';
	}
		
	
}

/**
 * 付款单显示页面，付款单关联订单时点击减号触发方法，隐藏关联订单
 * @author zjfh-raojc
 * @returns 点击减号缩掉付款单关联订单
 */
function jianhaoshow(num,columnNum){
	document.getElementById("ordertable"+num).style.display='none';
	document.getElementById("jiahao"+num).style.display='';
	document.getElementById("jianhao"+num).style.display='none';
	if(columnNum%2==0)
	{
		document.getElementById("mainOrder"+num).style.background='#fff';
		document.getElementById("ordertable"+num).style.background='#fff';
	}
	else
	{
		document.getElementById("mainOrder"+num).style.background='#f9f9f9';
		document.getElementById("ordertable"+num).style.background='#f9f9f9';
	}
	
}


/**
 * 按照付款单状态查找付款单,参数为下拉框元素
 * 
 */
function SearchByStatus(obj){
     $("#form_paymentStatusChk").val(obj.value);
     renderHtml(1,obj.value);
}

/**
 * 按照付款单编号和生成日期查询
 * 
 */
function SearchByKey(s){
	 var start=document.getElementById("form_create_start_time").value;
	 var end=document.getElementById("form_create_end_time").value;
	 start=start.substring(0,4)+start.substring(5,7)+start.substring(8,10);
	 end=end.substring(0,4)+end.substring(5,7)+end.substring(8,10);
	 if(start!="" && end!=""){
	 	if(start>end){
	 		$.dialog({
	 			content: "开始时间不能大于结束时间！",
	 			title:"alert",
	 			//width:200,
	 			ok : function () {}
	 		});
			
			return;
	 	}
	 }
	 var paymentStatus = $("#form_paymentStatus").val();
	 renderHtml(1,paymentStatus);
}

/**
 * 清除查询内容
 * 
 */
function clean(){
	var inputs=$("input");
	
    for(var m=0;m<inputs.length;m++){
    	if($(inputs[m]).val() != "重置" && $(inputs[m]).val() != "查询"  && $(inputs[m]).val() != "下载" && $(inputs[m]).val() != "跳转"
    		&& $(inputs[m]).attr("id") != "pageselect"){
        	$(inputs[m]).val("");
    	}
    }
   $("select").val("-1");
    renderHtml(1);
}

/**
 * 跳转新建付款单
 * 传入路径信息
 * 
 * 结果：跳转新建付款单页面
 */
function newpayment(st){
	  var rootpath = st.getAttribute("rootpath");
	  var orderIds = st.getAttribute("orderIds");
	  if(orderIds==null||orderIds=='')
      {
		  window.location=rootpath+'~main/share/frame.php?target=newPayment&&orderIds=';  
	  }
	  else
	  {
		  window.location=rootpath+'~main/share/frame.php?target=newPayment&&orderIds='+orderIds;
	  }
	   
}

/**
 * 跳转付款单详情
 * 传入路径信息
 * 
 * 结果：跳转付款单详情页面
 */
function paymentDetail(st){
	  var paymentId = st.getAttribute('paymentId');	  
	  var rootpath = 'mobile/share/frame.php?target=paymentDetail&&paymentId='+paymentId+'&&customerId=&&customerName='
	  window.location=getContextPath(rootpath);;  	    
}

/**
 * 填充数据到页面
 * 
 * @param page 当前页码
 * @param paymentStatus 付款单状态
 * */
function renderHtml(page,paymentStatus){
	 $("#mypayment_table").html(paymentList(page, paymentStatus));
}

var currentPage = 1;
var totalPage = 1;

/** 
 * 查询付款单列表
 * 参数pageclickednumber：选择页码
 * 参数status：付款单状态
 * 
 * 结果：加载页面
 */
function paymentList(pageclickednumber,status){
	   var limit = 5;
	   var params = {
		      "page":pageclickednumber,
		      "status":status,
		      "paymentID":$("#form_paymentNo").val(),
		      "startTime":$("#form_create_start_time").val(),
		      "endTime":$("#form_create_end_time").val(),
		      "sellerID":$("#form_sellerid").val(),
		      "sellerName":$("#form_sellername").val(),
		      "limit":limit
		    };
	   var ary = execjava('paymentBean.getPaymentList', params, 'json',"paymentservice");
	   
	   if(!ary || ary.resCode !="200"){
	 		$.dialog({
	 			content: "访问付款单服务出错！",
	 			title:"alert",
	 			time:1000,
	 			timeOut:function () {}
	 		});
		   return;
	   }
	   currentPage = pageclickednumber;
	   var paymentList = ary.paymentList;
	   //金额格式化	
	    for(var i = 0;i<paymentList.length;i++){
	    	paymentList[i].payAmount =addCommafy(paymentList[i].payAmount);
	    	paymentList[i].rsv1 =addCommafy(paymentList[i].rsv1==null?0:paymentList[i].rsv1);
	 	}
	   //总记录数
	   var totalNum = ary.D_COUNT
	   //总页数
	   totalPage = ary.PAGE_TOTAL;
	   var paymentListMode = 'paymentList';
	   var paymentListHtml = template.render(paymentListMode, {
		   	 paymentList: paymentList,
			 paymentDisplayII: paymentDisplayII,
			 orderDisplayII: orderDisplayII,			 
			 paymentStatus:status
		     });  
	   		    
		if(limit >=totalNum || currentPage>=totalPage){
	 		$(".ui-refresh-down").addClass("display");
	 		$(".ui-refresh-down").hide();
	 	} else {
	 		$(".ui-refresh-down").removeClass("display");
	 		$(".ui-refresh-down").show();
	 	}
	    
	   return paymentListHtml;
}	

/**
 * 付款单delete
 * 
 * 结果显示删除后付款单情况
 * 
 */
function deletePayment(st){
	    var paymentID = st.getAttribute("oId");
	    var cf = window.confirm("是否清除付款单？请确认");
	    if(cf){
	    	var parmStr = {"paymentID":paymentID};
	    	showLoading();
	    	var CancelPaymentOrder = execjava('paymentBean.deletePayment',parmStr,'json',"paymentservice");
	    	 if(CancelPaymentOrder.resCode!="200"){
	    		 var failedMes=CancelPaymentOrder.resMsg;
	    		 alert(failedMes);
	    	 }
	    	removeLoading();
	    	paymentList(1);
	    }

}

/**
 * 付款单跳转支付平台动作
 * 
 * 结果跳转支付平台
 */
function gotoPay(st){
		var status = st.getAttribute("orderStatus");
	    var paymentId = st.getAttribute("oId"); 
	    var rootpath = st.getAttribute("rootpath");
	    var parmStr = {"paymentID":paymentId};
	    if(status == 0){//待付款或贷款失败重新支付
	     var ret = execjava("paymentBean.updatePaymentTime",parmStr,"json","paymentservice");
	    // window.location=rootpath+'modules/paymentservice/gotopay.php?paymentId='+paymentId;
	     window.open(rootpath+'modules/paymentservice/gotopay.php?paymentId='+paymentId);     
	    }
	    /*else if(status == 1){
	   	 window.open(getPortalPath()+'html/qnfMatch.php?oId='+oId);
	    }*/
}

/**
 * 显示查询中的背影
 * 
 */
function showLoading(){
	    if($("#show-loading-div").size()>0){
	       $("#show-loading-div").show();
	       return ;
	    }
	  
		var overlayCSS =  {
			backgroundColor: '#fff',
			opacity:	  	 0.6, 
			cursor:		  	 'wait',
			width:'100%',
			height:___getPageSize().pheight,
			position: 'absolute',
			top:0 
		//	'-webkit-border-radius': '10px',
		//'-moz-border-radius':	 '10px',
		//'border-radius': 		 '10px'
		}
	    var element = jQuery("<div style='z-index:99999;filter:alpha(opacity=50)'/>").attr("id","show-loading-div").css(overlayCSS).appendTo(document.body);
}

function ___getPageSize() {  
	    var xScroll, yScroll;  
	    if (window.innerHeight && window.scrollMaxY) {    
	        xScroll = window.innerWidth + window.scrollMaxX;  
	        yScroll = window.innerHeight + window.scrollMaxY;  
	    } else if (document.body.scrollHeight > document.body.offsetHeight){ // all but Explorer Mac  
	        xScroll = document.body.scrollWidth;  
	        yScroll = document.body.scrollHeight;  
	    } else { // Explorer Mac...would also work in Explorer 6 Strict, Mozilla and Safari  
	        xScroll = document.body.offsetWidth;  
	        yScroll = document.body.offsetHeight;  
	    }  
	    var windowWidth, windowHeight;  
	    if (self.innerHeight) { // all except Explorer  
	        if(document.documentElement.clientWidth){  
	            windowWidth = document.documentElement.clientWidth;   
	        } else {  
	            windowWidth = self.innerWidth;  
	        }  
	        
	        windowHeight = self.innerHeight;  
	    } else if (document.documentElement && document.documentElement.clientHeight) { // Explorer 6 Strict Mode  
	        windowWidth = document.documentElement.clientWidth;  
	        windowHeight = document.documentElement.clientHeight;  
	    } else if (document.body) { // other Explorers  
	        windowWidth = document.body.clientWidth;  
	        windowHeight = document.body.clientHeight;  
	    }     
	    // for small pages with total height less then height of the viewport  
	    if(yScroll < windowHeight){  
	        pageHeight = windowHeight;  
	    } else {   
	        pageHeight = yScroll;  
	    }  
	    // for small pages with total width less then width of the viewport  
	    if(xScroll < windowWidth){     
	        pageWidth = xScroll;          
	    } else {  
	        pageWidth = windowWidth;  
	    }  
	  　　// arrayPageSize = new Array(pageWidth,pageHeight,windowWidth,windowHeight);  
	    return {pwidth:pageWidth,pheight:pageHeight,wwidth:windowWidth,wheight:windowHeight};  
};  

/**
 * 移除查询中的背影
 * 
 */
function removeLoading(){
		jQuery("#show-loading-div").hide();
}

	
/**
 * 显示查询中的背影
 * 
 */
function showHtml(html){
	     jQuery.blockUI({    //当点击事件发生时调用弹出层
	         message: jQuery('#editAddress'),
	         css: {
				top: '20%',
				left: '20%', 
				textAlign: 'left',
				width:760
	
	         } 
	      });

}

/**
 * 返回付款单页面
 * 
 */
function goBack(){
		　history.back();
}

/**
 * 保存notes
 * 
 * 结果notes数据保存到数据库中
 */
function savenote(st){
		　var notes=document.getElementById("notes").value;
		　var paymentID = st.getAttribute("oId"); 
		　var params = {"notes":notes, "paymentID":paymentID};
		　var rt= execjava("paymentBean.savePaymentNote",params, "json","paymentservice");
		　if(rt.resCode!="200"){
				alert("保存失败！");
			}else if(rt.resCode=="200"){
				alert("保存成功！");
			}
	
}

/**
 * 转换金额显示方方法
 * 
 * 结果：数字会显示成金额的表示形式
 */
function convertToMoney(number){
			number=number.toString();
			var result;
			var indexP = number.indexOf(".");
			var smallPart;
			var bigPart;
			var smallLen;
			if(indexP>-1){
				bigPart = number.substring(0,indexP);
				smallPart = number.substring(indexP,number.length);
				number = bigPart;
			}
			//小数部分补齐两位
			if(typeof smallPart == "undefined" ){
				smallPart = ".00";
			}else{
				smallLen = smallPart.length;
			for(var m=0;m<2-smallLen+1;m++){
				smallPart = smallPart+"0";
			}
			}
			//小数部分保留两位
			smallPart = smallPart.substring(0,3);
			
			number = '' + number;
			result = number;
			if (number.length > 3) {
				var mod = number.length % 3;
				result = (mod > 0 ? (number.substring(0,mod)) : '');
				var numLen = Math.floor(number.length / 3);
				for (i=0 ; i < numLen; i++) {
					if ((mod == 0) && (i == 0))
						result += number.substring(mod+ 3 * i, mod + 3 * i + 3);
					else
						result += ',' + number.substring(mod + 3 * i, mod + 3 * i + 3);
				}
			}
				result = result + smallPart;
			
			var rep = /a,/g;
			var rep1 = /a-,/g;
			var rep2 = /a/g;
			var tempresult = "a"+result;
			result = tempresult.replace(rep, "").replace(rep1, "-").replace(rep2, "");
			
			return result;
	
}

/**
 * 判断金额小数位
 * 
 * 结果：小数位不大于两位
 */
function moneyCount(value){
	var indexP = value.indexOf(".");
	if(indexP>-1){
		var reg = /\.\d{0,2}$/;
		if(reg.exec(value))return true;
		else return false;
	}
	return true;
		
}


/**
 * 跳转工银聚富
 * 
 */
function gotoGYJF(st){
	var rootpath = st.getAttribute("rootpath");
//	 window.location=rootpath+'modules/paymentservice/gotoGYJF.php';    
	window.open(rootpath+'modules/paymentservice/gotoGYJF.php');
}

/**
 * 跳转我的贷款
 * 
 */
function gotoMyFinance(st){
	var rootpath = st.getAttribute("rootpath");
//	 window.location=rootpath+'modules/paymentservice/gotoGYJF.php';    
	window.open(rootpath+'modules/paymentservice/gotoMyFinancing.php');
}


/**
 * 付款单汇总
 * 
 */
function paymentSum(){
	var status = $("#form_paymentStatusChk").val();
	var params = {
		      "paymentID":$("#form_order_no").val(),
		      "startTime":$("#form_create_start_time").val(),
		      "endTime":$("#form_create_end_time").val(),
		      "sellerID":$("#form_sellerid").val(),
		      "sellerName":$("#form_sellername").val(),
		      "status":status
		    };
	//alert("paymentId:"+params.paymentId+",startTime:"+params.startTime+",endTime:"+params.endTime+",companyId:"+params.companyId+",companyName:"+params.companyName);
	var ary = execjava('paymentBean.getPaymentListSum', params, 'json',"paymentservice");
	if(ary.resCode!=200){
		alert(order.resMsg);
		return;
	}
	//alert(ary.paymentListSum.payCount+','+ary.paymentListSum.payAmountSum);
	//document.getElementById("paymentSum").style.display='';
	 $("#paymentCountSumValue").html(ary.paymentListSum.payCount);
	 $("#paymentAmountSumValue").html(ary.paymentListSum.payAmountSum);
	showBg('paymentSum');
}

/**
 * 显示和隐藏查询条件
 */
function showSearch(){
	 $("#paymentSeach").toggleClass("display");
	 $("#iconArrow").toggleClass("icon-down");
	 $("#iconArrow").toggleClass("icon-up");
}
