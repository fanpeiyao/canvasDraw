var paymentorderLists = new Array();
var paymentcombineOrders = new Array();
var totalAmount=0;
var saleCompanyName;
var saleCompanyId;
var saleCompanyDebt;
var ThisTimeMoney="";
var orderIds;
//加载后执行查询方法
$(document).ready(function(){
	var orderID = S3Params.getData('orderIds');	
	var companyList = S3Config.getConfig('s3_company');				
	var CompMes = companyList[0];
	saleCompanyName=CompMes.salecompanyName;
	saleCompanyId=CompMes.id;
	saleCompanyDebt=CompMes.customerDebt;//存放的其实是scm_user_company_tbl中的balance字段的值
	//var fromOrder = '<?php echo $fromOrder;?>';			
	if(createNewPaymentMode=="0"||createNewPaymentMode=="1"&&isNeedDebt=="true"){
		if(saleCompanyDebt<0){
			totalAmount=totalAmount-saleCompanyDebt;
		}
	}	
	showpaymentInfo();
	hasRzDisplay('');
	showModel();  		
	if(createNewPaymentMode!="2"){
		if(orderID!=""&&orderID!=null){
			hasorderList(1); 	
		}else orderList(1); 
    } 
	if(isShowCompanyDebt=="1")$("#ye").html(saleCompanyDebt); 
	$("#amount").html(totalAmount);	
});


function hasRzDisplay(flag){		    			    	
    var showInfoHtml = "<span style='display:none'></span>";
    
    if(flag=="1"){

 	   var param = {
	     			  "customerId":S3Config.getConfig('s3_customerId'),
	     			  "customerName":S3Config.getConfig('s3_userName')
	    		    };

	       var resList = execjava('paymentBean.queryCustomerFinancingInfo', param, 'json',"paymentservice");
	        var usedAmount = resList.usedAmount;
	    	var loanTerm = resList.loanTerm;
	    	var leftAmount = resList.leftAmount;
	    	var loanRate = resList.loanRate;
	    	var totalAmount = resList.totalAmount;
	    	if(loanRate!='未知')
		    {
	    		loanRate = loanRate+'%';
			}
	       if(loanTerm!='未知')
	       {
	    	   loanTerm = loanTerm+'个月';
		   }
 	   showInfoHtml = "<span style='display:'><font class='pay-tab_money'>授信总额："+totalAmount+"</font>&nbsp&nbsp&nbsp" +
   		"<font class='pay-tab_money'>已用额度："+usedAmount+"</font>&nbsp&nbsp&nbsp" +
   		"<font class='pay-tab_money'>剩余额度："+leftAmount+"</font>&nbsp&nbsp&nbsp" +
   		"<font class='pay-tab_money'>融资利率："+loanRate+"</font>&nbsp&nbsp&nbsp" +
   		"<font class='pay-tab_money'>融资期限："+loanTerm+"</font></span>";
 	   $("#hasrzinfo").html(showInfoHtml);	
    }
    else
    {
 	   showInfoHtml = "<span style='display:none'></span>";
 	   $("#hasrzinfo").html(showInfoHtml);	
    }   	   	   
 		   		    		
 }

/** 
 * 不同模式下的前台显示(上面部分)
 * 
 * 结果：加载页面
 */
function showpaymentInfo(){  
	    
	    var orderID = S3Params.getData('orderIds');	    
	
		if(orderID==null||orderID==""){
			var params = {};
			var companyinfo = execjava('paymentBean.getCompanyInfoList', params,'json','paymentservice');
		
		}else{
			//传入订单不为空，订单付款
			var params = {"orderID":orderID};
			var companyinfo = execjava('paymentBean.getCompanyInfoList', params,'json','paymentservice');

		}
	   	   
	   var debtdisplay = "none";
	   var sellerdisplay="none";
	   var Rzdisplay="none";	   
	   
	   if(isShowCompany=="1"){
		   sellerdisplay = "";
	   }
	   if(isShowCompanyDebt=="1"){
		   debtdisplay = "";
	   }	  
	   
	   if(createNewPaymentMode!="2"&&isRz){
		   Rzdisplay="";
	   }
	   
	   var newpaymentinfo="newpaymentinfo";
	   
	   var showInfoHtml = template.render(newpaymentinfo, {
		   "companyList":companyinfo.companyInfoList,
		   "sellerdisplay":sellerdisplay,
		   "debtdisplay":debtdisplay,
		   "Rzdisplay":Rzdisplay
		     }); 

		$("#shownewpaymentInfo").html(showInfoHtml);		   		    		
}	



/**
 * 新建付款单时显示,查询符合条件的订单(中间部分)
 * 
 * 结果：显示订单列表
 */
function hasorderList(pageclickednumber){
	        var orderID = S3Params.getData('orderIds');
	        orderIds = (orderID==null?'':orderID+",");
	        //融资判断
			if(createNewPaymentMode!="2"&&isRz&&document.getElementById("form_IsRZ").checked){
				var isRZ = "true";				
			}else{
				var isRZ = "false";
			}
 
			var param = {
		 			"page":pageclickednumber,
		 			"orderNo":orderID,
				    "isFinancing":isRZ,
				    "sellerID":saleCompanyId,
				    "relateOrderMode":relateOrderMode,
				    "createNewPaymentMode": createNewPaymentMode
				    };

			var resList = execjava('paymentBean.getOrderInfoList', param, 'json',"paymentservice");
					   
			//翻页加载
			newpayorderListNextPage(pageclickednumber,resList.PAGE_TOTAL);			 				
			if(resList.orderList.length==0)
		    {
			    orderIds="";
			    orderID="";
			}			
			
			if(orderID!=""&&orderID!=null){	
				$("#cbSelected").val(orderID);							
			}			
			var BeSelected=$("#cbSelected").val();
			var newPaymentOrder = 'newPaymentOrder'+showOrderMode;
			//将获取的订单进行显示
			var orderListHtml = template.render(newPaymentOrder, {
				combineList: resList.orderList,
				orderDisplayII:	orderDisplayII,
				totalAmount:Number(totalAmount).toFixed(2),
				BeSelected:BeSelected		
			}); 	
			$("#newpaymentorder_table").html(orderListHtml);
			
			for( var j=0;j<resList.orderList.length;j++){
				for(var key in resList.orderList[j]){
					if(paymentcombineOrders[key]==null||paymentcombineOrders[key]==""){
						paymentcombineOrders[key]=resList.orderList[j][key];
					}					
				}
			}
					
			//订单跳转付款单时，获取选中订单的总金额，将选中订单加入选中列表中
			if(orderID!=""&&orderID!=null){	
				$("#cb"+orderID).attr('checked',true);
				for(var a=0;a<resList.orderList.length;a++){					
					for(var orderkey in resList.orderList[a]){
						if(resList.orderList[a][orderkey].orderId==orderID){
							if(paymentorderLists[orderkey]==null||paymentorderLists[orderkey]==""){
								paymentorderLists[orderkey]=resList.orderList[a][orderkey];
							}							
							totalAmount=parseFloat(totalAmount)+parseFloat(resList.orderList[a][orderkey].orderAmount.toString().replace(/,/g,""));
							totalAmount=totalAmount.toFixed(2)
						}else{
							totalAmount=parseFloat(totalAmount);
						}

					}
				}				
			}
			if(createNewPaymentModel!="2"&&isSupportRZ=="1"&&document.getElementById("form_IsRZ").checked){
				$("#amountRz").html(parseFloat(totalAmount));
			}else{
				$("#amount").html(parseFloat(totalAmount));
			} 

}

/**
 * 新建付款单时显示,查询符合条件的订单(中间部分)
 * 
 * 结果：显示订单列表
 */
function orderList(pageclickednumber){
	        var orderID = S3Params.getData('orderIds');
	        orderIds = (orderID==null?'':orderID+",");
	        //融资判断
			if(createNewPaymentMode!="2"&&isRz&&document.getElementById("form_IsRZ").checked){
				var isRZ = "true";				
			}else{
				var isRZ = "false";
			}
 
			var param = {
		 			"page":pageclickednumber,
		 			"orderNo":orderID,
				    "isFinancing":isRZ,
				    "sellerID":saleCompanyId,
				    "relateOrderMode":relateOrderMode,
				    "createNewPaymentMode": createNewPaymentMode
				    };

			var resList = execjava('paymentBean.getOrderInfoList', param, 'json',"paymentservice");
					   
			//翻页加载
			newpayorderListNextPage(pageclickednumber,resList.PAGE_TOTAL);			 				
			if(resList.orderList.length==0)
		    {
			    orderIds="";						  				   
			}	
				
			var BeSelected=$("#cbSelected").val();
			var newPaymentOrder = 'newPaymentOrder'+showOrderMode;
			//将获取的订单进行显示
			var orderListHtml = template.render(newPaymentOrder, {
				combineList: resList.orderList,
				orderDisplayII:	orderDisplayII,
				totalAmount:Number(totalAmount).toFixed(2),
				BeSelected:BeSelected		
			}); 
			for( var j=0;j<resList.orderList.length;j++){
				for(var key in resList.orderList[j]){
					if(paymentcombineOrders[key]==null||paymentcombineOrders[key]==""){
						paymentcombineOrders[key]=resList.orderList[j][key];
					}					
				}
			}
		
			$("#newpaymentorder_table").html(orderListHtml);
			if(createNewPaymentMode!="2"&&isRz&&document.getElementById("form_IsRZ").checked){
				$("#amountRz").html(parseFloat(totalAmount));
			}else{
				$("#amount").html(parseFloat(totalAmount));
			} 

}

/** 
 * 不同模式下的前台显示(下面部分)
 * 
 * 结果：加载页面
 */
function showModel(){  
	 var showModelII ={
			0: "zero",
			1: "one",
			2: "two",
			3: "three",
			4: "four"
		};
	   var params = {};
	   var noticedisplay = "none";
	   if(isNeedDebt=="1"){//是否提示--提示：本次付款金额必需大于欠款金额,当必须支付欠款的时候显示
		   noticedisplay = "";
	   }
	   var thistimedisplay = "";//是否显示最小付款金额(当为混合关联订单且传入的订单ID不为空时,不显示)
	   if(createNewPaymentMode=="3"&&(orderID==null||orderID=="")){
		   thistimedisplay = "none";
	   }
	   var inputdisplay = "";
	   if(payMode=="1"&&createNewPaymentMode!="3"){//等额付款并且不是混合关联订单的时候，不显示输入金额
		   inputdisplay = "none";
	   }
	   
	   if(createNewPaymentMode=="2"){
		   var showmodel="showmodel";
	   }else{
		   var showmodel="showmodelorder"+showModelII[payMode];
	   }
	   
	   
	   var showModelHtml = template.render(showmodel, {
		   "noticedisplay":noticedisplay,
		   "thistimedisplay":thistimedisplay,
		   "inputdisplay":inputdisplay
		     }); 

	   $("#showmoney_table").html(showModelHtml);		   		    		
}	




/**
 * 新建付款单时显示,点击下一步的操作
 * 
 * 结果：判断金额、备注情况并触发弹窗
 */
function paymentconfirm(){
			var notes=document.getElementById("notes").value;
			//notes = htmlEncode(notes);
			//获取id为cbSelected的参数，该参数为advance_form中的隐藏参数。
			//orderIds=document.getElementById("cbSelected").value;				
            //alert(orderIds);
			//if(createNewPaymentModel!="2"){//获取订单表中被选中的id，并且翻页记录
			//	var obj=document.getElementsByName("cb");			
			//	PassCheckBox(obj);
			//}			
			//$("#cbSelected").val(orderIds);	
			$("#customerDebt").html(saleCompanyDebt);
			var BeSelected=$("#cbSelected").val();			    	
			var BeSelectedList=BeSelected.split(",");
			if(relateOrderMode=="1"){
				if(BeSelectedList.length>2){
					alert("只能关联一笔订单！");
					return;
				}					
			}
			if(createNewPaymentMode!="2"&&isRz&&document.getElementById("form_IsRZ").checked){//判断是否融资																
						if(BeSelectedList==""||BeSelectedList==null){
							alert("请选择贷款订单！");							
							return;
						}else{
							ThisTimeMoney=totalAmount;
							showBg("paymentConfirm");
						}
			}else{

				if(payMode=="1"){//如果付款金额必须等于选中订单金额时，支付金额签字等于订单中金额
		    		if(createNewPaymentMode=="3"&&(BeSelectedList==""||BeSelectedList==null)){
		    			ThisTimeMoney=document.getElementById("ThisTimeMoney").value;
		    		}else ThisTimeMoney=totalAmount;
		    	}else{
		    		ThisTimeMoney=document.getElementById("ThisTimeMoney").value;
		    	}

				if(createNewPaymentMode=="0"){//强关联时必须关联订单					
					if(BeSelectedList==null||BeSelectedList==""){
						alert("请关联订单!");						
						return;
					}else if(payMode=="0"){
						if(Number(ThisTimeMoney-totalAmount).toFixed(2)<0){
							alert("付款金额不能小于最小付款单金额！");
							$("#ThisTimeMoney").focus();						
							return;
						}
					}
					
				}else if(ThisTimeMoney==""){
					alert("请输入本次付款金额！");
					$("#ThisTimeMoney").focus();					
					return;
				}else if(ThisTimeMoney<=0){
					alert("付款金额请大于0元！");
					$("#ThisTimeMoney").val("");
					$("#ThisTimeMoney").focus();					
					return;
				}else if(!moneyCount(ThisTimeMoney)){
					alert("付款金额小数位不要多于两位小数！");
					$("#ThisTimeMoney").focus();
					return;					
				}else if(notes.length>50){
					alert("备注字数大于50字，请删减！");					
					return;
				}else if(payMode=="0"&&createNewPaymentMode=="3"&&(BeSelectedList!=""&&BeSelectedList!=null)){
					if(Number(ThisTimeMoney-totalAmount).toFixed(2)<0){
						alert("付款金额不能小于最小付款单金额！");
						$("#ThisTimeMoney").focus();						
						return;
					}
				}
					showBg("paymentConfirm");
				
		    }
			
			if(createNewPaymentMode!="2"&&isRz&&document.getElementById("form_IsRZ").checked){
						document.getElementById("ThisTimeMoney1Span").innerHTML="贷款金额：";		
						//$("#ThisTimeMoney1").html(convertToMoney(parseFloat(ThisTimeMoney)));
						$("#ThisTimeMoney1").html(ThisTimeMoney);
						
			}else{
						
						document.getElementById("ThisTimeMoney1Span").innerHTML="本次付款金额：";								
					    //$("#ThisTimeMoney1").html(convertToMoney(parseFloat(ThisTimeMoney)));
						$("#ThisTimeMoney1").html(ThisTimeMoney);
			}

			if(notes == "备注请勿超过50字" ){
					 $("#notes1").html("");
			}else{
					 if ($.browser.msie) {
						 notes=notes.replace(/\n/g,"<br/>");
					 }	
					 $("#notes1").html(notes);
			}
			
			//确认弹出框中显示新将付款单时选中订单
			if(createNewPaymentMode!="2")createOrderTabel();
			//余额是否显示
			if(isShowCompanyDebt=="0"){
				document.getElementById("paymentconfirmdebt").style.display="none";
			}
			//是否显示最小付款金额
			if(createNewPaymentMode!="2"&&payMode!="1"&&!document.getElementById("form_IsRZ").checked){
				if(createNewPaymentMode=="3"&&(BeSelectedList==""||BeSelectedList==null)){
					document.getElementById("paymentconfirmshow").style.display="none";
				}else{
					$("#ThisTimeShow1Span").html($("#ThisTimeSpanShow").html());
					//$("#amount1span").html(convertToMoney(parseFloat(totalAmount)));
					$("#amount1span").html(totalAmount);
					document.getElementById("paymentconfirmshow").style.display="";
				}				
			}else{
				document.getElementById("paymentconfirmshow").style.display="none";
			}
}

/**
 * 翻页保存复选框
 * 
 * 结果：翻页被选上的复选框仍然被选中
 */
function PassCheckBox(obj){	       
			for(var i=0;i<obj.length;i++){
			// 勾选复选框后，判断前页面传递的串中是否已经包含了该复选框，如果包含不做处理，不包含则加到新串中取
			if(obj[i].checked){
				if(orderIds.indexOf(obj[i].value)!=-1){
					
				}else{
					orderIds+=obj[i].value+",";
				}
				//alert(orderIds);
			}
			// 如果没有勾选复选框，看前页面传递的串中是否包含该复选框，如果包含，则将该字段从原来串中去掉
			else{
				if(orderIds.indexOf(obj[i].value)!=-1){					
					orderIds=orderIds.replace(obj[i].value+",","");
				}
			}
		}
}


/**
* 生成付款单
*  
* 结果:生成付款单
* 
*/
function setPaymentOrder(){
    	
    	var paymoney=document.getElementById("ThisTimeMoney1").innerHTML.replace(/,/g,"");
    	paymoney= Number(paymoney).toFixed(2);
    	var notes=document.getElementById("notes1").innerHTML;
    	//notes=notes.replace(/<BR>/g,"<br/>")
    	if(createNewPaymentMode!="2"){
    		if(document.getElementById("form_IsRZ").value=="0"){
    			var isRZ="false";
    		}else var isRZ="true";
    	}else{
    		var isRZ="false";
    	}
    	   		
    	var BeSelected=$("#cbSelected").val();
    	
		var BeSelectedList=BeSelected.split(",");
		var hasOrder="";
		if(BeSelected!=""&&BeSelected!=null){
			hasOrder = "true";
		}else{
			hasOrder = "false";
		}
    	//var newOrderNo="";
    	var params = {//orderAmount订单金额，paymentAmount付款金额
	 			"sellerID":saleCompanyId,
	 			"paymentAmount":paymoney,
	 			"orderAmount":totalAmount,
			    "isFinancing":isRZ,
			    "notes":notes,
			    "orderIdList":BeSelected,
    			"hasOrder":hasOrder,
    			"createNewPaymentMode":createNewPaymentMode,
    			"payMode":payMode,
    			"relateOrderMode":relateOrderMode,
    			"isNeedDebt":isNeedDebt
			    };
    	var newpaymentmsg = execjava("paymentBean.createNewPayment", params, 'json',"paymentservice");
		if(newpaymentmsg.resCode=="200"){	
			window.location=S3Config.getConfig('s3_root')+"~main/share/frame.php?target=paymentSuccess&&paymentId="+newpaymentmsg.newPaymentID;								
		}else{
			alert(newpaymentmsg.resMsg);
			return;
		}
}


/**
* 勾选融资按钮，触发
*  
* 结果:筛选符合融资条件订单
* 
*/
function rzSelected(obj){
	
	   //cleanPass();
	   
	   if(obj.checked){
 		 obj.value="1";
 		 document.getElementById("ThisTimeMoneyShow").style.display="none";
 		 document.getElementById("ThisTimeMoneyRz").style.display="";
 		 $("#amountRz").html(convertToMoney(parseFloat(totalAmount)));
 		 hasRzDisplay('1');
	   }else{
		 obj.value="0";
 		 document.getElementById("ThisTimeMoneyShow").style.display="";
 		 document.getElementById("ThisTimeMoneyRz").style.display="none";
 		 $("#amount").html(convertToMoney(parseFloat(totalAmount)));
 		 hasRzDisplay('0');
 	   }
		//根据上送的融资标志查询列表
	    orderList(1);
	
}

	

/**
* 按照公司筛选订单,按照公司查询合并订单列表
*  
* 结果:显示选中公司的详情
* 
*/		
function selectByCompany(obj){

			cleanPass();
			var companyList = S3Config.getConfig('s3_company');
			totalAmount=parseFloat(totalAmount);
			for(var i=0;i<companyList.length;i++){
				if(companyList[i]["id"]==obj.value){
					saleCompanyDebt = parseFloat(companyList[i]["customerDebt"]);
					saleCompanyName=companyList[i]["salecompanyName"];
					saleCompanyId=companyList[i]["id"];					
					break;
				}
			}
			if(createNewPaymentMode=="0"||createNewPaymentMode=="1"&&isNeedDebt=="1"){
				if(customerDebt<0){
					totalAmount=totalAmount-customerDebt;
					totalAmount = totalAmount.toFixed(2);
				}
			}
			$("#amount").html(totalAmount);
			$("#seller_id").val(saleCompanyId);			 	
		 	$("#ye").html(saleCompanyDebt);
		 	$("#customerDebt").html(saleCompanyDebt);		 	
			// 显示订单
		 	if(createNewPaymentMode!="2")orderList(1);
	
}

/**
* 按照新建付款单订单列表中选中订单的动作。
*  
* 结果：选中订单的金额相加；选中订单的订单号记录；如果是混合关联订单模式，判断是否关联订单。
* 
*/	
function AfterBeSelected(orderAmount,obj){
			
			totalAmount = parseFloat(totalAmount);
			orderAmount = parseFloat(orderAmount.replace(/,/g, ""));
			if (obj.checked) {//选中情况
				totalAmount = orderAmount + totalAmount;
				totalAmount = totalAmount.toFixed(2);
				orderIds = orderIds + obj.value + ",";
				paymentorderLists[obj.value]=paymentcombineOrders[obj.value];//列表中增加选中订单详情
			} else {
				totalAmount = totalAmount - orderAmount;
				totalAmount = totalAmount.toFixed(2);
				orderIds = orderIds.replace(obj.value + ",", "");
				delete paymentorderLists[obj.value];//列表中删除订单详情				
			}
		    
			if(createNewPaymentMode!="2"&&isRz&&document.getElementById("form_IsRZ").checked){
				$("#amountRz").html(totalAmount);
			}else{
				$("#amount").html(totalAmount);	
			}
			    
			if(createNewPaymentMode=="3"){//混合关联订单方式时，判断是否关联上了订单。
				if(orderIds==null||orderIds==""){
					document.getElementById("ThisTimeMoneyInput").style.display="";
			 		document.getElementById("ThisTimeShow").style.display="none";
				}else{
					
			 		document.getElementById("ThisTimeShow").style.display="";
			 		if(payMode=="1"){
			 			document.getElementById("ThisTimeMoneyInput").style.display="none";
			 		}
				}				
			}
			
			$("#cbSelected").val(orderIds);

}

/**
* 新建付款单时，翻页方法，参数为当前页，总页数，状态
*  
* 结果：显示页码并翻页
* 
*/	
function newpayorderListNextPage(pageNum,PAGE_TOTAL){
		    var pageTotal=parseInt(PAGE_TOTAL);
		    //$("#combinePage").val(pageNum);
	        $("#pager").pager({ 
	        pagecount: pageTotal, 
	        pagenumber: pageNum, 
	        buttonClickCallback: function(pageclickednumber){orderList(pageclickednumber);} 
	   });			         			              			         
}


/**
* 有页面刷新时，清除记录
*  
* 结果：订单金额变0；订单页数显示第一页
* */
function cleanPass(){
	var companyList = S3Config.getConfig('s3_company');
	totalAmount=0;			
	ThisTimeMoney="";
	var CompMes = companyList[0];
	saleCompanyName=CompMes.salecompanyName;
	saleCompanyId=CompMes.id;
	saleCompanyDebt=CompMes.customerDebt;
	//var fromOrder = '<?php echo $fromOrder;?>';			
	if(createNewPaymentMode=="0"||createNewPaymentMode=="1"&&isNeedDebt=="true"){
		if(saleCompanyDebt<0){
			totalAmount=totalAmount-saleCompanyDebt;
		}
	}
	document.getElementById("ThisTimeMoney").value = "";
	document.getElementById("cbSelected").value = "";
	orderIds = "";
	paymentorderLists={};
	paymentcombineOrders={};
	return;
}

/**
* 在确认付款弹出框中显示选中订单列表
* @author zjfh-raojc
* @returns 显示选中订单
* 
*/
function createOrderTabel(){	
			if(showOrderMode=="default"){
				var confirmtable="<table class='pay-table' width='100%'>"+
				                 "<thead >" +
				                 "<tr class='pay-table_th'>" +
				                    "<th>订单编号</th>" +
				                    "<th>订单金额</th>" +
				                    "<th width='24%'>下单时间</th>" +
				                    "<th width='16%'>订单状态</th>" +
				                 "</tr>" +
				                 "</thead>" +
				                 "<tbody>";		
				var ordersize = 0;
				var keyCount=0;
				var css1='';
				for(var key in paymentorderLists){// 取出订单的键值，即订单号	
					    keyCount++;
						var order = paymentorderLists[key];		
						if(keyCount%2==0){
							confirmtable+="<tr class='pay-table_bgtr'>"+
						          "<td >"+order.orderNo+"</td>"+
				                  "<td class='pay-tab_money'>￥"+order.orderAmount+"</td>"+
				                  "<td >"+order.orderCreateTime+"</td>"+
				                  "<td class='pay-tab_status'>"+orderDisplayII[order.orderStatus]+"</td>" +
				              "</tr>";
						}
						else
						{
							confirmtable+="<tr>"+
						          "<td >"+order.orderNo+"</td>"+
				                  "<td class='pay-tab_money'>￥"+order.orderAmount+"</td>"+
				                  "<td >"+order.orderCreateTime+"</td>"+
				                  "<td class='pay-tab_status'>"+orderDisplayII[order.orderStatus]+"</td>" +
				              "</tr>";
						}						
						ordersize = ordersize + 1;
				}																										
				if(ordersize==0){
						confirmtable+="<tr><td colspan='4' class='pay-no_order'>此次支付为无关联订单</td></tr>";
				}				
				confirmtable+="</tbody></table>";
				$("#selectedtable").html(confirmtable);	
			}					 	
}
var oldValue = "";
function testCount(obj){
	var v = obj.value;
	if(!/^\d+\.?\d{0,2}$/.test(v)){
		if(v=="" || v== undefined){
			oldValue="";
			return;
		}
		alert("请输入正数，且最多只能输入两位小数！");
		$(obj).val(oldValue);
	}
//	oldValue = 	parseFloat(v).toFixed("2");
	oldValue = 	obj.value;
}