//方法内部记录当前页面变量
var inSidePage;
//加载后执行查询方法
	 $(document).ready(function(){	 	
	 	showpaymentSearch();
	 	paymentList(1);   
	   });

/** 
 * 我的付款单页面搜索条件控制，与tpl中的showpaymentSearch.php配合使用
 * 
 * 结果：加载页面
 */
function showpaymentSearch(){  
	   var params = {};
	   var paymentsearch="paymentsearch"+paymentSearchMode;
	   var showpaymentSearchHtml = template.render(paymentsearch, {		   
		     });  	   		    
		$("#mypaymentSearch").html(showpaymentSearchHtml);		   		    		
}


/** 
 * 查询付款单列表
 * 参数pageclickednumber：选择页码
 * 参数status：付款单状态
 * 
 * 结果：加载页面
 */
function paymentList(pageclickednumber,status){  
		inSidePage = pageclickednumber;
	   var params = {
		      "page":pageclickednumber,
		      "status":status,
		      "paymentID":$("#form_order_no").val(),
		      "startTime":$("#form_create_start_time").val(),
		      "endTime":$("#form_create_end_time").val(),
		      "sellerID":$("#form_sellerid").val(),
		      "sellerName":$("#form_sellername").val(),
		      "limit":'10'
		      
	   };
	   var ary = execjava('paymentBean.getPaymentList', params, 'json',"paymentservice");
	   var paymentList = ary.paymentList;
	   if(!paymentList){
		   paymentList=[];
	   }
	   //金额格式化
	   for(var i = 0;i<paymentList.length;i++){
		   paymentList[i].payAmount =addCommafy(paymentList[i].payAmount);
		   paymentList[i].rsv1 =addCommafy(paymentList[i].rsv1==null?0:paymentList[i].rsv1);
	   }
	   // 翻页
	   NextPage(pageclickednumber,ary.PAGE_TOTAL,status);
	   var paymentListMode = 'paymentList';
	   /*var paymentListHtml = template.render(paymentListMode, {
		   	 paymentList: paymentList,
			 paymentDisplayII: paymentDisplayII,
			 orderDisplayII: orderDisplayII,
			 paymentMethodII: paymentMethodII,
			 paymentStatus:status
	   });
	   		    
	   $("#mypayment_table").html(paymentListHtml);*/
	   var index;
	   for(var i = 0;i<colArray.length;i++){
			if(colArray[i][1] == "status"){
				index = i;
			}
		}
		var tableConfig = {  		
				paging:false,//分页
		  		processing:true,//处理数据显示
		  		searching:false,//搜索框
		   	    ordering:true,//排序
		  		autoWidth:true,//宽度自适应
		  		info:false,//是否显示页脚
		  		scrollX:true,
		  		order:[],
		  		columnDefs:[{orderable:false,targets:[index]}]
		  	};
		var selectHtml='<select name="form_paymentStatusChk" onchange="SearchByStatus(this);"  id="form_paymentStatusChk">'
			+'<option value="">全部状态</option>';
			for(var j in paymentDisplayII){
				selectHtml += '<option value='+j+'>'+paymentDisplayII[j]+'</option>';
			}
		selectHtml += '</select>';
		myPayment_col.status.title = selectHtml;
		var oTable = $("#mypayment_table").renderDatatables(colArray,myPayment_col,ary.paymentList,tableConfig);
}	



/**
 * 按照付款单状态查找付款单,参数为下拉框元素
 * 
 */
function SearchByStatus(obj){
     $("#form_paymentStatusChk").val(obj.value);
     paymentList(1,obj.value);
}

/**
 * 按照付款单编号和生成日期查询
 * 
 */
function SearchByKey(s){
	 var start=document.getElementById("form_create_start_time").value;
	 var end=document.getElementById("form_create_end_time").value;
	 start=start.substring(0,4)+start.substring(5,7)+start.substring(8,10);
	 end=end.substring(0,4)+end.substring(5,7)+end.substring(8,10);
	 if(start!="" && end!=""){
	 	if(start>end){
			alert("开始时间大于结束时间！");
			return;
	 		}
	 }
	 paymentList(1);
}

/**
 * 清楚查询内容
 * 
 */
function clean(){
	//　advance_form.reset();
	var inputs=$("input[type=text]");
    for(var m=0;m<inputs.length;m++){
    	$(inputs[m]).val("");
    }
	 paymentList(1);
}

/**
 * 付款单显示页面，付款单关联订单时点击加号触发方法，显示关联订单
 * @author zjfh-raojc
 * @returns 点击加号显示付款单关联订单
 */
function jiahaoshow(num){

	document.getElementById("jiahao"+num).style.display='none';
	document.getElementById("jianhao"+num).style.display='';
	document.getElementById("mainOrder"+num).style.background='#f9fbe1';
	if($("#showrelatedorder"+num).html()==""||$("#showrelatedorder"+num).html()==null){
		createRelatedOrderTabel(num);
	}else{
		document.getElementById("ordertable"+num).style.display='';
		document.getElementById("ordertable"+num).style.background='#f8f4ec';
	}
		
	$("#bottom").css("display","none");
	$("#bottom").css("display","block");

}

/**
 * 付款单显示页面，付款单关联订单时点击减号触发方法，隐藏关联订单
 * @author zjfh-raojc
 * @returns 点击减号缩掉付款单关联订单
 */
function jianhaoshow(num,columnNum){
	document.getElementById("ordertable"+num).style.display='none';
	document.getElementById("jiahao"+num).style.display='';
	document.getElementById("jianhao"+num).style.display='none';
	if(columnNum%2==0)
	{
		document.getElementById("mainOrder"+num).style.background='#fff';
		document.getElementById("ordertable"+num).style.background='#fff';
	}
	else
	{
		document.getElementById("mainOrder"+num).style.background='#f9f9f9';
		document.getElementById("ordertable"+num).style.background='#f9f9f9';
	}
	
	$("#bottom").css("display","none");
	$("#bottom").css("display","block");

}


/**
 * 跳转新建付款单
 * 传入路径信息
 * 
 * 结果：跳转新建付款单页面
 */
function newpayment(st){
	  var orderIds = st.getAttribute("orderIds");
	  if(orderIds==null||orderIds=='')
      {
		  window.location=getRealPath()+'~main/share/frame.php?target=newPayment&&orderIds=';  
	  }
	  else
	  {
		  window.location=getRealPath()+'~main/share/frame.php?target=newPayment&&orderIds='+orderIds;
	  }
	   
}

/**
 * 跳转付款单详情
 * 传入路径信息
 * 
 * 结果：跳转付款单详情页面
 */
function paymentDetail(st){
	  var paymentId = st.getAttribute('paymentId');	  
	  window.location=getRealPath()+'~main/share/frame.php?target=paymentDetail&&paymentId='+paymentId+'&&customerId=&&customerName=';  	    
}

/**
 * 翻页方法，参数为当前页，总页数，状态
 * 
 */
function NextPage(pageNum,PAGE_TOTAL,status){
	  PAGE_TOTAL=parseInt(PAGE_TOTAL);
	  //$("#combinePage").val(pageNum);
	  $("#pager").pager({ 
	  pagecount: PAGE_TOTAL, 
	  pagenumber: pageNum, 
      buttonClickCallback: function(pageclickednumber){paymentList(pageclickednumber,status);} 
 });
}



/**
 * 付款单delete
 * 
 * 结果显示删除后付款单情况
 * 
 */
function deletePayment(st){
	    var paymentID = st.getAttribute("oId");
	    var cf = window.confirm("是否清除付款单？请确认");
	    if(cf){
	    	var parmStr = {"paymentID":paymentID};
	    	showLoading();
	    	var CancelPaymentOrder = execjava('paymentBean.deletePayment',parmStr,'json',"paymentservice");
	    	 if(CancelPaymentOrder.resCode!="200"){
	    		 var failedMes=CancelPaymentOrder.resMsg;
	    		 alert(failedMes);
	    	 }
	    	 else{
	    		 alert('付款单'+paymentID+'删除成功！');
	    	 }
	    	removeLoading();
	    	paymentList(1);
	    }

}

/**
 * 付款单跳转支付平台动作
 * 
 * 结果跳转支付平台
 */
function gotoPay(st){
		var status = st.getAttribute("orderStatus");
	    var paymentId = st.getAttribute("oId"); 
	    var parmStr = {"paymentID":paymentId};
	    if(status == 0){//待付款或贷款失败重新支付
	     var ret = execjava("paymentBean.updatePaymentTime",parmStr,"json","paymentservice");
	    // window.location=rootpath+'modules/paymentservice/gotopay.php?paymentId='+paymentId;
	     window.open(S3Config.getConfig('s3_root')+'modules/paymentservice/gotopay.php?paymentId='+paymentId);     
	    }
	    /*else if(status == 1){
	   	 window.open(getPortalPath()+'html/qnfMatch.php?oId='+oId);
	    }*/
}

/**
 * 通过后台调用付款单易付支付接口
 * isSuccessPay 新建付款单成功界面支付为1
 */
function doEasyPay(paymentId,isSuccessPay){
	var params = {
			"paymentID":paymentId	
		}
	var ary = execjava('paymentBean.getPaymentDetail', params, 'json',"paymentservice");
	if(ary == false || ary == undefined){
		alert("没有获取到对应付款单信息！");
	}
	if (confirm("您本次将提交扣款指令，请回复手机短信确认扣款。本次扣款金额"+ary.paymentDetail.amount+"元，扣款编号"+ary.paymentDetail.id+"，请在收到短信内容后确认!")){
	var paymentDetail = ary.paymentDetail;
	var payParams = {
		"transNo":paymentDetail.paymentOrderNo,
		"sellerId":paymentDetail.sellerId,
		"sellerName":paymentDetail.sellerName,
		"customerId":paymentDetail.customerId,
		"customerName":paymentDetail.userName,
		"orderAmount":paymentDetail.amount
	}
	var ret = execjava("localEasyPayBean.doPaymentEasyPay",payParams,'json');
	 if(ret != undefined && ret != false){
		 if(isSuccessPay == "1"){
			 alert("扣款指令已提交，请在我的付款单页面查看！");
			window.location=S3Config.getConfig('s3_root')+'~main/share/frame.php?target=myPayment';  	    
			return;
		 }
//		var successList = ret.successList;
//		var failedList = ret.failedList;
//		var totalAmount = 0;
//		if(successList != null || successList!= undefined){
//			 for(var i=0; i<successList.length;i++) {
//				 totalAmount = accAdd(parseFloat(successList[i].orderAmount),parseFloat(totalAmount));
//			 }
//		}
//			var easyPayResultHtml = template.render('payResult', {
//				successList : successList,
//				isSuccessPay : isSuccessPay,
//				totalAmount : totalAmount
//			}); 
//			var faildListHtml = template.render('payFaildDetail', {
//				failedList : failedList
//			}); 
//		$("#easyPayResult").html(easyPayResultHtml);
//		$("#payFaildList").html(faildListHtml);
		
		
		
		var successList = ret.successList;
		var failedList = ret.failedList;
		var totalAmount = 0;
		var dataList = new Array();
		var succCount = 0;
		if(successList != undefined && successList.length > 0){
			 for(var i=0; i<successList.length;i++) {
				 totalAmount = accAdd(parseFloat(successList[i].orderAmount),parseFloat(totalAmount));
				 successList[i].isSucc = "1";
				 succCount = dataList.push(successList[i]);
			 }
			
		}
		if(failedList != undefined && failedList.length > 0){
			for(var i=0; i<failedList.length;i++) {
				dataList.push(failedList[i]);
			}
		}

		setCommitDetail(1,dataList,succCount,totalAmount);
		
		
		showBg('easyPayResult');
	}else{
		alert("调用出错了！");
		location.reload();
	}
	}
}

/**
 * 提交结果渲染
 */
function setCommitDetail(pageNum,dataList,succCount,totalAmount){
	var count = 5;//每页5条
	var start = parseInt(parseInt(pageNum)-1)*parseInt(count);
	var num = dataList.length;// 总记录数
	var pageTotal = parseInt((parseInt(num) + parseInt(count - 1)) / count);// 总页数
	var newDataList = new Array();
	var k =0;
	for(var i=start ; i < start+count; i++){
		if(i<=dataList.length-1){
			newDataList[k] = dataList[i];
		}
		k++;
	}
	var easyPayResultHtml1 = template.render('commitResult', {
		//successList : successList,
		//succCount : succCount,
		dataList : newDataList
		//totalAmount : totalAmount
	}); 
	$("#easyPayResult").html(easyPayResultHtml1);
//
//	// 分页
//	$("#easyPager").pager({
//		pagecount : pageTotal,
//		pagenumber : pageNum,
//		buttonClickCallback : function(pageclickednumber) {
//			setCommitDetail(pageclickednumber, dataList,succCount,totalAmount);
//		}
//	});
}



function doSucceEasyPay(paymentId){
		doEasyPay(paymentId,'1');
	
}

function closeWin(isSuccessPay){
	closeBg('easyPayResult');
//	if(isSuccessPay == '1'){
//		window.location=S3Config.getConfig('s3_root')+'~main/share/frame.php?target=myPayment';  	    
//	}else{
		paymentList(inSidePage);
//	}
}

/**
* 我的付款单关联订单显示
* @author zjfh-raojc 
* @returns 付款单关联订单table
* 
*/
function createRelatedOrderTabel(num){							
		 	      //查找该笔付款单关联订单信息。
				var parmStr = {
					      "paymentID":num,
					      "customerID":null
					    };
				var ary = execjava('paymentBean.getRelatedOrderList', parmStr, 'json',"paymentservice");
				if(ary.resCode!=200){
					alert(order.resMsg);
					return;
				}
				//金额格式化
				var orderList = ary.orderList || [];
			 	for(var i = 0;i<orderList.length;i++){
			 		orderList[i].orderAmount ="￥"+addCommafy(orderList[i].orderAmount);
			 	}
				var relateOrderTableHtml = template.render('relatedOrder_tpl', {
				   	 relatedOrderList: orderList,
				   	 paymentID:num,
				   	 orderDisplayII: orderDisplayII
				     }); 
				$("#showrelatedorder"+num).html(relateOrderTableHtml);			
				document.getElementById("ordertable"+num).style.background='#f8f4ec';								

}



/**
 * 付款单汇总
 * 
 */
function paymentSum(){
	var status = $("#form_paymentStatusChk").val();
	var params = {
		      "paymentID":$("#form_order_no").val(),
		      "startTime":$("#form_create_start_time").val(),
		      "endTime":$("#form_create_end_time").val(),
		      "sellerID":$("#form_sellerid").val(),
		      "sellerName":$("#form_sellername").val(),
		      "status":status
		    };
	//alert("paymentId:"+params.paymentId+",startTime:"+params.startTime+",endTime:"+params.endTime+",companyId:"+params.companyId+",companyName:"+params.companyName);
	var ary = execjava('paymentBean.getPaymentListSum', params, 'json',"paymentservice");
	if(ary.resCode!=200){
		alert(order.resMsg);
		return;
	}
	//alert(ary.paymentListSum.payCount+','+ary.paymentListSum.payAmountSum);
	//document.getElementById("paymentSum").style.display='';
	 $("#paymentCountSumValue").html(ary.paymentListSum.payCount);
	 if(ary.paymentListSum.payCount == 0){
		 $("#paymentAmountSumValue").html(0);
	 }else{
		 $("#paymentAmountSumValue").html("￥"+ ary.paymentListSum.payAmountSum);
	 }
	showBg('paymentSum');
}


/**
 * 跳转我的贷款
 * 
 */
function gotoMyFinance(st){
	window.open(S3Config.getConfig('s3_root')+'modules/paymentservice/gotoMyFinancing.php');
}