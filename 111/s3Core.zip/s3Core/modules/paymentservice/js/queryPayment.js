$(document).ready(function(){//加载搜索模块与显示模块，但是页面加载时不显示付款单信息
			querypaymentSearch();
			queryPayments(1);                                                                                                                                                                                                                                                                     
		});

/** 
 * 查询付款单时，不同模式下的前台显示不同的搜索方式
 * 
 * 结果：加载页面
 */
function querypaymentSearch(){  
	   var params = {};
	   var querypaymentsearch="querypaymentsearch"+paymentSearchMode;
	   var querypaymentSearchHtml = template.render(querypaymentsearch, {		   
		     });  	   		    
		$("#querypaymentSearch").html(querypaymentSearchHtml);		   		    		
}	

function judgeTime(){
	var start=$("#startTime").val();
	var end=$("#endTime").val();
	if($("#endTime").val()!=""){
		if(start>end){
			alert("起始时间大于结束时间");
			$("#endTime").val("");
		}
	}
};

function judgeAmount(){
	var start=parseFloat($("#startPayAmount").val());
	var end=parseFloat($("#endPayAmount").val());
	if($("#endPayAmount").val()!=""&&$("#startPayAmount").val()!=""){
		if(start>end){
			alert("请输入正确的金额范围！");
			$("#endPayAmount").val("");
			$("#startPayAmount").val("");
			return false;
		}		
	}
	return true;
	
};

/**
 * 付款单显示页面，付款单关联订单时点击加号触发方法，显示关联订单
 * 
 */
function jiaordershow(num,customerId){

	document.getElementById("jia"+num).style.display='none';
	document.getElementById("jian"+num).style.display='';
	document.getElementById("mainOrder"+num).style.background='#E9F6F8';
	if($("#showrelatedorder"+num).html()==""||$("#showrelatedorder"+num).html()==null){
		showRelatedOrderTabel(num,customerId);
	}else{
		document.getElementById("ordertable"+num).style.display='';
		document.getElementById("ordertable"+num).style.background='#f8f4ec';
	}
		
	$("#bottom").css("display","none");
	$("#bottom").css("display","block");

}

/**
 * 付款单显示页面，付款单关联订单时点击减号触发方法，隐藏关联订单
 * 
 */
function jianordernone(num,columnNum){
	document.getElementById("ordertable"+num).style.display='none';
	document.getElementById("jia"+num).style.display='';
	document.getElementById("jian"+num).style.display='none';
	if(columnNum%2==0)
	{
		document.getElementById("mainOrder"+num).style.background='#fff';
		document.getElementById("ordertable"+num).style.background='#fff';
	}
	else
	{
		document.getElementById("mainOrder"+num).style.background='#f9f9f9';
		document.getElementById("ordertable"+num).style.background='#f9f9f9';
	}
	
	$("#bottom").css("display","none");
	$("#bottom").css("display","block");

}

/**
 * 跳转付款单详情
 * 传入路径信息
 * 
 * 结果：跳转付款单详情页面
 */
function paymentDetailForSaler(st){
	  var rootpath = st.getAttribute("rootpath");
	  var paymentId = st.getAttribute('paymentId');
	  var customerId = st.getAttribute('customerId');	
	  var customerName = st.getAttribute('customerName');
	  window.location=S3Config.getConfig('s3_root')+'~main/share/frame.php?target=paymentDetailForSaler&&paymentId='+paymentId+'&&customerId='+customerId+'&&customerName='+customerName;     
}


/**
* 在确认弹出框中显示选中订单列表
*  
* 结果:显示选中订单
* 
*/
function showRelatedOrderTabel(num,customerId){
	
	if(showOrderMode=="jiuhao"){
		//订单关联时使用
		 orderDisplayII[1]="未核销";
		 orderDisplayII[4]="已核销";					
	}				
	   //查找该笔付款单关联订单信息。
	var parmStr = {
		      "paymentID":num,
		      "customerID":customerId
		    };
	var ary = execjava('paymentBean.getRelatedOrderList', parmStr, 'json',"paymentservice");	
	if(ary.resCode!=200){
		alert(ary.resMsg);
		return;
	}
	//金额格式化
	var orderList = ary.orderList || [];
 	for(var i = 0;i<orderList.length;i++){
 		orderList[i].orderAmount ="￥"+addCommafy(orderList[i].orderAmount);
 	}
	var relateOrderTableHtml = template.render('queryPaymentRelatedOrder_tpl', {
	   	 relatedOrderList: orderList,
	   	 paymentID:num,
	   	 orderDisplayII: orderDisplayII
	     }); 
	$("#showrelatedorder"+num).html(relateOrderTableHtml);		
	//document.getElementById("ordertable"+num).style.background='#f8f4ec';
 	
}

/**
 * 输入信息重置处理
 * 
 * 功能：输入信息全部清除
 */
function resetInput() {
		var inputs=$("input[type=text]");
	    for(var m=0;m<inputs.length;m++){
	    	if($(inputs[m]).val() != "重置" && $(inputs[m]).val() != "查询"  && $(inputs[m]).val() != "下载" && $(inputs[m]).val() != "跳转"
	    		&& $(inputs[m]).attr("id") != "pageselect"){
	        	$(inputs[m]).val("");
	    	}
	    }
		if(!$("#showMethod")){
			$("#showMethod").val(1);
		}
		if($("#paymentMethod")){
			$("#paymentMethod").val("");
		}
		
		queryPayments(1);
}

/**
 * 付款单搜索
 * 
 * 功能：查询出相关付款单信息
 */
function queryPayments(pageclickednumber,status) {
		var payAmountStart = document.getElementById("startPayAmount").value;	
		var payAmountEnd = document.getElementById("endPayAmount").value;
		var payMethod = document.getElementById("paymentMethod").value;
		var showMethod = document.getElementById("showMethod").value;
		var sellerName = document.getElementById("sellerName").value;
		var customerName = document.getElementById("customerName").value;
		var startTime = document.getElementById("startTime").value;
		var endTime = document.getElementById("endTime").value;
		var searchParams = {//付款单查询参数
	 			"startTime":startTime,
	 			"endTime":endTime,
	 			"payAmountStart":payAmountStart,
			    "payAmountEnd":payAmountEnd,
			    "customerName":customerName,
			    "sellerName":sellerName,
			    "status":status,
			    "page":pageclickednumber,
				"payMethod":payMethod,
				"queryType":showMethod,
				"limit":'10',
				"salerCustomerRelateFlag":salerCustomerRelateFlag
		};
	   var flag = judgeAmount();
	   if(flag==false)
	   {
		  return; 
	   }
	   var ary = execjava('paymentBean.getPaymentListForSaler', searchParams, 'json',"paymentservice");	
	   if(ary.resCode=='999')
	   {
			location.href = '../../~main/errorInfo.php?retmsg='+ary.resMsg;
			return ;
	   }
	   if($('#showMethod').val() == "1"){
			document.getElementById("detailPayment").style.display="";
			document.getElementById("collectPayment").style.display="none";
			document.getElementById("pager").style.display="";
			var paymentList = ary.paymentList;
		   //金额格式化
		    for(var i = 0;i<paymentList.length;i++){
		    	paymentList[i].payAmount =addCommafy(paymentList[i].payAmount);
		    	paymentList[i].rsv1 =addCommafy(paymentList[i].rsv1==null?0:paymentList[i].rsv1);
		 	}
			// 翻页
			NextPage(pageclickednumber,ary.PAGE_TOTAL,status);
			var paymentListMode = 'querypaymentList'+showOrderMode;
			var paymentListHtml = template.render(paymentListMode, {
				   	 paymentList: paymentList,
				   	 querypaymentDisplayII: paymentDisplayII,
				   	 querypaymentMethodII: paymentMethodII,
					 orderDisplayII: orderDisplayII,
					 paymentStatus:status
		    });  
			$("#detailPayment").html(paymentListHtml);
		}else{
			document.getElementById("detailPayment").style.display="none";
			document.getElementById("collectPayment").style.display="";
			document.getElementById("pager").style.display="none";
			var collectPayment = 'collectPayment'+showOrderMode;
			
			var paymentList = ary.paymentList;
		    //金额格式化	
		    for(var i = 0;i<paymentList.length;i++){
		    	paymentList[i].payAmountSum =addCommafy(paymentList[i].payAmountSum==null?0:paymentList[i].payAmountSum);
		 	}
			
			var collectPaymentHtml = template.render(collectPayment, {
				 retList: paymentList,
			   	 querypaymentDisplayII: paymentDisplayII,
				 orderDisplayII: orderDisplayII,
				 querypaymentMethodII: paymentMethodII
			});  
			$("#collectPayment").html(collectPaymentHtml);	
		}
};


/**
 * 按照付款单状态查找付款单,参数为下拉框元素
 * 
 */
function ChangeByStatus(obj){
	     $("#form_paymentStatus").val(obj.value);
	     queryPayments(1,obj.value);
}

/**
 * 翻页方法，参数为当前页，总页数，状态
 * 
 */
function NextPage(pageNum,PAGE_TOTAL,status){
		  PAGE_TOTAL=parseInt(PAGE_TOTAL);
		  //$("#combinePage").val(pageNum);
		  $("#pager").pager({ 
		  pagecount: PAGE_TOTAL, 
		  pagenumber: pageNum, 
	      buttonClickCallback: function(pageclickednumber){queryPayments(pageclickednumber,status);} 
		  });
}






var showData = function(data){
	
	if(!data) return;
	data = eval('(' + data + ')');
	//superjs.cleanData('datalist');
	$("#detailPayment").html("");
	$("#collectPayment").html("");
	var colArray = ['id','userid','username','paytime','amount','paymethod','status'];
	var dataArray = [];
	dataArray = data.RESULT_DATA;
	allcount = data.RESULT_COUNT;
	if(allcount!=0){
	document.getElementById("pager").style.display="block";
	var page1=p;
	var totalCount = 0;
     if (data != null) {
      totalCount = data.RESULT_COUNT;
     }
     if(totalCount != 0&&totalCount!=undefined){
      var count = data.RESULT_DATA.length;
      var pages;
      
      if(totalCount%10 == 0) pages = totalCount/10;
      else pages = totalCount/10 + 1;
      
      $("#pager").pager({ 
       pagecount: pages, 
       pagenumber: page1, 
       buttonClickCallback: function(pageclickednumber){searchMessage(pageclickednumber);
       } 
      });
      var html = template.render('queryPaymentTpl', {
    			retList: dataArray
    	});
      $("#detailPayment").html(html);   	
      $("#page").val(page1);
     }
	}else{
		document.getElementById("pager").style.display="none";
	}
};



/**
 *下载 
 */
function downExcel(){
	var tankuangpd = false;
	if(document.getElementById("detailPayment").style.display=="block"){
		if($("#detailPayment").html().length!=0){
			tankuangpd = true;
		}
	}
	if(document.getElementById("collectPayment").style.display=="block"){
		if($("#collectPayment").html().length!=0){
			tankuangpd = true;
		}
	}
	if(tankuangpd){
		var param = downlist || {};
		param.pageStart=0;
		param.pageLimit=0;
		execajax("baoReportFormsBean.downPaymentExcel","json",param,true,downPaymentExcel);
	}else{
		alert("没有数据下载");
	}	

};

var downPaymentExcel = function(data){
	if(!data) return;
	data = eval('(' + data + ')');
	if(!data || !data.RESULT_STATE || !data.FILE_PATH||data.RESULT_STATE=="RESULT_ERROR"){
		return;
	}
	$("#downFile").attr("href",data.FILE_PATH);
    $("#downFile")[0].click();
};



