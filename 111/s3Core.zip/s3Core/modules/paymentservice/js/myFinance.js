/**
 * 跳转我的贷款
 * 
 */
function gotoMyFinance(st){
	window.open(S3Config.getConfig('s3_root')+'modules/paymentservice/gotoMyFinancing.php');
}