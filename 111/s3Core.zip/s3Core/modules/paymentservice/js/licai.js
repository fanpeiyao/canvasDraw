/**
 * 跳转工银聚富
 * 
 */
function gotoGYJF(st){
	window.open(S3Config.getConfig('s3_root')+'modules/paymentservice/gotoGYJF.php');
}

/**
 * 跳转工银聚财
 * 
 */
function gotoGYJC(st){
	window.open(S3Config.getConfig('s3_root')+'modules/paymentservice/gotoGYJC.php');
}