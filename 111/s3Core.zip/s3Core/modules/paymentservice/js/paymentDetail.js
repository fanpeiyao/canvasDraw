//加载后执行查询方法
	 $(document).ready(function(){
		 showPaymentDetail();
	   });

/**
* 获取付款单详情信息
* 通过直接url传参方式将付款单号传入
* 
*/
function showPaymentDetail(){
			
		var params = {
				'paymentID': S3Params.getData('paymentId'),
				'customerId': S3Params.getData('customerId'),
				'customerName':S3Params.getData('customerName')	
		}
		var result = execjava('paymentBean.getPaymentDetail', params, 'json','paymentservice');		
		if(result.resCode!="200"){
				location.href = "../../~main/errorInfo.php?retmsg="+result.retmsg;
				return ;
		}
		
		//加载付款单详情
		var detailorderList = result.mappingOrder;
		var showTblHtml = template.render('paymentdetaillist', {
			   "paymentDetail":result.paymentDetail,
			   "repaySize":result.repaySize,
			   "totalRepayAmount":result.totalRepayAmount,
			   "paymentDisplayII":paymentDisplayII,
			   "customerId":params.customerId //用来区分是否是返回连接信息
			     }); 
		 $("#paymentDetail").html(showTblHtml);	
		 
		 
		 //加载付款单关联订单信息
		 var paymentdetaillist="paymentDetailRelatedOrderList"+showOrderMode;		 
		 //金额格式化	
		 for(var i = 0;i<detailorderList.length;i++){
		 		detailorderList[i].orderAmount =addCommafy(detailorderList[i].orderAmount);
		 }
		 var showTblHtml = template.render(paymentdetaillist, {
				   "orderList":detailorderList,
				   "orderDisplayII":orderDisplayII
				     }); 
		 $("#detailorderlist_table").html(showTblHtml);	
		
		 //加载付款单关联还款信息
		 var financingrepayList =result.repayList;
		 var showTblHtml1 = template.render("financingrepaylist", {
				   "repayList":financingrepayList
				     }); 
		 $("#financingrepaylist_table").html(showTblHtml1);
		 
		 var notes = result.paymentDetail.notes;
			 notes=notes.replace(/&lt;br\/&gt;/g,'\n');
		 $("#notes").html(notes);		
	}


/**
 * 保存notes
 * 
 * 结果notes数据保存到数据库中
 */
function savenote(st){
		　var notes=document.getElementById("notes").value;
		     notes =htmlEncode(notes);
		　var paymentID = st.getAttribute("oId"); 
		　var params = {"notes":notes, "paymentID":paymentID};
		　var rt= execjava("paymentBean.savePaymentNote",params, "json","paymentservice");
		　if(rt.resCode!="200"){
				alert("保存失败！");
			}else if(rt.resCode=="200"){
				alert("保存成功！");
			}
	
}


