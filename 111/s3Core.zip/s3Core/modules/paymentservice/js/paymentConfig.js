     //付款单状态
     var paymentDisplayII=[];
	 paymentDisplayII['0']="待付款";
	 paymentDisplayII['1']="待确认";
	 paymentDisplayII['2']="已付款";
	 paymentDisplayII['3']="贷款失败";
	 paymentDisplayII['4']="部分还款";
	 paymentDisplayII['5']="已还款";
	 paymentDisplayII['6']="付款失败";
	 //订单状态
	 var orderDisplayII ={
			 	'0' : "待审核",
				'1' : "已审核",
				'2' : "已核销",
				'3' : "已作废"
	 };
     //付款方式
	 var paymentMethodII=[];
	 paymentMethodII[0]="-";
	 paymentMethodII[3]="B2C";
	 paymentMethodII[1]="B2B";
	 paymentMethodII[2]="C2C";
	 paymentMethodII[8]="银联在线支付";
	 paymentMethodII[22]="汇票";
	 paymentMethodII[26]="汇款";
	 paymentMethodII[27]="承诺书";
	 paymentMethodII[29]="支票";
	 paymentMethodII[53]="贷款";
	 paymentMethodII[54]="电汇";
	 paymentMethodII[55]="易付";



/**
 * 获取付款单服务配置服务器参数值
 * @author zjfh-shengq
 * @returns 参数值
 */
function getPaymentConfigValue(key){

	//从后台获取相应的配置信息	
	var param={
		"payment_key":key	
	}
	var result = execjava('paymentBean.getConfigValue',param,'json','paymentservice');
    if(result.resCode!="200"){
		location.href = "../../~main/errorInfo.php?retmsg="+result.resMsg;
		return ;
	}
	return result[key];

}

function htmlEncode(str)
{
	return str.replace(/</g,'&lt').replace(/>/g,'&gt');
}

function htmlDecode(str)
{
	return str.replace(/&lt;/g,'<').replace(/&gt;/g,'>');
}

/**
 * 转换金额显示方方法
 * 
 * 结果：数字会显示成金额的表示形式
 */
function convertToMoney(number){
			number=number.toString();
			var result;
			var indexP = number.indexOf(".");
			var smallPart;
			var bigPart;
			var smallLen;
			if(indexP>-1){
				bigPart = number.substring(0,indexP);
				smallPart = number.substring(indexP,number.length);
				number = bigPart;
			}
			//小数部分补齐两位
			if(typeof smallPart == "undefined" ){
				smallPart = ".00";
			}else{
				smallLen = smallPart.length;
			for(var m=0;m<2-smallLen+1;m++){
				smallPart = smallPart+"0";
			}
			}
			//小数部分保留两位
			smallPart = smallPart.substring(0,3);
			
			number = '' + number;
			result = number;
			if (number.length > 3) {
				var mod = number.length % 3;
				result = (mod > 0 ? (number.substring(0,mod)) : '');
				var numLen = Math.floor(number.length / 3);
				for (i=0 ; i < numLen; i++) {
					if ((mod == 0) && (i == 0))
						result += number.substring(mod+ 3 * i, mod + 3 * i + 3);
					else
						result += ',' + number.substring(mod + 3 * i, mod + 3 * i + 3);
				}
			}
				result = result + smallPart;
			
			var rep = /a,/g;
			var rep1 = /a-,/g;
			var rep2 = /a/g;
			var tempresult = "a"+result;
			result = tempresult.replace(rep, "").replace(rep1, "-").replace(rep2, "");
			
			return result;
	
}

/**
 * 判断金额小数位
 * 
 * 结果：小数位不大于两位
 */
function moneyCount(value){
	var indexP = value.indexOf(".");
	if(indexP>-1){
		var reg = /\.\d{0,2}$/;
		if(reg.exec(value))return true;
		else return false;
	}
	return true;
		
}



//获取付款单服务配置服务器参数值(后面的值为从当前服务器上取的默认的值)
var isShowCompany= getPaymentConfigValue('isShowCompany');   //1-新建付款单和付款单详情中显示分公司
var paymentSearchMode = getPaymentConfigValue('paymentSearchMode');//default-付款单搜索框显示模式
//default-新建付款单显示订单列表时订单列表显示模式，default为默认模式，即订单号、下单时间、订单状态、关联付款单，如果B2B项目有特殊需要，则设该值为应用号，如jiuhao
var showOrderMode = getPaymentConfigValue('showOrderMode');
var isRz = getPaymentConfigValue('isSupportFinancing');//1-新建付款单是否支持融资，1-支持 0-不支持。
if(isRz=='true')isRz=true;
if(isRz=='false')isRz=false;
if(isRz=='1')isRz=true;
if(isRz=='0')isRz=false;
var showOrderMode = getPaymentConfigValue('showOrderMode');
//0-新建付款单关联订单模式：0-强关联订单 1-弱关联订单 2-不支持关联订单 3-混合关联订单（有关联订单时为强关联，无关联订单时为弱关联）
var createNewPaymentMode = getPaymentConfigValue('createNewPaymentMode');
//0-【可选参数，不配时默认值为0】新建付款单关联订单数量模式，0-任意数  1-只能关联一个
var relateOrderMode = getPaymentConfigValue('relateOrderMode');
var payMode = getPaymentConfigValue('payMode');//0-新建付款单付款金额模式，0-大于等于  1-必须等于  2-任意
var isNeedDebt = getPaymentConfigValue('isNeedDebt');//0-是否必须支付欠款，1-必须支付，0-非必须支付
var isShowCompanyDebt = getPaymentConfigValue('isShowCompanyDebt');//1-新建付款单是否显示账户余额，1-显示余额 0-不显示余额。
//0-业务员-经销商对应关系标志，0-不存在对应关系，业务员可以对应到全部经销商  1-存在对应关系，对应关系在scm_operator_customer_tbl（标准版改为scm_user_relate_tbl）表中
var salerCustomerRelateFlag = getPaymentConfigValue('salerCustomerRelateFlag');


/**
 * 显示查询中的背影
 * 
 */
function showLoading(){
	    if($("#show-loading-div").size()>0){
	       $("#show-loading-div").show();
	       return ;
	    }
	  
		var overlayCSS =  {
			backgroundColor: '#fff',
			opacity:	  	 0.6, 
			cursor:		  	 'wait',
			width:'100%',
			height:___getPageSize().pheight,
			position: 'absolute',
			top:0 
		//	'-webkit-border-radius': '10px',
		//'-moz-border-radius':	 '10px',
		//'border-radius': 		 '10px'
		}
	    var element = jQuery("<div style='z-index:99999;filter:alpha(opacity=50)'/>").attr("id","show-loading-div").css(overlayCSS).appendTo(document.body);
}

function ___getPageSize() {  
	    var xScroll, yScroll;  
	    if (window.innerHeight && window.scrollMaxY) {    
	        xScroll = window.innerWidth + window.scrollMaxX;  
	        yScroll = window.innerHeight + window.scrollMaxY;  
	    } else if (document.body.scrollHeight > document.body.offsetHeight){ // all but Explorer Mac  
	        xScroll = document.body.scrollWidth;  
	        yScroll = document.body.scrollHeight;  
	    } else { // Explorer Mac...would also work in Explorer 6 Strict, Mozilla and Safari  
	        xScroll = document.body.offsetWidth;  
	        yScroll = document.body.offsetHeight;  
	    }  
	    var windowWidth, windowHeight;  
	    if (self.innerHeight) { // all except Explorer  
	        if(document.documentElement.clientWidth){  
	            windowWidth = document.documentElement.clientWidth;   
	        } else {  
	            windowWidth = self.innerWidth;  
	        }  
	        
	        windowHeight = self.innerHeight;  
	    } else if (document.documentElement && document.documentElement.clientHeight) { // Explorer 6 Strict Mode  
	        windowWidth = document.documentElement.clientWidth;  
	        windowHeight = document.documentElement.clientHeight;  
	    } else if (document.body) { // other Explorers  
	        windowWidth = document.body.clientWidth;  
	        windowHeight = document.body.clientHeight;  
	    }     
	    // for small pages with total height less then height of the viewport  
	    if(yScroll < windowHeight){  
	        pageHeight = windowHeight;  
	    } else {   
	        pageHeight = yScroll;  
	    }  
	    // for small pages with total width less then width of the viewport  
	    if(xScroll < windowWidth){     
	        pageWidth = xScroll;          
	    } else {  
	        pageWidth = windowWidth;  
	    }  
	  　　// arrayPageSize = new Array(pageWidth,pageHeight,windowWidth,windowHeight);  
	    return {pwidth:pageWidth,pheight:pageHeight,wwidth:windowWidth,wheight:windowHeight};  
};  

/**
 * 移除查询中的背影
 * 
 */
function removeLoading(){
		jQuery("#show-loading-div").hide();
}



var colArray = [
["付款单号","paymentID"],
["付款单金额","payAmount"],
["实付金额","rsv1"],
["付款时间","payTime"],
["付款方式","payMethod"],
["全部状态","status"],
["操作","operation"],
];


var myPayment_col = {
		paymentID : {
			render : function(row, type, data, meta) {
				return '<div class="pay-tab_detail">'+'<a href="javascript:void(0);" onclick="paymentDetail(this)" paymentid="'+data.paymentID+'">'+data.paymentID+'(详情)</a>'+'</div>'
			},
			data : 'paymentID'
		},
		payAmount : {
			render : function(row, type, data, meta) {
				
				return '<span class="pay-tab_money">￥' + addCommafy(data.payAmount)+'</span>'
			},
			data : 'payAmount'
		},
		rsv1 : {
			render : function(row, type, data, meta) {
				
				return '<span class="pay-tab_money">￥' + addCommafy(data.rsv1)+'</span>'
			},
			data : 'rsv1'
		},
		payTime : {
			render : function(row, type, data, meta) {
				
				return '<span class="pay-tab_time">' + data.payTime+'</span>'
			},
			/*render : function(row, type, data, meta) {
				var content = "<div class='f1 fw tex_c' id='purproTotal" + meta.row
				+ "' rid='" + meta.row + "'>" + orderStatusDisplay[data.orderStatus]
				+ "</div>";
				return content;
			}*/
			data:"payTime"
		},
		payMethod : {
			"class":"pay-tab_status",
			render : function(row, type, data, meta) {
				var content = '<div>'+paymentMethodII[data.payMethod]+'</div>';
				return content;
			}
		   
		},
		status : {
			
			render : function(row, type, data, meta) {
				
				return '<span>'+paymentDisplayII[data.status]+'</span>';
			},
			data : 'status'
		},
		operation : {
			render : function(row, type, data, meta) {
				var delBtn = '<a class="pay-btn_del" href="javascript:void(0);" onclick="paymentDetail(this)" paymentid="'+data.paymentID+'">查看</a>'
				return delBtn;
			}
		},
		
		
		
};




