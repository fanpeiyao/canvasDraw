<!DOCTYPE html>
<html>
<head></head>
<body>

<?php 
	require_once '~main/ctx.php';    
	require_once 'PaymentOrder.class.php';
	$payInfo=PaymentOrder::selectGYJF();
?>
</body>
</html>
