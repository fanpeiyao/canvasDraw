<script id="financingrepaylist" type="text/html">
      <p class="pay-nwepay_relation_title">关联提货单 </p> 
	  <table class="pay-table" width="100%" >
               
                 <tr class="pay-bg2">
                   <td width='12%'>融资单号</td>
                   <td width='18%'>还款流水号</td>
                   <td width='12%'>还款金额</td>
                   <td width='10%'>还款状态</td>
                   <td width='16%'>还款时间</td>
                   <td width='10%'>利息</td>
                   <td>备注</td>
                 </tr>
              
               
							<%if(repayList.length>0){%>

											<%for(var i=0; i<repayList.length; i++){%>
												 <tr <% if (i%2==1){ %>  class="pay-bg1" <%}%> >
                                                 <td><%=repayList[i].financingId%></td>
                                                 <td><%=repayList[i].transerialNo%></td>
												 <td class="pay-tab_money"><%=repayList[i].repayamt%>&nbsp元</td>
                                                 <%if(repayList[i].repaystatus=="4"){%>
													 	<td class="pay-tab_status">部分还款</td>
											 	 <%}else if(repayList[i]["repaystatus"]=="5"){%>
													 	<td class="pay-tab_status">已还款</td>                                               
												 <%} else if(repayList[i]["repaystatus"]=="3"){%>
                                                     <td class="pay-tab_status">已融资</td>
                                                 <%}%> 
                                                 <td><%=repayList[i].repaytime%></td>
												 <td><%=repayList[i].interest%></td>
												 <td><%=repayList[i].notes%></td>
												 </tr>
											<%}%>
							<%}else{%>
							                <tr>
                  							<td colspan=7 class="pay-no_order">无还款记录!</td>
                  							</tr>
							<%}%>
				
       </table>  
</script>
