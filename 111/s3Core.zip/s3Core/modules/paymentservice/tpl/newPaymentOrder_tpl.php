<script id="newPaymentOrderdefault" type="text/html">
<table class="pay-table" width="100%"  style="display:<%=orderdisplay%>">
            
              <thead>
	               <tr class="pay-table_th">
		                <th width="4%"></th>
		                <th>订单编号</th>
		                <th >订单金额</th>
	                  	<th width="18%">下单时间</th>
	                  	<th width="12%">订单状态</th>
		                <th width="30%">关联付款单</th>
	               </tr>
               </thead>
               <tbody>
        <% if(combineList.length==0){%>
            	
            	<tr>
            		<td colspan="6" class="pay-no_order">无查询结果！</td>
            	</tr>
        <% }else{%>
		        <%  
                var BeSelectedList=BeSelected.split(",");
				//遍历需要合并的订单列表
                for( var i=0;i<combineList.length;i++)
				{ 
					//复选框是否需要勾选标志，0否1是;
					//如果是从订单直接到付款单的，BeSelected会有值，则会直接被勾选
					var IsChecked='0';
               		var combineOrderMap = combineList[i];
					//订单取出结果是一个list<MAP>,里面每一个Map使用订单号作为键值又指向一个map
					for(var key in combineOrderMap){
					var combineOrder=combineOrderMap[key];
                	var combineStatus=combineOrder.orderStatus;
					//循环标志串，是否包含订单号，如果包含，则将勾选标志置成1;同时将选中订单详情放入对象paymentorderLists中
               		for(var y=0;y<BeSelectedList.length;y++)
					{
                		if(BeSelectedList[y]==combineOrder.orderId)
						{
                			IsChecked='1';
                		}
                	}                
                %>
                 	<tr id="mainOrder<%=i%>" <% if(i%2==1){%> class='pay-table_bgtr'<%}%>>
                 		
                 		<td>
                 			<input id="cb<%=combineOrder.orderId%>" onclick="AfterBeSelected('<%=combineOrder.orderAmount%>',this)" name="cb" type="checkbox" value="<%=combineOrder.orderId %>" <% if(IsChecked=='1'){%>checked<% }%>/>
                 		</td>
                 		<td>
                 			<span><%=combineOrder.orderNo %></span>
                 		</td>
                 	
		                <td>
		                 	<b  class="pay-tab_money">￥<%=combineOrder.orderAmount %></b>
                 		</td> 
                 		<td>
		                	<%=combineOrder.orderCreateTime %>
		                </td>
                 		<td class="pay-tab_status">
		                    <%=orderDisplayII[combineStatus] %>
                 		</td>
                 		<td>
		                    <span><%=combineOrder.map.replace(/,/g, ", ")%></span>
                 		</td>
             		</tr>
             	  <% }%>
				<% }%>
             <% } %>	             	
				<tr>
				</tr>
               </tbody>
              
</table>
</script>


<script id="newpaymentinfo" type="text/html">

						<!-- 是否显示余额 -->
			      		<span style="display:<%=debtdisplay%>">余额：<font class="pay-tab_money" id="ye"></font> 元 &nbsp;&nbsp;&nbsp;&nbsp;</span>
			      		<!-- 显示子公司名称 -->
			      		<span style="display:<%=sellerdisplay%>">分公司：
							 <!-- 与子公司有关变量，获得列表中第一个子公司的信息进行，为展示用 -->
							 <% if(companyList.length==1) { %>
							 <font  id="seller" name="seller" class="pay-f_color2"><%=companyList[0].salecompanyName%></font><br/>
							 <% }else{%>	   			  
			      			 <select id="seller" name="seller" onchange="selectByCompany(this)">
								<% 		         		
		                		for(var i=0;i<companyList.length;i++){
		                			var eveCompMes= companyList[i];
		                			var companyName=eveCompMes.salecompanyName;
		                			var companyId=eveCompMes.id;
		                			%>
								<option value="<%=companyId%>" >
									<%=companyName%>
								</option>
								<% }%>
						     </select><br/>
						     <% }%>
 						</span>
						<!-- 余额的相关文字显示 -->
			      		<span style="display:<%=debtdisplay%>"><font class="pay-f_color3"><strong class="pay-tab_money">*</strong>余额为正，代表经销商预付款;余额为负，代表经销商已欠款</font><br/></span>
			      		<!-- 是否融资显示 -->
			      		<span style="display:<%=Rzdisplay%>"><input id="form_IsRZ" name="form_IsRZ" onclick="rzSelected(this)" type="checkbox" value="0" /> 是否融资 </span>
</script>