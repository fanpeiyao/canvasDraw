<script id="paymentdetaillist" type="text/html">
<div class="pay-numNo" >
			<?php if($id=="1"){//表示经销商登陆?>   
			<span>付款单编号：<font class="pay-tab_num"><%=paymentDetail.id%></font></span> 
			<span>状态：<font class="pay-tab_num"><%=paymentDisplayII[paymentDetail.status] %></font></span>
			<strong>可返回付款单列表进行相关操作 <i></i><a href="../../~main/share/frame.php?target=myPayment">返回我的付款单</a></strong>
		    <?php }else{?>
			<span>收款单编号：<font class="pay-tab_num"><%=paymentDetail.id%></font></span> 
			<span>状态：<font class="pay-tab_num"><%=paymentDisplayII[paymentDetail.status] %></font></span>
			<strong>可返回收款单列表进行相关操作 <i  class="iconfont icon-xiadan"></i><a href="../../~main/share/frame.php?target=queryPayment">收款单查询</a></strong>
		     <?php }?>
           </div>
    <!--内容2--> 
<?php if($id=="1"){//表示经销商登陆?>   
    <p class="pay-newpay_title">付款单详情</p>
    <?php }else{?> 	 
	<p class="pay-newpay_title">收款单详情</p>
<?php }?>    
        <div class="pay-newpay_div">
			<p class="pay-newpay_list">
				创建时间：<%=paymentDetail.createTime%><br/> 
				支付时间：<%=paymentDetail.paytime%><br/> 
<?php if($id=="1"){//表示经销商登陆?>   
				付款方式：<%=paymentDetail.payMethod%><br/> 
<?php }else{?> 	 
				收款方式：<%=paymentDetail.payMethod%><br/> 
<?php }?>   
				客户编号：<%=paymentDetail.customerId%><br/>
				客户名称：<%=paymentDetail.customerName%><br/>
				<% if(isShowCompany=="1"){%>
              	分公司编号：<%=paymentDetail.sellerId%><br/>
              	分公司名称：<%=paymentDetail.sellerName%>
                <% } else if(paymentDetail.status=="3"){%>
              	贷款失败信息：<%=paymentDetail.rv2%>
              	 <% } else if(paymentDetail.status=="4"||paymentDetail.status=="5"){%>
              	还款笔数：<%=repaySize%>&nbsp笔<br/>
              	还款金额：<%=totalRepayAmount%>&nbsp元
                <% }%> 
			</p>			                        
        </div>
       
    <!--内容3-->   
    <!--如果参数为3不支持关联订单，此部分不显示-->
    <% if(createNewPaymentMode!=2){%>
    <div id="detailorderlist_table" class="pay-newpay_relation"></div>  	 
    <% }%>    
    <%if(paymentDetail.status=="4"||paymentDetail.status=="5"){%>	
    <div id='financingrepaylist_table' class='pay-newpay_relation'></div>
    <% }%>
    <!--内容4--> 				         				 
    <div class="pay-detail_bottom">
<?php if($id=="1"){//表示经销商登陆?> 
          <p class="pay-detail_remark_title">付款单备注</p>
<?php }else{?> 	
		  <p class="pay-detail_remark_title">收款单备注</p>
<?php }?>  
          	<p class="pay-detail_remark">
          		<textarea id="notes" name="notes" cols="80" rows="4" 
                          onpropertychange="if(value.length>50) value=value.substr(0,50);"
	     				  oninput="if(value.length>50) value=value.substr(0,50);" >	 											        						            
                </textarea>
			</p> 	 
          	<p class="pay-remark_save"><a class="pay-btn_save" href="#" onclick='savenote(this)' orderStatus='0' oId='<%=paymentDetail.id%>' name="modifyaddr">保存</a></p>
		  	<?php if($id=="1"){//表示经销商登陆?> 
			<p class="pay-detail_amount">付款金额：<span>￥<%=paymentDetail.amount %></span></p> 
			<?php }else{?>   
			<p class="pay-detail_amount">收款金额：<span>￥<%=paymentDetail.amount %></span></p> 
			<?php }?>        
    </div>
</script>

<script id="paymentDetailRelatedOrderListdefault" type="text/html">
      <p class="pay-nwepay_relation_title">关联订单 </p> 
	  <table class="pay-table" width="100%" >
               
                 <tr class="pay-bg2">
                   <td>订单编号</td>
                   <td>订单金额</td>
                   <td>下单时间</td>
                   <td>状态</td>
                 </tr>
              
               
							<%if(orderList.length>0){%>

											<%for(var i=0; i<orderList.length; i++){%>
												 <tr <% if (i%2==1){ %>  class="pay-bg1" <%}%> >
												 <td><%=orderList[i].orderNo%></td>
												 <td class="pay-tab_money">￥<%=orderList[i].orderAmount%></td>
												 <td class="pay-tab_time"><%=orderList[i].orderTime%></td>
                                                 <td class="pay-tab_status"><%=orderDisplayII[orderList[i].orderStatus]%></td>												
												 </tr>
											<%}%>
							<%}else{%>
							                <tr>
                  							<td colspan=4 class="pay-no_order">无关联订单!</td>
                  							</tr>
							<%}%>
				
       </table>  
</script>