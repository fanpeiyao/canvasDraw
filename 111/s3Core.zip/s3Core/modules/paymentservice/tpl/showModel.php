<script id="showmodelorderzero" type="text/html">
				<div id="ThisTimeMoneyShow">
							<p id="ThisTimeShow" style="display:<%=thistimedisplay%>"><span id="ThisTimeSpanShow">最小付款金额：</span><b id="amount" ></b><span>&nbsp元</span></p> 
							<p id="ThisTimeMoneyInput" style="display:<%=inputdisplay%>"><span>本次付款金额：</span><b><input
								id="ThisTimeMoney" name="ThisTimeMoney"
								oninput="javascript:testCount(this)"

								onkeyup="this.value=this.value.replace(/[^\d.]/g,'')" value=""
								type="text"/></b><span>&nbsp元</span>
							</p>
				</div>
				<div id="ThisTimeMoneyRz" style="display:none">
							<p ><span>融资关联订单金额：</span><font>￥</font><b id="amountRz"></b><span>&nbsp元</span></p>
				</div> 
</script>

<script id="showmodelorderone" type="text/html">
				<div  id="ThisTimeMoneyShow">
							<p id="moneynotice" class="pay-tip" style="display:<%=noticedisplay%>">提示：本次付款金额必需大于欠款金额</p>
							<p id="ThisTimeShow" style="display:<%=thistimedisplay%>"><span>本次付款金额：</span><b id="amount" ></b><span>&nbsp元</span></p> 
							<p id="ThisTimeMoneyInput" style="display:<%=inputdisplay%>"><span>本次付款金额：</span><b><input
								id="ThisTimeMoney" name="ThisTimeMoney"
								onkeyup="this.value=this.value.replace(/[^\d.]/g,'')" value=""
								type="text"/></b><span>&nbsp元</span>
							</p>
				</div>
				<div  id="ThisTimeMoneyRz" style="display:none">
							<p ><span>融资关联订单金额：</span><b id="amountRz" ></b><span>&nbsp元</span></p>
				</div> 
</script>

<script id="showmodelordertwo" type="text/html">
				<div  id="ThisTimeMoneyShow">
							<p id="moneynotice" class="pay-tip" style="display:<%=noticedisplay%>">提示：本次付款金额必需大于欠款金额</p>
							<p id="ThisTimeShow" style="display:<%=thistimedisplay%>"><span id="ThisTimeSpanShow">关联订单金额：</span><b id="amount" ></b><span>&nbsp元</span></p> 
							<p id="ThisTimeMoneyInput" style="display:<%=inputdisplay%>"><span>本次付款金额：</span><b><input
								id="ThisTimeMoney" name="ThisTimeMoney"
								onkeyup="this.value=this.value.replace(/[^\d.]/g,'')" value=""
								type="text"/></b><span>&nbsp元</span>
							</p>
				</div>
				<div  id="ThisTimeMoneyRz" style="display:none">
							<p ><span>融资关联订单金额：</span><b id="amountRz" ></b><span>&nbsp元</span></p>
				</div> 
</script>

<script id="showmodel" type="text/html">
				<div  id="ThisTimeMoneyShow">
							<p id="moneynotice" class="pay-tip" style="display:<%=noticedisplay%>">提示：本次付款金额必需大于欠款金额</p>
							<p id="ThisTimeMoneyInput" ><span>本次付款金额：</span><b><input
								id="ThisTimeMoney" name="ThisTimeMoney"
								onkeyup="this.value=this.value.replace(/[^\d.]/g,'')" value=""
								type="text"/></b><span>&nbsp元</span>
							</p>
				</div>
</script>



