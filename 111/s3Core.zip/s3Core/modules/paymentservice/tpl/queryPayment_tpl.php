<script id="collectPaymentdefault" type="text/html">
<table>
    <colgroup>
        <col width="5%">
		<col width="11%">
	</colgroup> 
	<thead class="pay-table_th1">
		<tr>
			<td>总付款笔数</td>
			<td>总付款金额</td>
		</tr>
	</thead>
	<tbody align="center" class="pay-table_th2">
    <%if(retList.length==0){%>
		<tr>
             <td colspan="2" class="pay-no_order">无查询结果！</td>
        </tr>
	<%}else{%>
    <% 
        var paymentcount="";
		var paymentsum="";
	    for(var i=0;i<retList.length;i++){
			paymentcount = retList[i].payCount;
			paymentsum = retList[i].payAmountSum;
     %>
         <tr class="pay-table_th1" >
		        <td>
					<span><%=paymentcount%></span>
				</td>
		        <td class="pay-tab_money">
					<span><%=paymentsum%></span>
				</td>
		      </tr>
	  <%}}%>
	</tbody>
</table>
</script>

<script id="querypaymentListdefault" type="text/html">
<div class="mar10">
	<table class="mypayment_table" style="width: 100%">
	                <tr class="mypayment_tr">
                        <td width="3%"></td>
        				<td width="12%">收款单编号</td>
        				<td width="12%">客户编号</td>
        				<td width="16%">客户名称</td>
        				<td width="16%">收款时间</td>
       					<td width="11%">收款单金额</td>
						<td width="11%">实付金额</td>
						<td width="8%">支付方式</td>
       					<td width="11%">
	                   		<select id="form_paymentStatus" name="form_paymentStatus" onchange="ChangeByStatus(this)">
	                   			<option value="-1"  <%if(paymentStatus==-1){%> selected <%}%>>全部状态</option>
	                   			<option value="0" <%if(paymentStatus==0){%> selected <%}%>>待付款</option>
	                   			<option value="1" <%if(paymentStatus==1){%> selected <%}%>>待确认</option>
	                   			<option value="2" <%if(paymentStatus==2){%> selected <%}%>>已付款</option>
	                   			<option value="3" <%if(paymentStatus==3){%> selected <%}%>>贷款失败</option>
                                <option value="4" <%if(paymentStatus==4){%> selected <%}%>>部分还款</option>
	                   		    <option value="5" <%if(paymentStatus==5){%> selected <%}%>>已还款</option>
								<option value="6" <%if(paymentStatus==5){%> selected <%}%>>付款失败</option>
                           </select>
	                   </td>
     				</tr>
               <tbody>
            <%if(paymentList.length==0){ %>
            	<tr>
            		<td colspan="9"><strong>无查询结果！</strong></td>
            	</tr></table>
            <% }else{ %>
		       <% 
                /**
                 * 遍历付款单集合，回显相关字段               
                 */
                for(var i=0;i<paymentList.length;i++){ 
				
                var payment= paymentList[i];
                var paymentStatus=payment.status;
	            var isEmpty= paymentList[i].hasOrder;
                var paymentAmount = payment.payAmount; 
				var payMethod = payment.payMethod;            
                 %>
                 	<tr id="mainOrder<%=payment.paymentID%>" <% if(i%2==1){%>class="pay-table_bgtr"<%}%> >
                        <td>
                            <% if(isEmpty=='1'){%>
                            <span id="jia<%=payment.paymentID%>" class="pay-add" onclick="jiaordershow('<%=payment.paymentID%>','<%=payment.customerID%>')">+</span>
                 			<span id="jian<%=payment.paymentID%>" class="pay-add" onclick="jianordernone('<%=payment.paymentID%>',<%=i%>)" style="display: none;">-</span>                 			
                 			<% }%>
                        </td>
                 		<td class="pay-tab_detail">               								
                 			<span><a href="javascript:void(0);" onclick='paymentDetailForSaler(this)' rootpath='<?php echo $root_path ?>' paymentId='<%=payment.paymentID%>' customerId='<%=payment.customerID%>' customerName=<%=payment.customerName%> ><%=payment.paymentID%>(详情)</a></span>
                 		</td>
                 		<td ><!--客户编号-->
		                 	<span><%=payment.customerID%></span>
                 		</td> 
						<td ><!--客户名称-->
		                 	<span><%=payment.customerName%></span>
                 		</td> 
						<td class="pay-tab_time">
		                	<span ><%=payment.payTime %></span>
		                </td>
		                <td class="pay-tab_money"><!--付款单金额-->
		                 	<span>￥<%=paymentAmount%></span>
                 		</td> 
                        <td  class="pay-tab_money"><!--实付金额-->
		                 	<span>￥<%=payment.rsv1==null?0:payment.rsv1%></span>
                 		</td> 
						<td >
		                	<%=querypaymentMethodII[payMethod==null?0:payMethod]%>		                    			                    	
                 		</td>
                 		<td class="pay-tab_status">
		                	<%=querypaymentDisplayII[paymentStatus] %>		                    			                    	
                 		</td>
             		  </tr>
					  <tr id="showrelatedorder<%=payment.paymentID%>"></tr>
            
			   <% }%>
	             	
               </tbody>
              
</table>
 
<% }%>
</div>
</script>


<script id="querypaymentsearchdefault" type="text/html">
     
        <div class="paymentcondit2">
				<p class="mar_l20">
					<span class="paymentw100">起始时间：</span><input name="startTime" type="text" class="mypayment_inputDate" id="startTime" onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},maxDate:'%y-%M-%d' });"  onblur="judgeTime()"/>
					<span class="paymentw100_1">结束时间：</span><input name="endTime" type="text" class="mypayment_inputDate" id="endTime" onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},maxDate:'%y-%M-%d' });"  onblur="judgeTime()"/>
					<span class="paymentw100_1">客户名称：</span><input type="text" id="customerName" class="mypayment_input1"/>
				</p>     
         </div>
				     
          <div class="paymentcondit2">
				<p class="mar_l20">
					<span class="paymentw100">分公司名称：</span><input type="text" id="sellerName" class="mypayment_input1"/>
					<span class="paymentw100_1">支付方式：</span><select name="paymentMethod" id="paymentMethod" class="mypayment_input" style="margin-left:4px;">
				        <option value="">全部</option>
						<option value="3">B2C</option>
						<option value="4">B2B</option>
						<option value="5">C2C</option>
						<option value="8">银联在线支付</option>
						<option value="22">汇票</option>
						<option value="26">汇款</option>
						<option value="27">承诺书</option>
						<option value="29">支票</option>
						<option value="53">贷款</option>
						<option value="54">电汇</option>
						<option value="55">电汇</option>
				      </select>
					<span class="paymentw100_2">展现方式：</span>
                      <select name="showMethod" id="showMethod" class="mypayment_input">
				        <option value="1">明细</option>
						<option value="0">汇总</option>
				      </select>
				</p>
               </div>
           <div class="paymentcondit2">
				<p class="mar_l20">
					<span class="paymentw100">收款单金额：</span><input name="startPayAmount" id="startPayAmount" type="text" class="mypayment_input1" onkeyup="this.value=this.value.replace(/[^\d.]/g,'')"/>
					<span class="paymentw100_1">到</span><input name="endPayAmount" id="endPayAmount" type="text" class="mypayment_input1" onkeyup="this.value=this.value.replace(/[^\d.]/g,'')"/>
					<span >&nbsp;&nbsp;&nbsp;<a class="btn_mypayment" href="#" onclick="queryPayments(1)" >查询</a>&nbsp;&nbsp;<a class="btn-maypent_del" href="#" onclick="resetInput()">重置</a></span>
                      
				</p>
          </div>

</script>

<script id="queryPaymentRelatedOrder_tpl" type="text/html">
<td colspan='9' id='ordertable<%=paymentID%>' class='pay-add_td'>
<table style="width:100%">         
	    <tr>
		    <th>订单号</th>
            <th>客户编号</th>
       		<th>订单金额</th>
   			<th>下单时间</th>
            <th>订单状态</th>
	    </tr>
        <tbody >
               <%
                  if(relatedOrderList.length==0)
                  {%>
                    <tr>
            		   <td colspan="5" class="pay-no_order"><strong>无查询结果！</strong></td>
            	   </tr>
                  <%}
                for(var i=0;i<relatedOrderList.length;i++){ 				
                    var relatedOrder = relatedOrderList[i];
                    var orderNo = relatedOrder.orderNo;
                    var customerId = relatedOrder.customerId;
	                var orderAmount = relatedOrder.orderAmount;
                    var orderTime = relatedOrder.orderTime;  
                    var orderStatus = relatedOrder.orderStatus;       
                 %>
                  <tr <% if(i%2==1){%>class="pay-bg1"<% }else{ %> class="pay-bg"<% } %> >                      
                 		<td ><%=orderNo%></td>                 		  
		                <td ><%=customerId%></td> 
                        <td ><%=orderAmount%></td> 
                 		<td ><%=orderTime%></td>  
                        <td ><%=orderDisplayII[orderStatus]%></td>            		
             	  </tr> 
                <%}%>                 
        </tbody>             
</table> 
</script>