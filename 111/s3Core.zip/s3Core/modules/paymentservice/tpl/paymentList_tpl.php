<script id="paymentList" type="text/html">
<div class="mar10">
<table class="pay-table" style="width:100%">
	               <tr class="pay-table_th">
                        <th width='2%'></th>
		                <th width='14%'>付款单号</th>
       				    <th width='12%'>付款单金额</th>
                        <th width='12%'>实付金额</th> 			   		    
   			   		    <th width="17%">付款时间</th>
                        <th width="17%">付款方式</th>
	                    <th width="10%">
	                   		<select id="form_paymentStatusChk" name="form_paymentStatusChk" onchange="SearchByStatus(this)">
	                   			<option value="-1"  <%if(paymentStatus==-1){%> selected <%}%>>全部状态</option>
	                   			<option value="0" <%if(paymentStatus==0){%> selected <%}%>>待付款</option>
	                   			<option value="1" <%if(paymentStatus==1){%> selected <%}%>>待确认</option>
	                   			<option value="2" <%if(paymentStatus==2){%> selected <%}%>>已付款</option>
                                <option value="3" <%if(paymentStatus==3){%> selected <%}%>>贷款失败</option>
                                <option value="4" <%if(paymentStatus==4){%> selected <%}%>>部分还款</option>
                                <option value="5" <%if(paymentStatus==5){%> selected <%}%>>已还款</option>
                                <option value="6" <%if(paymentStatus==6){%> selected <%}%>>付款失败</option>
	                   		</select>
	                   </th>
		               <th  width="16%">操作</th>
	               </tr>
               <tbody >
            <%if(paymentList.length==0){ %>
            	<tr>
            		<td colspan="8" class="pay-no_order"><strong>无查询结果！</strong></td>
            	</tr></table>
            <% }else{ %>
		       <% 
                /**
                 * 遍历付款单集合，回显相关字段               
                 */
                for(var i=0;i<paymentList.length;i++){ 
				
                var payment= paymentList[i];
                var paymentStatus=payment.status;
	            var isEmpty= paymentList[i].hasOrder;
                var paymentAmount = payment.payAmount;         
                 %>
                  <tr id="mainOrder<%=payment.paymentID%>" <% if(i%2==1){%>class="pay-table_bgtr"<%}%> >
                        <td>
                            <% if(isEmpty=='1'){%>
                               <span id="jiahao<%=payment.paymentID%>" class="pay-add" onclick="jiahaoshow(<%=payment.paymentID%>)">+</span>
                 			   <span id="jianhao<%=payment.paymentID%>" class="pay-add" onclick="jianhaoshow(<%=payment.paymentID%>,<%=i%>)" style="display: none;">-</span>                 			
                 			<% }%>
                        </td>
                 		<td class="pay-tab_detail">               									
                            <a href="javascript:void(0);" onclick='paymentDetail(this)' paymentId=<%=payment.paymentID%> ><%=payment.paymentID%>(详情)</a>
                 		</td>
                 		  
		                <td class="pay-tab_money"><!--付款单金额-->
		                 	<span>￥<%=paymentAmount%></span>
                 		</td> 
                        <td  class="pay-tab_money"><!--实付金额-->
		                 	<span>￥<%=payment.rsv1==null?0:payment.rsv1%></span>
                 		</td>                 		
                 		<td class="pay-tab_time">
                 			<span><%=payment.payTime %></span>
		                </td>
                        <td class="pay-tab_status">
		                	<span ><%=paymentMethodII[payment.payMethod==null?0:payment.payMethod]%></span>
		                </td>
                 		<td class="pay-tab_status">
		                	<%=paymentDisplayII[paymentStatus] %>		                    			                    	
                 		</td>
                 		<td>
		                    <p><span>
		                    	<% if(paymentStatus=='0'){ %>		                  		
		                    		<a class="pay-btn_pay" href="javascript:void(0);" onclick='gotoPay(this)' orderStatus='0' oId='<%=payment.paymentID%>' >  <% if(payment.payMethod=='53'){%>贷款<% }else{%>付款<% }%> </a>
                         			<a class="pay-btn_pay" href="javascript:void(0);" onclick="doEasyPay('<%=payment.paymentID%>')">易付</a>
									<a class="pay-btn_del" href="javascript:void(0);" onclick='deletePayment(this)' orderStatus='0' oId='<%=payment.paymentID%>' >取消</a>
                         		                         	
	                         	<% }else if(paymentStatus=='2'){%>
                         			<a class="pay-btn_del" href="javascript:void(0);" onclick='paymentDetail(this)' paymentId=<%=payment.paymentID%>>查看</a>
                         	
	                         	<% }else if(paymentStatus=='3'){%>
									<a class="pay-btn_pay" href="javascript:void(0);" onclick="doEasyPay('<%=payment.paymentID%>')">易付</a>
	                         		<a class="pay-btn_pay" href="javascript:void(0);" onclick='gotoPay(this)' orderStatus='0' oId='<%=payment.paymentID%>'>重新支付</a>                       		
                         			<a class="pay-btn_del" href="javascript:void(0);" onclick='deletePayment(this)' orderStatus='0' oId='<%=payment.paymentID%>' >取消</a>
                         	
                         	   <% }else if(paymentStatus=='6'){%>
									<!--<a class="pay-btn_pay" href="javascript:void(0);" onclick="doEasyPay('<%=payment.paymentID%>')">易付</a>-->
                         			<a class="pay-btn_del" href="javascript:void(0);" onclick='deletePayment(this)' orderStatus='0' oId='<%=payment.paymentID%>' >取消</a>
							   <% }%>
		                    </span></p>
                 		</td>
             		  </tr>
					  <tr id="showrelatedorder<%=payment.paymentID%>"></tr>
            
			   <% }%>
	             	
               </tbody>
              
</table>
 
<% }%>
</div>
</script>


<script id="paymentsearchdefault1" type="text/html">
		<table width="100%">
			<form id="advance_form">				 
				 <tr>
				    <td>付款单编号：</td>
				    <td><input id="form_order_no" name="form_order_no" type="text" class="pay-input" /></td>
				    <td>生成日期：</td>
				    <td><input id="form_create_start_time" name="form_create_start_time" type="text" class="pay-input1" onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });" />&nbsp;-&nbsp;
        			<input id="form_create_end_time" name="form_create_end_time" type="text" class="pay-input1" onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });" /></td>
				  </tr>                 
				  <tr>
				    <td>分公司编号：</td>
				    <td><input id="form_sellerid" name="form_sellerid" type="text" class="pay-input" /></td>
					<td>分公司名：</td>
					<td><input id="form_sellername" name="form_sellername" type="text" class="pay-input" />&nbsp;&nbsp;&nbsp;
				    <a class="pay-btn_search"  href="#" id="searchLink" onclick="SearchByKey(this);">搜索</a>&nbsp;<a class="pay-btn_clear" href="#" onclick="paymentSum();">汇总</a>&nbsp;<a class="pay-btn_clear" href="#" onclick="clean();">重置</a></td>
  				  </tr>				  
			</form>
		</table> 
</script>

<script id="paymentsearchdefault" type="text/html">
		<table width="100%">
			<form id="advance_form">
				  <tr>
				    <td>付款单编号：</td>
				    <td><input id="form_order_no" name="form_order_no" type="text" class="pay-input" /></td>
				    <td>生成日期：</td>
				    <td><input id="form_create_start_time" name="form_create_start_time" type="text" class="pay-input2" onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });" />&nbsp;-&nbsp;
        			<input id="form_create_end_time" name="form_create_end_time" type="text" class="pay-input2" onclick="WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){},minDate:'2000-00-00' });" /></td>			  
				    <td colspan="2"><a class="pay-btn_search"  id="searchLink" href="#" onclick="SearchByKey(this);">搜索</a>&nbsp;<a class="pay-btn_clear" href="#" onclick="paymentSum();">汇总</a>&nbsp;<a class="pay-btn_clear" href="#" onclick="clean();">重置</a></td>
				  </tr>
			</form>
		</table> 
</script>


<script id="relatedOrder_tpl" type="text/html">
<td colspan='8' id='ordertable<%=paymentID%>' class='pay-add_td'>
<table style="width:100%">
	    <tr>
		    <th>订单号</th>
            <th>客户编号</th>
       		<th>订单金额</th>
   			<th>下单时间</th>
            <th>订单状态</th>
	    </tr>
        <tbody >
               <%
                for(var i=0;i<relatedOrderList.length;i++){ 				
                    var relatedOrder = relatedOrderList[i];
                    var orderNo = relatedOrder.orderNo;
                    var customerId = relatedOrder.customerId;
	                var orderAmount = relatedOrder.orderAmount;
                    var orderTime = relatedOrder.orderTime;  
                    var orderStatus = relatedOrder.orderStatus;       
                 %>
                  <tr <% if(i%2==1){%>class="pay-bg1"<% }else{ %> class="pay-bg"<% } %> >                      
                 		<td ><%=orderNo%></td>                 		  
		                <td ><%=customerId%></td> 
                        <td ><%=orderAmount%></td> 
                 		<td ><%=orderTime%></td>  
                        <td ><%=orderDisplayII[orderStatus]%></td>            		
             	  </tr> 
                <%}%>                 
        </tbody>             
</table> 
</script>

<!-- 易付支付结果详请 -->
<script id="payResult" type="text/html">
<div class="pop_window_title"><i></i>易付支付结果汇总 <span>
	<%if(isSuccessPay == '1'){%>
	<a href="javascript:closeWin('1')" title="关闭">×</a></span>
	<%}else{%>
	<a href="javascript:closeWin()" title="关闭">×</a></span>
	<%}%>
</div>
<div class="clifycont"  style="padding-bottom:0px;">
	<div class="bg_td bb_tb pad10 h25 f3">
		<p class="fl_l f14" style="padding-bottom:0px;">
			<% if (successList == null || successList.length == 0){ %>
				<span class="fw lin_h25 ">
					<font class="f1" align="center">本次支付没有成功信息！</font>			
				</span>
			<%}else {%>
				<span class="fw lin_h25 ">支付成功单据号：
					<% for(var i=0; i<successList.length;i++) {%>
						<font class="f1"><%=successList[i].transNo%></font>
					<% }%>
				</span>
			<%}%>
		</p>
	</div>
<div class="bg_td bb_tb pad10 h25 f3" style="border-top:0px solid #eaeaea;">
		<p class="fl_l f14">
				<span class="fw lin_h25 ">支付成功总额：
					<font class="f1">
						￥<%=totalAmount%>
					</font>
				</span>
		</p>
</div>
	<div class="pad20 pad_t10">
		<div class="cont-p">
			<div  id="payFaildList">
				
			</div>
		</div>
		<p class="fl_r pad10" id="easyPager"></p>
	</div>
</div>		  
</script>	

<script id="payFaildDetail" type="text/html">
<div class="bg_title h30 lin_h30 pad_l10 fw f3">支付失败明细</div>
					<table width="100%" class="table1">
						<% if (failedList.length == 0){ %>
							<tr>
								<td colspan="7" align="center">暂无支付失败信息！</td>
							</tr>
						<%}else {%>
						<tr>
							<th width="15%">单据编号</th>
							<th width="15%">失败原因</th>
						</tr>
							<% for (var i=0; i<failedList.length; i++){%>
								<% if(i%2==0){%>
									<tr>
								<% }else{%>
									<tr class="bg_tr1 bb_tb">
								<%}%>
									<td><%=failedList[i].orderNo%></td>
									<td><%=failedList[i].retMsg%></td>
								</tr>
							<% } %>
						<% } %>
					</table>
</script>


<script id="commitResult" type="text/html">
<div class="pop_window_title"><i></i>易付提交结果汇总 <span>
	<a href="javascript:closeWin()" title="关闭">×</a></span>
</div>
<div class="clifycont"  style="padding-bottom:0px;min-height:150px;">
<div class="bg_title h30 lin_h30 pad_l10 fw f3"  style="text-align:center;">提交结果明细</div>
					<table width="100%" class="table1">
						<% if (dataList.length == 0){ %>
							<tr>
								<td colspan="7" align="center">暂无提交信息！</td>
							</tr>
						<%}else {%>
						<tr>
							<th width="20%">单据编号</th>
							<th width="20%">批次号</th>
							<th width="20%">客户编号</th>
							<th width="20%">客户名称</th>
							<th width="20%">提交结果</th>
						</tr>
							<% for (var i=0; i<dataList.length; i++){%>
								<% if(i%2==0){%>
									<tr>
								<% }else{%>
									<tr class="bg_tr1 bb_tb">
								<%}%>
									<td><%=dataList[i].billNo%></td>
									<td><%=dataList[i].batchNo%></td>
									<td><%=dataList[i].customerId%></td>
									<td><%=dataList[i].customerName%></td>
									<%if(dataList[i].isSucc=='1'){ %>
									<td>提交成功</td>
									<%}else{ %>
									<td class="f1"><%=dataList[i].retMsg%></td>
									<%} %>
								</tr>
							<% } %>
						<% } %>
					</table>

</div>
</div>
</script>