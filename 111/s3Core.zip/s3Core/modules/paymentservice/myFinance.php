<script src="<?php echo $root_path ?>modules/paymentservice/js/myFinance.js" type="text/javascript"></script>
<body>

 <div class="dk_Box">
    <div class="dk_title">"我的贷款"简介</div>
    <p class="dk_jjie"><strong>贷款</strong>功能旨在为有融资需求的企业和个人建立起高效、透明、安全、便捷的互联网金融服务。</p>
    <p class="dk_fuwu">
       <strong>服务特色：</strong><br />
       <span style="margin-top:15px;">1.丰富的贷款业务品种</span>
        <span>2.专业的客户经理团队</span>
         <span>3.完善的增值服务体系</span>
    </p>
    <div class="btn_g_gyjf asty" ><a href="javascript:void(0);" onclick='gotoMyFinance(this)'>我的贷款</a></div>
  
 </div>   
      
</body>
</html>
