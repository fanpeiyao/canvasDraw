<!DOCTYPE html>
<html>
<?php
	 require_once '../../~main/ctx.php';
	$reqdata =$_REQUEST['reqdata'];
	$signature = $_REQUEST["signature"];
	$params= array(
			"reqdata"=>$reqdata,
			"signature"=>$signature		
	);
	execjava('accountsArriveNotifyBean.accountsArriveNotify',$params,'php','paymentservice');	
?>