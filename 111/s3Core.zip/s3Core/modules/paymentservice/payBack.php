<!DOCTYPE html>
<html>
<?php
	 require_once '../../~main/ctx.php';
	$reqdata =$_REQUEST['reqdata'];
	$signature = $_REQUEST["signature"];
	$transtype = $_REQUEST["transtype"];
	$params= array(
			"reqdata"=>$reqdata,
			"signature"=>$signature,
            "transtype"=>$transtype		
	);
	execjava('payBackBean.payBack',$params,'php','paymentservice');	
?>
