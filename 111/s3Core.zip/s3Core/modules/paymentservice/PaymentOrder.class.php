<?php
require_once 'inc/PropConfig.class.php';

class PaymentOrder{
		
	/**
	 * 获取支付信息
	 * 通过直接url传参方式将付款单号传入
	 *
	 */
	public static function selectPay(){
	
		$param = array('paymentID'=>$_GET["paymentId"]);
		$payInfo = execjava('paymentBean.selectPay', $param, 'php','paymentservice');
	
		if($payInfo["resCode"]!="200"){
				$retmsg = $payInfo["resMsg"];
				$failUrl = "../../~main/errorInfo.php?retmsg=".$retmsg;
				echo "<script language='javascript'>";
				echo " location.href = '$failUrl'";
				echo "</script>";
				return ;
		}
		
			$payUrl = $payInfo["payUrl"];
			$version = $payInfo["version"];
			$merid = $payInfo["merid"];
			$trancode = $payInfo["trancode"];
			$charset = $payInfo["charset"];
			$signature = $payInfo["signature"];
			$reqdata = $payInfo["reqdata"];
			echo "<form  id='payform' name='payform' action='$payUrl' method='post'>";
			echo "<input type=hidden id='version'  name='version' value='$version'>";
			echo "<input type=hidden id='charset'  name='charset' value='$charset'>";
			echo "<input type=hidden id='merid'  name='merid' value='$merid'>";
			echo "<input type=hidden id='signature'  name='signature' value='$signature'>";
			echo "<input type=hidden id='trancode'  name='trancode' value='$trancode'>";
			echo "<input type=hidden id='reqdata'  name='reqdata' value='$reqdata' >";
			echo "</form>";
			echo "<script language='javascript'>";
			echo " document.getElementById('payform').submit();";
		 echo "</script>";
		 return ;
	}
	
	/**
	 *跳转工银聚富
	 *
	 */
	public static function selectGYJF(){
	
		$payInfo = execjava('myFinancingBean.doGYJF', null, 'php','paymentservice');
	
		if($payInfo["resCode"]!="200"){
			$retmsg = $payInfo["resMsg"];
			$failUrl = "../../~main/errorInfo.php?retmsg=".$retmsg;
			echo "<script language='javascript'>";
			echo " location.href = '$failUrl'";
			echo "</script>";
					return ;
		}
	
		$gyjfurl = $payInfo["gyjfurl"];
		$version = $payInfo["version"];
		$merid = $payInfo["merid"];
		$trancode = $payInfo["trancode"];
		$charset = $payInfo["charset"];
		$signature = $payInfo["signature"];
		$reqdata = $payInfo["b64reqdata"];
								 
		 echo "<form  id='payform' name='payform' action='$gyjfurl' method='post'>";
		 echo "<input type=hidden id='version'  name='version' value='$version'>";
		 echo "<input type=hidden id='charset'  name='charset' value='$charset'>";
		 echo "<input type=hidden id='merid'  name='merid' value='$merid'>";
		 echo "<input type=hidden id='signature'  name='signature' value='$signature'>";
		 echo "<input type=hidden id='trancode'  name='trancode' value='$trancode'>";
		 echo "<input type=hidden id='reqdata'  name='reqdata' value='$reqdata'>";
		 echo "<input style='display: none' type='submit' value='Submit'/>";
		 echo "</form>";
		 echo "<script language='javascript'>";
			echo " document.getElementById('payform').submit();";
		 echo "</script>";
		 return ;
	}
	
	
	/**
	 *跳转工银聚财
	 *
	 */
	public static function selectGYJC(){
	
		$payInfo = execjava('myFinancingBean.doGYJC', null, 'php','paymentservice');
	
		if($payInfo["resCode"]!="200"){
			$retmsg = $payInfo["resMsg"];
			$failUrl = "../../~main/errorInfo.php?retmsg=".$retmsg;
			echo "<script language='javascript'>";
			echo " location.href = '$failUrl'";
			echo "</script>";
			return ;
		}
	
		$gyjcurl = $payInfo["gyjcurl"];
				$version = $payInfo["version"];
						$merid = $payInfo["merid"];
						$trancode = $payInfo["trancode"];
						$charset = $payInfo["charset"];
						$signature = $payInfo["signature"];
						$reqdata = $payInfo["b64reqdata"];
	
						echo "<form  id='payform' name='payform' action='$gyjcurl' method='post'>";
						echo "<input type=hidden id='version'  name='version' value='$version'>";
						echo "<input type=hidden id='charset'  name='charset' value='$charset'>";
						echo "<input type=hidden id='merid'  name='merid' value='$merid'>";
						echo "<input type=hidden id='signature'  name='signature' value='$signature'>";
						echo "<input type=hidden id='trancode'  name='trancode' value='$trancode'>";
						echo "<input type=hidden id='reqdata'  name='reqdata' value='$reqdata'>";
			echo "<input style='display: none' type='submit' value='Submit'/>";
			 echo "</form>";
			echo "<script language='javascript'>";
			echo " document.getElementById('payform').submit();";
						echo "</script>";
				return ;
		}
	
	
	/**
	 *跳转我的贷款
	 *
	 */
	public static function selectMyFinancing(){
	
		$payInfo = execjava('myFinancingBean.doMyFinancing', null, 'php','paymentservice');
	
		if($payInfo["resCode"]!="200"){
			$retmsg = $payInfo["resMsg"];
			$failUrl = "../../~main/errorInfo.php?retmsg=".$retmsg;
			echo "<script language='javascript'>";
			echo " location.href = '$failUrl'";
			echo "</script>";
			return ;
		}
	
		$myFinancingurl = $payInfo["myFinancingurl"];
				$version = $payInfo["version"];
						$merid = $payInfo["merid"];
						$trancode = $payInfo["trancode"];
						$charset = $payInfo["charset"];
						$signature = $payInfo["signature"];
						$reqdata = $payInfo["b64reqdata"];
	
						echo "<form  id='payform' name='payform' action='$myFinancingurl' method='post'>";
						echo "<input type=hidden id='version'  name='version' value='$version'>";
						echo "<input type=hidden id='charset'  name='charset' value='$charset'>";
						echo "<input type=hidden id='merid'  name='merid' value='$merid'>";
						echo "<input type=hidden id='signature'  name='signature' value='$signature'>";
						echo "<input type=hidden id='trancode'  name='trancode' value='$trancode'>";
						echo "<input type=hidden id='reqdata'  name='reqdata' value='$reqdata'>";
			echo "<input style='display: none' type='submit' value='Submit'/>";
			 echo "</form>";
			echo "<script language='javascript'>";
			echo " document.getElementById('payform').submit();";
						echo "</script>";
				return ;
		}
		
		/**
		 * 取得默认配置的参数
		 *
		 * @param key为参数值
		 * @return 返回session中与配置服务器中对比后的参数
		 */
		public static function getConfigValue($key) {
			//从后台获取相应的配置信息
			$para = array('payment_key'=>$key);
			$result = execjava('paymentBean.getConfigValue',$para,'php','paymentservice');
			if($result["resCode"]!="200"){
				$retmsg = $result["resMsg"];
				$failUrl = "../../~main/errorInfo.php?retmsg=".$retmsg;
				echo "<script language='javascript'>";
				echo " location.href = '$failUrl'";
				echo "</script>";
				return ;
			}
			return $result[$key];
		}
		
		/**
		 * 获取付款单详情信息
		 * 通过直接url传参方式将付款单号传入
		 *
		 */
		public static function getPaymentDetail(){
		
			$param = array('paymentID'=>$_GET["paymentId"],'customerId'=>$_GET["customerId"],'customerName'=>$_GET["customerName"]);
			$ret = execjava('paymentBean.getPaymentDetail', $param, 'php','paymentservice');
		
			if($ret["resCode"]!="200"){
				$retmsg = $ret["resMsg"];
				$failUrl = "../../~main/errorInfo.php?retmsg=".$retmsg;
				echo "<script language='javascript'>";
				echo " location.href = '$failUrl'";
				echo "</script>";
				return ;
			}
			return $ret;
		}
		
}

?>