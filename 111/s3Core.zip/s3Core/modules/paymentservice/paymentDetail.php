<?php
	require_once 'tpl/paymentDetail_tpl.php';
	require_once 'tpl/financingRepay_tpl.php';
?>
<script src="<?php echo $root_path ?>modules/paymentservice/js/paymentConfig.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/paymentservice/js/paymentDetail.js" type="text/javascript"></script>

<div class="main">
   <div class="pay-wrapper">
    <div class="pay-main">
     <!--内容1--> 
     <?php if($id=="1"){//表示经销商登陆?>   
     <p class="pay-detail_title">付款单详情</p>  
     <?php }elseif($id=="2"){?>
     <p class="pay-detail_title">收款单详情</p>  
     <?php }?>  	  
     <div id="paymentDetail"></div>
     <div class="clear">&nbsp;</div>  
    </div>
  </div>  
</div>    
	
     
    
<!--付款单详情页面end-->
