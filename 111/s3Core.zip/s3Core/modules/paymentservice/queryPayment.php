<?php   
	require_once 'tpl/queryPayment_tpl.php';
?>
<script src="<?php echo $root_path ?>modules/paymentservice/js/paymentConfig.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/paymentservice/js/queryPayment.js" type="text/javascript"></script>		

<!-- 业务员付款单查询显示主体 --> 
   <div class="payment-border">
		<div class="payment-side"> 请选择筛选条件:</div> 
        <!-- 业务员付款单查询第一块内容：搜索模块 -->
   			     
		  <div class="mypayment_search" id="querypaymentSearch">
			  <!-- <a id="downFile" target="downIFrame" style="display:none;">下载</a>
			  <iframe name="downIFrame" style="display:none;"></iframe>   -->  
		  </div>
		  <div class="clear"></div>
		  		  
		  		  
		  <!-- 业务员付款单查询第二块内容：付款单显示模块 -->
		  <p class="payment-inner">
			<span><i></i>全部收款单</span></p>
		      <!-- 明细 -->
		      <div id="detailPayment" style="display:none"></div>		      
		      <!-- 页码 -->
		      <div id="pager" class="pay-page"></div>		  	  
		  	  <!--汇总-->
		      <div id="collectPayment" style="display:none"></div>
		      <div class="clear"></div>
		    	  		  
   </div>    

</div>
	
		

