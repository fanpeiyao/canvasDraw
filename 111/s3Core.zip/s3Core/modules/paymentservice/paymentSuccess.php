<?php require_once '~main/ctx.php';?>
<?php   
	require_once 'tpl/paymentList_tpl.php';
?>
<script src="<?php echo $root_path ?>modules/paymentservice/js/PaymentOrder.class.js" type="text/javascript"></script>
<script src="<?php echo $root_path ?>modules/paymentservice/js/myPayment.js" type="text/javascript"></script>
<div class="main">
	<div class="pay-wrapper">
		<div class="pay-main">
     		<div class="pay-suc">
	          <p class="pay-suc_title"><span > 付款单生成成功！</span> </p>
	          <p>付款单编号：<span class="pay-tab_num"><?php echo $_GET["paymentId"]?></span>&nbsp;已生成，正在等待支付。</p>
	          <p class="pay-suc_btn">
	          	<a class="pay-btn_mypay" href="javascript:void(0);" onclick="doSucceEasyPay('<?php echo $_GET["paymentId"]; ?>')">易付支付</a>&nbsp;
	         	<a class="pay-btn_mypay" href="javascript:void(0);" onclick='gotoPay(this)' rootpath='<?php echo $root_path ;?>' orderStatus='0' oId='<?php echo $_GET["paymentId"]; ?>'>支付</a>&nbsp;
	          	<a class="pay-btn_back" href="<?php echo $root_path ?>~main/share/frame.php?target=myPayment" >我的付款单</a>				
			  </p>  
			  <div class="pay-suc_reminder">
			        <p><strong class="f3">温馨提示：</strong></p> 
			        <p class="f8">
			        	1.我们将在24小时与您联系确认订单情况，并且安排仓库发货；<br/>
			        	2.每天18：00以前的订单将在当天发货，18：00以后的订单将在第二天发货；<br/>
			        	3.发货成功后，我们会往您的邮箱中发送一份发货通知，您可以根据邮件中提示的物流信息，或在"我的订单"中查询物流信息进行跟进；<br/>
			        	4.特殊商品在签收后非质量问题，不予退换。<br/>
			                                         感谢您的光临，祝您购物愉快！
			        </p>
	     	   </div>
     		</div>
     	</div>	
	</div>
</div>
<div id="fullbg" class="pop_shadow"></div>
<div class="popupsty pop_window_box" id="easyPayResult" style="display: none;"></div>