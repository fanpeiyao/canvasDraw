<div id="fullbg" class="pop_shadow"></div>
<div class="popupsty pop_window_box" id="paymentSum" style="width: 50%">
	<div class="pop_window_title">
		<i></i>付款单汇总信息 <span><a href="javascript:closeBg('paymentSum')">×</a> </span>
	</div>
	<div class="pad10">
		<table class="table1" width="100%">
			<tr>
				<td>付款单总数</td>
				<td>总金额数</td>
			</tr>
			<tr>
				<td id="paymentCountSumValue"></td>
				<td id="paymentAmountSumValue"></td>
			</tr>
		</table>
	</div>
	<p>
		<a href="javascript:closeBg('paymentSum')" class="btn_small skin_btn_dark" style="margin-top:0px">关闭</a>
	</p>
</div>