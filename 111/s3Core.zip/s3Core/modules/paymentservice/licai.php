﻿<script src="<?php echo $root_path ?>modules/paymentservice/js/licai.js" type="text/javascript"></script>
<?php  
	require_once 'PaymentOrder.class.php';
?>

<!--页面 start-->
<div class="main-gyjc"> 
  <!--工银聚财 start-->
  <div class="gyjc-main">
    <div class="pad20">
      <p class="gyjc_title"><span>"工银聚"系列基金产品简介</span></p>
      <p class="gyjc_p">"工银聚"系列基金产品是工商银行基于与工银瑞信的业务合作和系统对接，专为个人及企业客户提供的一项"现金管理"和"投资理财型"专属金融服务，包括两大产品：工银聚财（企业客户适用）和工银聚富（个人客户适用）。</p>
    </div>
    <div class="gyj-reminder">
      <p>★ 申购全自动：个人客户签约后，每个工作日下午，为您自动申购工银聚富。<br />
         ★ 申购随心意：企业客户提供"手动申购"功能，您任意时间均可提交"工银聚财"产品申购意向。 <br />
         ★ 赎回瞬时到：7*24小时随时可发起赎回，资金T+0实时到账。 <br />
         ★ 天天有收益：每天计算收益，自动本金再投，收益可查可赎回。<br />
         注：证券工作日15:00前及非工作日申购，T+1工作日确认并起息，证券工作日15:00后申购，T+2工作日确认并起息。<br /></p>
      <p class="mar_t20 mar_b20"><a href="javascript:void(0);" onclick='gotoGYJF(this)' rootpath='<?php echo $root_path ?>' class="btn-gyjf">工银聚富(个人)</a> 
      <a href="javascript:void(0);" onclick='gotoGYJC(this)' rootpath='<?php echo $root_path ?>' class="btn-gyjc">工银聚财(企业)</a></p>
      <p> <b class="f_red">温馨提示：</b><br/>
        个人签约申购工银聚富需要绑定<strong class="f16">浙江省工行开立的借记卡。</strong><br/>
      企业签约申购工银聚财可绑定<strong class="f16">全国任一工行对公结算账户。</strong> </p>
    </div>
  </div>
  <!--工银聚财 end--> 
  
 
</div>
<!--页面 end--> 
