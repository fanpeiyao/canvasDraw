﻿<?php  
	require_once 'PaymentOrder.class.php';
?>
<script src="<?php echo $root_path ?>modules/paymentservice/js/PaymentOrder.class.js" type="text/javascript"></script>


<body class="body_gyjf">					
			<div class="bg_g_gyjf">
			  <p class="title_g_gyjf">"工银聚富"简介</p>
			  <p class="wz1_g_gyjf mar_t30_gyjf">"<span class="red_g_gyjf"><b>工银聚富</b></span>"是工商银行基于与工银瑞信的业务合作和系统对接，为您提供的一项“现金管理”和“投资理财型”专属金融服务。您签约后，工商银行将为您提供自动购买其代理的工银货币基金，以及赎回、查询等交易服务。</p>
			     <p class="wz1_g_gyjf wz2 mar_t30_gyjf">
			  <span class="red_g_gyjf"><b>主要服务内容包括：</b></span></p>
			     <p class="wz1_g_gyjf wz2"><b>★购买全自动：</b>每个工作日下午，为您自动购买工银聚富。</p>
			     <p class="wz1_g_gyjf wz2"><b>★赎回瞬时到：</b>您发起赎回工银聚富，资金T＋0实时到账。</p>
			     <p class="wz1_g_gyjf wz2"><b>★天天有收益：</b>工银聚富每天计算收益，收益可查可赎回。</p>
			  <p class="wz1_g_gyjf wz2"><b>★季季利滚利：</b>每季末自动赎回本息，次日本利自动再投资。 </p>
			     <p class="wz1_g_gyjf wz2 red_g mar_t30"><b>温馨提示：</b></p>
			     <p class="wz1_g_gyjf wz2">购买工银聚富需要绑定浙江省工行借记卡。</p>
			     <p class="mar_t50_gyjf pad_b_gyjf"><a class="btn_g_gyjf" href="javascript:void(0);" onclick='gotoGYJF(this)' rootpath='<?php echo $root_path ?>'>我的工银聚富</a></p>
			</div>
</body>
</html>