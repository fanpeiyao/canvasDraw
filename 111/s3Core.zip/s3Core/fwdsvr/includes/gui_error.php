<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" >
<title>内部服务器错误</title>
<style>
body {font-family: Arial,Verdana, "Lucida Grande","Microsoft Yahei", Helvetica, sans-serif}
h2 { color:#FF0000; }
em {color:#0000FF; }
.a {color:#FF0000;}
</style>
<script type="text/javascript">
//<!--
var k={tb:function(){var a = document.getElementById('ret_body');if(!a){alert();return;}if(a.style.display==""){a.style.display="none";}else{a.style.display="";}}};
//-->
</script>
</head>
<body>
<h2><span style="color:#000000;"><?php if($eobj['status']<1000){ echo 'Error';}else{ echo 'Proxy';}?>: </span><i><?php echo fetch_error((int)$eobj['status']);?></i></h2>
<p>对不起，出错了！服务器在访问以下链接<span style="font-family:monospace;"><?php echo preg_replace('~>~','&gt;',preg_replace('~<~','&lt;',$url));?></span>
<br>时遇到了一些问题，请检查访问url的正确性。如果仍无法解决，请联系管理员。<br>
<a href="javascript:history.back();"><br>回到上一页</a></p>
</body></html>