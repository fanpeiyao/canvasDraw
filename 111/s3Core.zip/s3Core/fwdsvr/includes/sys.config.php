<?php

$GLOBALS['_APP_ADDRESS'] = array(
		"s3Config"=>array('http://109.6.29.48:9012/s3Config/'),
		"usermanage"=>array('http://109.5.13.122:9082/usermanageTest/'),
);

?>