// JavaScript Document
//<!--


/**
 * EvenetManager类
 */


var EvenetManager={
	/**
	 * 获取当前事件
	 */
	getEvent:function () {
		return window.event || arguments[0] || arguments.callee.caller.arguments[0];
	},
	/**
	 * 获取当前事件的节点
	 */
	getElement:function(){
		var evt = this.getEvent();
		return evt.target ? evt.target : evt.srcElement;
	},

	/**
	 * 删除指定元素指定事件
	 * 指定元素
	 * 事件类型
	 */

	removeEvent:function (node,event,fun) {
		if (node.addEventListener){
			node.removeEventListener(event,fun,false)
		}else if(node.attachEvent){
			node.datachEvent('on'+event,fun);
		}else{
			delete node['on'+event];
		}
	},
	/**
	 * 兼容性的添加事件
	 * 指定元素
	 * 事件类型
	 * 执行函数
	 */
	addEventType:function (node,event,fun) {
		if (node.addEventListener){
			node.addEventListener(event,fun,false);
		}else if (node.attachEvent){
			node.attachEvent('on'+event,fun);
		}else{
			node['on'+event]=fun;
		}
		node['listener-'+event]=!0;
	},


	/**
	 * 获取指定元素上的所有绑定事件
	 * 指定元素
	 */
	getNodeEvent:function (node) {
		var types =['blur','focus','click','dbclick','mouseover','mousedown','mouseup','mousemove','mouseout','mouseenter','mouseleave','change','load','unload','resize','scroll','select','submit','keydown','keypress','keyup','error'];
		var newTypes = [];
		for (i in types) {
			if (node['on' + types[i]] || node['listener-' + types[i]] || node.getAttribute('on' + types[i])) {
				newTypes.push(types[i])
			}
		}
		return newTypes;
	},
	
	/**
	 * 执行指定元素上的指定事件.
	 * 第一个参数是指定元素.
	 * 第二个参数是指定事件参数名.
	 */
	doElementEvent:function(node, att){
		if(!node || node == document || !node.tagName || node.tagName.toLowerCase() == 'html') return;
		var fn = node.getAttribute(att);
		if(fn && typeof fn != 'object'){
			var fns = fn.split(',');
			for(var i = 0, len = fns.length; i < len; i++){
				var fnName = fns[i];
				var fun = functionList[fnName];
				if(typeof fun == 'function') fun.call(node, getParams(node));
			}
		}
		doElementEvent(node.parentNode, att);
	},
	/**
	 * 事件委派绑定
	 * @param node 绑定事件的元素
	 * @param event 绑定的事件
	 * @param 执行的事件对象
	 */
	bindEvent:function (node,event,listeners) {
		this.addEvent(node,event,function (e) {
			var ev=e||window.event,target=ev.target||ev.srcElement,event,returnVal;
			while(target&&target!==node){
				event=target.getAttribute('event');
				if (listeners[event]){
					returnVal=listeners[event]({
						target:target,
						e:ev,
						event:event
					});
					if (returnVal==false){
						break;
					}
				};
				target=target.parentNode;
			}

		});
	},
	


	addEvent:function (obj,type,handle) {
		if(!obj||!type||!handle){
			return ;
		};
		//绑定事件到多个对象
		if(obj instanceof  Array){
			for (var i=0,len=obj.length;i<len;i++){
				this.addEvent(obj[i],type,handle);
			}
			return ;
		};
		//绑定多个事件
		if(type instanceof  Array){
			for (var i=0,len=type.length;i<len;i++){
				this.addEvent(obj,type[i],handle);
			}
			return ;
		};
		//记录当前页面共绑定了多少事件，及相关信息
		window.allHandlers=window.allHandlers||{};
		window.Hcounter=window.Hcounter|| 0;
		function setHandler(obj,type,handler,wrapper) {
			obj.hids=obj.hids||[];
			var hid='h'+ ++window.Hcounter;
			obj.hids.push(hid);
			window.allHandlers[hid]={
				type:type,
				handler:handler,
				wrapper:wrapper
			}
		};
		console.dir(window.allHandlers)
		// alert(window.Hcounter)
		function createDelegate(handle,context) {
			return function () {
				return handle.apply(context,arguments);
			}
		};
		if (window.addEventListener){
			var wrapper=createDelegate(handle,obj);
			setHandler(obj,type,handle,wrapper);
			obj.addEventListener(type,wrapper,false);
		}else if (window.attachEvent){
			var wrapper=createDelegate(handle,obj);
			setHandler(obj,type,handle,wrapper);
			obj.attachEvent('on'+type,wrapper);
		}else{
			obj['on'+type]=handle;
		}
	},




};








/**
 * 获取参数列表 
 */
var getParams = function(node){
    var paramStr = node.getAttribute('params');
    if(!paramStr || !(paramStr = paramStr.trim())) return null;
    var paramList = paramStr.split(',');
    if(!paramList || !paramList.length) return null;
    var params = {}, keyAndValue;
    for (var i = 0, len = paramList.length; i  < len; i ++) {
        keyAndValue = paramList[i].split('=');
        if(keyAndValue.length != 2) continue;
        params[keyAndValue[0]] = keyAndValue[1];
    };
    return params;
};

/**
 * 根据ID获取节点 
 */
var $$ = function(id){
	return 'string' == typeof id ? document.getElementById(id) : id;
};

window.onload = function(){
	window.document.body.onclick = function(){
    	doElementEvent(getElement(), 'click');
	};
	
	window.document.body.onchange = function(){
	    doElementEvent(getElement(), 'change');
	};
	//清除弹出页面额外的按钮
	if(window.parent && typeof window.parent.cleanButton == 'function') window.parent.cleanButton();
	//执行页面自定义onload方法
	if(typeof functionList.onload == 'function') functionList.onload.call();
	//文本框添加验证事件
	var texts = document.getElementsByTagName('input');
	for(var i = 0, len = texts.length; i < len; i++) verify(texts[i]);
};

/**
 * 给文本框增加验证 
 */
var verify = function(ele){
	if(!ele) return;
	var type = ele.getAttribute('type');
	type = type ? type.toLowerCase() : 'text';
	var verifyType = ele.getAttribute('verifyType');
	if((type != 'text' && type != 'password') || !verifyType || !(verifyType = verifyType.trim())) return;
	var num = ele.getAttribute('verifyNum');
	if(!num){
		num = superjs.rndNum(6);
		ele.setAttribute('verifyNum', num);
		ele.onblur = validation;
	}
	if(ele.value.trim() == '') verifyArray[num] = false;
	else validation(ele);
};

/**
 * 页面中需要验证的文本框验证结果集
 */
var verifyArray = {};

/**
 * 判断是否全部验证通过 
 */
var isCheck = function(){
	for(var num in verifyArray) if(!verifyArray[num]) return false;
	return true;
};

/**
 * 页面加载后又用javascript动态添加一些需要验证的文本框,或者对某些需要验证的文本框有赋值操作,后需要对这些文本框添加或者再次验证.<br />
 * 参数可以为需要添加或者再次验证的文本框节点,或者该节点ID,或者其上级节点,或者上级节点ID.<br />
 * 注:如果有批量文本框需要加或者再次验证,只需要传入包含了这些节点的任一上级节点或者该上级节点ID即可.
 */
var addVerify = function(ele){
	ele = $$(ele);
	if(ele.tagName.toLowerCase() == 'input') verify(ele);
	else{
		var inputs = ele.getElementsByTagName('input');
		if(!inputs || !inputs.length) return;
		for(var i = 0, len = inputs.length; i < len; i++) verify(inputs[i]);
	}
};

/**
 * 添加文本框验证的方法
 */
var validation = function(ele){
	var eve = typeof ele == 'undefined' ? getElement() : ele.target || ele.srcElement || ele;
	var type = eve.getAttribute('type').toLowerCase();
	var verifyType = eve.getAttribute('verifyType');
	if(eve.tagName.toLowerCase() != 'input' || (type != 'text' && type != 'password') || !verifyType || !(verifyType = verifyType.trim())) return;
	var value = eve.value.trim(), isCorrect, msg;
	switch(verifyType){
		case 'noNull' :
			isCorrect = value;
			msg = '不能为空！';
			break;
		case 'number' :
			isCorrect = value && !isNaN(value);
			msg = '必须为数字！';
			break;
		case 'integer' :
			isCorrect = /^\d+$/.test(value); //正整数
			msg = '必须为正整数！';
			break;
		case 'mail' :
			isCorrect = /^[^\.@]+@[^\.@]+\.[a-z]+$/.test(value); //邮箱
			msg = '邮箱格式不正确！';
			break;
		case 'mobile' :
			isCorrect = /1[3-8]+\d{9}/.test(value); //手机
			msg = '手机号码不正确！';
			break;
		case 'phoneORmobile' :
			isCorrect = /^(\d{3,4}-)?\d{7,8}$|^1\d{10}$/.test(value); //手机及固话
			msg = '手机/电话号码不正确！';
			break;
		default:
			isCorrect = true;
	}
	var span = eve.next();
	var hasSpan = span && span.tagName.toLowerCase() == 'span' && span.getAttribute('isVerify') == 'Y';
	var verifyNum = eve.getAttribute('verifyNum');
	if(isCorrect) {
		verifyArray[verifyNum] = true;
		if(hasSpan) span.parentNode.removeChild(span);
	} else{
		verifyArray[verifyNum] = false;
		if(!hasSpan){
			var span = document.createElement('span');
			span.setAtt({isVerify : 'Y', 'class' : 'public'});
			span.innerHTML = msg;
			eve.parentNode.insertBefore(span, eve.next());
		}
	}
};

//当前页码
var page = 1;
//每页显示数量
var pageSize = 15;
//数据总数量
var dataCount = 0;

/**
 * 方法列表. 
 */
var functionList = {
	/**
	* 设置页码数方法
	*/
	setPageNumber : function(){
		if(!dataCount) return;
		var span = $$('pageNumber');
		if(!span) return;
		var bs = span.getElementsByTagName('b');
		bs[0].innerHTML = dataCount; //总数据量
		bs[1].innerHTML = (page - 1) * pageSize + 1; //当前页显示从第几条开始
		bs[2].innerHTML = (page * pageSize) < dataCount ? (page * pageSize) : dataCount; //当前页显示到多少条结束
		bs[3].innerHTML = page; //当前页码
		bs[4].innerHTML = Math.ceil(dataCount / pageSize); //最大页码
		span.next('input').value = '';
	},
	/**
	 * 分页相关方法.
	 * 使用人员需要在js中提供functionList.loadData方法;
	 * 翻页时会调用此方法查询数据,在该方法中可使用page\pageSize\dataCount等全局变量;
	 * 方法中需要设置数据总数量,即页面全局变量dataCount的值.
	 */
	toPage : function(params){
		if(!params || !params.cmd) return;
		var lastPage = Math.ceil(dataCount / pageSize);
		switch(params.cmd){
			case 'first' :
				page = 1;
				break;
			case 'last' :
				page = lastPage;
				break;
			case 'previous' :
				if(page == 1) return;
				page--;
				break;
			case 'next' :
				if(page == lastPage) return;
				page++;
				break;
			case 'set' :
				var pageNum = this.previous('input').value;
				if(!/^\d+$/.test(pageNum) || pageNum > lastPage){
					superjs.alert('跳转页码必须为小于等于最大页码的正整数！');
					return;
				}
				page = pageNum;
				break;
			case 'setSize' :
				pageSize = this.value;
				page = 1;
				break;
			default:
				return;
		}
		if(typeof functionList.loadData != 'function') return;
		functionList.loadData.call();
		functionList.setPageNumber.call();
	},
	/**
	 * 日期控件调用方法 
	 */
	showDate : function(){
		if(typeof WdatePicker == 'function') WdatePicker();
	},
    showDate2 : function(params){
        if(typeof WdatePicker == 'function'){ 
            if(jQuery.isEmptyObject(params)){
                WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',onpicked:function(){updDueDateAll(this.value);},minDate:'%y-%M-%d' });
            }else{
                 WdatePicker({readOnly:true,dateFmt:'yyyy-MM-dd',minDate:'%y-%M-%d' });
            }
            }
    },
	/**
	 * 树形展开折叠方法 
	 */
	showBranch : function(){
		var parent = this.parentNode;
		if(parent.className == 'branch'){
			var branch = this.next('div');
			branch.style.display = branch.style.display == 'block' ? 'none' : 'block';
			this.src = this.src.indexOf('close.gif') > -1 ? 'images/open.gif' : 'images/close.gif';
		}
	},
	/**
	 * Checkbox默认点击方法
	 */
	checkMe : function(){
		var src = this.src.indexOf('no.gif') > -1 ? '../images/yes.gif' : '../images/no.gif';
		this.src = src;
		var div = this.next('div');
        var clickNodeLabel = jQuery(this).next();
        clickNodeLabel.css("color",this.src.indexOf('no.gif') > -1?"black":"red");
		if(div){
			var checkboxs = div.getElementsByTagName('img'), checkbox;
			for(var i = 0, len = checkboxs.length; i < len; i++){
				checkbox = checkboxs[i];
				if(checkbox.getAttribute('type') == 'checkbox') checkbox.src = src;
			}
		}
		functionList.setCheckbox(document.body);
	},
	/**
	 * 设置属性机构中所有 Checkbox
	 */
	setCheckbox : function(obj){
		obj = $$(obj);
		if(!obj) return;
		var getCheckboxs = function(obj){
			obj = $$(obj);
			if(!obj) return obj;
			var imgs = obj.getElementsByTagName('img');
			if(!imgs || !imgs.length) return imgs;
			var newImgs = [], img;
			for(var i = 0, len = imgs.length; i < len; i++){
				img = imgs[i];
				if(img.getAttribute('type') == 'checkbox') newImgs.push(img);
			}
			return newImgs;
		};
		var checkboxs = getCheckboxs(obj), checkbox, div; 
		for(var i = 0, len = checkboxs.length; i < len; i++){
			checkbox = checkboxs[i];
			div = checkbox.next('div');
			if(!div || div.className != 'leaf') continue;
			var cs = getCheckboxs(div), c, checkNum = 0;
			for(var j = 0, size = cs.length; j < size; j++){
				c = cs[j];
				if(c.src.indexOf('yes.gif') > -1 || (c.parent && c.parent.className == 'branch')) checkNum++;
			}
			if(!checkNum) checkbox.src = '../images/no.gif';
			else if(checkNum == cs.length) checkbox.src = '../images/yes.gif';
			else checkbox.src = '../images/half.gif';
		}
	}
};
/**
 * String去空格方法. 
 */
String.prototype.trim = function(){    
    return this.replace(/(^\s*)|(\s*$)/g, '');    
};
/**
 * 批量全部替换 
 */
String.prototype.replaceAll = function(s1,s2){
	return this.replace(new RegExp(s1,'gm'),s2);
};
/**
 * 获取元素在数组中首次出现的位置. 
 */
Array.prototype.indexOf = function(val){
    for (var i = 0, len = this.length; i < len; i++) {  
        if (this[i] == val) {  
            return i;  
        }  
    }  
    return -1;  
};  
/**
 * 从数组中删除指定元素 
 */
Array.prototype.remove = function(val){  
    var index = this.indexOf(val);  
    if (index > -1) this.splice(index, 1);  
};

/**
 * 遍历集合中所以元素并执行指定操作.
 * 参数为要对集合中元素执行的回调方法. 
 */
Array.prototype.foreach = function(fun){
    if(!this.length) return;
    for (var i = 0, len = this.length; i < len; i++) {
        if(typeof fun == 'function')fun(this[i]);
    }
};

/**
 * 格式日期.
 *  参数为日期格式,默认为yyyy-MM-dd
 */
Date.prototype.format = function(style) {
    if(!style || !(style = style.toString().trim())) style = 'yyyy-MM-dd';
    var o = {
        'M+' : this.getMonth() + 1, //month
        'd+' : this.getDate(),      //day
        'h+' : this.getHours(),     //hour
        'm+' : this.getMinutes(),   //minute
        's+' : this.getSeconds(),   //second
        'q+' : Math.floor((this.getMonth() + 3) / 3), //quarter
        'S' : this.getMilliseconds() //millisecond
    };
    if(/(y+)/.test(style)) style = style.replace(RegExp.$1, this.getFullYear().toString().substr(4 - RegExp.$1.length));
    for(var k in o) if(new RegExp('('+ k +')').test(style)) style = style.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(o[k].toString().length));
    return style;
};
/**
 * 获取N天后的时间 
 */
Date.prototype.addDate = function(days){
  return new Date(this.valueOf() + days * 24 * 60 * 60 * 1000);
};
var superjs = {};

/**
 * 从URL中根据key获取参数值
 * 参数为key. 
 */
superjs.getParamFromURl = function(key){
	var arr = document.location.search.substr(1).match(new RegExp('(^|&)' + key + '=([^&]*)(&|$)'));
    if(!arr || !arr.length) return null;
    return arr[2]; 
};
/**
 * 判断对象是否是Array类型.
 */
superjs.isArray = function(obj){
    if(!obj) return false;
    return Object.prototype.toString.call(obj) === '[object Array]';
};

/**
 * html符号替换 
 */
superjs.escapeHtml = function(original) {
    if(!original) return '';
    original = original.toString();
    return original.replace(/(\r)?\n/g, '<br/>').replace(/(["\\])/g, '\\$1').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

};

/**
 * 将json格式的数据转换成json格式的字符串
 */
superjs.toJsonString = function(obj){ 
    if(!obj) return obj;
    var type = typeof(obj);
    if(type == 'object') type = superjs.isArray(obj) ? 'array' : type;
    switch(type){
        case 'string' :
            return '"' + superjs.escapeHtml(obj) + '"';
        case 'number' :  
            return obj;  
        case 'boolean' :
            return obj ? 'true' : 'false';
        case 'object' :
            var strArr = [], val;
            for (var key in obj){
                val = obj[key];
                if(!key || (!val && val !== 0)) continue;
                strArr.push(superjs.toJsonString(key) + ':' + superjs.toJsonString(val));
            }
            return '{' + strArr.join(',') + '}'; 
        case 'array' : 
        	var strArr = [], val;
        	for(var i = 0, len = obj.length; i < len; i++){
        		val = obj[i];
        		if(!val) continue;
        		strArr.push(superjs.toJsonString(val));
        	}
        	return '[' + strArr.join(',') + ']';
        default:  
            return obj;
    }
};

/**
 * 获取上下文路径. 
 */
superjs.getContextPathWithOutPathName = function(){
    var location = document.location;
    var path = location.protocol + '//' + location.hostname;
    if(location.port && location.port != 80){
        path += ':' + location.port;
    }
    return path;
};



/**
 * 获取上下文路径. 
 */
superjs.getContextPath = function(){
    var location = document.location;
    var path = location.protocol + '//' + location.hostname;
    if(location.port && location.port != 80){
        path += ':' + location.port;
    }
    var pathName = decodeURIComponent(document.location.pathname);
    var idx = pathName.substr(1).indexOf('/');
    path += pathName.substr(0, idx + 1) + '/';
    return path;
};

/**
 * 获得站点ID. 
 */
superjs.getCustId = function(){
    var custId = null;
    var searchStr = document.location.search;
    if(searchStr != null){
        var paramAry = searchStr.substr(1).split('&'), ary;
        for (var i = 0, len = paramAry.length; i < len;  i++){
             ary = paramAry[i].split('=');
             if('custId' == ary[0]){
                 custId = ary[1];
                 break;
             }
        }
    }
    if(!custId || !custId.length){
        var pathName = document.location.pathname;
        pathName = decodeURIComponent(pathName);
        var idx = pathName.indexOf('~');
        if(idx > 0){
            pathName = pathName.substr(idx + 1);
            idx = pathName.indexOf('/');
            custId = pathName.substr(0, idx);
            
        }
    }
    if(!custId || !custId.length) return '';
    return custId;
};

/**
 * 获取指定name的Cookie值
 * name: 键
 */
superjs.getCookie = function(name){
    var arr = document.cookie.match(new RegExp('(^| )' + name + '=([^;]*)(;|$)'));
    if(!arr || !arr.length) return null;
    return unescape(arr[2]); 
    
};

/**
 * 设置Cookie值
 * name: 键
 * value: 值
 * days: 时间,单位为天,为0或者为空时不设定过期时间，浏览器关闭时cookie自动消失
 */
superjs.setCookie = function(name, value, days){
    var str = name + '=' + escape(value);
    if(!isNaN(days) && days > 0) str += '; expires=' + new Date().addDate(days).toGMTString();
    document.cookie = str;
};

/**
 * 删除Cookie值 
 * name: 键
 */
superjs.delCookie = function(name){
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var value = superjs.getCookie(name);
    if(cval) document.cookie = name + '=' + escape(value) + ';expires=' + exp.toGMTString();
};

/*
 * 生产指定位数的随机数.
 * 参数为生成随机数的位数.
 */
superjs.rndNum = function(n){
	n = n || 1;
	var rnd = '';
	for(var i = 0; i < n; i++) rnd += Math.floor(Math.random() * 10);
	return rnd - 0;
};

/**
 * 数据填充方法.<br />
 * 参数1, tbadyId:显示数据的tbady的ID;<br />
 * 参数2, colArray:数据属性显示顺序拍戏,即第一列显示哪个属性,第二列显示哪个属性......;<br />
 * 参数3, dataArray:要显示的数据的数组 ;<br />
 * 参数4, totalCount:数据总数量 ;<br />
 * 参数5, startCallBack:每行的起始列的内容回调方法,如:选择列表中第一列需要显示checkbox选择框等;<br />
 * 参数6, endCallback:每行的结束列的内容回调方法,如:最后一列需要加入操作按钮,编辑\删除\等;<br />
 * 参数7, callbackArray:每一列的回调函数列表,key对应参数2数组中的值;<br />
 * 注1:所有传入的回调函数都有2个参数,参数1为该列td,参数2为该行tr;参数3为该行行号从0开始;
 * 并且在方法中可以直接使用this,this值为当前要显示的数据,即参数3数组中的某个元素.
 */
superjs.dataView = function(tbadyId, colArray, dataArray, totalCount, startCallBack, endCallback, callbackArray){
	if(!totalCount || !tbadyId || !superjs.isArray(colArray) || !superjs.isArray(dataArray)) return;
	var tbody = $$(tbadyId);
	var hasStart = typeof startCallBack == 'function';
	var hasEnd = typeof endCallback == 'function';
	var data, col, tr, td;
	for(var i = 0, len = dataArray.length; i < len; i++){
		data = dataArray[i];
		tr = document.createElement('tr');
		if(hasStart){
			td = document.createElement('td');
			startCallBack.call(data, td, tr, i);
			tr.appendChild(td);
		}
		for(var j = 0, size = colArray.length; j < size; j++){
			col = colArray[j];
			td = document.createElement('td');
			if(callbackArray && typeof callbackArray[col] == 'function') callbackArray[col].call(data, td, tr, i);
			else td.innerHTML = superjs.toString(data[col]);
			tr.appendChild(td);
		}
		if(hasEnd){
			td = document.createElement('td');
			endCallback.call(data, td, tr, i);
			tr.appendChild(td);
		}
		tbody.appendChild(tr);
	}
	dataCount = totalCount;
	functionList.setPageNumber.call();
};

/**
 * 移除显示的数据,参数为 tbady的ID.
 */
superjs.cleanData = function(tbadyId){
	//$$(tbadyId).clean();
	var ele = $$(tbadyId);
	var nodes = ele.childNodes;
	if(nodes && nodes.length) for(var i = 0, len = nodes.length; i < len; i++) ele.removeChild(nodes[0]);
};

superjs.setCss = function(ele, style){
	if(!style || typeof style != 'object') return ele;
	for(var name in style){
		ele.style[name] = style[name];
	}
	return ele;
};

/**
 * 处理IE下null和undifined变字符串问题.
 */
superjs.toString = function(str){
	if(str) return str.toString();
	return '';
};


/**
 * 获取当前弹出框的上级页面的window 
 */
superjs.getParentWindow = function(){
	var _window = window.parent || window;
	if(!_window.stackNumber) return _window;
	if(_window.stackNumber == 1) return _window.$$('iframe').contentWindow;
	return _window.$$('absoluteIframe' + (stackNumber - 1)).getElementsByTagName('iframe')[0].contentWindow;
	
};

/**
 * 弹出消息提示方法
 * @param {String} msg 消息内容
 * @param {number} num 关闭时关闭弹出页面的个数.
 */
superjs.alert = function(msg, num){
	if(window.parent && typeof window.parent.parentAlert == 'function') window.parent.parentAlert(msg, num);
	else alert(msg);
};

/**
 * 弹出是非框方法
 * @param {String} yesStr yes按钮文字内容
 * @param {String} noStr no按钮文字内容
 * @param {String} msg 提示消息内容
 * @param {String} yesCallback 点击yes按钮要执行的方法名称
 * @param {number} num 关闭时关闭弹出页面的个数.
 */
superjs.confirm = function(yesStr, noStr, msg, yesCallback, num){
	if(window.parent && typeof window.parent.parentConfirm == 'function') window.parent.parentConfirm(yesStr, noStr, msg, yesCallback, num);
	else if(confirm(msg) && typeof functionList[yesCallback] == 'function') functionList[yesCallback].call();
};



/**
 * 树节点对象 
 * @param {String} text 显示文字.
 * @param {String} click 点击事件名称.
 * @param {String} params 点击事件参数列表.
 * @param {boolean} showCheckbox 是否显示checkbox.
 * @param {String} isChecked 是否选中:yes\no\half, 为null时默认为不选中.
 * @param {String} checkboxClick checkbox点击事件名称.
 * @param {String} checkboxParams checkbox点击事件参数列表.
 */
var branch = function(text, click, params, showCheckbox, isChecked, checkboxClick, checkboxParams){
	var clickStr = click ? ' click="' + click + '"' : '';
	var paramsStr = params ? ' params="' + params + '"' : '';
	var checkboxStr = '';
	if(showCheckbox){
		var isCheckedStr = '../images/' + (isChecked ? isChecked + '.gif' : 'no.gif');
		var checkboxClickStr = checkboxClick ? ' click="checkMe,' + checkboxClick + '"' : 'click="checkMe"';
		var checkboxParamsStr = checkboxParams ? ' params="' + checkboxParams + '"' : '';
		checkboxStr = '<img type="checkbox" src="' + isCheckedStr + '" ' + checkboxClickStr + checkboxParamsStr + '/>';
	}
	this.branches = new Array();
	this.add = function(leaf){
		this.branches[this.branches.length] = leaf;
	};
	this.html = function(){
		if(this.branches.length){
			var branchString ='<div class="branch">';
			branchString += '<img src="images/open.gif" click="showBranch" />' + checkboxStr;
			branchString += '<label class="label"' + clickStr + paramsStr + '>' + text + '</label>';
			branchString += '<div class="leaf">';    
			for (var i = 0, len = this.branches.length; i < len; i++) branchString += this.branches[i].html();
			branchString += '</div></div>';
			return branchString;
		}else{
			var leafString = '<div class="leafNode">';
			leafString += '<img src="images/doc.gif" border="0" />' + checkboxStr;
			leafString += '<label class="label" ' + clickStr + paramsStr + ' >' + text + '</label>';
			leafString += '</div>';
			return leafString;
		}
	};
};

/*
 * 树节点使用方法
	var branch1 = new branch('参考书');
	var leaf1 = new branch('前言');
	var leaf2 = new branch('绪论');
	branch1.add(leaf1);
	branch1.add(leaf2);
	
	var branch2 = new branch('第一章');
	branch2.add(new branch('第一节', 'hha', 'id=9,name=p'));
	branch2.add(new branch('第二节'));
	branch2.add(new branch('第三节'));
	branch1.add(branch2);
	
	var branch3 = new branch('第二章');
	branch3.add(new branch('第一节'));
	branch3.add(new branch('第二节'));
	branch3.add(new branch('第三节'));
	branch1.add(branch3);
	
	
	document.write(branch1.html());
 */



//-->