// 模拟数据
angular.module("services",['directives'])
    .service("data",function($resource){
        var arr=[
            {
                id:"index",url:"#/",
                title:"首页",
                img:'image/index.png'
            },
            {
                id:"product",url:"#/product",
                title:"产品和服务"
            },
            {
                id:"case",url:"#/case",
                title:"成功案例"
            },
            {
                id:"about",url:"#/about",
                title:"关于我们"
            },
            {
                id:"use",url:"#/use",
                title:"操作指南"
            }

        ]
        
        var service = {
            getNav:function () {
                return arr;
            }
        }
        return service;
    });

angular.module("List",["ngRoute","ngResource","ngAnimate"])
            .service("config",function($resource){
                return $resource('modules/:List.json',{},{
                    // params---用来填充url中的变量
                    query:{method:'GET',params:{List:'config'},isArray:false}
                })
    });

