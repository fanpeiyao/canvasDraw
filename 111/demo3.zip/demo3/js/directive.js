angular.module("directives",["services"])
    //定义menu指令
    .directive("menu",function(data){
        return {
            restrict: "A",
            templateUrl: "template/menu.html",
            scope: {},//作用域完全独立
            link: function ($scope) {
                $scope.arr = data.getNav();
            },
            controller: function ($scope) {
                $scope.changePage = function (id) {
                    $scope.navid = id;
                }
            }
        }
    })