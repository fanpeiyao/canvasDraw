angular.module("myapp",["ngRoute","ngResource","ngAnimate","directives","services",'List'])
//定义一个路由表"$routeProvider"（地址栏与视图模板的映射）    
    .config(["$routeProvider",function ($routeProvider) {
        $routeProvider.when("/product",{
            templateUrl:"template/product.html" ,
            controller:'ProductCtrl'
        }).when("/case",{
            templateUrl:"template/case.html",
            controller:'CaseCtrl'
        }).when("/about",{
            templateUrl:"template/about.html",
            controller:'AboutCtrl'
        }).when("/",{
            templateUrl:"template/home.html",
            controller:'HomeCtrl'
        })
    }]).controller('IndexCtrl',['$scope','$location',function ($scope,$location) {
        if ($location.url() == "/product"){
            $scope.navid = 'product';
        }else if ($location.url() == "/case"){
            $scope.navid = 'case';
        }else if ($location.url() == "/about"){
            $scope.navid = 'about';
        }else{
            $scope.navid = 'home';
        }
    }]).controller('ProductCtrl',['$scope',function ($scope) {

    }]).controller('CaseCtrl',function ($scope) {


    }).controller('AboutCtrl',function ($scope) {


    }).controller('HomeCtrl',function ($scope) {


    })

    
    // .controller("ProductCtrl",["$scope","$routeParams","data",function ($scope,$routeParams,data) {
    //
    //
    //         $scope.title=data[$routeParams.id1].son[$routeParams.id2].title;
    //         $scope.nr1=data[$routeParams.id1].son[$routeParams.id2].nr1;
    //         $scope.nr1xia=data[$routeParams.id1].son[$routeParams.id2].nr1xia;
    //         $scope.nr2=data[$routeParams.id1].son[$routeParams.id2].nr2;
    //
    //
    // }])
  