$(function () {
    var h = window.innerHeight -127 ;
    $('.mainBox').css("height",h+'px');
    $('.mainBox').css("background",'#e6e6e6');





    /**
        左侧菜单点击事件
    */
    // 侧滑
    $('.slide_but').click(function () {
        var nn = $(this).attr('class');
        if(nn == 'slide_but slide_back'){
            $(".leftsidebar_box dt p font").hide();
            $(".leftsidebar_box dt p span").css({
                borderTop: '4px solid transparent',
                borderRight: '4px solid transparent',
                borderLeft: '4px dashed',
                borderBottom: '4px solid transparent',
                right:'8px'
            });
            $('#con_right').removeClass('col-md-10');
            $('#con_right').addClass('col-md-11');
            $('#erwei_list').removeClass('col-md-2');
            $('#erwei_list').addClass('col-md-1');
            $(".slide_but").addClass("slide_back2");
        }else{
            $(".slide_but").addClass("slide_back2");
            $(".leftsidebar_box dt p font").fadeIn();
            $(".leftsidebar_box dt p span").css({
                borderTop: '4px dashed',
                borderRight: '4px solid transparent',
                borderLeft: '4px solid transparent',
                right:'0'
            });
            $('#con_right').removeClass('col-md-11');
            $('#con_right').addClass('col-md-10');
            $('#erwei_list').removeClass('col-md-1');
            $('#erwei_list').addClass('col-md-2');
            $(".slide_but").attr("class",'slide_but slide_back');
        }
    });
    // 下拉二级菜单
    $(".leftsidebar_box dd").hide();
    $(".leftsidebar_box dt").click(function(){
        $(".leftsidebar_box dt").removeClass("dt_active").filter(this).addClass("dt_active");
        $(this).parent().find('dd').removeClass("menu_chioce");
        $(".menu_chioce").slideUp();
        $(this).parent().find('dd').slideToggle();
        $(this).parent().find('dd').addClass("menu_chioce");
        var first_span = $(this).parent().find(".first_dd").children();
         //处理逻辑
        var clickObj = first_span;
        first_span.addClass("scolor");
        var paramsId=clickObj.attr('params');
        var name = clickObj.html()
        if(checkMenu(paramsId,name))
            //已存在了
            activeMenu(paramsId,name);
        else
            //增加一个按钮
            addMenu(paramsId,name);

        renderMenu();
    });
    // 左侧菜单栏点击事件
    $(".leftsidebar_box dd span").click(function () {
        $(".leftsidebar_box dd span").removeClass("scolor").filter(this).addClass("scolor");

        //处理逻辑
        var clickObj = $(this);
        var paramsId=clickObj.attr('params');
        var name = clickObj.html()
        if(checkMenu(paramsId,name))
            //已存在了
            activeMenu(paramsId,name);
        else
            //增加一个按钮
            addMenu(paramsId,name);

        renderMenu();
    });

    /**
        导航部分功能
    */

    //导航栏缓存
    var navCache = [];
    //导航栏对象
    var NavMenu = function(type,name,flag){
        this.type = type;  //为避免id字段混淆，使用type
        this.name = name;
        this.flag = flag;
    };

    //新增一个导航按钮
    var addMenu = function(type,name){
        //其他的都不激活
        navCache.forEach(function(item){
                item.flag = 0;
        });
        //新增的激活
        var nm = new NavMenu(type,name,1);
        navCache.push(nm);
    };


    //检查是否已存在
    var checkMenu = function(type,name){
        var exist = false;
        navCache.forEach(function(item){
            if(item.type == type){
                exist = true;
            }
        });
        return exist;
    };

    //激活某个按钮
    var activeMenu = function(type,name){
        //全部不激活
        navCache.forEach(function(item){
            if(item.type == type)
                item.flag = 1;
            else
                item.flag = 0;
        })
    };

    //删除某个导航按钮
    var deleteMenu = function(type,name){
        var newNav = [];
        navCache.forEach(function(item){
            if(item.type != type){
                newNav.push(item);
            }
        });
        navCache = newNav;

        if(navCache.length>0){
            //重新遍历，如果没有激活的，就激活第一个
            var active = 0;
            for(var i =0;i<navCache.length;i++){
                if(navCache[i].flag == 1)
                    active = i;
            }
            navCache[active].flag = 1;
        }
    };

    //渲染导航
    //增量，全量
    var renderMenu = function(){
        //准备容器
        var container = $("#navMenu");
        var newul = $(' <ul></ul>');
        //遍历缓存

        /**
            如果要自动渲染数据，那么需要标记当前激活的id
        */
        //var activeId = ;

        navCache.forEach(function(item){
            //新增前导航数组
            console.dir(item)
            var newli = $('<li></li>');
            newli.attr('id',item.type);
            newli.append( '<div><p><span><a href="##">'+item.name+'</a></span><a class="closeMenu" type="'+item.type+'"><i>&#xe60f;</i><a></p></div>')
           
            if(item.flag == 1){
                newli.addClass("nav_active");
				//这里配置activeId
				//activeId = item.type;
            }
            newul.append(newli);
        });
        container.html(newul);

              //全量渲染需要重新绑定事件
        eventBind(container);

        //调用取数据的函数
        //getData(activeId)
    };

    //全部关闭
    $('.nav_close').click(function () {
        $('#navMenu').html('');
        navCache = [];
    });
    var eventBind = function(){
        //单个点击删除
        $("#navMenu .closeMenu").click(function(){
            //获取type 和name
            var ele = $(this);
            var type = ele.attr("type");
            deleteMenu(type,name);
            renderMenu();
        });
        //nav选项卡点击
        $("#navMenu li").click(function(){

            //获取type 和name
            var li = $(this);
            var type = li.attr("id");

            activeMenu(type,name);
            
            renderMenu();
        });
    };
    //左右按钮移动
    //new_w : 当前所有li的宽度；
    //box_w : 导航的宽度；
    //cub_w ；
    var box_w = $('.nav_right').width(),cub_w = 0,i=0;
    //给按钮添加
    $(".pre_nav").click(function(){
        var new_w = 0;
        $(".nav_right li").each(function () {
            new_w += $(this).outerWidth();
        });
        if (new_w>box_w) {
            cub_w = new_w - box_w ;
            $(".nav_right ul").animate({left:-cub_w});
        }
    });
    $(".next_nav").click(function(){
        i++;
        var left = -$(".nav_right ul").position().left;
        if(left>145){
            $(".nav_right ul").animate({left:-left+i*30});
        }else{
            $(".nav_right ul").animate({left:0});
        }
    });
    //阻止浏览器默认行为
    $(".pre_nav,.next_nav").mousedown(function(e){
        e.preventDefault();
    });

    /**
     右侧内容事件
     */
    //表单ul模拟select
    $('.form-control .select_in').click(function () {
        var thisInput=$(this);
        var thisUl=$(this).parent().find('ul');
        if(thisUl.css('display') == 'none'){
            if(thisUl.height()>200){
                thisUl.css({height:'200px',overflowY:'scroll'})
            }
            thisUl.fadeIn(100);
            thisUl.hover(function () {
                
            },function () {
                thisUl.fadeOut(200);
            });
            thisUl.find('li').click(function () {
                thisInput.val($(this).text());
                thisUl.fadeOut(200);
            })
        }else{
            thisUl.fadeOut(200)
        }
    });
  





    //table表单隐藏显示
   /* $(".search-icon").click(function(){
        $(".panel-body").slideToggle(500);
    });*/
    //表单清空
    var form = $('#myform');
    $('.emptyButton').click(function(){
        $('#myform input').val('')
    });
    //查询
    $('.seachButton').click(function(){
        var endinfo='';
        $('.auto input').each(function (i) {
            endinfo = endinfo +(i+1)+":"+$(this).val()+";\n";
        });
        alert(endinfo);
    });
    /* 表格高光*/
    $("#table-new tr:even ").mouseover(function(){
        $(this).css("background","#faeeed")
    });
    $("#table-new tr:even ").mouseout(function(){
        $(this).css("background","#f7f7f7")
    });
    
    
});
/**
 * 自定义变量，实际需后台获取
 */
var page = 1;
var pageSize = 30;
var lastPage = 5;
var dataCount = 150;
/**
 * 分页相关方法.
 * 翻页时会调用此方法查询数据,在该方法中可使用page\pageSize\dataCount等全局变量;
 * 方法中需要设置数据总数量,即页面全局变量dataCount的值.
 */
function  toPage(params) {
    switch(params.id){
        case 'first' :
            if(page == 1) return;
            page = 1;
            break;
        case 'last' :
            if(page == lastPage) return;
            page = lastPage;
            break;
        case 'previous' :
            if(page == 1) return;
            page--;
            break;
        case 'next' :
            if(page == lastPage) return;
            page++;
            break;
        case 'set' :
            var pageNum = $("input[name='set']").val();
            if(!/^\d+$/.test(pageNum) || pageNum == '0' || pageNum > lastPage){
                alert('跳转页码必须为小于等于最大页码的正整数！');
                return;
            }
            if(!pageNum || pageNum == page) return;
            page = pageNum;
            break;
        default:
            return;
    }
    setPageNumber();
};
/**
 * 设置页码数方法
 */
function setPageNumber(){
    dataCount = dataCount || 0;
    var div = $('#pageBox');
    if(!div) return;
    var bs = $('#pageBox b');
    bs[0].innerHTML = dataCount; //总数据量
    bs[1].innerHTML = pageSize; //一页多少条
    if(dataCount > 0) bs[2].innerHTML = (page - 1) * pageSize + 1; //当前页显示从第几条开始
    else bs[2].innerHTML = 0; //当前页显示从第几条开始
    bs[3].innerHTML = (page * pageSize) < dataCount ? (page * pageSize) : dataCount; //当前页显示到多少条结束
    bs[4].innerHTML = page; //当前页码
    bs[5].innerHTML = Math.ceil(dataCount / pageSize); //最大页码
    $('#pageBox input[name="set"]').val('');
}

