    $('#begin_time').datetimepicker({
    	format:'yyyy-mm-dd',
    	language:  'zh-CN'
    }).on("changeDate",function(ev){
    	var transferdate=transferDate($("#begin_time").val());//转时间日期
        $('#end_time').datetimepicker('remove');
    	$('#end_time').datetimepicker({
    		format:'yyyy-mm-dd',
    		language:  'zh-CN',
    		'startDate':transferdate
    	}).on("changeDate",function(ev){
            var enddate=$("#end_time").val();
            setEndTime(enddate);
        });
    });
    $('#end_time').datetimepicker({
        format:'yyyy-mm-dd',
        language:  'zh-CN',
    }).on("changeDate",function(ev){
        var enddate=$("#end_time").val();
        setEndTime(enddate);
    });
    function setEndTime(enddate){
        $('#begin_time').datetimepicker('remove');
            $('#begin_time').datetimepicker({
                format:'yyyy-mm-dd',
                language:  'zh-CN',
                'endDate':transferDate(enddate)
        });
    }
    //将时间字符串转为date
    function transferDate(data){
        var start_time=data;
        var newTime= start_time.replace(/-/g,"-");
        var transferdate = new Date(newTime);
        return transferdate;
    }
    /*$('#end_time').datetimepicker({
        format:'yyyy-mm-dd hh:ii',
        language:  'zh-CN',
        minView:2,
        autoclose: 1,
        'startDate':'2015-12-11 11:11'
    }).on("changeDate",function(ev){
        var getStart=$("#begin_time").val();
        var getEnd=$("#end_time").val();
        var getStartTime=transferTime(getStart);//开始时间戳
        var getEndTime=transferTime(getEnd);//结束时间戳
        if(checkTime(getStartTime,getEndTime)){
            alert("结束时间应该大于开始时间");
        }
        console.log(getStartTime);
        console.log(getEndTime);
    });*/
    function transferTime(str){
        var newstr=str.replace(/-/g,'-');
        var newdate=new Date(newstr);
        var time=newdate.getTime();
        return time;
    }
    //结束时间戳和开始时间戳比较
    function checkTime(start,end){
        if(end<=start){
            return true;
        }
        return false;
    }