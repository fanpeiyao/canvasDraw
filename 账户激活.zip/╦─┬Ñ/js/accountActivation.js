$(function () {
    //模拟radio
    var checkButton = $('.checkButton');
    for (var i = 0; i < checkButton.length ; i++){
        $(checkButton[i]).click(function (params) {
            if ($(this).attr('flag') == 1) {
                $(this).addClass('radio-active icon-queren1').removeClass('icon-circle2yuanquan');
                $(this).attr('flag',0);
            } else {
                $(this).removeClass('radio-active icon-queren1').addClass('icon-circle2yuanquan');
                $(this).attr('flag',1);
            }
        })
    }

})