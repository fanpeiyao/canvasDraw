$(function () {
    //模拟radio
    var checkButton = $('.checkButton'), radioes,len;
    for (var i = 0; i < checkButton.length ; i++){
        $(checkButton[i]).click(function (params) {
            radioes = $("i[name =" + $(this).attr('name') + "]");
            if ($(this).attr('flag') == 1) {
                radioes.removeClass('radio-active icon-queren1').addClass('icon-circle2yuanquan');
                radioes.attr('flag', 1);
                $(this).addClass('radio-active icon-queren1').removeClass('icon-circle2yuanquan');
                $(this).attr('flag', 0);
            } else {
                radioes.attr('flag', 0);
                radioes.addClass('radio-active icon-queren1').removeClass('icon-circle2yuanquan');
                $(this).removeClass('radio-active icon-queren1').addClass('icon-circle2yuanquan');
                $(this).attr('flag', 1);
            }

        })
    }

})